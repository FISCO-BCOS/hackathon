/*
    This file is part of web3.js.
    web3.js is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    web3.js is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.
    You should have received a copy of the GNU Lesser General Public License
    along with web3.js.  If not, see <http://www.gnu.org/licenses/>.
*/
/**
 * @file index.d.ts
 * @author MiaoXia <flysommer@outlook.com>
 * @date 2019
 */

import {provider} from 'web3-providers';
import {
    AbstractWeb3Module,
    Log,
    PromiEvent,
    RLPEncodedTransaction,
    Transaction,
    TransactionConfig,
    TransactionReceipt,
    Web3ModuleOptions,
} from 'web3-core';
import {Contract, ContractOptions} from 'web3-eth-contract';
import {Iban} from 'web3-eth-iban';
import {Accounts} from 'web3-eth-accounts';
import {AbiCoder} from 'web3-eth-abi';
import {Network} from 'web3-net';
import {Personal} from 'web3-eth-personal';
import {AbiItem} from 'web3-utils';
import {Ens} from 'web3-eth-ens';
import * as net from 'net';

export class Eth extends AbstractWeb3Module {
    constructor(
        provider: provider,
        net?: net.Socket | null,
        options?: Web3ModuleOptions
    );

    Contract: new (jsonInterface: AbiItem[] | AbiItem, address?: string, options?: ContractOptions) => Contract;
    Iban: new(iban: string) => Iban;
    personal: Personal;
    accounts: Accounts;
    ens: Ens;
    abi: AbiCoder;
    net: Network;

    clearSubscriptions(): Promise<boolean>;

    subscribe(type: 'logs', options?: LogsOptions, callback?: (error: Error, log: Log) => void): Subscription<Log>;
    subscribe(type: 'syncing', options?: null, callback?: (error: Error, result: Syncing) => void): Subscription<Syncing>;
    subscribe(type: 'newBlockHeaders', options?: null, callback?: (error: Error, blockHeader: BlockHeader) => void): Subscription<BlockHeader>;
    subscribe(type: 'pendingTransactions', options?: null, callback?: (error: Error, transactionHash: string) => void): Subscription<string>;
    subscribe(
        type: 'pendingTransactions' | 'logs' | 'syncing' | 'newBlockHeaders',
        options?: null | LogsOptions,
        callback?: (error: Error, item: Log | Syncing | BlockHeader | string) => void
    ): Subscription<Log | BlockHeader | Syncing | string>;

    getClientVersion(groupId: number, callback?: (error: Error, getClientVersion: string) => void): Promise<string>;

    getPbftView(groupId: number, callback?: (error: Error, getPbftView: string) => void): Promise<string>;

    getSealerList(groupId: number, callback?: (error: Error, getSealerList: string) => void): Promise<string>;

    getObserverList(groupId: number, callback?: (error: Error, getObserverList: string) => void): Promise<string>;

    getConsensusStatus(groupId: number, callback?: (error: Error, getConsensusStatus: string) => void): Promise<string>;

    getSyncStatus(groupId: number, callback?: (error: Error, getSyncStatus: string) => void): Promise<string>;

    getPeers(groupId: number, callback?: (error: Error, getPeers: string) => void): Promise<string>;

    getGroupPeers(groupId: number, callback?: (error: Error, getGroupPeers: string) => void): Promise<string>;

    getNodeIDList(groupId: number, callback?: (error: Error, getNodeIDList: string) => void): Promise<string>;

    getGroupList(callback?: (error: Error, getGroupList: string) => void): Promise<string>;

    getBlockByHash(groupId: number, blockHash: string, includeTransactions: boolean, callback?: (error: Error, getBlockByHash: string) => void): Promise<string>;

    // 存在bug
    // getBlockByNumber(groupId: number, blockNumber: string, includeTransactions: boolean, callback?: (error: Error, getBlockByNumber: string) => void): Promise<string>;

    getBlockHashByNumber(groupId: number, blockNumber: string, callback?: (error: Error, getBlockHashByNumber: string) => void): Promise<string>;

    getTransactionByHash(groupId: number, txHash: string, callback?: (error: Error, getTransactionByHash: string) => void): Promise<string>;

    getTransactionByBlockHashAndIndex(groupId: number, blockHash: string, txHash: string, callback?: (error: Error, getTransactionByBlockHashAndIndex: string) => void): Promise<string>;

    getTransactionByBlockNumberAndIndex(groupId: number, blockNumber: string, txHash: string, callback?: (error: Error, getTransactionByBlockNumberAndIndex: string) => void): Promise<string>;

    getPendingTransactions(groupId: number, callback?: (error: Error, getPendingTransactions: string) => void): Promise<string>;

    getPendingTxSize(groupId: number, callback?: (error: Error, getPendingTxSize: string) => void): Promise<string>;

    getTotalTransactionCount(groupId: number, callback?: (error: Error, getTotalTransactionCount: string) => void): Promise<string>;

    getSystemConfigByKey(groupId: number, key: string, callback?: (error: Error, getSystemConfigByKey: string) => void): Promise<string>;

    getBlockNumber(callback?: (error: Error, blockNumber: number) => void): Promise<number>;

    getCode(groupId: number, address: string): Promise<string>;
    getCode(groupId: number, address: string, defaultBlock: string | number): Promise<string>;
    getCode(groupId: number, address: string, callback?: (error: Error, code: string) => void): Promise<string>;
    getCode(groupId: number, address: string, defaultBlock: string | number, callback?: (error: Error, code: string) => void): Promise<string>;

    getTransactionReceipt(groupId: string, hash: string, callback?: (error: Error, transactionReceipt: TransactionReceipt) => void): Promise<TransactionReceipt>;

    getTransactionCount(address: string): Promise<number>;
    getTransactionCount(address: string, defaultBlock: number | string): Promise<number>;
    getTransactionCount(address: string, callback?: (error: Error, count: number) => void): Promise<number>;
    getTransactionCount(address: string, defaultBlock: number | string, callback?: (error: Error, count: number) => void): Promise<number>;

    sendTransaction(transactionConfig: TransactionConfig, callback?: (error: Error, hash: string) => void): PromiEvent<TransactionReceipt>;

    sendSignedTransaction(groupId: number, signedTransactionData: string, callback?: (error: Error, hash: string) => void): PromiEvent<TransactionReceipt>

    sign(dataToSign: string, address: string | number, callback?: (error: Error, signature: string) => void): Promise<string>;

    signTransaction(transactionConfig: TransactionConfig, callback?: (error: Error, signedTransaction: RLPEncodedTransaction) => void): Promise<RLPEncodedTransaction>;
    signTransaction(transactionConfig: TransactionConfig, address: string): Promise<RLPEncodedTransaction>;
    signTransaction(transactionConfig: TransactionConfig, address: string, callback: (error: Error, signedTransaction: RLPEncodedTransaction) => void): Promise<RLPEncodedTransaction>;

    call(groupId: number, transactionConfig: TransactionConfig): Promise<string>;
    call(groupId: number, transactionConfig: TransactionConfig, defaultBlock?: number | string): Promise<string>;
    call(groupId: number, transactionConfig: TransactionConfig, callback?: (error: Error, data: string) => void): Promise<string>;
    call(groupId: number, transactionConfig: TransactionConfig, defaultBlock: number | string, callback: (error: Error, data: string) => void): Promise<string>;
}

export interface Methods {
    property?: string;
    methods: Method[];
}

export interface Method {
    name: string;
    call: string;
    params?: number;
    inputFormatter?: Array<(() => void) | null>;
    outputFormatter?: () => void;
}

export interface Syncing {
    startingBlock: number;
    currentBlock: number;
    highestBlock: number;
    knownStates: number;
    pulledStates: number;
}

export interface BlockHeader {
    number: number
    hash: string
    parentHash: string
    nonce: string
    sha3Uncles: string
    logsBloom: string
    transactionRoot: string
    stateRoot: string
    receiptRoot: string
    miner: string
    extraData: string
    gasLimit: number
    gasUsed: number
    timestamp: number | string
}

export interface Block extends BlockHeader {
    transactions: Transaction[];
    size: number
    difficulty: number
    totalDifficulty: number
    uncles: string[];
}

export interface PastLogsOptions {
    fromBlock?: number | string;
    toBlock?: number | string;
    address?: string | string[];
    topics?: Array<string | string[]>;
}

export interface LogsOptions {
    fromBlock?: number | string;
    address?: string | string[];
    topics?: Array<string | string[]>
}

export interface Subscription<T> {
    id: string;
    options: {};

    subscribe(callback?: (error: Error, result: T) => void): Subscription<T>;

    unsubscribe(callback?: (error: Error, result: boolean) => void): Promise<undefined | boolean>;

    on(type: 'data', handler: (data: T) => void): void

    on(type: 'changed', handler: (data: T) => void): void

    on(type: 'error', handler: (data: Error) => void): void
}

export interface GetProof {
    jsonrpc: string;
    id: number;
    result: {
      address: string;
      accountProof: string[];
      balance: string;
      codeHash: string;
      nonce: string;
      storageHash: string;
      storageProof: StorageProof[];
    };
}

export interface StorageProof {
    key: string;
    value: string;
    proof: string[];
}
