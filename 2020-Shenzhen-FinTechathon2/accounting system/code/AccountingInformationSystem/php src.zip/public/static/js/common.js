$(function () {
    $('select[data-val][data-val!=""]').val(function () {

        var $that = $(this);
        var selected = $(this).data('val');

        var text = new Array;
        if (typeof(selected) == "string" && selected.indexOf(",")){

            var select = new Array;
            selected.split(',').forEach(function (v) {
                $that.find('option[value='+v+']').attr('selected','selected');
                select.push(v);
                text.push($that.find('option[value='+v+']').text());
            })

            selectdmultText($that,text)
            return select;
        }else{
            text.push($that.find('option[value='+selected+']').text());
            selectdmultText($that,text)
            return selected;
        }


    });

    function selectdmultText(that,text) {
        var upbit= that.next().find('.layui-anim-upbit');
        text.forEach(function (i,v) {
            upbit.find('input[title='+i+']').prop('checked',true);
            upbit.find('input[title='+i+']').next().addClass('layui-form-checked');
        })
        that.next().find('.layui-unselect').val(text.join())
    }
    $('.multi').on('click', function () {
        var ele = $(this).parent();
        var text = new Array;

        ele.find('option:selected').each(function (i,v ) {
            text.push(($(v).text()))
        })

        $(this).find('.layui-unselect').val(text.join())
    })


    //时间
    laydate.render({
        elem: '.layuiDate' //指定元素
    })
})