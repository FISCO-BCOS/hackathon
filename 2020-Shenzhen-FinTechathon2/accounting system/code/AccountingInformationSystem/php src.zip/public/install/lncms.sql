/*
 Navicat MySQL Data Transfer

 Source Server         : 腾讯高可用版
 Source Server Type    : MySQL
 Source Server Version : 50718
 Source Host           : 59507f211162e.gz.cdb.myqcloud.com:17014
 Source Schema         : LNCMS

 Target Server Type    : MySQL
 Target Server Version : 50718
 File Encoding         : 65001

 Date: 02/08/2019 12:20:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for hq_ad
-- ----------------------------
DROP TABLE IF EXISTS `hq_ad`;
CREATE TABLE `hq_ad`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` smallint(8) NULL DEFAULT NULL COMMENT '用户ID',
  `category` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' COMMENT '分类',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '描述',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '链接',
  `target` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '打开方式',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '图片',
  `sort_order` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '广告' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_admin
-- ----------------------------
DROP TABLE IF EXISTS `hq_admin`;
CREATE TABLE `hq_admin`  (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员密码',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0禁用/1启动',
  `last_login_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上次登录时间',
  `last_login_ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `login_count` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '登录次数',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `update_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '管理员' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_admin
-- ----------------------------
INSERT INTO `hq_admin` VALUES (1, 'admin', '25d55ad283aa400af464c76d713c07ad', 1, 1564718680, '120.32.62.89', 30, 1555249039, 1564719163);

-- ----------------------------
-- Table structure for hq_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `hq_admin_log`;
CREATE TABLE `hq_admin_log`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_id` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '管理员id',
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `useragent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'ip地址',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '请求链接',
  `method` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '请求类型',
  `type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '资源类型',
  `param` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '请求参数',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '日志备注',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 342 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '管理员日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_article
-- ----------------------------
DROP TABLE IF EXISTS `hq_article`;
CREATE TABLE `hq_article`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` int(8) NULL DEFAULT NULL COMMENT '用户ID',
  `cid` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '分类ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '图片',
  `author` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '作者',
  `summary` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '简介',
  `photo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '相册',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '内容',
  `view` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击量',
  `is_top` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否置顶',
  `is_hot` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否推荐',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `sort_order` int(11) NOT NULL DEFAULT 100 COMMENT '排序',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '描述',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `update_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '更新时间',
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'URL',
  `template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '文章' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `hq_auth_group`;
CREATE TABLE `hq_auth_group`  (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `rules` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限组' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_auth_group
-- ----------------------------
INSERT INTO `hq_auth_group` VALUES (1, '超级管理员', '', 1, '6,44,43,1,8,34,35,36,71,72,73,74,75,76,77,78,7,31,32,33,2,9,28,29,30,10,54,60,61,62,63,64,65,66,67,79,80,81,82,3,56,57,58,59,11,25,26,27,46,47,48,49,50,51,52,4,12,14,19,20,21,13,45,68,69,70,55,5,16,37,38,39,17,40,41,42,15,22,23,24,18,53');

-- ----------------------------
-- Table structure for hq_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `hq_auth_group_access`;
CREATE TABLE `hq_auth_group_access`  (
  `uid` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `group_id` smallint(5) UNSIGNED NOT NULL DEFAULT 0
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限授权' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_auth_group_access
-- ----------------------------
INSERT INTO `hq_auth_group_access` VALUES (1, 1);

-- ----------------------------
-- Table structure for hq_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `hq_auth_rule`;
CREATE TABLE `hq_auth_rule`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `icon` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `type` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'nav,auth',
  `index` tinyint(1) NOT NULL DEFAULT 0 COMMENT '快捷导航',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 83 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限规则' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_auth_rule
-- ----------------------------
INSERT INTO `hq_auth_rule` VALUES (1, 0, '内容', '', 'fa fa-book', 2, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (2, 0, '会员', '', 'fa fa-users', 3, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (3, 0, '扩展', '', 'fa fa-puzzle-piece', 4, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (4, 0, '设置', '', 'fa fa-gear', 5, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (5, 0, '权限', '', 'fa fa-lock', 6, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (6, 0, '控制台', 'admin/index/index', '', 1, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (7, 1, '分类管理', 'admin/category/index', 'fa fa-navicon', 2, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (8, 1, '文章管理', 'admin/article/index', 'fa fa-book', 1, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (9, 2, '会员管理', 'admin/user/index', 'fa fa-users', 0, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (10, 2, '会员日志', 'admin/user/log', 'fa fa-clock-o', 0, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (11, 3, '广告管理', 'admin/ad/index', 'fa fa-image', 1, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (12, 4, '基本设置', 'admin/config/setting', 'fa fa-cog', 1, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (13, 4, '系统设置', 'admin/config/system', 'fa fa-wrench', 3, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (14, 4, '设置管理', 'admin/config/index', 'fa fa-bars', 2, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (15, 5, '权限规则', 'admin/auth/rule', 'fa fa-th-list', 3, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (16, 5, '管理员', 'admin/admin/index', 'fa fa-user', 0, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (17, 5, '权限组', 'admin/auth/group', 'fa fa-users', 1, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (18, 5, '管理员日志', 'admin/admin/log', 'fa fa-clock-o', 5, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (19, 14, '添加', 'admin/config/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (20, 14, '编辑', 'admin/config/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (21, 14, '删除', 'admin/config/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (22, 15, '添加', 'admin/auth/addRule', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (23, 15, '编辑', 'admin/auth/editRule', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (24, 15, '删除', 'admin/auth/delRule', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (25, 11, '添加', 'admin/ad/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (26, 11, '编辑', 'admin/ad/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (27, 11, '删除', 'admin/ad/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (28, 9, '添加', 'admin/user/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (29, 9, '编辑', 'admin/user/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (30, 9, '删除', 'admin/user/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (31, 7, '添加', 'admin/category/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (32, 7, '编辑', 'admin/category/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (33, 7, '删除', 'admin/category/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (34, 8, '添加', 'admin/article/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (35, 8, '编辑', 'admin/article/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (36, 8, '删除', 'admin/article/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (37, 16, '添加', 'admin/admin/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (38, 16, '编辑', 'admin/admin/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (39, 16, '删除', 'admin/admin/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (40, 17, '添加', 'admin/auth/addGroup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (41, 17, '编辑', 'admin/auth/editGroup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (42, 17, '删除', 'admin/auth/delGroup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (43, 6, '修改密码', 'admin/index/editPassword', '', 2, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (44, 6, '清除缓存', 'admin/index/clear', '', 1, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (45, 4, '上传设置', 'admin/config/upload', 'fa fa-upload', 4, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (46, 3, '数据管理', 'admin/database/index', 'fa fa-database', 4, 'nav', 1, 1);
INSERT INTO `hq_auth_rule` VALUES (47, 46, '还原', 'admin/database/import', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (48, 46, '备份', 'admin/database/backup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (49, 46, '优化', 'admin/database/optimize', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (50, 46, '修复', 'admin/database/repair', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (51, 46, '下载', 'admin/database/download', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (52, 46, '删除', 'admin/database/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (53, 18, '一键清空', 'admin/admin/truncate', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (54, 10, '一键清空', 'admin/user/truncate', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (55, 4, '邮件设置', 'admin/config/email', 'fa fa-envelope', 5, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (56, 3, '友情链接', 'admin/flink/index', 'fa fa-address-book-o', 0, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (57, 56, '添加', 'admin/flink/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (58, 56, '编辑', 'admin/flink/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (59, 56, '删除', 'admin/flink/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (60, 2, '权限组', 'admin/user_auth/group', 'fa fa-users', 0, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (61, 60, '添加', 'admin/user_auth/addGroup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (62, 60, '编辑', 'admin/user_auth/editGroup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (63, 60, '删除', 'admin/user_auth/delGroup', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (64, 2, '权限规则', 'admin/user_auth/rule', 'fa fa-th-list', 0, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (65, 64, '添加', 'admin/user_auth/addRule', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (66, 64, '编辑', 'admin/user_auth/editRule', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (67, 64, '删除', 'admin/user_auth/delRule', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (68, 45, '上传图片', 'admin/index/uploadimage', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (69, 45, '上传文件', 'admin/index/uploadfile', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (70, 45, '上传视频', 'admin/index/uploadvideo', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (71, 1, '产品管理', 'admin/product/index', 'fa fa-cube', 1, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (72, 71, '添加', 'admin/product/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (73, 71, '编辑', 'admin/product/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (74, 71, '删除', 'admin/product/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (75, 1, '单页管理', 'admin/page/index', 'fa fa-file-word-o', 1, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (76, 75, '添加', 'admin/page/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (77, 75, '编辑', 'admin/page/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (78, 75, '删除', 'admin/page/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (79, 2, '商户管理', 'admin/user/shop', 'fa fa-institution', 0, 'nav', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (80, 79, '添加', 'admin/user/shop_add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (81, 79, '编辑', 'admin/user/shop_edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_auth_rule` VALUES (82, 79, '删除', 'admin/user/shop_del', '', 0, 'auth', 0, 1);

-- ----------------------------
-- Table structure for hq_category
-- ----------------------------
DROP TABLE IF EXISTS `hq_category`;
CREATE TABLE `hq_category`  (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `userid` int(8) NULL DEFAULT NULL COMMENT '用户ID',
  `pid` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上级分类ID',
  `category_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '标题',
  `catdir` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '目录名称',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '默认头图',
  `sort_order` int(11) NOT NULL DEFAULT 100 COMMENT '排序',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '描述',
  `url` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '栏目URL',
  `model` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '模型',
  `template` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '分类' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_category
-- ----------------------------
INSERT INTO `hq_category` VALUES (1, 1, 0, '111111', 'asdfasf', '', 100, '', '', 'http://hqss.ennn.cn/lists/1.html', 'article', 'lists');

-- ----------------------------
-- Table structure for hq_config
-- ----------------------------
DROP TABLE IF EXISTS `hq_config`;
CREATE TABLE `hq_config`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `group` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '配置分组',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '配置标题',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '配置标识',
  `type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '配置类型',
  `value` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '默认值',
  `options` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '选项值',
  `sort_order` int(11) NOT NULL DEFAULT 100 COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_config
-- ----------------------------
INSERT INTO `hq_config` VALUES (1, 'website', '网站logo', 'logo', 'image', '', '', 100, 1);
INSERT INTO `hq_config` VALUES (2, 'website', '网站名称', 'site_name', 'input', '现金表-简易记账系统', '', 100, 1);
INSERT INTO `hq_config` VALUES (3, 'website', '网站标题', 'site_title', 'input', '现金表-简易记账系统', '', 100, 1);
INSERT INTO `hq_config` VALUES (4, 'website', '网站关键字', 'site_keywords', 'input', '现金表-简易记账系统', '', 100, 1);
INSERT INTO `hq_config` VALUES (5, 'website', '网站描述', 'site_description', 'textarea', '现金表-简易记账系统', '', 100, 1);
INSERT INTO `hq_config` VALUES (6, 'website', '版权信息', 'site_copyright', 'input', '福州六诺科技', '', 100, 1);
INSERT INTO `hq_config` VALUES (7, 'website', 'ICP备案号', 'site_icp', 'input', '闽ICP备18022286号', '', 100, 1);
INSERT INTO `hq_config` VALUES (8, 'website', '统计代码', 'site_code', 'textarea', '', '', 100, 1);
INSERT INTO `hq_config` VALUES (9, 'contact', '公司名称', 'company', 'input', '福州六诺科技有限公司', '', 100, 1);
INSERT INTO `hq_config` VALUES (10, 'contact', '公司地址', 'address', 'input', '福州软件园C区13号楼101-01室', '', 100, 1);
INSERT INTO `hq_config` VALUES (11, 'contact', '联系电话', 'tel', 'input', '400-6622-003', '', 100, 1);
INSERT INTO `hq_config` VALUES (12, 'contact', '联系邮箱', 'email', 'input', 'hq@xiapu.com.cn', '', 100, 1);
INSERT INTO `hq_config` VALUES (20, 'website', '分类URL规则', 'cat_rewrite', 'radio', '2', '0:/index/index/lists?id=1\r\n1:/lists/abcd.html\r\n2:/lists/1.html', 100, 1);
INSERT INTO `hq_config` VALUES (21, 'website', '文章URL', 'art_rewrite', 'radio', '1', '0:/index/index/show?id=1\r\n1:/show/1.html', 100, 1);

-- ----------------------------
-- Table structure for hq_domain
-- ----------------------------
DROP TABLE IF EXISTS `hq_domain`;
CREATE TABLE `hq_domain`  (
  `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `userid` int(8) NOT NULL COMMENT '用户ID',
  `domain` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '域名',
  `controller` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '控制器',
  `create_time` int(10) NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_domain
-- ----------------------------
INSERT INTO `hq_domain` VALUES (1, 1, 'hqss.ennn.cn', 'web', NULL);

-- ----------------------------
-- Table structure for hq_finance
-- ----------------------------
DROP TABLE IF EXISTS `hq_finance`;
CREATE TABLE `hq_finance`  (
  `id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `sid` int(5) NULL DEFAULT NULL COMMENT '学校ID',
  `userid` int(5) NULL DEFAULT NULL COMMENT '操作人',
  `bxuser` int(5) NULL DEFAULT NULL COMMENT '报销人',
  `type` int(5) NULL DEFAULT NULL COMMENT '费用类型',
  `category` int(5) NULL DEFAULT NULL COMMENT '费用类别',
  `department` int(5) NULL DEFAULT NULL COMMENT '费用部门',
  `price` decimal(10, 2) NULL DEFAULT NULL COMMENT '金额',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '备注',
  `voucher` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '凭证号',
  `datetime` int(10) NULL DEFAULT NULL COMMENT '凭证时间',
  `create_time` int(10) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) NULL DEFAULT 0 COMMENT '更新时间',
  `delete_time` int(10) NULL DEFAULT 0 COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3291 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_flink
-- ----------------------------
DROP TABLE IF EXISTS `hq_flink`;
CREATE TABLE `hq_flink`  (
  `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` smallint(5) NOT NULL DEFAULT 0 COMMENT '商家ID',
  `linktype` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `image` char(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `addtime` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `category` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `username` varchar(30) CHARACTER SET ucs2 COLLATE ucs2_general_ci NOT NULL,
  `sort_order` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `target` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_hook
-- ----------------------------
DROP TABLE IF EXISTS `hq_hook`;
CREATE TABLE `hq_hook`  (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `sid` int(5) NULL DEFAULT NULL COMMENT '商家ID',
  `userid` int(5) NULL DEFAULT NULL COMMENT '用户ID',
  `group` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '分组',
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '名称',
  `status` int(5) NULL DEFAULT NULL COMMENT '状态',
  `create_time` int(10) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) NULL DEFAULT 0 COMMENT '更新时间',
  `delete_time` int(10) NULL DEFAULT 0 COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_page
-- ----------------------------
DROP TABLE IF EXISTS `hq_page`;
CREATE TABLE `hq_page`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '分类ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '图片',
  `author` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '作者',
  `summary` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '简介',
  `photo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '相册',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '内容',
  `view` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击量',
  `is_top` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否置顶',
  `is_hot` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否推荐',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `sort_order` int(11) NOT NULL DEFAULT 100 COMMENT '排序',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '描述',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `update_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '更新时间',
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'URL',
  `template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '单页' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_product
-- ----------------------------
DROP TABLE IF EXISTS `hq_product`;
CREATE TABLE `hq_product`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` smallint(8) NULL DEFAULT NULL COMMENT '用户ID',
  `cid` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '分类ID',
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '图片',
  `author` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '作者',
  `summary` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '简介',
  `photo` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '相册',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '内容',
  `view` int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '点击量',
  `is_top` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否置顶',
  `is_hot` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否推荐',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `sort_order` int(11) NOT NULL DEFAULT 100 COMMENT '排序',
  `keywords` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '描述',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `update_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '更新时间',
  `url` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'URL',
  `template` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '产品' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_shop
-- ----------------------------
DROP TABLE IF EXISTS `hq_shop`;
CREATE TABLE `hq_shop`  (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '机构名称',
  `simplename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '机构简称',
  `type` int(5) NULL DEFAULT NULL COMMENT '机构类型',
  `identifier` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '纳税人识别号',
  `personname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '法人姓名',
  `personid` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '法人身份证号',
  `business` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '经营范围',
  `logo` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'LOGO',
  `province` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '省份',
  `city` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '市区',
  `area` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '县市',
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '地址',
  `mobile` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '移动电话',
  `telephone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '固定电话',
  `remark` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '简介',
  `exp_time` int(10) NULL DEFAULT NULL COMMENT '过期时间',
  `create_time` int(10) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) NULL DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(10) NULL DEFAULT 0 COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '学校表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_system
-- ----------------------------
DROP TABLE IF EXISTS `hq_system`;
CREATE TABLE `hq_system`  (
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `value` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统配置' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_system
-- ----------------------------
INSERT INTO `hq_system` VALUES ('administrator', 'hqs316');
INSERT INTO `hq_system` VALUES ('colse_explain', '网站升级中');
INSERT INTO `hq_system` VALUES ('email_server', 'a:7:{s:4:\"host\";s:0:\"\";s:6:\"secure\";s:3:\"tls\";s:4:\"port\";s:0:\"\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:8:\"fromname\";s:0:\"\";s:5:\"email\";s:0:\"\";}');
INSERT INTO `hq_system` VALUES ('page_number', '15');
INSERT INTO `hq_system` VALUES ('upload_image', 'a:15:{s:8:\"is_thumb\";s:1:\"1\";s:9:\"max_width\";s:4:\"1200\";s:10:\"max_height\";s:4:\"3600\";s:8:\"is_water\";s:1:\"0\";s:12:\"water_source\";s:0:\"\";s:12:\"water_locate\";s:1:\"1\";s:11:\"water_alpha\";s:0:\"\";s:7:\"is_text\";s:1:\"0\";s:4:\"text\";s:0:\"\";s:9:\"text_font\";s:0:\"\";s:11:\"text_locate\";s:1:\"1\";s:9:\"text_size\";s:0:\"\";s:10:\"text_color\";s:0:\"\";s:11:\"text_offset\";s:0:\"\";s:10:\"text_angle\";s:0:\"\";}');
INSERT INTO `hq_system` VALUES ('website_status', '1');

-- ----------------------------
-- Table structure for hq_tongji
-- ----------------------------
DROP TABLE IF EXISTS `hq_tongji`;
CREATE TABLE `hq_tongji`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `userid` smallint(8) NULL DEFAULT NULL COMMENT '用户ID',
  `client` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '客户端',
  `referer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '来源',
  `useragent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'ip地址',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '请求链接',
  `method` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '请求类型',
  `type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '资源类型',
  `param` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '请求参数',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '日志备注',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ip`(`ip`) USING BTREE,
  INDEX `create_time`(`create_time`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1593 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '访问统计' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_user
-- ----------------------------
DROP TABLE IF EXISTS `hq_user`;
CREATE TABLE `hq_user`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(8) NULL DEFAULT 0 COMMENT '学校ID',
  `username` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `realname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '昵称',
  `mobile` char(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '手机',
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '0禁用/1启动',
  `last_login_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '上次登录时间',
  `last_login_ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `login_count` int(11) NOT NULL DEFAULT 0 COMMENT '登录次数',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `update_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '更新时间',
  `delete_time` int(10) NULL DEFAULT 0 COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_user_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_auth_group`;
CREATE TABLE `hq_user_auth_group`  (
  `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(5) NULL DEFAULT NULL,
  `name` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `description` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `rules` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_time` int(10) NULL DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) NULL DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(10) NULL DEFAULT 0 COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限组' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for hq_user_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_auth_group_access`;
CREATE TABLE `hq_user_auth_group_access`  (
  `uid` smallint(5) UNSIGNED NOT NULL DEFAULT 0,
  `group_id` smallint(5) UNSIGNED NOT NULL DEFAULT 0
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限授权' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_user_auth_group_access
-- ----------------------------
INSERT INTO `hq_user_auth_group_access` VALUES (1, 4);
INSERT INTO `hq_user_auth_group_access` VALUES (2, 1);
INSERT INTO `hq_user_auth_group_access` VALUES (5, 3);
INSERT INTO `hq_user_auth_group_access` VALUES (6, 1);
INSERT INTO `hq_user_auth_group_access` VALUES (7, 1);
INSERT INTO `hq_user_auth_group_access` VALUES (8, 1);
INSERT INTO `hq_user_auth_group_access` VALUES (9, 4);
INSERT INTO `hq_user_auth_group_access` VALUES (10, 1);
INSERT INTO `hq_user_auth_group_access` VALUES (11, 1);
INSERT INTO `hq_user_auth_group_access` VALUES (12, 6);
INSERT INTO `hq_user_auth_group_access` VALUES (13, 7);

-- ----------------------------
-- Table structure for hq_user_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_auth_rule`;
CREATE TABLE `hq_user_auth_rule`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pid` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `icon` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT 0 COMMENT '排序',
  `type` char(4) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'nav,auth',
  `index` tinyint(1) NOT NULL DEFAULT 0 COMMENT '快捷导航',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 141 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '权限规则' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of hq_user_auth_rule
-- ----------------------------
INSERT INTO `hq_user_auth_rule` VALUES (1, 0, '系统设置', 'user/config/index', 'layui-icon-set', 10, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (2, 1, '账户信息', 'user/index/info', 'fa fa-user', 10, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (3, 1, '修改密码', 'user/index/editpassword', 'fa fa-unlock-alt', 11, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (77, 0, '员工管理', 'user/staff/index', 'layui-icon-username', 5, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (78, 77, '用户列表', 'user/staff/index', '', 0, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (79, 77, '角色管理', 'user/staff/role', '', 0, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (80, 77, '操作日志', 'user/staff/log', '', 0, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (81, 78, '添加', 'user/staff/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (82, 78, '编辑', 'user/staff/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (83, 78, '删除', 'user/staff/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (84, 79, '添加', 'user/staff/role_add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (85, 79, '编辑', 'user/staff/role_edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (86, 79, '删除', 'user/staff/role_del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (87, 80, '清空', 'user/staff/truncate', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (124, 0, '财务记账', 'user/finance/index', 'layui-icon-rmb', 0, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (125, 124, '现金日记账', 'user/finance/index', '', 0, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (126, 124, '参数设置', 'user/hook/index', '', 100, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (127, 124, '现金报表', 'user/finance/report', '', 0, 'nav', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (128, 125, '添加', 'user/finance/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (129, 126, '添加', 'user/hook/add', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (130, 126, '编辑', 'user/hook/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (131, 126, '删除', 'user/hook/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (132, 125, '编辑', 'user/finance/edit', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (133, 125, '删除', 'user/finance/del', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (137, 79, '添加角色', 'user/staff/add_role', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (138, 79, '编辑角色', 'user/staff/edit_role', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (139, 79, '删除角色', 'user/staff/del_role', '', 0, 'auth', 0, 1);
INSERT INTO `hq_user_auth_rule` VALUES (140, 124, '账目数据分析', 'user/finance/analysis', '', 0, 'nav', 0, 1);

-- ----------------------------
-- Table structure for hq_user_log
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_log`;
CREATE TABLE `hq_user_log`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sid` int(5) NULL DEFAULT NULL,
  `user_id` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT '管理员id',
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `useragent` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'ip地址',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '请求链接',
  `method` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '请求类型',
  `type` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '资源类型',
  `param` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '请求参数',
  `remark` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '日志备注',
  `create_time` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '创建时间',
  `delete_time` int(10) NULL DEFAULT 0 COMMENT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '会员日志' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
