/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : lncms

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2020-10-26 09:34:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for hq_accounting_entry
-- ----------------------------
DROP TABLE IF EXISTS `hq_accounting_entry`;
CREATE TABLE `hq_accounting_entry` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `certificate_id` int(10) NOT NULL DEFAULT '0' COMMENT '凭证id',
  `actual_certificate_id` int(10) DEFAULT '0' COMMENT '实际属于的凭证id',
  `abstract` varchar(100) DEFAULT NULL COMMENT '摘要',
  `accounting_title_serial_number` int(10) NOT NULL COMMENT '会计科目编号',
  `accounting_title_name` varchar(50) NOT NULL COMMENT '会计科目',
  `type` tinyint(1) NOT NULL COMMENT '借贷类型：1表示借，2表示贷',
  `spent_accounting_entry_id` int(10) DEFAULT '0' COMMENT '作为输入时，花费的上一条会计分录',
  `original_accounting_entry_id` int(10) DEFAULT '0' COMMENT '源自最原始的那个会计分录',
  `debit_amount` int(10) DEFAULT NULL COMMENT '借方金额',
  `credit_amount` int(10) DEFAULT NULL COMMENT '贷方金额',
  `original_document_hash` varchar(500) DEFAULT NULL COMMENT '原始凭证的存储地址',
  `company_id` int(10) NOT NULL COMMENT '公司id',
  `is_unspent` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否没有被花费',
  `spent_timestamp` int(10) DEFAULT NULL COMMENT '被花费的时间',
  `spent_for_certificate_id` varchar(10) DEFAULT NULL COMMENT '作为哪个凭证的花费输入',
  `create_timestamp` int(10) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 COMMENT='会计分录';

-- ----------------------------
-- Records of hq_accounting_entry
-- ----------------------------
INSERT INTO `hq_accounting_entry` VALUES ('19', '0', '7', '找零生成', '1001', '库存现金', '1', '0', '0', '-1000', '0', null, '1', '0', '1602063874', '11', '1601905896');
INSERT INTO `hq_accounting_entry` VALUES ('20', '7', '7', null, '1001', '库存现金', '2', '0', '0', '0', '1000', null, '1', '1', null, null, '1601905896');
INSERT INTO `hq_accounting_entry` VALUES ('21', '7', '7', 'A', '1002', '银行存款', '1', '0', '0', '1000', '0', null, '1', '0', '1602062188', '8', '1601905896');
INSERT INTO `hq_accounting_entry` VALUES ('22', '8', '8', null, '1002', '银行存款', '2', '0', '0', '0', '1000', null, '1', '1', null, null, '1602062188');
INSERT INTO `hq_accounting_entry` VALUES ('23', '8', '8', 'A', '1001', '库存现金', '1', '0', '0', '1000', '0', null, '1', '0', '1602063874', '11', '1602062188');
INSERT INTO `hq_accounting_entry` VALUES ('24', '0', '9', '找零生成', '1002', '银行存款', '1', '0', '0', '-10000', '0', null, '1', '0', '1602063811', '10', '1602062322');
INSERT INTO `hq_accounting_entry` VALUES ('25', '9', '9', null, '1002', '银行存款', '2', '0', '0', '0', '10000', null, '1', '1', null, null, '1602062322');
INSERT INTO `hq_accounting_entry` VALUES ('26', '9', '9', '1233', '6701', '资产减值损失', '1', '0', '0', '10000', '0', null, '1', '1', null, null, '1602062322');
INSERT INTO `hq_accounting_entry` VALUES ('27', '0', '10', '找零生成', '1002', '银行存款', '1', '24', '24', '-10456', '0', null, '1', '0', '1602825791', '21', '1602063816');
INSERT INTO `hq_accounting_entry` VALUES ('28', '10', '10', null, '1002', '银行存款', '2', '0', '0', '0', '456', null, '1', '1', null, null, '1602063811');
INSERT INTO `hq_accounting_entry` VALUES ('29', '10', '10', 'asd', '1403', '原材料', '1', '0', '0', '456', '0', null, '1', '1', null, null, '1602063816');
INSERT INTO `hq_accounting_entry` VALUES ('30', '0', '11', '找零生成', '1001', '库存现金', '1', '23', '23', '-888', '0', null, '1', '0', '1602818425', '16', '1602063884');
INSERT INTO `hq_accounting_entry` VALUES ('31', '11', '11', null, '1001', '库存现金', '2', '0', '0', '0', '888', null, '1', '1', null, null, '1602063874');
INSERT INTO `hq_accounting_entry` VALUES ('32', '11', '11', '1234', '1406', '库存商品', '1', '0', '0', '888', '0', null, '1', '1', null, null, '1602063884');
INSERT INTO `hq_accounting_entry` VALUES ('33', '12', '12', '123', '1001', '库存现金', '1', '0', '0', '123', '123', null, '1', '0', '1602818425', '16', '1602814220');
INSERT INTO `hq_accounting_entry` VALUES ('34', '0', '16', '找零生成', '1001', '库存现金', '1', '33', '33', '-1098', '0', null, '1', '0', '1602818964', '19', '1602818426');
INSERT INTO `hq_accounting_entry` VALUES ('35', '16', '16', '21', '1001', '库存现金', '2', '0', '0', '0', '333', null, '1', '1', null, null, '1602818425');
INSERT INTO `hq_accounting_entry` VALUES ('36', '16', '16', '12', '1015', '其它货币基金', '1', '0', '0', '333', '0', null, '1', '1', null, null, '1602818426');
INSERT INTO `hq_accounting_entry` VALUES ('37', '0', '19', '找零生成', '1001', '库存现金', '1', '34', '33', '-1764', '0', null, '1', '0', '1602825758', '20', '1602818965');
INSERT INTO `hq_accounting_entry` VALUES ('38', '19', '19', '123', '1001', '库存现金', '2', '0', '0', '0', '666', null, '1', '1', null, null, '1602818964');
INSERT INTO `hq_accounting_entry` VALUES ('39', '19', '19', '321', '1031', '存出保证金', '1', '0', '0', '666', '0', null, '1', '1', null, null, '1602818965');
INSERT INTO `hq_accounting_entry` VALUES ('40', '0', '20', '找零生成', '1001', '库存现金', '1', '37', '33', '-2764', '0', null, '1', '1', null, null, '1602825759');
INSERT INTO `hq_accounting_entry` VALUES ('41', '20', '20', null, '1001', '库存现金', '2', '0', '0', '0', '1000', null, '1', '1', null, null, '1602825758');
INSERT INTO `hq_accounting_entry` VALUES ('42', '20', '20', 'A', '1002', '银行存款', '1', '0', '0', '1000', '0', null, '1', '0', '1602825791', '21', '1602825759');
INSERT INTO `hq_accounting_entry` VALUES ('43', '0', '21', '找零生成', '1002', '银行存款', '1', '42', '42', '-9656', '0', null, '1', '0', '1602825820', '22', '1602825792');
INSERT INTO `hq_accounting_entry` VALUES ('44', '21', '21', null, '1002', '银行存款', '2', '0', '0', '0', '200', null, '1', '1', null, null, '1602825791');
INSERT INTO `hq_accounting_entry` VALUES ('45', '21', '21', 'B', '1401', '材料采购', '1', '0', '0', '100', '0', null, '1', '1', null, null, '1602825792');
INSERT INTO `hq_accounting_entry` VALUES ('46', '21', '21', 'C', '1402', '在途物资', '1', '0', '0', '100', '0', null, '1', '1', null, null, '1602825792');
INSERT INTO `hq_accounting_entry` VALUES ('47', '0', '22', '找零生成', '1002', '银行存款', '1', '43', '42', '-9856', '0', null, '1', '1', null, null, '1602825820');
INSERT INTO `hq_accounting_entry` VALUES ('48', '22', '22', null, '1002', '银行存款', '2', '0', '0', '0', '200', null, '1', '1', null, null, '1602825820');
INSERT INTO `hq_accounting_entry` VALUES ('49', '22', '22', 'D', '1406', '库存商品', '1', '0', '0', '100', '0', null, '1', '1', null, null, '1602825820');
INSERT INTO `hq_accounting_entry` VALUES ('50', '22', '22', 'E', '1403', '原材料', '1', '0', '0', '100', '0', null, '1', '1', null, null, '1602825820');

-- ----------------------------
-- Table structure for hq_accounting_title
-- ----------------------------
DROP TABLE IF EXISTS `hq_accounting_title`;
CREATE TABLE `hq_accounting_title` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '顺序号',
  `serial_number` int(10) NOT NULL COMMENT '编号',
  `title` varchar(50) NOT NULL COMMENT '会计科目名称',
  `application_range` varchar(50) DEFAULT NULL COMMENT '会计科目适用范围',
  `type` int(1) NOT NULL COMMENT '类型（1资产类、2负债类、3共同类、4所有者权益类、5成本类、6损益类）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8 COMMENT='会计科目表2018';

-- ----------------------------
-- Records of hq_accounting_title
-- ----------------------------
INSERT INTO `hq_accounting_title` VALUES ('1', '1001', '库存现金', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('2', '1002', '银行存款', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('3', '1003', '存放中央银行款项', '银行专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('4', '1011', '存放同业', '银行专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('5', '1015', '其它货币基金', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('6', '1021', '结算备付金', '证券专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('7', '1031', '存出保证金', '金融共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('8', '1051', '拆出资金', '金融共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('9', '1101', '交易性金融资产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('10', '1111', '买入返售金融资产', '金融共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('11', '1121', '应收票据', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('12', '1122', '应收帐款', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('13', '1123', '预付帐款', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('14', '1131', '应收股利', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('15', '1132', '应收利息', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('16', '1211', '应收保护储金', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('17', '1221', '应收代位追偿款', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('18', '1222', '应收分保帐款', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('19', '1223', '应收分保未到期责任准备金', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('20', '1224', '应收分保保险责任准备金', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('21', '1231', '其它应收款', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('22', '1241', '坏帐准备', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('23', '1251', '贴现资产', '银行专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('24', '1301', '贷款', '银行和保险共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('25', '1302', '贷款损失准备', '银行和保险共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('26', '1311', '代理兑付证券', '银行和保险共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('27', '1321', '代理业务资产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('28', '1401', '材料采购', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('29', '1402', '在途物资', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('30', '1403', '原材料', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('31', '1404', '材料成本差异', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('32', '1406', '库存商品', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('33', '1407', '发出商品', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('34', '1410', '商品进销差价', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('35', '1411', '委托加工物资', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('36', '1412', '包装物及低值易耗品', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('37', '1421', '消耗性物物资产', '农业专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('38', '1431', '周转材料', '建造承包商专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('39', '1441', '贵金属', '银行专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('40', '1442', '抵债资产', '金融共用', '1');
INSERT INTO `hq_accounting_title` VALUES ('41', '1451', '损余物资', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('42', '1461', '存货跌价准备', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('43', '1501', '待摊费用', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('44', '1511', '独立帐户资产', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('45', '1521', '持有至到期投资', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('46', '1522', '持有至到期投资减值准备', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('47', '1523', '可供出售金融资产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('48', '1524', '长期股权投资', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('49', '1525', '长期股权投资减值准备', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('50', '1526', '投资性房地产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('51', '1531', '长期应收款', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('52', '1541', '未实现融资收益', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('53', '1551', '存出资本保证金', '保险专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('54', '1601', '固定资产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('55', '1602', '累计折旧', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('56', '1603', '固定资产减值准备', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('57', '1604', '在建工程', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('58', '1605', '工程物资', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('59', '1606', '固定资产清理', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('60', '1611', '融资租赁资产', '租赁专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('61', '1612', '未担保余值', '租赁专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('62', '1621', '生产性生物资产', '农业专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('63', '1622', '生产性生物资产累计折旧', '农业专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('64', '1623', '公益性生物资产', '农业专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('65', '1631', '油气资产', '石油天然气开采专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('66', '1632', '累计折耗', '石油天然气开采专用', '1');
INSERT INTO `hq_accounting_title` VALUES ('67', '1701', '无形资产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('68', '1702', '累计摊销', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('69', '1703', '无形资产减值准备', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('70', '1711', '商誉', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('71', '1801', '长期待摊费用', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('72', '1811', '递延所得资产', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('73', '1901', '待处理财产损益', '', '1');
INSERT INTO `hq_accounting_title` VALUES ('74', '2001', '短期借款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('75', '2002', '存入保证金', '金融共用', '2');
INSERT INTO `hq_accounting_title` VALUES ('76', '2003', '拆入资金', '金融共用', '2');
INSERT INTO `hq_accounting_title` VALUES ('77', '2004', '向中央银行借款', '银行专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('78', '2011', '同业存放', '银行专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('79', '2012', '吸收存款', '银行专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('80', '2021', '贴现负债', '银行专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('81', '2101', '交易性金融负债', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('82', '2111', '专出回购金融资产款', '金融共用', '2');
INSERT INTO `hq_accounting_title` VALUES ('83', '2201', '应付票据', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('84', '2202', '应付帐款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('85', '2205', '预收帐款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('86', '2211', '应付职工薪酬', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('87', '2221', '应交税费', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('88', '2231', '应付股利', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('89', '2232', '应付利息', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('90', '2241', '其他应付款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('91', '2251', '应付保户红利', '保险专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('92', '2261', '应付分保帐款', '保险专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('93', '2311', '代理买卖证券款', '证券专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('94', '2312', '代理承销证券款', '证券和银行共用', '2');
INSERT INTO `hq_accounting_title` VALUES ('95', '2313', '代理兑付证券款', '证券和银行共用', '2');
INSERT INTO `hq_accounting_title` VALUES ('96', '2314', '代理业务负债', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('97', '2401', '预提费用', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('98', '2411', '预计负债', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('99', '2501', '递延收益', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('100', '2601', '长期借款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('101', '2602', '长期债券', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('102', '2701', '未到期责任准备金', '保险专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('103', '2702', '保险责任准备金', '保险专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('104', '2711', '保户储金', '保险专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('105', '2721', '独立帐户负债', '保险专用', '2');
INSERT INTO `hq_accounting_title` VALUES ('106', '2801', '长期应付款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('107', '2802', '未确认融资费用', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('108', '2811', '专项应付款', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('109', '2901', '递延所得税负债', '', '2');
INSERT INTO `hq_accounting_title` VALUES ('110', '3001', '清算资金往来', '银行专用', '3');
INSERT INTO `hq_accounting_title` VALUES ('111', '3002', '外汇买卖', '金融共用', '3');
INSERT INTO `hq_accounting_title` VALUES ('112', '3101', '衍生工具', '', '3');
INSERT INTO `hq_accounting_title` VALUES ('113', '3201', '套期工具', '', '3');
INSERT INTO `hq_accounting_title` VALUES ('114', '3202', '被套期项目', '', '3');
INSERT INTO `hq_accounting_title` VALUES ('115', '4001', '实收资本', '', '4');
INSERT INTO `hq_accounting_title` VALUES ('116', '4002', '资本公积', '', '4');
INSERT INTO `hq_accounting_title` VALUES ('117', '4101', '盈余公积', '', '4');
INSERT INTO `hq_accounting_title` VALUES ('118', '4102', '一般风险准备', '金融共用', '4');
INSERT INTO `hq_accounting_title` VALUES ('119', '4103', '本年利润', '', '4');
INSERT INTO `hq_accounting_title` VALUES ('120', '4104', '利润分配', '', '4');
INSERT INTO `hq_accounting_title` VALUES ('121', '4201', '库存股', '', '4');
INSERT INTO `hq_accounting_title` VALUES ('122', '5001', '生产成本', '', '5');
INSERT INTO `hq_accounting_title` VALUES ('123', '5101', '制造费用', '', '5');
INSERT INTO `hq_accounting_title` VALUES ('124', '5201', '劳务成本', '', '5');
INSERT INTO `hq_accounting_title` VALUES ('125', '5301', '研发支出', '', '5');
INSERT INTO `hq_accounting_title` VALUES ('126', '5401', '工程施工', '建造承包商专用', '5');
INSERT INTO `hq_accounting_title` VALUES ('127', '5402', '工程结算', '建造承包商专用', '5');
INSERT INTO `hq_accounting_title` VALUES ('128', '5403', '机械作业', '建造承包商专用', '5');
INSERT INTO `hq_accounting_title` VALUES ('129', '6001', '主营业务收入', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('130', '6011', '利息收入', '金融共用', '6');
INSERT INTO `hq_accounting_title` VALUES ('131', '6021', '手续费收入', '金融共用', '6');
INSERT INTO `hq_accounting_title` VALUES ('132', '6031', '保费收入', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('133', '6032', '分保费收入', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('134', '6041', '租赁收入', '租赁专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('135', '6051', '其他业务收入', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('136', '6061', '汇兑损益', '金融专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('137', '6101', '公允价值变动损益', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('138', '6111', '投资收益', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('139', '6201', '摊回保险责任准备金', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('140', '6202', '摊回赔付支出', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('141', '6203', '摊回分保费用', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('142', '6301', '营业外收入', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('143', '6401', '主营业务成本', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('144', '6402', '其它业务成本', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('145', '6405', '营业税金及附加', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('146', '6411', '利息支出', '金融共用', '6');
INSERT INTO `hq_accounting_title` VALUES ('147', '6421', '手续费支出', '金融共用', '6');
INSERT INTO `hq_accounting_title` VALUES ('148', '6501', '提取未到期责任准备金', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('149', '6502', '撮保险责任准备金', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('150', '6511', '赔付支出', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('151', '6521', '保户红利支出', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('152', '6531', '退保金', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('153', '6541', '分出保费', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('154', '6542', '分保费用', '保险专用', '6');
INSERT INTO `hq_accounting_title` VALUES ('155', '6601', '销售费用', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('156', '6602', '管理费用', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('157', '6603', '财务费用', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('158', '6604', '勘探费用', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('159', '6701', '资产减值损失', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('160', '6711', '营业外支出', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('161', '6801', '所得税', '', '6');
INSERT INTO `hq_accounting_title` VALUES ('162', '6901', '以前年度损益调整', '', '6');

-- ----------------------------
-- Table structure for hq_ad
-- ----------------------------
DROP TABLE IF EXISTS `hq_ad`;
CREATE TABLE `hq_ad` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` smallint(8) DEFAULT NULL COMMENT '用户ID',
  `category` varchar(32) NOT NULL DEFAULT '0' COMMENT '分类',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '分类名称',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `url` varchar(255) DEFAULT '' COMMENT '链接',
  `target` varchar(10) DEFAULT '' COMMENT '打开方式',
  `image` varchar(255) DEFAULT '' COMMENT '图片',
  `sort_order` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告';

-- ----------------------------
-- Records of hq_ad
-- ----------------------------

-- ----------------------------
-- Table structure for hq_admin
-- ----------------------------
DROP TABLE IF EXISTS `hq_admin`;
CREATE TABLE `hq_admin` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员密码',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0禁用/1启动',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次登录时间',
  `last_login_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `login_count` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员';

-- ----------------------------
-- Records of hq_admin
-- ----------------------------
INSERT INTO `hq_admin` VALUES ('1', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '1', '1600243440', '0.0.0.0', '6', '1597937397', '1600243440');

-- ----------------------------
-- Table structure for hq_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `hq_admin_log`;
CREATE TABLE `hq_admin_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '管理员id',
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `useragent` varchar(255) NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `ip` varchar(16) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '请求链接',
  `method` varchar(32) NOT NULL DEFAULT '' COMMENT '请求类型',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '资源类型',
  `param` text NOT NULL COMMENT '请求参数',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='管理员日志';

-- ----------------------------
-- Records of hq_admin_log
-- ----------------------------
INSERT INTO `hq_admin_log` VALUES ('342', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/caiwu/public/admin.html', 'POST', 'xml', '{\"username\":\"admin\",\"password\":\"123456\"}', '登录了后台系统', '1597937432');
INSERT INTO `hq_admin_log` VALUES ('343', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user/shop_add.html', 'POST', 'json', '{\"name\":\"\\u4e50\\u4eab\\u5947\\u8ff9\",\"simplename\":\"\\u4e50\\u4eab\",\"type\":\"\",\"identifier\":\"\",\"personname\":\"\",\"personid\":\"\",\"mobile\":\"\",\"telephone\":\"\",\"logo\":\"\",\"province\":\"\\u798f\\u5efa\\u7701\",\"city\":\"\\u798f\\u5dde\",\"area\":\"\\u53f0\\u6c5f\\u533a\",\"address\":\"\",\"business\":\"\",\"remark\":\"\",\"exp_time\":\"2025-08-29\",\"id\":\"\"}', '添加了学校', '1597937790');
INSERT INTO `hq_admin_log` VALUES ('344', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user_auth/addgroup/shop_id/1.html', 'POST', 'json', '{\"name\":\"\\u8d22\\u52a1\\u7ec4\",\"description\":\"\",\"rules\":\"124,125,128,132,133,127,140,126,129,130,131,77,78,81,82,83,79,84,85,86,137,138,139,80,87,1,2,3\",\"shop_id\":\"1\"}', '添加了用户组', '1597937833');
INSERT INTO `hq_admin_log` VALUES ('345', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user/add/shop_id/1.html', 'POST', 'json', '{\"username\":\"shi\",\"realname\":\"\\u65bd\\u5efa\\u950b\",\"mobile\":\"18811593392\",\"password\":\"123456\",\"group_id\":\"1\",\"shop_id\":\"1\"}', '添加了用户', '1597937889');
INSERT INTO `hq_admin_log` VALUES ('346', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user/del/id/1.html', 'POST', 'json', '{\"id\":\"1\"}', '删除了用户', '1597938317');
INSERT INTO `hq_admin_log` VALUES ('347', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user_auth/addgroup/shop_id/1.html', 'POST', 'json', '{\"name\":\"\\u8d22\\u52a1\\u7ec4\",\"description\":\"\",\"rules\":\"124,125,128,132,133,127,140,126,129,130,131,77,78,81,82,83,79,84,85,86,137,138,139,80,87,1,2,3\",\"shop_id\":\"1\"}', '添加了用户组', '1597938453');
INSERT INTO `hq_admin_log` VALUES ('348', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user/add/shop_id/1.html', 'POST', 'json', '{\"username\":\"shi\",\"realname\":\"shi\",\"mobile\":\"18811593392\",\"password\":\"123456\",\"group_id\":\"2\",\"shop_id\":\"1\"}', '添加了用户', '1597938489');
INSERT INTO `hq_admin_log` VALUES ('349', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin.html', 'POST', 'json', '{\"username\":\"admin\",\"password\":\"123456\"}', '登录了后台系统', '1598497326');
INSERT INTO `hq_admin_log` VALUES ('350', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/database/optimize/table/hq_accounting_titles.html', 'POST', 'json', '{\"table\":\"hq_accounting_titles\"}', '优化了数据', '1598513562');
INSERT INTO `hq_admin_log` VALUES ('351', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/database/repair/table/hq_accounting_titles.html', 'POST', 'json', '{\"table\":\"hq_accounting_titles\"}', '修复了数据', '1598513565');
INSERT INTO `hq_admin_log` VALUES ('352', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user/shop_add.html', 'POST', 'json', '{\"name\":\"\\u5929\\u6d77\\u96c6\\u56e2\",\"simplename\":\"\\u5929\\u6d77\",\"type\":\"\",\"identifier\":\"\",\"personname\":\"\",\"personid\":\"\",\"mobile\":\"\",\"telephone\":\"\",\"logo\":\"\",\"province\":\"\\u798f\\u5efa\\u7701\",\"city\":\"\\u798f\\u5dde\",\"area\":\"\\u53f0\\u6c5f\\u533a\",\"address\":\"\",\"business\":\"\",\"remark\":\"\",\"exp_time\":\"2024-10-11\",\"id\":\"\"}', '添加了学校', '1598515885');
INSERT INTO `hq_admin_log` VALUES ('353', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/user_auth/editgroup/id/2.html', 'POST', 'json', '{\"name\":\"\\u7ba1\\u7406\\u7ec4\",\"description\":\"\",\"rules\":\"124,125,128,132,133,127,140,126,129,130,131,77,78,81,82,83,79,84,85,86,137,138,139,80,87,1,2,3\",\"id\":\"2\"}', '修改了用户组', '1598515935');
INSERT INTO `hq_admin_log` VALUES ('354', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598516251');
INSERT INTO `hq_admin_log` VALUES ('355', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin.html', 'POST', 'json', '{\"username\":\"admin\",\"password\":\"123456\"}', '登录了后台系统', '1598516257');
INSERT INTO `hq_admin_log` VALUES ('356', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598516265');
INSERT INTO `hq_admin_log` VALUES ('357', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin.html', 'POST', 'json', '{\"username\":\"admin\",\"password\":\"123456\"}', '登录了后台系统', '1598516284');
INSERT INTO `hq_admin_log` VALUES ('358', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598516378');
INSERT INTO `hq_admin_log` VALUES ('359', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin.html', 'POST', 'json', '{\"username\":\"admin\",\"password\":\"123456\"}', '登录了后台系统', '1598516383');
INSERT INTO `hq_admin_log` VALUES ('360', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/admin/index/clear.html', 'POST', 'json', '[]', '清除了系统缓存', '1598516573');
INSERT INTO `hq_admin_log` VALUES ('361', '1', 'admin', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/admin.html', 'POST', 'json', '{\"username\":\"admin\",\"password\":\"123456\"}', '登录了后台系统', '1600243440');

-- ----------------------------
-- Table structure for hq_article
-- ----------------------------
DROP TABLE IF EXISTS `hq_article`;
CREATE TABLE `hq_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(8) DEFAULT NULL COMMENT '用户ID',
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) DEFAULT '' COMMENT '图片',
  `author` varchar(255) DEFAULT '' COMMENT '作者',
  `summary` text COMMENT '简介',
  `photo` text COMMENT '相册',
  `content` longtext COMMENT '内容',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击量',
  `is_top` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `sort_order` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(200) DEFAULT NULL COMMENT 'URL',
  `template` varchar(255) DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文章';

-- ----------------------------
-- Records of hq_article
-- ----------------------------

-- ----------------------------
-- Table structure for hq_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `hq_auth_group`;
CREATE TABLE `hq_auth_group` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限组';

-- ----------------------------
-- Records of hq_auth_group
-- ----------------------------
INSERT INTO `hq_auth_group` VALUES ('1', '超级管理员', '', '1', '6,44,43,1,8,34,35,36,71,72,73,74,75,76,77,78,7,31,32,33,2,9,28,29,30,10,54,60,61,62,63,64,65,66,67,79,80,81,82,3,56,57,58,59,11,25,26,27,46,47,48,49,50,51,52,4,12,14,19,20,21,13,45,68,69,70,55,5,16,37,38,39,17,40,41,42,15,22,23,24,18,53');

-- ----------------------------
-- Table structure for hq_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `hq_auth_group_access`;
CREATE TABLE `hq_auth_group_access` (
  `uid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限授权';

-- ----------------------------
-- Records of hq_auth_group_access
-- ----------------------------
INSERT INTO `hq_auth_group_access` VALUES ('1', '1');

-- ----------------------------
-- Table structure for hq_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `hq_auth_rule`;
CREATE TABLE `hq_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(64) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `type` char(4) NOT NULL DEFAULT '' COMMENT 'nav,auth',
  `index` tinyint(1) NOT NULL DEFAULT '0' COMMENT '快捷导航',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限规则';

-- ----------------------------
-- Records of hq_auth_rule
-- ----------------------------
INSERT INTO `hq_auth_rule` VALUES ('2', '0', '企业', '', 'fa fa-users', '3', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('5', '0', '权限', '', 'fa fa-lock', '6', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('7', '1', '分类管理', 'admin/category/index', 'fa fa-navicon', '2', 'nav', '1', '1');
INSERT INTO `hq_auth_rule` VALUES ('8', '1', '文章管理', 'admin/article/index', 'fa fa-book', '1', 'nav', '1', '1');
INSERT INTO `hq_auth_rule` VALUES ('10', '2', '客户端日志', 'admin/user/log', 'fa fa-clock-o', '0', 'nav', '1', '1');
INSERT INTO `hq_auth_rule` VALUES ('11', '3', '广告管理', 'admin/ad/index', 'fa fa-image', '1', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('12', '4', '基本设置', 'admin/config/setting', 'fa fa-cog', '1', 'nav', '1', '1');
INSERT INTO `hq_auth_rule` VALUES ('13', '4', '系统设置', 'admin/config/system', 'fa fa-wrench', '3', 'nav', '1', '1');
INSERT INTO `hq_auth_rule` VALUES ('14', '4', '设置管理', 'admin/config/index', 'fa fa-bars', '2', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('15', '5', '权限规则', 'admin/auth/rule', 'fa fa-th-list', '3', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('16', '5', '管理员', 'admin/admin/index', 'fa fa-user', '0', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('17', '5', '用户权限设置', 'admin/auth/group', 'fa fa-users', '1', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('18', '5', '管理员日志', 'admin/admin/log', 'fa fa-clock-o', '5', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('19', '14', '添加', 'admin/config/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('20', '14', '编辑', 'admin/config/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('21', '14', '删除', 'admin/config/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('22', '15', '添加', 'admin/auth/addRule', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('23', '15', '编辑', 'admin/auth/editRule', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('24', '15', '删除', 'admin/auth/delRule', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('25', '11', '添加', 'admin/ad/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('26', '11', '编辑', 'admin/ad/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('27', '11', '删除', 'admin/ad/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('28', '9', '添加', 'admin/user/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('29', '9', '编辑', 'admin/user/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('30', '9', '删除', 'admin/user/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('31', '7', '添加', 'admin/category/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('32', '7', '编辑', 'admin/category/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('33', '7', '删除', 'admin/category/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('34', '8', '添加', 'admin/article/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('35', '8', '编辑', 'admin/article/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('36', '8', '删除', 'admin/article/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('37', '16', '添加', 'admin/admin/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('38', '16', '编辑', 'admin/admin/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('39', '16', '删除', 'admin/admin/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('40', '17', '添加', 'admin/auth/addGroup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('41', '17', '编辑', 'admin/auth/editGroup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('42', '17', '删除', 'admin/auth/delGroup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('43', '6', '修改密码', 'admin/index/editPassword', '', '2', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('44', '6', '清除缓存', 'admin/index/clear', '', '1', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('45', '4', '上传设置', 'admin/config/upload', 'fa fa-upload', '4', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('46', '3', '数据管理', 'admin/database/index', 'fa fa-database', '4', 'nav', '1', '1');
INSERT INTO `hq_auth_rule` VALUES ('47', '46', '还原', 'admin/database/import', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('48', '46', '备份', 'admin/database/backup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('49', '46', '优化', 'admin/database/optimize', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('50', '46', '修复', 'admin/database/repair', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('51', '46', '下载', 'admin/database/download', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('52', '46', '删除', 'admin/database/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('53', '18', '一键清空', 'admin/admin/truncate', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('54', '10', '一键清空', 'admin/user/truncate', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('55', '4', '邮件设置', 'admin/config/email', 'fa fa-envelope', '5', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('56', '3', '友情链接', 'admin/flink/index', 'fa fa-address-book-o', '0', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('57', '56', '添加', 'admin/flink/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('58', '56', '编辑', 'admin/flink/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('59', '56', '删除', 'admin/flink/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('60', '2', '用户权限设置', 'admin/user_auth/group', 'fa fa-users', '0', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('61', '60', '添加', 'admin/user_auth/addGroup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('62', '60', '编辑', 'admin/user_auth/editGroup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('63', '60', '删除', 'admin/user_auth/delGroup', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('64', '2', '权限规则', 'admin/user_auth/rule', 'fa fa-th-list', '0', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('65', '64', '添加', 'admin/user_auth/addRule', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('66', '64', '编辑', 'admin/user_auth/editRule', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('67', '64', '删除', 'admin/user_auth/delRule', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('68', '45', '上传图片', 'admin/index/uploadimage', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('69', '45', '上传文件', 'admin/index/uploadfile', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('70', '45', '上传视频', 'admin/index/uploadvideo', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('71', '1', '产品管理', 'admin/product/index', 'fa fa-cube', '1', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('72', '71', '添加', 'admin/product/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('73', '71', '编辑', 'admin/product/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('74', '71', '删除', 'admin/product/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('75', '1', '单页管理', 'admin/page/index', 'fa fa-file-word-o', '1', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('76', '75', '添加', 'admin/page/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('77', '75', '编辑', 'admin/page/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('78', '75', '删除', 'admin/page/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('79', '2', '企业管理', 'admin/user/shop', 'fa fa-institution', '0', 'nav', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('80', '79', '添加', 'admin/user/shop_add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('81', '79', '编辑', 'admin/user/shop_edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_auth_rule` VALUES ('82', '79', '删除', 'admin/user/shop_del', '', '0', 'auth', '0', '1');

-- ----------------------------
-- Table structure for hq_category
-- ----------------------------
DROP TABLE IF EXISTS `hq_category`;
CREATE TABLE `hq_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `userid` int(8) DEFAULT NULL COMMENT '用户ID',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `category_name` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `catdir` varchar(100) DEFAULT NULL COMMENT '目录名称',
  `image` varchar(255) DEFAULT NULL COMMENT '默认头图',
  `sort_order` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `url` varchar(100) DEFAULT NULL COMMENT '栏目URL',
  `model` varchar(100) DEFAULT NULL COMMENT '模型',
  `template` varchar(100) DEFAULT NULL COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类';

-- ----------------------------
-- Records of hq_category
-- ----------------------------
INSERT INTO `hq_category` VALUES ('1', '1', '0', '111111', 'asdfasf', '', '100', '', '', 'http://hqss.ennn.cn/lists/1.html', 'article', 'lists');

-- ----------------------------
-- Table structure for hq_certificate
-- ----------------------------
DROP TABLE IF EXISTS `hq_certificate`;
CREATE TABLE `hq_certificate` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `certificate_number` varchar(10) NOT NULL COMMENT '凭证字号',
  `year` int(4) NOT NULL COMMENT '年',
  `month` int(2) NOT NULL COMMENT '月期',
  `day` int(2) NOT NULL COMMENT '日',
  `total_debit_amount` int(10) DEFAULT NULL COMMENT '借方金额，单位分',
  `total_credit_amount` int(10) DEFAULT NULL COMMENT '贷方金额，单位分',
  `tabulator` varchar(30) NOT NULL COMMENT '制表人',
  `company_id` varchar(10) NOT NULL COMMENT '公司id',
  `create_timestamp` int(10) NOT NULL COMMENT '创建时间',
  `transactionHash` varchar(500) DEFAULT NULL COMMENT '交易的hash地址',
  `transactionIndex` int(10) DEFAULT '-1' COMMENT '交易索引序号',
  `blockHash` varchar(500) DEFAULT NULL COMMENT '区块的hash地址',
  `blockNumber` int(10) DEFAULT '-1' COMMENT '区块索引序号',
  `blockchain_timestamp` int(10) DEFAULT NULL COMMENT '区块链记录时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COMMENT='凭证表';

-- ----------------------------
-- Records of hq_certificate
-- ----------------------------
INSERT INTO `hq_certificate` VALUES ('7', '1', '2020', '10', '5', '1000', '1000', 'shi', '1', '1601905893', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('8', '2', '2020', '10', '7', '1000', '1000', 'shi', '1', '1602062182', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('9', '3', '2020', '10', '7', '10000', '10000', 'shi', '1', '1602062310', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('10', '4', '2020', '10', '7', '456', '456', 'shi', '1', '1602063799', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('11', '5', '2020', '10', '7', '888', '888', 'shi', '1', '1602063861', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('12', '6', '2020', '10', '16', '123', '123', 'shi', '1', '1602814215', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('13', '7', '2020', '10', '16', '4444', '4444', 'shi', '1', '1602817745', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('14', '7', '2020', '10', '16', '4444', '4444', 'shi', '1', '1602817996', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('15', '9', '2020', '10', '16', '333', '333', 'shi', '1', '1602818253', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('16', '9', '2020', '10', '16', '333', '333', 'shi', '1', '1602818423', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('17', '11', '2020', '10', '16', '123', '123', 'shi', '1', '1602818564', null, '-1', null, '-1', null);
INSERT INTO `hq_certificate` VALUES ('18', '11', '2020', '10', '16', '123', '123', 'shi', '1', '1602818851', '0xf9075944156b488222f7a47d94b7a0920dcdc4ca0b1fd3b214aee8436b3e0f66', '0', '0xadd8d5202a1ad1101ff1ddb23f5f262acc32b7198475808f7438b691f646229b', '98', '1602818853');
INSERT INTO `hq_certificate` VALUES ('19', '13', '2020', '10', '16', '666', '666', 'shi', '1', '1602818962', '0x38059f25e2ccae49425ff31d238b052673f007a6c126e38684446a82eaf3c097', '0', '0xad0bc013acf18d880515206db311220addf1e230d62e605446c47a0701b4ac81', '99', '1602818964');
INSERT INTO `hq_certificate` VALUES ('20', '14', '2020', '10', '16', '1000', '1000', 'shi', '1', '1602825756', '0xd5cd99f07c75cbf05560118c4fcd6349fa84dea7ee3f8b84e1ee7e74f26baee4', '0', '0x79849c3f44f1a5dd137e5f707842b42e4eb69161a5d626800d0aadf600d28478', '104', '1602825758');
INSERT INTO `hq_certificate` VALUES ('21', '15', '2020', '10', '16', '200', '200', 'shi', '1', '1602825789', '0xb4575659c9374c0380fc71aead5f720855a33486f0fbb78743ec204e37b2bbc8', '0', '0x01727f5eb57f05b11dfab13f5c4450d5e866689c0405118a11b6b36587af8585', '109', '1602825791');
INSERT INTO `hq_certificate` VALUES ('22', '16', '2020', '10', '16', '200', '200', 'shi', '1', '1602825817', '0x73fb61207d51eec59f3003841219e4f5029c9a2210545f77edb995558ad4b0bb', '0', '0x9e47cb9452cf9e7b776ea2788191084f8288d82312dc535fb0d0d68a285d1913', '114', '1602825820');

-- ----------------------------
-- Table structure for hq_config
-- ----------------------------
DROP TABLE IF EXISTS `hq_config`;
CREATE TABLE `hq_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(32) NOT NULL DEFAULT '' COMMENT '配置分组',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '配置标题',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '配置标识',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '配置类型',
  `value` text NOT NULL COMMENT '默认值',
  `options` text COMMENT '选项值',
  `sort_order` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='配置';

-- ----------------------------
-- Records of hq_config
-- ----------------------------
INSERT INTO `hq_config` VALUES ('1', 'website', '网站logo', 'logo', 'image', '', '', '100', '1');
INSERT INTO `hq_config` VALUES ('2', 'website', '网站名称', 'site_name', 'input', '现金表-简易记账系统', '', '100', '1');
INSERT INTO `hq_config` VALUES ('3', 'website', '网站标题', 'site_title', 'input', '现金表-简易记账系统', '', '100', '1');
INSERT INTO `hq_config` VALUES ('4', 'website', '网站关键字', 'site_keywords', 'input', '现金表-简易记账系统', '', '100', '1');
INSERT INTO `hq_config` VALUES ('5', 'website', '网站描述', 'site_description', 'textarea', '现金表-简易记账系统', '', '100', '1');
INSERT INTO `hq_config` VALUES ('6', 'website', '版权信息', 'site_copyright', 'input', '福州六诺科技', '', '100', '1');
INSERT INTO `hq_config` VALUES ('7', 'website', 'ICP备案号', 'site_icp', 'input', '闽ICP备18022286号', '', '100', '1');
INSERT INTO `hq_config` VALUES ('8', 'website', '统计代码', 'site_code', 'textarea', '', '', '100', '1');
INSERT INTO `hq_config` VALUES ('9', 'contact', '公司名称', 'company', 'input', '福州六诺科技有限公司', '', '100', '1');
INSERT INTO `hq_config` VALUES ('10', 'contact', '公司地址', 'address', 'input', '福州软件园C区13号楼101-01室', '', '100', '1');
INSERT INTO `hq_config` VALUES ('11', 'contact', '联系电话', 'tel', 'input', '400-6622-003', '', '100', '1');
INSERT INTO `hq_config` VALUES ('12', 'contact', '联系邮箱', 'email', 'input', 'hq@xiapu.com.cn', '', '100', '1');
INSERT INTO `hq_config` VALUES ('20', 'website', '分类URL规则', 'cat_rewrite', 'radio', '2', '0:/index/index/lists?id=1\r\n1:/lists/abcd.html\r\n2:/lists/1.html', '100', '1');
INSERT INTO `hq_config` VALUES ('21', 'website', '文章URL', 'art_rewrite', 'radio', '1', '0:/index/index/show?id=1\r\n1:/show/1.html', '100', '1');

-- ----------------------------
-- Table structure for hq_domain
-- ----------------------------
DROP TABLE IF EXISTS `hq_domain`;
CREATE TABLE `hq_domain` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `userid` int(8) NOT NULL COMMENT '用户ID',
  `domain` varchar(50) NOT NULL COMMENT '域名',
  `controller` varchar(50) NOT NULL COMMENT '控制器',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of hq_domain
-- ----------------------------
INSERT INTO `hq_domain` VALUES ('1', '1', 'hqss.ennn.cn', 'web', null);

-- ----------------------------
-- Table structure for hq_finance
-- ----------------------------
DROP TABLE IF EXISTS `hq_finance`;
CREATE TABLE `hq_finance` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `sid` int(5) DEFAULT NULL COMMENT '学校ID',
  `userid` int(5) DEFAULT NULL COMMENT '操作人',
  `bxuser` int(5) DEFAULT NULL COMMENT '报销人',
  `type` int(5) DEFAULT NULL COMMENT '费用类型',
  `category` int(5) DEFAULT NULL COMMENT '费用类别',
  `department` int(5) DEFAULT NULL COMMENT '费用部门',
  `price` decimal(10,2) DEFAULT NULL COMMENT '金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `voucher` varchar(100) DEFAULT NULL COMMENT '凭证号',
  `datetime` int(10) DEFAULT NULL COMMENT '凭证时间',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT '0' COMMENT '更新时间',
  `delete_time` int(10) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of hq_finance
-- ----------------------------
INSERT INTO `hq_finance` VALUES ('1', '1', '2', '2', '1', '2', '1', '100000.00', '大幅', '1231231', '1597938573', '1597938582', '1597938582', '0');

-- ----------------------------
-- Table structure for hq_flink
-- ----------------------------
DROP TABLE IF EXISTS `hq_flink`;
CREATE TABLE `hq_flink` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `userid` smallint(5) NOT NULL DEFAULT '0' COMMENT '商家ID',
  `linktype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `image` char(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `category` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(30) CHARACTER SET ucs2 NOT NULL,
  `sort_order` smallint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `target` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of hq_flink
-- ----------------------------

-- ----------------------------
-- Table structure for hq_hook
-- ----------------------------
DROP TABLE IF EXISTS `hq_hook`;
CREATE TABLE `hq_hook` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `sid` int(5) DEFAULT NULL COMMENT '商家ID',
  `userid` int(5) DEFAULT NULL COMMENT '用户ID',
  `group` varchar(100) DEFAULT NULL COMMENT '分组',
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `status` int(5) DEFAULT NULL COMMENT '状态',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT '0' COMMENT '更新时间',
  `delete_time` int(10) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of hq_hook
-- ----------------------------
INSERT INTO `hq_hook` VALUES ('1', '1', '2', '1', '技术部', '1', '1597938556', '1597938556', '0');
INSERT INTO `hq_hook` VALUES ('2', '1', '2', '2', '研发费', '1', '1597938571', '1597938571', '0');

-- ----------------------------
-- Table structure for hq_page
-- ----------------------------
DROP TABLE IF EXISTS `hq_page`;
CREATE TABLE `hq_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) DEFAULT '' COMMENT '图片',
  `author` varchar(255) DEFAULT '' COMMENT '作者',
  `summary` text COMMENT '简介',
  `photo` text COMMENT '相册',
  `content` longtext COMMENT '内容',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击量',
  `is_top` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `sort_order` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(200) DEFAULT NULL COMMENT 'URL',
  `template` varchar(255) DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='单页';

-- ----------------------------
-- Records of hq_page
-- ----------------------------

-- ----------------------------
-- Table structure for hq_product
-- ----------------------------
DROP TABLE IF EXISTS `hq_product`;
CREATE TABLE `hq_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` smallint(8) DEFAULT NULL COMMENT '用户ID',
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `image` varchar(255) DEFAULT '' COMMENT '图片',
  `author` varchar(255) DEFAULT '' COMMENT '作者',
  `summary` text COMMENT '简介',
  `photo` text COMMENT '相册',
  `content` longtext COMMENT '内容',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击量',
  `is_top` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `sort_order` int(11) NOT NULL DEFAULT '100' COMMENT '排序',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `url` varchar(200) DEFAULT NULL COMMENT 'URL',
  `template` varchar(255) DEFAULT '' COMMENT '模板',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='产品';

-- ----------------------------
-- Records of hq_product
-- ----------------------------

-- ----------------------------
-- Table structure for hq_shop
-- ----------------------------
DROP TABLE IF EXISTS `hq_shop`;
CREATE TABLE `hq_shop` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL COMMENT '机构名称',
  `simplename` varchar(255) DEFAULT NULL COMMENT '机构简称',
  `type` int(5) DEFAULT NULL COMMENT '机构类型',
  `identifier` varchar(255) DEFAULT NULL COMMENT '纳税人识别号',
  `personname` varchar(255) DEFAULT NULL COMMENT '法人姓名',
  `personid` varchar(255) DEFAULT NULL COMMENT '法人身份证号',
  `business` varchar(255) DEFAULT NULL COMMENT '经营范围',
  `logo` varchar(200) DEFAULT NULL COMMENT 'LOGO',
  `province` varchar(255) DEFAULT NULL COMMENT '省份',
  `city` varchar(255) DEFAULT NULL COMMENT '市区',
  `area` varchar(255) DEFAULT NULL COMMENT '县市',
  `address` varchar(255) DEFAULT NULL COMMENT '地址',
  `mobile` varchar(255) DEFAULT NULL COMMENT '移动电话',
  `telephone` varchar(255) DEFAULT NULL COMMENT '固定电话',
  `remark` text COMMENT '简介',
  `exp_time` int(10) DEFAULT NULL COMMENT '过期时间',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(10) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='学校表';

-- ----------------------------
-- Records of hq_shop
-- ----------------------------
INSERT INTO `hq_shop` VALUES ('1', '乐享奇迹', '乐享', '0', '', '', '', '', '', '福建省', '福州', '台江区', '', '', '', '', '1756396800', '1597937790', '1597937790', '0');
INSERT INTO `hq_shop` VALUES ('2', '天海集团', '天海', '0', '', '', '', '', '', '福建省', '福州', '台江区', '', '', '', '', '1728576000', '1598515885', '1598515885', '0');

-- ----------------------------
-- Table structure for hq_system
-- ----------------------------
DROP TABLE IF EXISTS `hq_system`;
CREATE TABLE `hq_system` (
  `name` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  PRIMARY KEY (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统配置';

-- ----------------------------
-- Records of hq_system
-- ----------------------------
INSERT INTO `hq_system` VALUES ('administrator', 'hqs316');
INSERT INTO `hq_system` VALUES ('colse_explain', '网站升级中');
INSERT INTO `hq_system` VALUES ('email_server', 'a:7:{s:4:\"host\";s:0:\"\";s:6:\"secure\";s:3:\"tls\";s:4:\"port\";s:0:\"\";s:8:\"username\";s:0:\"\";s:8:\"password\";s:0:\"\";s:8:\"fromname\";s:0:\"\";s:5:\"email\";s:0:\"\";}');
INSERT INTO `hq_system` VALUES ('page_number', '15');
INSERT INTO `hq_system` VALUES ('upload_image', 'a:15:{s:8:\"is_thumb\";s:1:\"1\";s:9:\"max_width\";s:4:\"1200\";s:10:\"max_height\";s:4:\"3600\";s:8:\"is_water\";s:1:\"0\";s:12:\"water_source\";s:0:\"\";s:12:\"water_locate\";s:1:\"1\";s:11:\"water_alpha\";s:0:\"\";s:7:\"is_text\";s:1:\"0\";s:4:\"text\";s:0:\"\";s:9:\"text_font\";s:0:\"\";s:11:\"text_locate\";s:1:\"1\";s:9:\"text_size\";s:0:\"\";s:10:\"text_color\";s:0:\"\";s:11:\"text_offset\";s:0:\"\";s:10:\"text_angle\";s:0:\"\";}');
INSERT INTO `hq_system` VALUES ('website_status', '1');

-- ----------------------------
-- Table structure for hq_tongji
-- ----------------------------
DROP TABLE IF EXISTS `hq_tongji`;
CREATE TABLE `hq_tongji` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` smallint(8) DEFAULT NULL COMMENT '用户ID',
  `client` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '客户端',
  `referer` varchar(255) DEFAULT '' COMMENT '来源',
  `useragent` varchar(255) NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `ip` varchar(16) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '请求链接',
  `method` varchar(32) NOT NULL DEFAULT '' COMMENT '请求类型',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '资源类型',
  `param` text NOT NULL COMMENT '请求参数',
  `remark` varchar(255) DEFAULT '' COMMENT '日志备注',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ip` (`ip`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='访问统计';

-- ----------------------------
-- Records of hq_tongji
-- ----------------------------

-- ----------------------------
-- Table structure for hq_user
-- ----------------------------
DROP TABLE IF EXISTS `hq_user`;
CREATE TABLE `hq_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(8) DEFAULT '0' COMMENT '学校ID',
  `username` varchar(255) DEFAULT NULL COMMENT '用户名',
  `realname` varchar(255) DEFAULT NULL COMMENT '昵称',
  `mobile` char(20) DEFAULT '' COMMENT '手机',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0禁用/1启动',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次登录时间',
  `last_login_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '上次登录IP',
  `login_count` int(11) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `delete_time` int(10) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员';

-- ----------------------------
-- Records of hq_user
-- ----------------------------
INSERT INTO `hq_user` VALUES ('2', '1', 'shi', 'shi', '18811593392', 'e10adc3949ba59abbe56e057f20f883e', '1', '1603010578', '0.0.0.0', '36', '1597938489', '1603010578', '0');
INSERT INTO `hq_user` VALUES ('3', '1', 'jian', 'jian', '18811593393', 'e10adc3949ba59abbe56e057f20f883e', '1', '1598515525', '0.0.0.0', '1', '1598514677', '1598515525', '0');

-- ----------------------------
-- Table structure for hq_user_auth_group
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_auth_group`;
CREATE TABLE `hq_user_auth_group` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(5) DEFAULT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(10) DEFAULT '0' COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限组';

-- ----------------------------
-- Records of hq_user_auth_group
-- ----------------------------
INSERT INTO `hq_user_auth_group` VALUES ('1', '1', '财务组', '', '1', '124,125,128,132,133,127,140,126,129,130,131,77,78,81,82,83,79,84,85,86,137,138,139,80,87,1,2,3', null, null, '0');
INSERT INTO `hq_user_auth_group` VALUES ('2', '1', '管理组', '', '1', '124,125,128,132,133,127,140,126,129,130,131,77,78,81,82,83,79,84,85,86,137,138,139,80,87,1,2,3', null, null, '0');

-- ----------------------------
-- Table structure for hq_user_auth_group_access
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_auth_group_access`;
CREATE TABLE `hq_user_auth_group_access` (
  `uid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限授权';

-- ----------------------------
-- Records of hq_user_auth_group_access
-- ----------------------------
INSERT INTO `hq_user_auth_group_access` VALUES ('2', '1');
INSERT INTO `hq_user_auth_group_access` VALUES ('5', '3');
INSERT INTO `hq_user_auth_group_access` VALUES ('6', '1');
INSERT INTO `hq_user_auth_group_access` VALUES ('7', '1');
INSERT INTO `hq_user_auth_group_access` VALUES ('8', '1');
INSERT INTO `hq_user_auth_group_access` VALUES ('9', '4');
INSERT INTO `hq_user_auth_group_access` VALUES ('10', '1');
INSERT INTO `hq_user_auth_group_access` VALUES ('11', '1');
INSERT INTO `hq_user_auth_group_access` VALUES ('12', '6');
INSERT INTO `hq_user_auth_group_access` VALUES ('13', '7');
INSERT INTO `hq_user_auth_group_access` VALUES ('2', '2');
INSERT INTO `hq_user_auth_group_access` VALUES ('3', '1');

-- ----------------------------
-- Table structure for hq_user_auth_rule
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_auth_rule`;
CREATE TABLE `hq_user_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(64) NOT NULL DEFAULT '',
  `sort_order` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `type` char(4) NOT NULL DEFAULT '' COMMENT 'nav,auth',
  `index` tinyint(1) NOT NULL DEFAULT '0' COMMENT '快捷导航',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='权限规则';

-- ----------------------------
-- Records of hq_user_auth_rule
-- ----------------------------
INSERT INTO `hq_user_auth_rule` VALUES ('1', '0', '系统设置', 'user/config/index', 'layui-icon-set', '102', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('2', '1', '账户信息', 'user/index/info', 'fa fa-user', '10', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('3', '1', '修改密码', 'user/index/editpassword', 'fa fa-unlock-alt', '11', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('77', '0', '员工管理', 'user/staff/index', 'layui-icon-username', '101', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('78', '77', '用户列表', 'user/staff/index', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('79', '77', '角色管理', 'user/staff/role', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('80', '77', '操作日志', 'user/staff/log', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('81', '78', '添加', 'user/staff/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('82', '78', '编辑', 'user/staff/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('83', '78', '删除', 'user/staff/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('84', '79', '添加', 'user/staff/role_add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('85', '79', '编辑', 'user/staff/role_edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('86', '79', '删除', 'user/staff/role_del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('87', '80', '清空', 'user/staff/truncate', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('124', '0', '出纳', 'user/finance/index', 'layui-icon-rmb', '99', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('125', '124', '现金日记账', 'user/finance/index', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('126', '124', '参数设置', 'user/hook/index', '', '100', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('127', '124', '现金报表', 'user/finance/report', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('128', '125', '添加', 'user/finance/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('129', '126', '添加', 'user/hook/add', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('130', '126', '编辑', 'user/hook/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('131', '126', '删除', 'user/hook/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('132', '125', '编辑', 'user/finance/edit', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('133', '125', '删除', 'user/finance/del', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('137', '79', '添加角色', 'user/staff/add_role', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('138', '79', '编辑角色', 'user/staff/edit_role', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('139', '79', '删除角色', 'user/staff/del_role', '', '0', 'auth', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('140', '124', '账目数据分析', 'user/finance/analysis', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('150', '0', '凭证', 'user/certificate/index', 'layui-icon-rmb', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('151', '150', '录凭证', 'user/certificate/record_certificate', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('152', '150', '查凭证', 'user/certificate/all_certificates', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('160', '0', '账簿', 'user/ledger/index', 'layui-icon-rmb', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('161', '160', '明细账', 'user/ledger/subsidiary_ledger', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('162', '160', '总账', 'user/ledger/general_ledger', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('170', '0', '财务报表', 'user/FinancialStatement/index', 'layui-icon-rmb', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('171', '170', '资产负债表', 'user/FinancialStatement/balance_sheet', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('172', '170', '利润表', 'user/FinancialStatement/income_statement', '', '0', 'nav', '0', '1');
INSERT INTO `hq_user_auth_rule` VALUES ('173', '170', '现金流量表', 'user/FinancialStatement/cash_flows_statement ', '', '0', 'nav', '0', '1');

-- ----------------------------
-- Table structure for hq_user_log
-- ----------------------------
DROP TABLE IF EXISTS `hq_user_log`;
CREATE TABLE `hq_user_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sid` int(5) DEFAULT NULL,
  `user_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '管理员id',
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '管理员用户名',
  `useragent` varchar(255) NOT NULL DEFAULT '' COMMENT 'User-Agent',
  `ip` varchar(16) NOT NULL DEFAULT '' COMMENT 'ip地址',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '请求链接',
  `method` varchar(32) NOT NULL DEFAULT '' COMMENT '请求类型',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '资源类型',
  `param` text NOT NULL COMMENT '请求参数',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `delete_time` int(10) DEFAULT '0' COMMENT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员日志';

-- ----------------------------
-- Records of hq_user_log
-- ----------------------------
INSERT INTO `hq_user_log` VALUES ('1', '1', '1', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\",\"remember_user\":\"on\"}', '登录了后台系统', '1597937974', '0');
INSERT INTO `hq_user_log` VALUES ('2', '1', '1', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1597938294', '0');
INSERT INTO `hq_user_log` VALUES ('3', '1', '1', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\",\"remember_user\":\"on\"}', '登录了后台系统', '1597938298', '0');
INSERT INTO `hq_user_log` VALUES ('4', '1', '1', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1597938509', '0');
INSERT INTO `hq_user_log` VALUES ('5', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\",\"remember_user\":\"on\"}', '登录了后台系统', '1597938512', '0');
INSERT INTO `hq_user_log` VALUES ('6', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/hook/add/group/1.html', 'POST', 'json', '{\"group\":\"1\",\"name\":\"\\u6280\\u672f\\u90e8\"}', '添加了钩子', '1597938556', '0');
INSERT INTO `hq_user_log` VALUES ('7', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/hook/add/group/2.html', 'POST', 'json', '{\"group\":\"2\",\"name\":\"\\u7814\\u53d1\\u8d39\"}', '添加了钩子', '1597938571', '0');
INSERT INTO `hq_user_log` VALUES ('8', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36', '0.0.0.0', 'http://localhost/user/finance/add.html', 'POST', 'json', '{\"datetime\":\"2020-08-20 23:49:33\",\"bxuser\":\"2\",\"department\":\"1\",\"category\":\"2\",\"voucher\":\"1231231\",\"type\":\"1\",\"price\":\"100000\",\"remark\":\"\\u5927\\u5e45\"}', '添加了费用', '1597938582', '0');
INSERT INTO `hq_user_log` VALUES ('9', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598514088', '0');
INSERT INTO `hq_user_log` VALUES ('10', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/staff/add.html', 'POST', 'json', '{\"username\":\"jian\",\"realname\":\"jian\",\"mobile\":\"18811593393\",\"password\":\"123456\",\"group_id\":\"1\"}', '添加了用户', '1598514677', '0');
INSERT INTO `hq_user_log` VALUES ('11', '1', '3', 'jian', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.15', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"jian\",\"password\":\"123456\"}', '登录了后台系统', '1598515525', '0');
INSERT INTO `hq_user_log` VALUES ('12', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598622929', '0');
INSERT INTO `hq_user_log` VALUES ('13', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598622998', '0');
INSERT INTO `hq_user_log` VALUES ('14', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598623028', '0');
INSERT INTO `hq_user_log` VALUES ('15', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598623049', '0');
INSERT INTO `hq_user_log` VALUES ('16', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598623055', '0');
INSERT INTO `hq_user_log` VALUES ('17', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598624856', '0');
INSERT INTO `hq_user_log` VALUES ('18', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598624878', '0');
INSERT INTO `hq_user_log` VALUES ('19', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598625462', '0');
INSERT INTO `hq_user_log` VALUES ('20', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598625480', '0');
INSERT INTO `hq_user_log` VALUES ('21', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598625518', '0');
INSERT INTO `hq_user_log` VALUES ('22', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598625526', '0');
INSERT INTO `hq_user_log` VALUES ('23', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1598627607', '0');
INSERT INTO `hq_user_log` VALUES ('24', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598627614', '0');
INSERT INTO `hq_user_log` VALUES ('25', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1598674519', '0');
INSERT INTO `hq_user_log` VALUES ('26', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1599034795', '0');
INSERT INTO `hq_user_log` VALUES ('27', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1599215483', '0');
INSERT INTO `hq_user_log` VALUES ('28', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1599293839', '0');
INSERT INTO `hq_user_log` VALUES ('29', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1599386231', '0');
INSERT INTO `hq_user_log` VALUES ('30', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1599915366', '0');
INSERT INTO `hq_user_log` VALUES ('31', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1599916054', '0');
INSERT INTO `hq_user_log` VALUES ('32', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1599916137', '0');
INSERT INTO `hq_user_log` VALUES ('33', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1600244133', '0');
INSERT INTO `hq_user_log` VALUES ('34', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1600392413', '0');
INSERT INTO `hq_user_log` VALUES ('35', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1600417955', '0');
INSERT INTO `hq_user_log` VALUES ('36', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1600443124', '0');
INSERT INTO `hq_user_log` VALUES ('37', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1600603392', '0');
INSERT INTO `hq_user_log` VALUES ('38', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601026497', '0');
INSERT INTO `hq_user_log` VALUES ('39', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601776158', '0');
INSERT INTO `hq_user_log` VALUES ('40', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1601802444', '0');
INSERT INTO `hq_user_log` VALUES ('41', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601893196', '0');
INSERT INTO `hq_user_log` VALUES ('42', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1601897584', '0');
INSERT INTO `hq_user_log` VALUES ('43', '1', '2', 'shi', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601897966', '0');
INSERT INTO `hq_user_log` VALUES ('44', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601903128', '0');
INSERT INTO `hq_user_log` VALUES ('45', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1601903587', '0');
INSERT INTO `hq_user_log` VALUES ('46', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601904265', '0');
INSERT INTO `hq_user_log` VALUES ('47', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1601904378', '0');
INSERT INTO `hq_user_log` VALUES ('48', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601904425', '0');
INSERT INTO `hq_user_log` VALUES ('49', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1601904495', '0');
INSERT INTO `hq_user_log` VALUES ('50', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1601904632', '0');
INSERT INTO `hq_user_log` VALUES ('51', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1602062105', '0');
INSERT INTO `hq_user_log` VALUES ('52', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1602594062', '0');
INSERT INTO `hq_user_log` VALUES ('53', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1602814015', '0');
INSERT INTO `hq_user_log` VALUES ('54', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1603006668', '0');
INSERT INTO `hq_user_log` VALUES ('55', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1603008281', '0');
INSERT INTO `hq_user_log` VALUES ('56', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1603008351', '0');
INSERT INTO `hq_user_log` VALUES ('57', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/logout.html', 'GET', 'xml', '[]', '退出了后台系统', '1603008406', '0');
INSERT INTO `hq_user_log` VALUES ('58', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1603008423', '0');
INSERT INTO `hq_user_log` VALUES ('59', '1', '2', 'shi', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36', '0.0.0.0', 'http://localhost/user/index/login.html', 'POST', 'json', '{\"return_url\":\"0\",\"username\":\"shi\",\"password\":\"123456\"}', '登录了后台系统', '1603010578', '0');
