<?php

namespace app\admin\validate;

use think\Validate;

class Flink extends Validate
{
    protected $rule = [
        'category' => 'require',
        'name'     => 'require',
        'url'     => 'require|url',
    ];

    protected $message = [
        'category.require' => '请选择所属分类',
        'name.require'     => '名称不能为空',
        'url.require'     => '链接不能为空',
    ];
}
