<?php

namespace app\admin\validate;

use think\Validate;

class System extends Validate
{

}
