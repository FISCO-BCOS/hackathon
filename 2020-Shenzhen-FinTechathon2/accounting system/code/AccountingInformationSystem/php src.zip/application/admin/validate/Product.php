<?php

namespace app\admin\validate;

use think\Validate;

class Product extends Validate
{
    protected $rule = [
        'cid'   => 'require',
        'title' => 'require',
    ];

    protected $message = [
        'cid.require'   => '请选择所属分类',
        'title.require' => '标题不能为空',
    ];
}
