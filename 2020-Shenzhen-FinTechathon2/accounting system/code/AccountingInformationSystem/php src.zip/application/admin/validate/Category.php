<?php

namespace app\admin\validate;

use think\Validate;

class Category extends Validate
{
    protected $rule = [
        'category_name' => 'require',
        'model' => 'require',
        'template' => 'require',
        'catdir' => 'require|min:3|max:20|unique:category|^[a-zA-Z][a-zA-Z0-9_]*$',
    ];

    protected $message = [
        'category_name.require' => '分类名称不能为空',
        'model.require' => '模型不能为空',
        'template.require' => '分类模板不能为空',
        'catdir.require' => '分类目录只能字母',
    ];
}
