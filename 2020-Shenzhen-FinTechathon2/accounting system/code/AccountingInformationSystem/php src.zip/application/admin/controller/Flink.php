<?php
namespace app\admin\controller;
use app\common\controller\AdminBase;
class Flink extends AdminBase
{
    protected function _initialize()
    {
        parent::_initialize();
        if ($this->request->isGet()) {
            $category = [
                '53' => '摄影协会',
                '54' => '知名摄网',
                '55' => '合作伙伴',
                '56' => '友情链接',
            ];
            $this->assign('category', $category);
        }
    }

    public function index()
    {
        $param = $this->request->param();
        $where = [];
        if (isset($param['name'])) {
            $where['name'] = ['like', "%" . $param['title'] . "%"];
        }
        if (isset($param['category'])) {
            $where['category'] = $param['category'];
        }
        $list = model('flink')->order('id desc')->where($where)
            ->paginate(config('page_number'), false, ['query' => $param]);
        return $this->fetch('index', ['list' => $list]);
    }

    public function add()
    {
        if ($this->request->isPost()) {
            if ($this->insert('flink', $this->request->param()) === true) {
                insert_admin_log('添加了广告图');
                $this->success('添加成功', url('admin/flink/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save');
    }

    public function edit()
    {
        if ($this->request->isPost()) {
            if ($this->update('flink', $this->request->param(), input('_verify', true)) === true) {
                insert_admin_log('修改了广告图');
                $this->success('修改成功', url('admin/flink/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', ['data' => model('flink')->where('id', input('id'))->find()]);
    }

    public function del()
    {
        if ($this->request->isPost()) {
            if ($this->delete('flink', $this->request->param()) === true) {
                insert_admin_log('删除了广告图');
                $this->success('删除成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
    }
}
