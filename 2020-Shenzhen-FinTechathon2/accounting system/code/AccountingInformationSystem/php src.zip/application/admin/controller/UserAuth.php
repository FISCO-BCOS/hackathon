<?php
namespace app\admin\controller;
use app\common\controller\AdminBase;
class UserAuth extends AdminBase
{
    protected function _initialize()
    {
        parent::_initialize();
    }

    public function auto()
    {
        $insertId = db('userAuthRule')->insertGetId([
            'pid' => 3,
            'name' => '数据管理',
            'url' => 'admin/column/index',
            'icon' => 'fa fa-th-list',
            'type' => 'nav',
        ]);
        db('userAuthRule')->insertAll([
            [
                'pid' => $insertId,
                'name' => '还原',
                'url' => 'admin/database/import',
                'type' => 'nav',
            ],
            [
                'pid' => $insertId,
                'name' => '备份',
                'url' => 'admin/database/backup',
                'type' => 'auth',
            ],
            [
                'pid' => $insertId,
                'name' => '优化',
                'url' => 'admin/database/optimize',
                'type' => 'auth',
            ],
            [
                'pid' => $insertId,
                'name' => '修复',
                'url' => 'admin/database/repair',
                'type' => 'auth',
            ],
            [
                'pid' => $insertId,
                'name' => '下载',
                'url' => 'admin/database/download',
                'type' => 'auth',
            ],
            [
                'pid' => $insertId,
                'name' => '删除',
                'url' => 'admin/database/del',
                'type' => 'auth',
            ],
        ]);
    }

    public function group()
    {
        return $this->fetch('group', ['list' => model('userAuthGroup')->paginate(config('page_number'))]);
    }

    public function addGroup()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['sid'] = input('shop_id');
            if ($this->insert('userAuthGroup', $param) === true) {
                insert_admin_log('添加了用户组');
                $this->success('添加成功', url('admin/user/shop'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        $userAuthRule = collection(model('userAuthRule')->where(['status' => 1])->order('sort_order asc')->select())->toArray();
        foreach ($userAuthRule as $k => $v) {
            // $userAuthRule[$k]['open'] = true;
        }
        return $this->fetch('saveGroup', ['userAuthRule' => json_encode(list_to_tree($userAuthRule))]);
    }

    public function editGroup()
    {
        if ($this->request->isPost()) {
            if ($this->update('userAuthGroup', $this->request->param(), input('_verify', true)) === true) {
                insert_admin_log('修改了用户组');
                $this->success('修改成功', url('admin/user/shop'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        $data     = model('userAuthGroup')->where('id', input('id'))->find();
        $userAuthRule = collection(model('userAuthRule')->where(['status' => 1])->order('sort_order asc')->select())->toArray();
        foreach ($userAuthRule as $k => $v) {
            // $userAuthRule[$k]['open'] = true;
            $userAuthRule[$k]['checked'] = in_array($v['id'], explode(',', $data['rules']));
        }
        return $this->fetch('saveGroup', ['data' => $data, 'userAuthRule' => json_encode(list_to_tree($userAuthRule))]);
    }

    public function delGroup()
    {
        if ($this->request->isPost()) {
            if ($this->delete('userAuthGroup', $this->request->param()) === true) {
                insert_admin_log('删除了用户组');
                $this->success('删除成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
    }

    public function rule()
    {
        $userAuthRule = collection(model('userAuthRule')->where(['status' => 1])->order('sort_order asc')->select())->toArray();
        foreach ($userAuthRule as $k => $v) {
            // $userAuthRule[$k]['open'] = true;
        }
        return $this->fetch('rule', ['userAuthRule' => json_encode(list_to_tree($userAuthRule))]);
    }

    public function addRule()
    {
        if ($this->request->isPost()) {
            if ($this->insert('userAuthRule', $this->request->param()) === true) {
                insert_admin_log('添加了权限规则');
                $this->success('添加成功', url('admin/user_auth/rule'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('saveRule');
    }

    public function editRule()
    {
        if ($this->request->isPost()) {
            if ($this->update('userAuthRule', $this->request->param()) === true) {
                insert_admin_log('修改了权限规则');
                $this->success('修改成功', url('admin/user_auth/rule'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('saveRule', ['data' => model('userAuthRule')->where('id', input('id'))->find()]);
    }

    public function delRule()
    {
        if ($this->request->isPost()) {
            model('userAuthRule')->where('pid', input('id'))->count() && $this->error('请先删除子节点');
            if ($this->delete('userAuthRule', $this->request->param()) === true) {
                insert_admin_log('删除了权限规则');
                $this->success('删除成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
    }
}
