<?php

namespace app\admin\controller;
use app\common\controller\AdminBase;
use app\common\model\Tongji;
vendor('Qiniu.autoload');
use Qiniu\Auth as Auth;
use Qiniu\Storage\BucketManager;
use Qiniu\Storage\UploadManager;
use think\Db;
use think\Request;
class Index extends AdminBase
{
    protected $noLogin = ['login', 'captcha'];
    protected $noAuth = ['index', 'uploadImage', 'uploadFile', 'uploadVideo', 'icon', 'logout'];

    protected function _initialize()
    {
        parent::_initialize();
        !config('website_status') && die(config('colse_explain'));
        $config = cache('db_config_data');
        if (!$config) {
            $config = [];
            foreach (model('config')->select() as $v) {
                $config[$v['group']][$v['name']] = $v['value'];
            }
            cache('db_config_data', $config);
        }
        config($config);
    }

    public function index()
    {
        // 快捷导航
        $where = ['index' => 1, 'status' => 1];
        if (session('admin_auth.username') != config('administrator')) {
            $access      = model('authGroupAccess')->with('authGroup')
                ->where('uid', session('admin_auth.admin_id'))->find();
            $where['id'] = ['in', $access['rules']];
        }
        $index = model('authRule')->where($where)->order('pid asc,sort_order asc')->select();
        //统计信息
        //今日时间戳
        $beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
        $endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $data['today_pcip'] = Tongji::where("client = '0' and create_time >=".$beginToday." and create_time <=".$endToday."")->group('ip')->count();
        $data['today_mip'] = Tongji::where("client = '1' and create_time >=".$beginToday." and create_time <=".$endToday."")->group('ip')->count();
        $data['today_pcpv'] = Tongji::where("client = '0' and create_time >=".$beginToday." and create_time <=".$endToday."")->count();
        $data['today_mpv'] = Tongji::where("client = '1' and create_time >=".$beginToday." and create_time <=".$endToday."")->count();
        //本月
        $beginThismonth=mktime(0,0,0,date('m'),1,date('Y'));
        $endThismonth=mktime(23,59,59,date('m'),date('t'),date('Y'));
        $data['month_pcip'] = Tongji::where("client = '0' and create_time >=".$beginThismonth." and create_time <=".$endThismonth."")->group('ip')->count();
        $data['month_mip'] = Tongji::where("client = '1' and create_time >=".$beginThismonth." and create_time <=".$endThismonth."")->group('ip')->count();
        $data['month_pcpv'] = Tongji::where("client = '0' and create_time >=".$beginThismonth." and create_time <=".$endThismonth."")->count();
        $data['month_mpv'] = Tongji::where("client = '1' and create_time >=".$beginThismonth." and create_time <=".$endThismonth."")->count();
        //本年
        $begin_year = strtotime(date("Y",time())."-1"."-1");
        $end_year = strtotime(date("Y",time())."-12"."-31");
        $data['year_pcip'] = Tongji::where("client = '0' and create_time >=".$begin_year." and create_time <=".$end_year."")->group('ip')->count();
        $data['year_mip'] = Tongji::where("client = '1' and create_time >=".$begin_year." and create_time <=".$end_year."")->group('ip')->count();
        $data['year_pcpv'] = Tongji::where("client = '0' and create_time >=".$begin_year." and create_time <=".$end_year."")->count();
        $data['year_mpv'] = Tongji::where("client = '1' and create_time >=".$begin_year." and create_time <=".$end_year."")->count();
        
        //本月访问
        $start_time = mktime(0,0,0,date('m',strtotime('-30 days')),date('d',strtotime('-30 days')),date('Y',strtotime('-30 days')));
        $end_time = mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $now_j = (($end_time-$start_time)/86400);
        $array = array();
        $value = array();
        $num = '0';
        for($i=0;$i<$now_j;$i++){
            $array[] = $dtrq = date('d',$start_time+$i*86400); //每隔一天赋值给数组
            $day_begin = $start_time+$i*86400;
            $day_end = ($start_time+$i*86400)+86399;
            $ip[] = $nums = model('tongji')->where("create_time >='".$day_begin."' and create_time <= '".$day_end."'")->group('ip')->count();
            $pv[] = $nums = model('tongji')->where("create_time >='".$day_begin."' and create_time <= '".$day_end."'")->count();
            $num = $num + $nums;
        }
        
        // 服务器信息
        $server = [
            'os'                  => PHP_OS, // 服务器操作系统
            'sapi'                => PHP_SAPI, // 服务器软件
            'version'             => PHP_VERSION, // PHP版本
            'mysql'               => db()->query('select VERSION() as version'), // mysql 版本
            'root'                => $_SERVER['DOCUMENT_ROOT'], // 当前运行脚本所在的文档根目录
            'max_execution_time'  => ini_get('max_execution_time') . 's', // 最大执行时间
            'upload_max_filesize' => ini_get('upload_max_filesize'), // 文件上传限制
            'memory_limit'        => ini_get('memory_limit'), // 允许内存大小
            'date'                => date('Y-m-d H:i:s', time()), // 服务器时间
        ];
        return $this->fetch('index', ['index' => $index, 'server' => $server, 'data' => $data,'array' => $array,'ip' => $ip,'pv' => $pv,'num'=>$num]);
    }

    public function login()
    {
        is_admin_login() && $this->redirect('admin/index/index'); // 登录直接跳转
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $result = $this->validate($param, 'login');
            if ($result !== true) {
                $this->error($result);
            }
            $admin = model('admin')->where([
                'username' => $param['username'],
                'password' => md5($param['password'])
            ])->find();
            if ($admin) {
                $admin['status'] != 1 && $this->error('账号已禁用');
                // 保存状态
                $auth = [
                    'admin_id' => $admin['id'],
                    'username' => $admin['username'],
                ];
                session('admin_auth', $auth);
                session('admin_auth_sign', data_auth_sign($auth));
                // 更新信息
                model('admin')->save([
                    'last_login_time' => time(),
                    'last_login_ip'   => $this->request->ip(),
                    'login_count'     => $admin['login_count'] + 1,
                ], ['id' => $admin['id']]);
                insert_admin_log('登录了后台系统');
                $this->success('登录成功', url('admin/user/shop'));
            } else {
                $this->error('账号或密码错误');
            }
        }
        return $this->fetch('login');
    }

    public function captcha()
    {
        $config = [
            // 验证码字符集合
            'codeSet'  => '1234567890',
            // 验证码字体大小(px)
            'fontSize' => 16,
            // 是否画混淆曲线
            'useCurve' => false,
            // 验证码图片高度
            'imageH'   => 42,
            // 验证码图片宽度
            'imageW'   => 135,
            // 验证码位数
            'length'   => 4,
            // 验证成功后是否重置
            'reset'    => true,
        ];
        return captcha('', $config);
    }

    public function uploadImage()
    {
        try {
            $file = $this->request->file('file');
            $qiniuConfig = include(__DIR__ ."/../../setting.php");
            //判断上传位置
            if($qiniuConfig['qiniu']['type']=='1'){//七牛
                //$file = $this->request->file('file');
                // 要上传图片的本地路径
                $filePath = $file->getRealPath();
                $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);  //后缀
                //$size = $this->sizecount(filesize($filePath));
                // 上传到七牛后保存的文件名
                $key = date('Y').'/'.date('md').'/'.date('YmdHis').rand(0,9999).substr(md5($file->getRealPath()),0,5). '.' . $ext;
                include APP_PATH . '/../vendor/qiniu/autoload.php';
                // 需要填写你的 Access Key 和 Secret Key
                $accessKey = $qiniuConfig['qiniu']['upak'];
                $secretKey = $qiniuConfig['qiniu']['upsk'];
                // 构建鉴权对象
                $auth = new Auth($accessKey, $secretKey);
                // 要上传的空间
                $bucket = $qiniuConfig['qiniu']['upbucket'];
                $domain = $qiniuConfig['qiniu']['updomain'];
                $token = $auth->uploadToken($bucket);
                // 初始化 UploadManager 对象并进行文件的上传
                $uploadMgr = new UploadManager();
                // 调用 UploadManager 的 putFile 方法进行文件的上传
                list($ret, $err) = $uploadMgr->putFile($token, $key, $filePath);
                if ($err !== null) {
                    return ["err"=>1,"msg"=>$err,"data"=>""];
                } else {
                    //返回图片的完整URL
                    return ['code' => 1, 'url' => $domain.$ret['key']];
                }
            }else{//默认本地
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads' . DS . 'image');
                if ($info) {//               
                    $upload_image = unserialize(config('upload_image'));
                    if ($upload_image['is_thumb'] == 1 || $upload_image['is_water'] == 1 || $upload_image['is_text'] == 1) {
                        $object_image = \think\Image::open($info->getPathName());
                        // 图片压缩
                        if ($upload_image['is_thumb'] == 1) { 
                            $object_image->thumb($upload_image['max_width'], $upload_image['max_height']);
                        }
                        // 图片水印
                        if ($upload_image['is_water'] == 1) {
                            $object_image->water(ROOT_PATH . str_replace('/', '\\', trim($upload_image['water_source'], '/')), $upload_image['water_locate'], $upload_image['water_alpha']);
                        }
                        // 文本水印
                        if ($upload_image['is_text'] == 1) {
                            $font = !empty($upload_image['text_font']) ? str_replace('/', '\\', trim($upload_image['text_font'], '/')) : 'vendor\topthink\think-captcha\assets\zhttfs\1.ttf';
                            $object_image->text($upload_image['text'], ROOT_PATH . $font, $upload_image['text_size'], $upload_image['text_color'], $upload_image['text_locate'], $upload_image['text_offset'], $upload_image['text_angle']);
                        }
                        $object_image->save($info->getPathName());
                    }
                    return ['code' => 1, 'url' => '/uploads/image/' . str_replace('\\', '/', $info->getSaveName())];
                }else {
                    return ['code' => 0, 'msg' => $file->getError()];
                }
            }
        } catch (\Exception $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

    public function uploadFile()
    {
        try {
            $file = $this->request->file('file');
            $qiniuConfig = include(__DIR__ ."/../../setting.php");
            //判断上传位置
            if($qiniuConfig['qiniu']['type']=='1'){//七牛
                //$file = $this->request->file('file');
                // 要上传图片的本地路径
                $filePath = $file->getRealPath();
                $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);  //后缀
                //$size = $this->sizecount(filesize($filePath));
                // 上传到七牛后保存的文件名
                $key = date('Y').'/'.date('md').'/'.date('YmdHis').rand(0,9999).substr(md5($file->getRealPath()),0,5). '.' . $ext;
                include APP_PATH . '/../vendor/qiniu/autoload.php';
                // 需要填写你的 Access Key 和 Secret Key
                $accessKey = $qiniuConfig['qiniu']['upak'];
                $secretKey = $qiniuConfig['qiniu']['upsk'];
                // 构建鉴权对象
                $auth = new Auth($accessKey, $secretKey);
                // 要上传的空间
                $bucket = $qiniuConfig['qiniu']['upbucket'];
                $domain = $qiniuConfig['qiniu']['updomain'];
                $token = $auth->uploadToken($bucket);
                // 初始化 UploadManager 对象并进行文件的上传
                $uploadMgr = new UploadManager();
                // 调用 UploadManager 的 putFile 方法进行文件的上传
                list($ret, $err) = $uploadMgr->putFile($token, $key, $filePath);
                if ($err !== null) {
                    return ["err"=>1,"msg"=>$err,"data"=>""];
                } else {
                    //返回图片的完整URL
                    return ['code' => 1, 'url' => $domain.$ret['key']];
                }
            }else{//默认本地
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads' . DS . 'file');
                if ($info) {
                    return ['code' => 1, 'url' => '/uploads/file/' . str_replace('\\', '/', $info->getSaveName())];
                } else {
                    return ['code' => 0, 'msg' => $file->getError()];
                }
            }
        } catch (\Exception $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

    public function uploadVideo()
    {
        try {
            $file = $this->request->file('file');
            $qiniuConfig = include(__DIR__ ."/../../setting.php");
            //判断上传位置
            if($qiniuConfig['qiniu']['type']=='1'){//七牛
                //$file = $this->request->file('file');
                // 要上传图片的本地路径
                $filePath = $file->getRealPath();
                $ext = pathinfo($file->getInfo('name'), PATHINFO_EXTENSION);  //后缀
                //$size = $this->sizecount(filesize($filePath));
                // 上传到七牛后保存的文件名
                $key = date('Y').'/'.date('md').'/'.date('YmdHis').rand(0,9999).substr(md5($file->getRealPath()),0,5). '.' . $ext;
                include APP_PATH . '/../vendor/qiniu/autoload.php';
                // 需要填写你的 Access Key 和 Secret Key
                $accessKey = $qiniuConfig['qiniu']['upak'];
                $secretKey = $qiniuConfig['qiniu']['upsk'];
                // 构建鉴权对象
                $auth = new Auth($accessKey, $secretKey);
                // 要上传的空间
                $bucket = $qiniuConfig['qiniu']['upbucket'];
                $domain = $qiniuConfig['qiniu']['updomain'];
                $token = $auth->uploadToken($bucket);
                // 初始化 UploadManager 对象并进行文件的上传
                $uploadMgr = new UploadManager();
                // 调用 UploadManager 的 putFile 方法进行文件的上传
                list($ret, $err) = $uploadMgr->putFile($token, $key, $filePath);
                if ($err !== null) {
                    return ["err"=>1,"msg"=>$err,"data"=>""];
                } else {
                    //返回图片的完整URL
                    return ['code' => 1, 'url' => $domain.$ret['key']];
                }
            }else{//默认本地
                $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads' . DS . 'video');
                if ($info) {
                    return ['code' => 1, 'url' => '/uploads/video/' . str_replace('\\', '/', $info->getSaveName())];
                } else {
                    return ['code' => 0, 'msg' => $file->getError()];
                }
            }
        } catch (\Exception $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

    public function icon()
    {
        return $this->fetch();
    }

    // 修改密码
    public function editPassword()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            // 验证条件
            empty($param['password']) && $this->error('请输入旧密码');
            empty($param['new_password']) && $this->error('请输入新密码');
            empty($param['rep_password']) && $this->error('请输入确认密码');
            !check_password($param['new_password'], 6, 16) && $this->error('请输入6-16位的密码');
            $param['new_password'] != $param['rep_password'] && $this->error('两次密码不一致');
            $admin = model('admin')->where('id', session('admin_auth.admin_id'))->find();
            $admin['password'] != md5($param['password']) && $this->error('旧密码错误');
            $data = ['id' => session('admin_auth.admin_id'), 'password' => $param['new_password']];
            if ($this->update('admin', $data, false) === true) {
                insert_admin_log('修改了登录密码');
                $this->success('更新成功', url('admin/index/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('editPassword');
    }

    // 退出登录
    public function logout()
    {
        insert_admin_log('退出了后台系统');
        session('admin_auth', null);
        session('admin_auth_sign', null);
        $this->redirect('admin/index/login');
    }

    // 清除缓存
    public function clear()
    {
        clear_cache();
        insert_admin_log('清除了系统缓存');
        $this->success('清除成功');
    }
}
