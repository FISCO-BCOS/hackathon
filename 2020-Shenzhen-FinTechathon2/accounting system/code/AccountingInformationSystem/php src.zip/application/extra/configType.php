<?php

return [
    'input'    => '单行文本',
    'textarea' => '多行文本',
    'select'   => '下拉选项',
    'radio'    => '单选项',
    'image'    => '图片',
];
