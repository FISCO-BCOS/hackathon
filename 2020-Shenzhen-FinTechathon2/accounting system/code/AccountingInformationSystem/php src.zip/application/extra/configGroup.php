<?php

return [
    'website' => '网站配置',
    'contact' => '联系方式',
];
