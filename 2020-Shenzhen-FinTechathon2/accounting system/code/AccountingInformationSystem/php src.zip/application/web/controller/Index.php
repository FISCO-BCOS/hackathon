<?php
namespace app\web\controller;
use app\common\controller\IndexBase;
use think\Request;

class Index extends IndexBase
{
    protected function _initialize()
    {
        parent::_initialize();
        $request= Request::instance();
        $id = input('param.id');
        $this->assign('seo',$seo = seo($id,$request->action()));
    }
    public function index()
    {
        $this->redirect('/user/');
    }
    //列表
    public function lists()
    {
        
        return $this->fetch($col['template'],[
           
        ]);
    }
    //列表
    public function product()
    {
        
        
        return $this->fetch('product',[
            'col' => $col,
            'list' => $list,
        ]);
    }
    //单页
    public function page()
    {
        $cid = input('param.id');
        //查看内容
        $data = model('page')->where(['cid'=>$cid])->find();
        //关于我们列表
        $about = model('category')->where(['pid'=>2])->select();
        return $this->fetch($data['template'],[
            'data' => $data,
            'about' => $about,
            'cid' => $cid,
        ]);
    }
    //内容
    public function show()
    {
        $id = input('param.id');
        //统计浏览量
        article_view($id);
        $data = Article::where(['id'=>$id])->find();
        $col = Category::where(['id'=>$data['cid']])->find();
        //随机图文
        $righta = Article::where("status='1' and image <>''")->orderRaw('rand()')->limit("3")->select();
        $rightb = Article::where(['status'=>1])->orderRaw('rand()')->limit("10")->select();
        web_tongji();//统计
        return $this->fetch($data['template'],[
            'data' => $data,
            'col' => $col,
            'righta' => $righta,
            'rightb' => $rightb,
        ]);
    }
    //内容
    public function product_show()
    {
        $id = input('param.id');
        //统计浏览量
        article_view($id);
        $data = model('product')->where(['id'=>$id])->find();
        $col = Category::where(['id'=>$data['cid']])->find();
        //随机图文
        $righta = model('article')->where("status='1' and image <>''")->orderRaw('rand()')->limit("3")->select();
        $rightb = model('product')->where(['status'=>1])->orderRaw('rand()')->limit("10")->select();
        web_tongji();//统计
        return $this->fetch($data['template'],[
            'data' => $data,
            'col' => $col,
            'righta' => $righta,
            'rightb' => $rightb,
        ]);
    }
    public function baoming()
    {
        //$share = \app\index\model\Wxshare::get_share();
        //$appid = $share['appid'];
        //$nonceStr = $share['nonceStr'];
        //$signature = $share['signature'];
        //$timestamp = $share['timestamp'];
        return $this->fetch('baoming',[

            ]);
    }
}
