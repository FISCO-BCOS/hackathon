<?php
namespace app\index\controller;
use app\common\controller\IndexBase;
use app\common\model\Article;
use app\common\model\Category;
use app\common\model\Ad;
use think\Request;

class Index extends IndexBase
{
    protected function _initialize()
    {
        parent::_initialize();
        //$request= Request::instance();
        //$id = input('param.id');
        //$this->assign('seo',$seo = seo($id,$request->action()));
    }
    public function index()
    {
        $this->redirect('/user/');
    }
    //列表
    public function lists()
    {
        $cid = input('param.id');
        $category = Category::where("pid = '0'")->limit('7')->select();
        $col = Category::where(['id'=>$cid])->find();
        //查看是否有子栏目
        $pcol = Category::where(['pid'=>$cid])->select();
        $pid = '';
        foreach($pcol as $r){
            $pid = $r['id'].','.$pid;
        }
        $pid = substr($pid,0,-1);
        if($pid){
            $list = Article::where("cid in ($pid)")->order('sort_order desc,id desc')->paginate(5);
        }else{
            $pcol = Category::where(['pid'=>$col['pid']])->select();
            $list = Article::where(['cid'=>$cid])->order('sort_order desc,id desc')->paginate(5);
        }
        //随机图文
        $righta = Article::where("status='1' and image <>''")->orderRaw('rand()')->limit("5")->select();
        $rightb = Article::where(['status'=>1])->orderRaw('rand()')->limit("10")->select();
        web_tongji();//统计
        return $this->fetch($col['template'],[
            'col' => $col,
            'pcol' => $pcol,
            'list' => $list,
            'category' => $category,
            'righta' => $righta,
            'rightb' => $rightb,
        ]);
    }
    //列表
    public function product()
    {
        $cid = input('param.id');
        $category = Category::where("pid = '0'")->limit('7')->select();
        $col = Category::where(['id'=>$cid])->find();
        $list = model('product')->order('sort_order desc,id desc')->paginate(12);
        
        return $this->fetch('product',[
            'col' => $col,
            'list' => $list,
        ]);
    }
    //单页
    public function page()
    {
        $cid = input('param.id');
        //查看内容
        $data = model('page')->where(['cid'=>$cid])->find();
        //关于我们列表
        $about = model('category')->where(['pid'=>2])->select();
        return $this->fetch($data['template'],[
            'data' => $data,
            'about' => $about,
            'cid' => $cid,
        ]);
    }
    //内容
    public function show()
    {
        $id = input('param.id');
        //统计浏览量
        article_view($id);
        $data = Article::where(['id'=>$id])->find();
        $col = Category::where(['id'=>$data['cid']])->find();
        //随机图文
        $righta = Article::where("status='1' and image <>''")->orderRaw('rand()')->limit("3")->select();
        $rightb = Article::where(['status'=>1])->orderRaw('rand()')->limit("10")->select();
        web_tongji();//统计
        return $this->fetch($data['template'],[
            'data' => $data,
            'col' => $col,
            'righta' => $righta,
            'rightb' => $rightb,
        ]);
    }
    //内容
    public function product_show()
    {
        $id = input('param.id');
        //统计浏览量
        article_view($id);
        $data = model('product')->where(['id'=>$id])->find();
        $col = Category::where(['id'=>$data['cid']])->find();
        //随机图文
        $righta = model('article')->where("status='1' and image <>''")->orderRaw('rand()')->limit("3")->select();
        $rightb = model('product')->where(['status'=>1])->orderRaw('rand()')->limit("10")->select();
        web_tongji();//统计
        return $this->fetch($data['template'],[
            'data' => $data,
            'col' => $col,
            'righta' => $righta,
            'rightb' => $rightb,
        ]);
    }
    public function baoming()
    {
        //$share = \app\index\model\Wxshare::get_share();
        //$appid = $share['appid'];
        //$nonceStr = $share['nonceStr'];
        //$signature = $share['signature'];
        //$timestamp = $share['timestamp'];
        return $this->fetch('baoming',[

            ]);
    }
    public function yubu()
    {
        $share = \app\index\model\Wxshare::get_share();
        $appid = $share['appid'];
        $nonceStr = $share['nonceStr'];
        $signature = $share['signature'];
        $timestamp = $share['timestamp'];
        return $this->fetch('yubu',[
                'appid' => $appid,
                'nonceStr' => $nonceStr,
                'signature' => $signature,
                'timestamp' => $timestamp,
            ]);
    }
    
}
