<?php

namespace app\user\validate;

use think\Validate;

class School extends Validate
{
    protected $rule = [

    ];

    protected $message = [

    ];
}
