<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Db;
use think\Model;

class Hook extends UserBase
{
    protected function _initialize()
    {
        parent::_initialize();
        //$this->assign('today',date('Y-m-d',time()));
    }
    //钩子列表
    public function index()
    {
        $list = model('hook')->order('id desc')->paginate(config('page_number'));
        return $this->fetch('index', [
            'list' => $list,
        ]);
    }
    //添加教室
    public function add()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['userid'] = session('user_auth.user_id');
            $param['sid'] = ShopId();
            $param['status'] = '1';
            $data = $this->insert('hook', $param);
            if ($data === true) {
                insert_user_log('添加了钩子');
                $this->success('添加成功', url('user/hook/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', [
            
        ]);
    }
    //编辑教室
    public function edit()
    {
        $id = input('id')?: $this->error('参数错误');
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['update_time'] = time();
            $data = $this->update('hook', $param, input('_verify', true));
            if ($data === true) {
                insert_user_log('修改了教室');
                $this->success('修改成功', url('user/hook/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', [ 
            'data'     => model('hook')->where('id', $id)->find()?: $this->error('参数错误'),
        ]);
    }
    //删除教室
    public function del()
    {
        if ($this->request->isPost()) {
            if ($this->delete_recovery('hook', $this->request->param()) === true) {
                insert_user_log('删除了钩子');
                $this->success('删除成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
    }
    
    
}
