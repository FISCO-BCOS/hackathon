<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Db;
use think\Model;

class Finance extends UserBase
{
    protected function _initialize()
    {
        parent::_initialize();
        //$this->assign('today',date('Y-m-d',time()));
    }
    //现金表
    public function index()
    {
        $dateframe = input('dateframe');
        if($dateframe){
            $start_time = strtotime(substr($dateframe,0,10));
            $end_time = strtotime(substr($dateframe,-10));
            $where = "datetime >='".$start_time."' and datetime <='".$end_time."'";
        }else{
            $start_time = strtotime(date('Y-1-1 00:00:00'));
            $end_time = mktime(23,59,59,date('m'),date('t'),date('Y'));
            $where = "datetime >='".$start_time."' and datetime <='".$end_time."'";
        }
        $bxuser = input('bxuser');
        if($bxuser){
            $where = "bxuser ='".$bxuser."'";
        }
        $department = input('department');
        if($department){
            $where = "department ='".$department."'";
        }
        $category = input('category');
        if($category){
            $where = "category ='".$category."'";
        }
        $type = input('type');
        if($type){
            $where = "type ='".$type."'";
        }
        $list = model('finance')->where($where)->order('datetime desc,id desc')->paginate(config('page_number'));
        $data['shouru'] = number_format(model('finance')->where(['type'=>'1'])->where($where)->sum('price'),2);
        $data['zhichu'] = number_format(model('finance')->where(['type'=>'2'])->where($where)->sum('price'),2);
        return $this->fetch('index', [
            'list'      => $list,
            'data'      => $data,
            'dateframe' => $dateframe,
        ]);
    }
    //现金报表
    public function report()
    {
        $dateframe = input('dateframe');
        if($dateframe){
            $start_time = strtotime(substr($dateframe,0,10));
            $end_time = strtotime(substr($dateframe,-10));
            $where = "datetime >='".$start_time."' and datetime <='".$end_time."'";
        }
        $department = model('hook')->where(['group'=>'1','status'=>'1'])->select();
        $category = model('hook')->where(['group'=>'2','status'=>'1'])->select();
        $user = model('user')->where(['status'=>'1'])->select();
        return $this->fetch('report', [
            'where'       => $where,
            'dateframe'  => $dateframe,
            'department' => $department,
            'category' => $category,
            'user' => $user,
        ]);
    }
    //现金数据分析
    public function analysis()
    {
        $dateframe = input('dateframe');
        if($dateframe){
            $start_time = strtotime(substr($dateframe,0,10));
            $end_time = strtotime(substr($dateframe,-10));
            $where = "datetime >='".$start_time."' and datetime <='".$end_time."'";
        }else{
            $start_time = mktime(0,0,0,date('m'),1,date('Y'));
            $end_time = mktime(23,59,59,date('m'),date('t'),date('Y'));
        }
        $bxuser = input('bxuser');
        if($bxuser){
            $where = "bxuser ='".$bxuser."'";
        }
        $department = input('department');
        if($department){
            $where = "department ='".$department."'";
        }
        $category = input('category');
        if($category){
            $where = "category ='".$category."'";
        }
        $type = input('type');
        if($type){
            $where = "type ='".$type."'";
        }
        $now_j = (($end_time-$start_time)/86400)+1;
        $array = array();
        $shouru = array();
        $zhichu = array();
        for($i=0;$i<$now_j;$i++){
            //筛选
            $array[] = $dtrq = date('d',$start_time+$i*86400); //每隔一天赋值给数组
            $day_begin = $start_time+$i*86400;
            $day_end = ($start_time+$i*86400)+86399;
            $shouru[] = $nums = model('finance')->where($where)->where("type='1' and datetime >='".$day_begin."' and datetime <= '".$day_end."'")->sum('price');
            $zhichu[] = $nums = model('finance')->where($where)->where("type='2' and datetime >='".$day_begin."' and datetime <= '".$day_end."'")->sum('price');
            $num = $num + $nums;
        }
        $dateframe = date('Y-m-d',$start_time) .' - '. date('Y-m-d',$end_time);
        return $this->fetch('analysis', [
            'data' => $data,
            'array' => $array,
            'shouru' => $shouru,
            'zhichu' => $zhichu,
            'name' => $name,
            'dateframe' => $dateframe,
        ]);
    }
    //添加教室
    public function add()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['userid'] = session('user_auth.user_id');
            $param['sid'] = ShopId();
            $param['datetime'] = strtotime($param['datetime']);
            $data = $this->insert('finance', $param);
            if ($data === true) {
                insert_user_log('添加了费用');
                $this->success('操作成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', [
            
        ]);
    }
    //编辑教室
    public function edit()
    {
        $id = input('id')?: $this->error('参数错误');
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['update_time'] = time();
            $param['datetime'] = strtotime($param['datetime']);
            $data = $this->update('finance', $param, input('_verify', true));
            if ($data === true) {
                insert_user_log('修改了费用');
                $this->success('修改成功', url('user/finance/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', [ 
            'data'     => model('finance')->where('id', $id)->find()?: $this->error('参数错误'),
        ]);
    }
    
    public function del()
    {
        if ($this->delete('finance', $this->request->param()) === true) {
            insert_user_log('删除了费用');
            $this->success('删除成功');
        } else {
            $this->error($this->errorMsg);
        }
    }
    
    
}
