<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Db;
use think\Model;

class AccountingTitle extends UserBase
{
    
    protected function _initialize()
    {
        parent::_initialize();
        //$this->assign('today',date('Y-m-d',time()));
    }

    /**
     * 得到所有会计分录
     * @return [type] [description]
     */
    public function get_all_accounting_titles()
    {
        
        $all_accounting_titles = Db::table('hq_accounting_title')->select();

        $result = array();
        $result['errCode'] = 0;
        $result['errMsg'] = '调用成功';
        $result['data']['all_accounting_titles'] = $all_accounting_titles;
        
        return json($result);
        
    }

    

}