<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Db;
use think\Model;

use think\Loader;
use rannmann\PhpIpfsApi\IPFS;


class Certificate extends UserBase
{

    protected function _initialize()
    {
        parent::_initialize();
        //$this->assign('today',date('Y-m-d',time()));
    }

    /**
     * 录凭证
     * @return [type] [description]
     */
    public function record_certificate()
    {

        $total_certificates = Db::table('hq_certificate')->count();

        $all_accounting_titles = Db::table('hq_accounting_title')->select();
        return $this->fetch('record_certificate', [
            'total_certificates' => $total_certificates,
            'all_accounting_titles' => $all_accounting_titles
        ]);
    }

    /**
     * 查看所有凭证
     * @return [type] [description]
     */
    public function all_certificates(){
        return $this->fetch('all_certificates', []);
    }



    /**
     * 新增凭证
     */
    public function add_certificate(){


        $param = $this->request->param();


        // 检测参数是否合理
        if($param['certificate']['total_debit_amount'] != $param['certificate']['total_credit_amount'] || $param['certificate']['total_debit_amount'] == 0){

            $result = array();
            $result['errCode'] = 1;
            $result['errMsg'] = '借方总金额和贷方总金额不相等';
            $result['data']['param'] = $param;

            return json($result);

        }


        /** 新增凭证 start */
        $data = array();
        $data['certificate_number'] = $param['certificate']['certificate_number'];
        $data['year'] = $param['certificate']['year'];
        $data['month'] = $param['certificate']['month'];
        $data['day'] = $param['certificate']['day'];
        $data['total_debit_amount'] = $param['certificate']['total_debit_amount'];
        $data['total_credit_amount'] = $param['certificate']['total_credit_amount'];
        $data['tabulator'] = $param['certificate']['tabulator'];
        $data['company_id'] = 1;
        $data['create_timestamp'] = time();

        try{

            // insertGetId 返回自增 id 数
            $certificate_id = Db::table('hq_certificate')->insertGetId($data);


        }
        catch(\Exception $e){

            $result = array();
            $result['errCode'] = 1;
            $result['errMsg'] = '凭证添加失败，请刷新重试';
            $result['data']['exception'] = $e->getMessage();

            return json($result);

        }


        /** 新增凭证 end */




        /** 将凭证同步区块链 start */


        try{

            // 构造要同步的数据
            $to_add_blockchain_data = array();
            $to_add_blockchain_data = $data;
            $to_add_blockchain_data['id'] = $certificate_id;


            /**
             *  array(10) {
                  ["certificate_number"] => string(1) "1"
                  ["year"] => string(4) "2020"
                  ["month"] => string(2) "09"
                  ["day"] => string(2) "12"
                  ["total_debit_amount"] => string(4) "1000"
                  ["total_credit_amount"] => string(4) "1000"
                  ["tabulator"] => string(3) "shi"
                  ["company_id"] => int(1)
                  ["create_timestamp"] => int(1600653812)
                  ["id"] => string(2) "52"
                }
            */
            // dump($to_add_blockchain_data);
            // die();


            // TODO 1
            // 同步区块链的代码
            // 新增操作

            $send_data=array();
            $send_data['data'] = array();
            $send_data['data']['company_address']="76cf7e6faf9a4097999710742e4351e1";
            $send_data['data']['certificate']=$to_add_blockchain_data;

            $url = "http://127.0.0.1:8888/demo/insert_certificate";
            $jsonStr = json_encode($send_data);
            list($returnCode, $returnContent) = $this->http_post_json($url, $jsonStr);

            $return_data = json_decode($returnContent,true);

            $where=array();
            $where['id'] = $certificate_id;

            $save_data=array();
            $save_data['transactionHash'] = $return_data['Data']['transactionHash'];
            $save_data['transactionIndex'] = $return_data['Data']['transactionIndex'];
            $save_data['blockHash'] = $return_data['Data']['blockHash'];
            $save_data['blockNumber'] = $return_data['Data']['blockNumber'];
            $save_data['blockchain_timestamp'] = time();
            $res_code = Db::table('hq_certificate')->where($where)->update($save_data);

        }
        catch(\Exception $e){

            // 什么也不做

        }


        /** 将凭证同步区块链 end */




        /** 新增会计分录 start */

        $datas = [];

        foreach ($param['certificate']['accounting_entries'] as $key => $val){

            // 跳过不合法的
            if(($val['debit_amount'] == 0 && $val['credit_amount'] == 0) || !$val['serial_number']){

                // echo '信息不全，跳过该会计分录';

            }
            else{

                $data = array();
                $data['certificate_id'] = $certificate_id;
                $data['actual_certificate_id'] = $certificate_id; // 实际归属哪个凭证
                $data['abstract'] = $val['abstract'];
                $data['accounting_title_serial_number'] = $val['serial_number'];
                $data['accounting_title_name'] = $val['title'];

                $data['debit_amount'] = $val['debit_amount'] ? $val['debit_amount'] : 0;
                $data['credit_amount'] = $val['credit_amount'] ? $val['credit_amount'] : 0;
                $data['company_id'] = 1;
                $data['create_timestamp'] = time();


                // 借方创建UTXO（只有借方才是UTXO)，花费掉的UTXO，因为输入不会有同会计科目，所以默认为0
                $data['spent_accounting_entry_id'] = 0;

                // 源自最原始的那个会计分录，因为输入不会有同会计科目，所以默认为0
                $data['original_accounting_entry_id'] = 0;


                // 借方还是贷方
                if($val['debit_amount'] != 0){

                    // 借方（输出）
                    $data['type'] = 1;

                }
                else{


                    // 贷方（输入）
                    $data['type'] = 2;


                    /** 贷方消耗UTXO start */

                    // 查找出所有 会计科目为当前、尚未使用的、类型为借方的UTXO，借方金额从小到大排序
                    $where = array();
                    $where['is_unspent'] = 1;    // 未被花费的
                    $where['accounting_title_serial_number'] = $val['serial_number'];   // 会计科目为当前
                    $where['type'] = 1; // 类型为借方的UTXO

                    $unspent_accounting_entries = Db::table('hq_accounting_entry')->where($where)->order('debit_amount', 'asc')->column('id, certificate_id, abstract, accounting_title_serial_number, accounting_title_name, type, spent_accounting_entry_id, original_accounting_entry_id, debit_amount, credit_amount, original_document_hash, company_id, is_unspent, spent_timestamp, spent_for_certificate_id, create_timestamp', 'id');

                    // 从大开始累加，找到前几个组合在一起的借方金额大于当前贷方金额

                    // 可用于消费的UTXO的金额累计
                    $total_unspended_amount = 0;
                    // 保存此次用于消费的UTXO的id
                    $to_spend_accounting_entries = array();

                    foreach($unspent_accounting_entries as $key => $unspended_accounting_entry){

                        $total_unspended_amount += $unspended_accounting_entry['debit_amount'];
                        $to_spend_accounting_entries[$key] = $unspended_accounting_entry;

                        // 如果找到，则将该组合内的所有UTXO的状态置为已消耗，并生成新的剩余UTXO
                        if($total_unspended_amount >= $val['credit_amount']){
                            break;
                        }
                    }

                    // 如果要花费的UTXO不为空
                    if($to_spend_accounting_entries != null){

                        /** 将所有要花费的UTXO的状态置为已花费 start */
                        $where = array();
                        $where['id'] = array('in', array_keys($to_spend_accounting_entries));
                        $where['company_id'] = 1;

                        $new_data = array();
                        $new_data['is_unspent'] = 0;
                        $new_data['spent_timestamp'] = time();
                        $new_data['spent_for_certificate_id'] = $certificate_id;    // 其实是标记了这些UTXO作为了哪个凭证的输入

                        $update_result = Db::table('hq_accounting_entry')->where($where)->update($new_data);

                        /** 将所有要花费的UTXO的状态置为已花费 end */




                        /** 将凭证同步区块链 start */


                        try{

                            // 构造要同步的条件
                            $to_update_blockchain_where = array();
                            $to_update_blockchain_where = $where;


                            /**
                             *  array(2) {
                                  ["id"] => array(2) {
                                    [0] => string(2) "in"
                                    [1] => array(1) {
                                      [0] => int(77)
                                      [1] => int(100)
                                    }
                                  }
                                  ["company_id"] => int(1)
                                }
                            */
                            // dump($to_update_blockchain_where);




                            // 构造要同步的数据
                            $to_update_blockchain_data = array();
                            $to_update_blockchain_data = $new_data;


                            /**
                             *  array(3) {
                                  ["is_unspent"] => int(0)
                                  ["spent_timestamp"] => int(1600655081)
                                  ["spent_for_certificate_id"] => string(2) "53"
                                }
                            */
                            // dump($to_update_blockchain_data);
                            // die();


                            // TODO 2
                            // 同步区块链的代码
                            // 修改操作（注意修改条件是一个in数组，如果区块链可以使用in操作，就使用，如果不能，则可以使用for循环一条条修改

                            $send_data=array();
                            $send_data['data'] = array();
                            $send_data['data'] = $new_data;
                            $send_data['data']['company_address']="76cf7e6faf9a4097999710742e4351e1";
                            $send_data['data']['company_id']=$to_update_blockchain_where['company_id'];
                            $send_data['data']['id']=$to_update_blockchain_where['id'][1];

                            $url = "http://127.0.0.1:8888/demo/update_spend_utxo";
                            $jsonStr = json_encode($send_data);
                            list($returnCode, $returnContent) = $this->http_post_json($url, $jsonStr);

                        }
                        catch(\Exception $e){

                            // 什么也不做

                        }


                        /** 将凭证同步区块链 end */





                    }

                    /** 如果要花费的UTXO的总额大于本次实际要花费的金额，则找零 start*/
                    if($total_unspended_amount != $val['credit_amount']){


                        // 生成一个UTXO
                        $data2 = array();
                        $data2['certificate_id'] = 0;
                        $data2['actual_certificate_id'] = $certificate_id;
                        $data2['abstract'] = '找零生成';
                        $data2['accounting_title_serial_number'] = $val['serial_number'];
                        $data2['accounting_title_name'] = $val['title'];


                        // 如果不够扣，也会生成一个负项
                        $data2['debit_amount'] = $total_unspended_amount - $val['credit_amount'];
                        $data2['credit_amount'] = 0;
                        $data2['company_id'] = 1;
                        $data2['create_timestamp'] = time();


                        // 如果一个输入也没有
                        if(count($to_spend_accounting_entries) == 0){

                            $data2['spent_accounting_entry_id'] = 0;
                            $data2['original_accounting_entry_id'] = 0;

                        }
                        else{

                            // 找零的资金来自值最大的一项
                            $last_to_spend_accounting_entries = end($to_spend_accounting_entries);
                            $data2['spent_accounting_entry_id'] = $last_to_spend_accounting_entries['id'];

                            // 源自最原始的那个会计分录
                            if($last_to_spend_accounting_entries['original_accounting_entry_id'] == 0){
                                // 如果是新创建的UTXO
                                $data2['original_accounting_entry_id'] = $last_to_spend_accounting_entries['id'];
                            }
                            else{
                                $data2['original_accounting_entry_id'] = $last_to_spend_accounting_entries['original_accounting_entry_id'];
                            }

                        }


                        // 借方（输出）,借方创建UTXO
                        $data2['type'] = 1;

                        $datas[] = $data2;

                    }
                    /** 如果要花费的UTXO的总额大于本次实际要花费的金额，则找零 end*/


                    /** 贷方消耗UTXO end */

                }


                $datas[] = $data;
            }


        }

        // dump($datas);
        // die();

        foreach($datas as $key => $data){

            try{

                $accounting_entry_id = Db::table('hq_accounting_entry')->insertGetId($data);

                // 记录id，方便区块链
                $datas[$key]['id'] = $accounting_entry_id;
                $datas[$key]['is_unspent'] = "1";

            }
            catch(\Exception $e){

                $result = array();
                $result['errCode'] = 3;
                $result['errMsg'] = '会计分录添加失败，请刷新重试';
                $result['data']['exception'] = $e->getMessage();

                return json($result);

            }

        }


        /** 新增会计分录 end */



        /** 将会计分录同步区块链 start */


        try{

            // 构造要同步的数据
            $to_add_blockchain_data = array();
            $to_add_blockchain_data = $datas;


            /**
             *  array(4) {
                  [0] => array(13) {
                    ["certificate_id"] => int(0)
                    ["actual_certificate_id"] => string(2) "54"
                    ["abstract"] => string(12) "找零生成"
                    ["accounting_title_serial_number"] => string(4) "1002"
                    ["accounting_title_name"] => string(12) "银行存款"
                    ["debit_amount"] => int(800)
                    ["credit_amount"] => int(0)
                    ["company_id"] => int(1)
                    ["create_timestamp"] => int(1600656041)
                    ["spent_accounting_entry_id"] => int(82)
                    ["original_accounting_entry_id"] => int(82)
                    ["type"] => int(1)
                    ["id"] => string(2) "83"
                  }
                  [1] => array(13) {
                    ["certificate_id"] => string(2) "54"
                    ["actual_certificate_id"] => string(2) "54"
                    ["abstract"] => NULL
                    ["accounting_title_serial_number"] => string(4) "1002"
                    ["accounting_title_name"] => string(12) "银行存款"
                    ["debit_amount"] => int(0)
                    ["credit_amount"] => string(3) "200"
                    ["company_id"] => int(1)
                    ["create_timestamp"] => int(1600656041)
                    ["spent_accounting_entry_id"] => int(0)
                    ["original_accounting_entry_id"] => int(0)
                    ["type"] => int(2)
                    ["id"] => string(2) "84"
                  }
                  [2] => array(13) {
                    ["certificate_id"] => string(2) "54"
                    ["actual_certificate_id"] => string(2) "54"
                    ["abstract"] => string(3) "222"
                    ["accounting_title_serial_number"] => string(4) "1406"
                    ["accounting_title_name"] => string(12) "库存商品"
                    ["debit_amount"] => string(3) "100"
                    ["credit_amount"] => int(0)
                    ["company_id"] => int(1)
                    ["create_timestamp"] => int(1600656041)
                    ["spent_accounting_entry_id"] => int(0)
                    ["original_accounting_entry_id"] => int(0)
                    ["type"] => int(1)
                    ["id"] => string(2) "85"
                  }
                  [3] => array(13) {
                    ["certificate_id"] => string(2) "54"
                    ["actual_certificate_id"] => string(2) "54"
                    ["abstract"] => string(3) "333"
                    ["accounting_title_serial_number"] => string(4) "1403"
                    ["accounting_title_name"] => string(9) "原材料"
                    ["debit_amount"] => string(3) "100"
                    ["credit_amount"] => int(0)
                    ["company_id"] => int(1)
                    ["create_timestamp"] => int(1600656041)
                    ["spent_accounting_entry_id"] => int(0)
                    ["original_accounting_entry_id"] => int(0)
                    ["type"] => int(1)
                    ["id"] => string(2) "86"
                  }
                }
            */
            // dump($to_add_blockchain_data);
            // die();


            // TODO 3
            // 同步区块链的代码
            // 新增操作

            $send_data=array();
            $send_data['data'] = array();
            $send_data['data']['company_address']="76cf7e6faf9a4097999710742e4351e1";
            $send_data['data']['accounting']=$to_add_blockchain_data;

            $url = "http://127.0.0.1:8888/demo/insert_accounting_entry";
            $jsonStr = json_encode($send_data);
            list($returnCode, $returnContent) = $this->http_post_json($url, $jsonStr);

        }
        catch(\Exception $e){

            // 什么也不做

        }


        /** 将会计分录同步区块链 end */




        $result = array();
        $result['errCode'] = 0;
        $result['errMsg'] = '添加成功';
        $result['data']['res'] = $res;
        $result['data']['datas'] = $datas;
        $result['data']['certificate_block_return'] = $return_data;

        return json($result);


    }

    /**
     * 得到所有凭证
     * @return [type] [description]
     */
    public function get_all_certificates(){


        $param = $this->request->param();


        $where = array();

        if($param['year']){
            $where['year'] = $param['year'];
        }

        if($param['month']){
            $where['month'] = $param['month'];
        }


        $all_certificates = Db::table('hq_certificate')->where($where)->column('*', 'id');



        // 提取出所有凭证id
        $certificate_id_arr = [];
        foreach($all_certificates as $key => $certificate){
            $certificate_id_arr[] = $certificate['id'];
        }



        if(count($certificate_id_arr) > 0){

            $where = array();
            // 不取UTXO类型找零的
            $where['certificate_id'] = array('in', $certificate_id_arr);
            $all_accounting_entries = Db::table('hq_accounting_entry')->where($where)->select();

            foreach($all_accounting_entries as $key => $accounting_entry){
                $all_certificates[$accounting_entry['certificate_id']]['accounting_entries'][] = $accounting_entry;
            }

        }



        $result = array();
        $result['errCode'] = 0;
        $result['errMsg'] = '调用成功';
        $result['data']['all_certificates'] = $all_certificates;

        return json($result);

    }

    /**
     * 查看所有相关凭证（资金穿透）
     * @return [type] [description]
     */
    public function all_related_certificates(){

        // 查询出当前会计分录
        $param = $this->request->param();

        $where = array();
        $where['id'] = $param['accounting_entry_id'];


        $now_accounting_entry = Db::table('hq_accounting_entry')->where($where)->find();


        return $this->fetch('all_related_certificates', [
            'now_accounting_entry' => $now_accounting_entry
        ]);

    }


    /**
     * 得到所有相关凭证（资金穿透）
     * @return [type] [description]
     */
    public function get_all_related_certificates(){


        // 查询出当前会计分录
        $param = $this->request->param();

        $where = array();
        $where['id'] = $param['accounting_entry_id'];


        $now_accounting_entry = Db::table('hq_accounting_entry')->where($where)->find();



        /** 找出所有的关联的会计分录对应的凭证 start */
        $where = array();

        // 是否为第一个
        if($now_accounting_entry['original_accounting_entry_id'] == 0){
            $where['b.original_accounting_entry_id'] = $now_accounting_entry['id'];
        }
        else{
            $where['b.original_accounting_entry_id'] = $now_accounting_entry['original_accounting_entry_id'];
        }


        $all_certificates = Db::table('hq_certificate')->alias('a')
                                                       ->join('hq_accounting_entry b', 'b.actual_certificate_id = a.id')
                                                       ->where($where)
                                                       ->order('a.id', 'ASC')
                                                       ->column('a.*, b.actual_certificate_id, b.id as accounting_entry_id', 'a.id');


        /** 找出所有的关联的会计分录对应的凭证 end */


        if($all_certificates){
            // 查找所有凭证的所有会计分录
            $where = array();
            // 不取UTXO类型找零的
            $where['certificate_id'] = array('in', array_keys($all_certificates));
            $all_accounting_entries = Db::table('hq_accounting_entry')->where($where)->select();

            foreach($all_accounting_entries as $key => $accounting_entry){
                $all_certificates[$accounting_entry['certificate_id']]['accounting_entries'][] = $accounting_entry;
            }
        }







        $result = array();
        $result['errCode'] = 0;
        $result['errMsg'] = '调用成功';
        $result['data']['now_accounting_entry'] = $now_accounting_entry;
        $result['data']['all_certificates'] = $all_certificates;

        return json($result);

    }


    /**
     * 上传原始凭证
     * @return [type] [description]
     */
    public function upload_original_document(){

        $param = $this->request->param();


        // 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('file');

        // 移动到框架应用根目录/public/uploads/ 目录下
        if($file){

            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');

            if($info){


                try{

                    Loader::import('IPFS', EXTEND_PATH, '.php');

                    // 接口文档https://github.com/cloutier/php-ipfs-api
                    $ipfs = new IPFS('127.0.0.1', 8080, 5001);

                    $filePath = './uploads/' . $info->getSaveName();


                    $file_ipfs_hash = $ipfs->addFromPath($filePath);
                }
                catch(\Exception $e){
                    // 上传失败获取错误信息

                }




                /** 修改原始凭证的存储地址 start */
                $where = array();
                $where['id'] = $param['accounting_entry_id'];

                $new_data = array();
                $new_data['original_document_hash'] = $file_ipfs_hash;

                $update_result = Db::table('hq_accounting_entry')->where($where)->update($new_data);
                /** 修改原始凭证的存储地址 end */



                // 成功上传后 获取上传信息
                $result = array();
                $result['errCode'] = 0;
                $result['errMsg'] = '调用成功';
                // 输出 jpg
                $result['data']['getExtension'] = $info->getExtension();
                // 输出 20160820/42a79759f284b767dfcb2a0197904287.jpg
                $result['data']['getSaveName'] = $info->getSaveName();
                // 输出 42a79759f284b767dfcb2a0197904287.jpg
                $result['data']['getFilename'] = $info->getFilename();


                $result['data']['original_document_hash'] = $new_data['original_document_hash'];
                $result['data']['request'] = $param;


                if(file_exists($filePath))
                {
                    $result['data']['is_file_existed'] =  "当前目录中，文件".$filePath."存在";
                }
                else
                {
                     $result['data']['is_file_existed'] =  "当前目录中，文件".$filePath."不存在";
                }

                $result['data']['file_ipfs_hash'] = $file_ipfs_hash;


                return json($result);

            }
            else{

                // 上传失败获取错误信息
                $result = array();
                $result['errCode'] = 2;
                $result['errMsg'] = '上传失败';
                $result['data']['getError'] = $file->getError();

                return json($result);

            }
        }
        else{

            $result = array();
            $result['errCode'] = 1;
            $result['errMsg'] = '没有文件上传';

            return json($result);

        }

    }


    public function test(){

        dump(1111);

        Loader::import('IPFS', EXTEND_PATH, '.php');

        // 接口文档https://github.com/cloutier/php-ipfs-api
        $ipfs = new IPFS('127.0.0.1', 8080, 5001);

        $filePath = './uploads/20200916/3efff4210071bda5b470f6c5a1c837b1.png';
        // $filePath = 'ce6f228802ccd23587fa82cd77c19731.png';


        if(file_exists($filePath))
        {
            echo "当前目录中，文件".$filePath."存在";
        }
        else
        {
             echo "当前目录中，文件".$filePath."不存在";
        }


        $result = $ipfs->addFromPath($filePath);
        dump($result);

        dump(555);


    }

    public function http_post_json($url, $jsonStr)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonStr);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset=utf-8',
            'Content-Length: ' . strlen($jsonStr)
        ));
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return array($httpCode, $response);
    }

























}
