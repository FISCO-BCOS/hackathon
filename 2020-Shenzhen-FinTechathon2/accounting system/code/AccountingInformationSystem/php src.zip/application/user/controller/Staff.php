<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Request;

class Staff extends UserBase
{
    protected function _initialize()
    {
        parent::_initialize();
        
    }
    //商品列表
    public function index()
    {
        $list = model('user')->where($where)->order('id desc')->paginate(config('page_number'));
        return $this->fetch('index',[
            'list' => $list,
        ]);
    }
    //添加
    public function add()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['sid'] = ShopId();
            $param['user_id'] = UserId();
            empty($param['password']) && $this->error('密码不能为空');
            if ($this->insert('user', $param) === true) {
                model('userAuthGroupAccess')->save(['uid' => $this->insertId, 'group_id' => $param['group_id']]);
                insert_user_log('添加了用户');
                $this->success('添加成功', url('user/staff/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', ['userAuthGroup' => model('userAuthGroup')->where('status', 1)->select()]);
    }
    //编辑
    public function edit()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $verify = input('_verify', true);
            if (empty($param['password'])) {
                unset($param['password']);
            }
            if ($this->update('user', $param, input('_verify', true)) === true) {
                $verify && model('userAuthGroupAccess')->save(['group_id' => $param['group_id']], ['uid' => $param['id']]);
                insert_admin_log('修改了用户');
                $this->success('修改成功', url('user/staff/index'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        return $this->fetch('save', [
            'data' => model('user')->with('userAuthGroupAccess')->where('id', input('id'))->find(),
            'userAuthGroup' => model('userAuthGroup')->where('status', 1)->select(),]);
    }
    //删除
    public function del()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            if ($this->delete('user', $this->request->param()) === true) {
                model('userAuthGroupAccess')->where('uid', $param['id'])->delete();
                insert_admin_log('删除了用户');
                $this->success('删除成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
    }
    //商品列表
    public function role()
    {
        $list = model('user_auth_group')->where($where)->order('id desc')->paginate(config('page_number'));
        return $this->fetch('role',[
            'list' => $list,
        ]);
    }
    //添加角色
    public function add_role()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            $param['sid'] = ShopId();
            $param['user_id'] = UserId();
            if ($this->insert('userAuthGroup', $param) === true) {
                insert_user_log('添加了角色');
                $this->success('添加成功', url('user/staff/role'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        $userAuthRule = collection(model('userAuthRule')->where(['status' => 1])->order('sort_order asc')->select())->toArray();
        foreach ($userAuthRule as $k => $v) {
            // $userAuthRule[$k]['open'] = true;
        }
        return $this->fetch('save_role', ['userAuthRule' => json_encode(list_to_tree($userAuthRule))]);
    }
    //编辑角色
    public function edit_role()
    {
        if ($this->request->isPost()) {
            $param = $this->request->param();
            if ($this->update('userAuthGroup', $param, input('_verify', true)) === true) {
                insert_user_log('修改了角色');
                $this->success('修改成功', url('user/staff/role'));
            } else {
                $this->error($this->errorMsg);
            }
        }
        $data     = model('userAuthGroup')->where('id', input('id'))->find();
        $userAuthRule = collection(model('userAuthRule')->where(['status' => 1])->order('sort_order asc')->select())->toArray();
        foreach ($userAuthRule as $k => $v) {
            // $userAuthRule[$k]['open'] = true;
            $userAuthRule[$k]['checked'] = in_array($v['id'], explode(',', $data['rules']));
        }
        return $this->fetch('save_role', ['data' => $data, 'userAuthRule' => json_encode(list_to_tree($userAuthRule))]);
    }
    //删除角色
    public function del_role()
    {
        if ($this->request->isPost()) {
            if ($this->delete('userAuthGroup', $this->request->param()) === true) {
                insert_admin_log('删除了角色');
                $this->success('删除成功');
            } else {
                $this->error($this->errorMsg);
            }
        }
    }
    //日志
    public function log()
    {
        return $this->fetch('log', ['list' => model('userLog')->order('create_time desc')->paginate(config('page_number'))]);
    }
    //清除日志
    public function truncate()
    {
        if ($this->request->isPost()) {
            db()->query('TRUNCATE ' . config('database.prefix') . 'user_log');
            $this->success('操作成功');
        }
    }
}
