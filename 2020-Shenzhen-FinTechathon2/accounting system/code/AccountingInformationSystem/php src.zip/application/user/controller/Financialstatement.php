<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Db;
use think\Model;

class Financialstatement extends UserBase
{

    protected function _initialize()
    {
        parent::_initialize();
        //$this->assign('today',date('Y-m-d',time()));
    }

    /**
     * 资产负债表
     * @return [type] [description]
     */
    public function balance_sheet()
    {
        return $this->fetch('balance_sheet', []);
    }

    /**
     * 利润表
     * @return [type] [description]
     */
    public function income_statement(){

        return $this->fetch('income_statement', []);
    }

    /**
     * 现金流量表
     * @return [type] [description]
     */
    public function cash_flows_statement(){
        return $this->fetch('cash_flows_statement', []);
    }

    /**
     * 得到某期的资产负债表
     * @return [type] [description]
     */
    public function get_balance_sheet_ledger()
    {


        $param = $this->request->param();


        if(!$param['year'] || !$param['month']){

            $result = array();
            $result['errCode'] = 1;
            $result['errMsg'] = '参数不足';
            $result['data']['param'] = $param;

            return json($result);

        }



        $where = array();
        $where['a.certificate_id'] = array('neq', 0);   // 排除找零生成的

        $where['b.year'] = $param['year'];
        $where['b.month'] = array('elt', $param['month']);




        $all_accounting_entries = Db::table('hq_accounting_entry')->alias('a')
                                                            ->join('hq_certificate b', 'a.certificate_id = b.id')
                                                            ->where($where)
                                                            ->order('certificate_number', 'asc')
                                                            ->column('a.*, b.id as certificate_id, b.certificate_number, b.year, b.month, b.day, b.total_debit_amount, b.total_credit_amount, b.tabulator, a.original_document_hash', 'a.id');


        // dump($all_accounting_entries);

        // 年初数
        $amount_at_the_beginning_of_the_year = array();
        $amount_at_end_of_period = array();


        // http://www.canet.com.cn/kemu/596034.html


        /** 统计年初和期末的情况 start */
        foreach($all_accounting_entries as $key => $accounting_entry){

            /** 获取年初余额 start */
            if($accounting_entry['year'] < $param['year']){


                // 货币资金 = 1001 库存现金+1002 银行存款+1012 其他货币资金
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1001, 1002, 1012))){

                    dump($accounting_entry);die();
                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['bank_and_cash'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['bank_and_cash'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 短期投资 = 110101 短期投资_股票+110102 短期投资_债券+110103 短期投资_基金+110110 短期投资_其他
                if(in_array($accounting_entry['accounting_title_serial_number'], array(110101, 110102, 110103, 110110))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['short_term_investment'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['short_term_investment'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应收票据 = 1121 应收票据
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1121))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['notes_receivable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['notes_receivable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应收账款 = 1122 应收账款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1122))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['account_receivable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['account_receivable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 预付账款 = 1123 预付账款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1123))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['prepayment'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['prepayment'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应收股利 = 1131 应收股利
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1131))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['dividend_receivable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['dividend_receivable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应收利息 = 1132 应收利息
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1132))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['interest_receivable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['interest_receivable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 其他应收款  = 1221 其他应收款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1221))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['other_receivable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['other_receivable'] -= $accounting_entry['credit_amount'];
                    }

                }



                // 原材料  =  1403 原材料
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1403))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['raw_material'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['raw_material'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 在产品 TODO = 1401.材料采购 1402.在途物资
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1401, 1402))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['products_in_process'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['products_in_process'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 库存商品 = 1406 库存商品
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1406))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['goods_in_stock'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['goods_in_stock'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 周转材料 = 1431 周转材料
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1431))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['turnover_materials'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['turnover_materials'] -= $accounting_entry['credit_amount'];
                    }

                }

                // 其他流动资产 TODO
                $amount_at_the_beginning_of_the_year['other_current_assets'] = 0;









                // 长期债券投资   =  150101 长期债券投资_债券投资+150102 长期债券投资_其他债权投资
                if(in_array($accounting_entry['accounting_title_serial_number'], array(150101, 150102))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['long_term_debt_investment'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['long_term_debt_investment'] -= $accounting_entry['credit_amount'];
                    }

                }

                // 长期股权投资   =  1524 长期股权投资
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1524))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['long_term_equity_investment'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['long_term_equity_investment'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 投资性房地产   =  1526 投资性房地产
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1526))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['investment_real_estate'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['investment_real_estate'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 固定资产原价  =  1601 固定资产
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1601))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['net_assets'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['net_assets'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 累计折旧  =  1602 累计折旧
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1602))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['accumulated_depreciation'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['accumulated_depreciation'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 在建工程 = 160401 在建工程_建筑工程+160402 在建工程_安装工程+160403 在建工程_技术改造工程+160404 在建工程_其他支出
                if(in_array($accounting_entry['accounting_title_serial_number'], array(160401, 160402, 160403, 160404))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['construction_in_progress'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['construction_in_progress'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 工程物资 = 1605 工程物资
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1605))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['construction_materials'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['construction_materials'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 固定资产清理  =  1606 固定资产清理
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1606))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['disposal_of_fixed_assets'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['disposal_of_fixed_assets'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 生产性生物资产  =  1621 生产性生物资产
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1621))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['productive_biological_assets'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['productive_biological_assets'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 无形资产 = 1701 无形资产
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1701))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['intangible_assets'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['intangible_assets'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 开发支出 TODO
                $amount_at_the_beginning_of_the_year['development_expenditure'] = 0;

                // 长期待摊费用  =  1801 长期待摊费用
                if(in_array($accounting_entry['accounting_title_serial_number'], array(1801))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['long_term_deferred_expense'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['long_term_deferred_expense'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 其它非流动资产 TODO
                $amount_at_the_beginning_of_the_year['other_non_current_assets'] = 0;


                // 短期借款 = 2001 短期借款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2001))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['short_term_loans'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['short_term_loans'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应付票据 = 2201 应付票据
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2201))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['notes_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['notes_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应付账款 = 2202 应付账款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2202))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['accounts_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['accounts_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 预收账款 = 2203 预收账款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2203))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['advance_from_customers'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['advance_from_customers'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应付职工薪酬  =  2211 应付职工薪酬
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2211))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['payroll_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['payroll_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应交税费 = 22210101 应交税费_应交增值税_进项税额+22210102 应交税费_应交增值税_销项税额的抵减+22210103 应交税费_应交增值税_已交税金+22210104 应交税费_应交增值税_转出未交增值税+22210105 应交税费_应交增值税_减免税款+22210106 应交税费_应交增值税_出口抵减内销产品应纳税额
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2221, 22210101, 22210102, 22210103, 22210104, 22210105, 22210106))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['taxes_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['taxes_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应付利息 = 2232 应付利息
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2232))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['interest_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['interest_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 应付利润 = 2232 应付利润
                // if(in_array($accounting_entry['accounting_title_serial_number'], array(2232))){

                //     // 该会计分录在借方
                //     if($accounting_entry['type'] == 1){

                //         $amount_at_the_beginning_of_the_year['profit_payable'] += $accounting_entry['debit_amount'];
                //     }
                //     // 在贷方
                //     else{

                //         $amount_at_the_beginning_of_the_year['profit_payable'] -= $accounting_entry['credit_amount'];
                //     }

                // }


                // 其他应付款  =  2241 其他应付款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2241))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['other_accounts_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['other_accounts_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 其他流动负债 TODO
                $amount_at_the_beginning_of_the_year['other_current_liabilities'] = 0;


                // 长期借款  =  2601 长期借款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2601))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['long_term_loans'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['long_term_loans'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 长期应付款  =  2801 长期应付款
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2801))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['long_term_payable'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['long_term_payable'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 递延收益 = 2501 递延收益
                if(in_array($accounting_entry['accounting_title_serial_number'], array(2501))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['deferred_revenue'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['deferred_revenue'] -= $accounting_entry['credit_amount'];
                    }

                }

                // 其它非流动性负债 TODO
                $amount_at_the_beginning_of_the_year['other_non_current_liabilities'] = 0;


                // 实收资本（或股本） =  4001 实收资本
                if(in_array($accounting_entry['accounting_title_serial_number'], array(4001))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['paid_in_capital'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['paid_in_capital'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 资本公积 = 4002 资本公积
                if(in_array($accounting_entry['accounting_title_serial_number'], array(4002))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['capital_surplus'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['capital_surplus'] -= $accounting_entry['credit_amount'];
                    }

                }



                // 盈余公积 = 4101 盈余公积
                if(in_array($accounting_entry['accounting_title_serial_number'], array(4101))){

                    // 该会计分录在借方
                    if($accounting_entry['type'] == 1){

                        $amount_at_the_beginning_of_the_year['surplus_reserves'] += $accounting_entry['debit_amount'];
                    }
                    // 在贷方
                    else{

                        $amount_at_the_beginning_of_the_year['surplus_reserves'] -= $accounting_entry['credit_amount'];
                    }

                }


                // 未分配利润   =  310415 利润分配_未分配利润
                // if(in_array($accounting_entry['accounting_title_serial_number'], array(310415))){

                //     // 该会计分录在借方
                //     if($accounting_entry['type'] == 1){

                //         $amount_at_the_beginning_of_the_year['retained_profits_after_appropriation'] += $accounting_entry['debit_amount'];
                //     }
                //     // 在贷方
                //     else{

                //         $amount_at_the_beginning_of_the_year['retained_profits_after_appropriation'] -= $accounting_entry['credit_amount'];
                //     }

                // }





            }
            /** 获取年初余额 end */



            /** 获取期末数 start */
            // 货币资金 = 1001 库存现金+1002 银行存款+1012 其他货币资金
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1001, 1002, 1012))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['bank_and_cash'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['bank_and_cash'] -= $accounting_entry['credit_amount'];
                }

            }


            // 短期投资 = 110101 短期投资_股票+110102 短期投资_债券+110103 短期投资_基金+110110 短期投资_其他
            if(in_array($accounting_entry['accounting_title_serial_number'], array(110101, 110102, 110103, 110110))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['short_term_investment'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['short_term_investment'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应收票据 = 1121 应收票据
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1121))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['notes_receivable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['notes_receivable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应收账款 = 1122 应收账款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1122))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['account_receivable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['account_receivable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 预付账款 = 1123 预付账款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1123))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['prepayment'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['prepayment'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应收股利 = 1131 应收股利
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1131))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['dividend_receivable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['dividend_receivable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应收利息 = 1132 应收利息
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1132))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['interest_receivable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['interest_receivable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 其他应收款  = 1221 其他应收款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1221))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['other_receivable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['other_receivable'] -= $accounting_entry['credit_amount'];
                }

            }



            // 原材料  =  1403 原材料
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1403))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['raw_material'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['raw_material'] -= $accounting_entry['credit_amount'];
                }

            }



            // 在产品 TODO = 1401.材料采购 + 1402.在途物资
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1401, 1402))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['products_in_process'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['products_in_process'] -= $accounting_entry['credit_amount'];
                }

            }



            // 库存商品 = 1406 库存商品
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1406))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['goods_in_stock'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['goods_in_stock'] -= $accounting_entry['credit_amount'];
                }

            }


            // 周转材料 = 1431 周转材料
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1431))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['turnover_materials'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['turnover_materials'] -= $accounting_entry['credit_amount'];
                }

            }

            // 其他流动资产 TODO
            $amount_at_end_of_period['other_current_assets'] = 0;

            // 长期债券投资   =  150101 长期债券投资_债券投资+150102 长期债券投资_其他债权投资
            if(in_array($accounting_entry['accounting_title_serial_number'], array(150101, 150102))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['long_term_debt_investment'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['long_term_debt_investment'] -= $accounting_entry['credit_amount'];
                }

            }

            // 长期股权投资   =  1524 长期股权投资
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1524))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['long_term_equity_investment'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['long_term_equity_investment'] -= $accounting_entry['credit_amount'];
                }

            }


            // 投资性房地产   =  1526 投资性房地产
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1526))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['investment_real_estate'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['investment_real_estate'] -= $accounting_entry['credit_amount'];
                }

            }




            // 固定资产原价  =  1601 固定资产
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1601))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['net_assets'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['net_assets'] -= $accounting_entry['credit_amount'];
                }

            }


            // 累计折旧  =  1602 累计折旧
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1602))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['accumulated_depreciation'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['accumulated_depreciation'] -= $accounting_entry['credit_amount'];
                }

            }


            // 在建工程 = 160401 在建工程_建筑工程+160402 在建工程_安装工程+160403 在建工程_技术改造工程+160404 在建工程_其他支出
            if(in_array($accounting_entry['accounting_title_serial_number'], array(160401, 160402, 160403, 160404))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['construction_in_progress'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['construction_in_progress'] -= $accounting_entry['credit_amount'];
                }

            }


            // 工程物资 = 1605 工程物资
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1605))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['construction_materials'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['construction_materials'] -= $accounting_entry['credit_amount'];
                }

            }


            // 固定资产清理  =  1606 固定资产清理
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1606))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['disposal_of_fixed_assets'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['disposal_of_fixed_assets'] -= $accounting_entry['credit_amount'];
                }

            }


            // 生产性生物资产  =  1621 生产性生物资产
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1621))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['productive_biological_assets'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['productive_biological_assets'] -= $accounting_entry['credit_amount'];
                }

            }


            // 无形资产 = 1701 无形资产
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1701))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['intangible_assets'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['intangible_assets'] -= $accounting_entry['credit_amount'];
                }

            }


            // 开发支出 TODO
            $amount_at_end_of_period['development_expenditure'] = 0;

            // 长期待摊费用  =  1801 长期待摊费用
            if(in_array($accounting_entry['accounting_title_serial_number'], array(1801))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['long_term_deferred_expense'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['long_term_deferred_expense'] -= $accounting_entry['credit_amount'];
                }

            }


            // 其它非流动资产 TODO
            $amount_at_end_of_period['other_non_current_assets'] = 0;


            // 短期借款 = 2001 短期借款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2001))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['short_term_loans'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['short_term_loans'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应付票据 = 2201 应付票据
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2201))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['notes_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['notes_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应付账款 = 2202 应付账款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2202))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['accounts_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['accounts_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 预收账款 = 2203 预收账款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2203))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['advance_from_customers'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['advance_from_customers'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应付职工薪酬  =  2211 应付职工薪酬
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2211))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['payroll_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['payroll_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应交税费 = 22210101 应交税费_应交增值税_进项税额+22210102 应交税费_应交增值税_销项税额的抵减+22210103 应交税费_应交增值税_已交税金+22210104 应交税费_应交增值税_转出未交增值税+22210105 应交税费_应交增值税_减免税款+22210106 应交税费_应交增值税_出口抵减内销产品应纳税额
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2221, 22210101, 22210102, 22210103, 22210104, 22210105, 22210106))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['taxes_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['taxes_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应付利息 = 2232 应付利息
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2232))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['interest_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['interest_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 应付利润 = 2232 应付利润
            // if(in_array($accounting_entry['accounting_title_serial_number'], array(2232))){

            //     // 该会计分录在借方
            //     if($accounting_entry['type'] == 1){

            //         $amount_at_end_of_period['profit_payable'] += $accounting_entry['debit_amount'];
            //     }
            //     // 在贷方
            //     else{

            //         $amount_at_end_of_period['profit_payable'] -= $accounting_entry['credit_amount'];
            //     }

            // }


            // 其他应付款  =  2241 其他应付款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2241))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['other_accounts_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['other_accounts_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 其他流动负债 TODO
            $amount_at_end_of_period['other_current_liabilities'] = 0;


            // 长期借款  =  2601 长期借款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2601))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['long_term_loans'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['long_term_loans'] -= $accounting_entry['credit_amount'];
                }

            }


            // 长期应付款  =  2801 长期应付款
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2801))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['long_term_payable'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['long_term_payable'] -= $accounting_entry['credit_amount'];
                }

            }


            // 递延收益 = 2501 递延收益
            if(in_array($accounting_entry['accounting_title_serial_number'], array(2501))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['deferred_revenue'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['deferred_revenue'] -= $accounting_entry['credit_amount'];
                }

            }

            // 其它非流动性负债 TODO
            $amount_at_end_of_period['other_non_current_liabilities'] = 0;


            // 实收资本（或股本） =  4001 实收资本
            if(in_array($accounting_entry['accounting_title_serial_number'], array(4001))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['paid_in_capital'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['paid_in_capital'] -= $accounting_entry['credit_amount'];
                }

            }


            // 资本公积 = 300201 资本公积_资本溢价+300202 资本公积_接受捐赠非现金资产准备+300206 资本公积_外币资本折算差额+300207 资本公积_其他资本公积
            if(in_array($accounting_entry['accounting_title_serial_number'], array(300201, 300202, 300206, 300207))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['capital_surplus'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['capital_surplus'] -= $accounting_entry['credit_amount'];
                }

            }



            // 盈余公积 = 4101 盈余公积
            if(in_array($accounting_entry['accounting_title_serial_number'], array(4101))){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){

                    $amount_at_end_of_period['surplus_reserves'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{

                    $amount_at_end_of_period['surplus_reserves'] -= $accounting_entry['credit_amount'];
                }

            }


            // 未分配利润   =  310415 利润分配_未分配利润
            // if(in_array($accounting_entry['accounting_title_serial_number'], array(310415))){

            //     // 该会计分录在借方
            //     if($accounting_entry['type'] == 1){

            //         $amount_at_end_of_period['retained_profits_after_appropriation'] += $accounting_entry['debit_amount'];
            //     }
            //     // 在贷方
            //     else{

            //         $amount_at_end_of_period['retained_profits_after_appropriation'] -= $accounting_entry['credit_amount'];
            //     }

            // }

            /** 获取期末数 end */



        }

        // dump($amount_at_the_beginning_of_the_year);
        // dump($amount_at_end_of_period);



        /** 年初求和 start */

        // 存货 = 原料+在产品+库存商品+周转材料
        $amount_at_the_beginning_of_the_year['inventory'] = $amount_at_the_beginning_of_the_year['raw_material'] + $amount_at_the_beginning_of_the_year['products_in_process'] + $amount_at_the_beginning_of_the_year['goods_in_stock'] + $amount_at_the_beginning_of_the_year['turnover_materials'];


        // 流动资产合计 = 货币资金+短期投资+应收票据+应收账款+预付账款+应收股利+应收利息+其他应收款+存货+其他流动资产
        $amount_at_the_beginning_of_the_year['total_current_assets'] = $amount_at_the_beginning_of_the_year['bank_and_cash'] + $amount_at_the_beginning_of_the_year['short_term_investment'] + $amount_at_the_beginning_of_the_year['notes_receivable'] + $amount_at_the_beginning_of_the_year['account_receivable'] + $amount_at_the_beginning_of_the_year['prepayment'] + $amount_at_the_beginning_of_the_year['dividend_receivable'] + $amount_at_the_beginning_of_the_year['interest_receivable'] + $amount_at_the_beginning_of_the_year['other_receivable'] + $amount_at_the_beginning_of_the_year['inventory'] + $amount_at_the_beginning_of_the_year['other_current_assets'];


        //  固定资产账面价值 = 1601 固定资产-1602 累计折旧
        $amount_at_the_beginning_of_the_year['net_value_of_fixed_assets'] = $amount_at_the_beginning_of_the_year['net_assets'] - $amount_at_the_beginning_of_the_year['accumulated_depreciation'];


        // 非流动资产合计 = 长期债券投资+长期股权投资+固定资产账面价值+在建工程+工程物资+固定资产清理+生产性生物资产+无形资产+开发支出+长期待摊费用+其他非流动资产
        $amount_at_the_beginning_of_the_year['total_non_current_assets'] = $amount_at_the_beginning_of_the_year['long_term_debt_investment'] + $amount_at_the_beginning_of_the_year['long_term_equity_investment'] + $amount_at_the_beginning_of_the_year['net_value_of_fixed_assets'] + $amount_at_the_beginning_of_the_year['construction_in_progress'] + $amount_at_the_beginning_of_the_year['construction_materials'] + $amount_at_the_beginning_of_the_year['disposal_of_fixed_assets'] + $amount_at_the_beginning_of_the_year['productive_biological_assets'] + $amount_at_the_beginning_of_the_year['intangible_assets'] + $amount_at_the_beginning_of_the_year['development_expenditure'] + $amount_at_the_beginning_of_the_year['long_term_deferred_expense'] + $amount_at_the_beginning_of_the_year['other_non_current_assets'] + $amount_at_the_beginning_of_the_year['investment_real_estate'];



        // 资产合计 = 流动资产合计+非流动资产合计
        $amount_at_the_beginning_of_the_year['total_assets'] = $amount_at_the_beginning_of_the_year['total_current_assets'] + $amount_at_the_beginning_of_the_year['total_non_current_assets'];







        // 流动负债合计 = 短期借款+应付票据+应付账款+预收账款+应付职工薪酬+应交税费+应付利息+应付利润+其他应付款+其他流动负债
        $amount_at_the_beginning_of_the_year['total_current_liability'] = $amount_at_the_beginning_of_the_year['short_term_loans'] + $amount_at_the_beginning_of_the_year['notes_payable'] + $amount_at_the_beginning_of_the_year['accounts_payable'] + $amount_at_the_beginning_of_the_year['advance_from_customers'] + $amount_at_the_beginning_of_the_year['payroll_payable'] + $amount_at_the_beginning_of_the_year['taxes_payable'] + $amount_at_the_beginning_of_the_year['interest_payable'] + $amount_at_the_beginning_of_the_year['profit_payable'] + $amount_at_the_beginning_of_the_year['other_accounts_payable'] + $amount_at_the_beginning_of_the_year['other_current_liabilities'];







        // 非流动负债合计 = 长期借款+长期应付款+递延收益+其他非流动负债
        $amount_at_the_beginning_of_the_year['total_non_current_liability'] = $amount_at_the_beginning_of_the_year['long_term_loans'] + $amount_at_the_beginning_of_the_year['long_term_payable'] + $amount_at_the_beginning_of_the_year['deferred_revenue'] + $amount_at_the_beginning_of_the_year['other_non_current_liabilities'];




        // 负债合计 = 流动负债+非流动负债
        $amount_at_the_beginning_of_the_year['total_liability'] = $amount_at_the_beginning_of_the_year['total_current_liability'] + $amount_at_the_beginning_of_the_year['total_non_current_liability'];


        //  所有者权益（或股东权益）合计 = 实收资本+资本公积+盈余公积+未分配利润
        $amount_at_the_beginning_of_the_year['total_owners_equity'] = $amount_at_the_beginning_of_the_year['paid_in_capital'] + $amount_at_the_beginning_of_the_year['capital_surplus'] + $amount_at_the_beginning_of_the_year['surplus_reserves'] + $amount_at_the_beginning_of_the_year['retained_profits_after_appropriation'];



        //  负债和所有者权益（或股东权益）总计
        $amount_at_the_beginning_of_the_year['total_liability_and_total_owners_equity'] = $amount_at_the_beginning_of_the_year['total_liability'] + $amount_at_the_beginning_of_the_year['total_owners_equity'];

        /** 年初求和 start */





        /** 期末求和 start */

        // 存货 = 原料+在产品+库存商品+周转材料
        $amount_at_end_of_period['inventory'] = $amount_at_end_of_period['raw_material'] + $amount_at_end_of_period['products_in_process'] + $amount_at_end_of_period['goods_in_stock'] + $amount_at_end_of_period['turnover_materials'];


        // 流动资产合计 = 货币资金+短期投资+应收票据+应收账款+预付账款+应收股利+应收利息+其他应收款+存货+其他流动资产
        $amount_at_end_of_period['total_current_assets'] = $amount_at_end_of_period['bank_and_cash'] + $amount_at_end_of_period['short_term_investment'] + $amount_at_end_of_period['notes_receivable'] + $amount_at_end_of_period['account_receivable'] + $amount_at_end_of_period['prepayment'] + $amount_at_end_of_period['dividend_receivable'] + $amount_at_end_of_period['interest_receivable'] + $amount_at_end_of_period['other_receivable'] + $amount_at_end_of_period['inventory'] + $amount_at_end_of_period['other_current_assets'];


        //  固定资产账面价值 = 1601 固定资产-1602 累计折旧
        $amount_at_end_of_period['net_value_of_fixed_assets'] = $amount_at_end_of_period['net_assets'] - $amount_at_end_of_period['accumulated_depreciation'];


        // 非流动资产合计 = 长期债券投资+长期股权投资+固定资产账面价值+在建工程+工程物资+固定资产清理+生产性生物资产+无形资产+开发支出+长期待摊费用+其他非流动资产+投资性房地产
        $amount_at_end_of_period['total_non_current_assets'] = $amount_at_end_of_period['long_term_debt_investment'] + $amount_at_end_of_period['long_term_equity_investment'] + $amount_at_end_of_period['net_value_of_fixed_assets'] + $amount_at_end_of_period['construction_in_progress'] + $amount_at_end_of_period['construction_materials'] + $amount_at_end_of_period['disposal_of_fixed_assets'] + $amount_at_end_of_period['productive_biological_assets'] + $amount_at_end_of_period['intangible_assets'] + $amount_at_end_of_period['development_expenditure'] + $amount_at_end_of_period['long_term_deferred_expense'] + $amount_at_end_of_period['other_non_current_assets'] + $amount_at_end_of_period['investment_real_estate'];



        // 资产合计 = 流动资产合计+非流动资产合计
        $amount_at_end_of_period['total_assets'] = $amount_at_end_of_period['total_current_assets'] + $amount_at_end_of_period['total_non_current_assets'];







        // 流动负债合计 = 短期借款+应付票据+应付账款+预收账款+应付职工薪酬+应交税费+应付利息+应付利润+其他应付款+其他流动负债
        $amount_at_end_of_period['total_current_liability'] = $amount_at_end_of_period['short_term_loans'] + $amount_at_end_of_period['notes_payable'] + $amount_at_end_of_period['accounts_payable'] + $amount_at_end_of_period['advance_from_customers'] + $amount_at_end_of_period['payroll_payable'] + $amount_at_end_of_period['taxes_payable'] + $amount_at_end_of_period['interest_payable'] + $amount_at_end_of_period['profit_payable'] + $amount_at_end_of_period['other_accounts_payable'] + $amount_at_end_of_period['other_current_liabilities'];







        // 非流动负债合计 = 长期借款+长期应付款+递延收益+其他非流动负债
        $amount_at_end_of_period['total_non_current_liability'] = $amount_at_end_of_period['long_term_loans'] + $amount_at_end_of_period['long_term_payable'] + $amount_at_end_of_period['deferred_revenue'] + $amount_at_end_of_period['other_non_current_liabilities'];




        // 负债合计 = 流动负债+非流动负债
        $amount_at_end_of_period['total_liability'] = $amount_at_end_of_period['total_current_liability'] + $amount_at_end_of_period['total_non_current_liability'];


        //  所有者权益（或股东权益）合计 = 实收资本+资本公积+盈余公积+未分配利润
        $amount_at_end_of_period['total_owners_equity'] = $amount_at_end_of_period['paid_in_capital'] + $amount_at_end_of_period['capital_surplus'] + $amount_at_end_of_period['surplus_reserves'] + $amount_at_end_of_period['retained_profits_after_appropriation'];



        //  负债和所有者权益（或股东权益）总计
        $amount_at_end_of_period['total_liability_and_total_owners_equity'] = $amount_at_end_of_period['total_liability'] + $amount_at_end_of_period['total_owners_equity'];

        /** 期末求和 start */



        /** 统计年初和期末的情况 start */


        // dump($amount_at_the_beginning_of_the_year);
        // dump($amount_at_end_of_period);
        // die();





        $result = array();
        $result['errCode'] = 0;
        $result['errMsg'] = '调用成功';
        $result['data']['amount_at_end_of_period'] = $amount_at_end_of_period;
        $result['data']['amount_at_the_beginning_of_the_year'] = $amount_at_the_beginning_of_the_year;

        return json($result);

    }

}
