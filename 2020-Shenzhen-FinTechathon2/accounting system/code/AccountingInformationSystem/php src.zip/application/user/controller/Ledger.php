<?php

namespace app\user\controller;
use app\common\controller\UserBase;
use think\Db;
use think\Model;

class Ledger extends UserBase
{
    
    protected function _initialize()
    {
        parent::_initialize();
        //$this->assign('today',date('Y-m-d',time()));
    }

    /**
     * 明细账
     * @return [type] [description]
     */
    public function subsidiary_ledger()
    {

        $all_accounting_titles = Db::table('hq_accounting_title')->select();
        return $this->fetch('subsidiary_ledger', [
            'all_accounting_titles' => $all_accounting_titles
        ]);

    }

    /**
     * 总账
     * @return [type] [description]
     */
    public function general_ledger(){
        return $this->fetch('general_ledger', []);
    }


    /**
     * 得到某个科目的明细账
     * @return [type] [description]
     */
    public function get_subsidiary_ledger()
    {


        $param = $this->request->param();


        if(!$param['accounting_title_serial_number'] || !$param['year'] || !$param['month']){

            $result = array();
            $result['errCode'] = 1;
            $result['errMsg'] = '参数不足';
            $result['data']['param'] = $param;
            
            return json($result);

        }
            


        $where = array();
        $where['a.accounting_title_serial_number'] = $param['accounting_title_serial_number'];
        $where['a.certificate_id'] = array('neq', 0);   // 排除找零生成的
        
        $where['b.year'] = $param['year'];
        $where['b.month'] = array('elt', $param['month']);




        $all_accounting_entries = Db::table('hq_accounting_entry')->alias('a')
                                                            ->join('hq_certificate b', 'a.certificate_id = b.id')
                                                            ->where($where)
                                                            ->order('certificate_number', 'asc')
                                                            ->column('a.*, b.id as certificate_id, b.certificate_number, b.year, b.month, b.day, b.total_debit_amount, b.total_credit_amount, b.tabulator, a.original_document_hash', 'a.id');


        /** 获取期初余额 start */

        // 第一个月的情况
        $beginning_balance = array();
        $beginning_balance['date'] = $param['year'] . '-' . $param['month'] . '-1';
        
        $beginning_balance['debit_amount'] = 0;    // 默认
        $beginning_balance['credit_amount'] = 0;    // 默认
        $beginning_balance['balance'] = 0;    // 默认


        // 统计month-1月的情况
        foreach($all_accounting_entries as $key => $accounting_entry){

            // 本期的统计，非本期的跳过
            if($accounting_entry['year'] == $param['year'] && $accounting_entry['month'] < $param['month']){

                // 该会计分录在借方
                if($accounting_entry['type'] == 1){
                    $beginning_balance['debit_amount'] += $accounting_entry['debit_amount'];
                    $beginning_balance['balance'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{
                    $beginning_balance['credit_amount'] += $accounting_entry['credit_amount'];
                    $beginning_balance['balance'] -= $accounting_entry['credit_amount'];
                }
                
            }



        }

        if($beginning_balance['balance'] == 0){
            $beginning_balance['side'] = '平';
        }
        else if($beginning_balance['balance'] < 0){
            $beginning_balance['side'] = '借';
        }
        else if($beginning_balance['balance'] > 0){
            $beginning_balance['side'] = '贷';
        }


        /** 获取期初余额 end */



        // 本期合计
        $total_for_the_current_period = array();
        $total_for_the_current_period['date'] = $param['year'] . '-' . $param['month'] . '-31'; // 将来修改为需要判断具体是多少天
        
        $total_for_the_current_period['balance'] = $beginning_balance['balance'];    // 默认
        $total_for_the_current_period['debit_amount'] = 0;    // 默认
        $total_for_the_current_period['credit_amount'] = 0;    // 默认


        

        /** 计算每个会计分录的借贷方向和余额 start */

        // 保存本期的所有会计分录
        $now_month_accounting_entries = array();

        foreach($all_accounting_entries as $key => $accounting_entry){

            // 本期的统计，非本期的跳过
            if($accounting_entry['year'] == $param['year'] && $accounting_entry['month'] == $param['month']){


                // 该会计分录在借方
                if($accounting_entry['type'] == 1){
                    $total_for_the_current_period['debit_amount'] += $accounting_entry['debit_amount'];
                    $total_for_the_current_period['balance'] += $accounting_entry['debit_amount'];
                }
                // 在贷方
                else{
                    $total_for_the_current_period['credit_amount'] += $accounting_entry['credit_amount'];
                    $total_for_the_current_period['balance'] -= $accounting_entry['credit_amount'];
                }

                $all_accounting_entries[$key]['balance'] = $total_for_the_current_period['balance'];

                // 判断此时的借贷方向
                if($all_accounting_entries[$key]['balance'] == 0){
                    $all_accounting_entries[$key]['side'] = '平';
                }
                else if($all_accounting_entries[$key]['balance'] < 0){
                    $all_accounting_entries[$key]['side'] = '借';
                }
                else if($all_accounting_entries[$key]['balance'] > 0){
                    $all_accounting_entries[$key]['side'] = '贷';
                }


                // 保存到结果数组中
                $now_month_accounting_entries[] = $all_accounting_entries[$key];
                
                
            }



        }


        // 判断本期累计的借贷方向
        if($total_for_the_current_period['balance'] < 0){
            $total_for_the_current_period['side'] = '借';
        }
        else if($total_for_the_current_period['balance'] > 0){
            $total_for_the_current_period['side'] = '贷';
        }
        else{
            $total_for_the_current_period['side'] = '平';
        }


        /** 计算每个会计分录的借贷方向和余额 end */



        // 本年累计
        $accumulated_in_this_year = array();
        $accumulated_in_this_year['date'] = $param['year'] . '-' . $param['month'] . '-31'; // 将来修改为需要判断具体是多少天
        
        $accumulated_in_this_year['balance'] = $total_for_the_current_period['balance'];    // 默认
        $accumulated_in_this_year['debit_amount'] = $beginning_balance['debit_amount'] + $total_for_the_current_period['debit_amount'];  // 期初加期末
        $accumulated_in_this_year['credit_amount'] = $beginning_balance['credit_amount'] + $total_for_the_current_period['credit_amount'];  // 期初加期末


        // 判断本年累计的借贷方向
        if($accumulated_in_this_year['balance'] < 0){
            $accumulated_in_this_year['side'] = '借';
        }
        else if($accumulated_in_this_year['balance'] > 0){
            $accumulated_in_this_year['side'] = '贷';
        }
        else{
            $accumulated_in_this_year['side'] = '平';
        }

        
        
        

        $result = array();
        $result['errCode'] = 0;
        $result['errMsg'] = '调用成功';
        $result['data']['beginning_balance'] = $beginning_balance;
        $result['data']['now_month_accounting_entries'] = $now_month_accounting_entries;
        $result['data']['total_for_the_current_period'] = $total_for_the_current_period;
        $result['data']['accumulated_in_this_year'] = $accumulated_in_this_year;
        
        return json($result);

    }

}