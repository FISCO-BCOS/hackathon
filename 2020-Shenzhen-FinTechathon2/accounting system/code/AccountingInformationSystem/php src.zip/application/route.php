<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\Route;
//use think\Db;
//$domain = db('domain')->select();
//foreach ($domain as $r){
//    Route::domain($r['domain'],$r['controller'].'?userid='.$r['userid']);
//}
Route::rule('lists/:id','index/index/lists','get|post',['ext'=>'html']);
Route::rule('page_lists/:id','index/index/page','get|post',['ext'=>'html']);
Route::rule('product_lists/:id','index/index/product','get|post',['ext'=>'html']);
Route::rule('show/:id','index/index/show','get|post',['ext'=>'html']);
Route::rule('page_show/:id','index/index/page_show','get|post',['ext'=>'html']);
Route::rule('product_show/:id','index/index/product_show','get|post',['ext'=>'html']);
return [
//    '__domain__'=>[
//    
//        'hqss'      => 'index?userid=1',
//        'abcd'      => 'index?userid=2',
//        //'hq.dingshibao.com'      => 'index?userid=3',
//    ],
    'admin$' => 'admin/index/login', // 后台入口地址
];
