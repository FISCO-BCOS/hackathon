<?php
/**
 * Created by 六诺科技.
 * User: 黄青
 * Date: 2019/2/12
 * Time: 22:36
 */
return [
    'qiniu'  => [
        'type'      => '0',//0 本地存储，1七牛上传
        'upak'      => '',
        'upsk'      => '',
        'upbucket'  => '',
        'updomain'  => '', 
    ],
    //微信参数
    'weixin'  => [
        'appid'      => '',
        'appsecret'      => '',
    ],
    //腾讯云短信
    'qcloud_sms'  => [
        'appid'      => '',
        'appkey'      => '',
    ],
];
