<?php

namespace app\common\model;

use think\Model;

class Ad extends Model
{
    protected $type = [

    ];
    protected function base($query)
    {
        $query->where('userid', session('user_auth.user_id'));
    }
}