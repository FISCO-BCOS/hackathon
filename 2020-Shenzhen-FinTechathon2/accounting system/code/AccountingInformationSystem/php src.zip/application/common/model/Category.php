<?php

namespace app\common\model;
use think\Model;

class Category extends Model
{
    protected function _initialize()
    {
        parent::_initialize();
        
    }
    protected $type = [

    ];
    protected function base($query)
    {
        //$query->where('userid', session('user_auth.user_id'));
    }
    static function geturl($id) {
        !config('website_status') && die(config('colse_explain'));
        $config = cache('db_config_data');
        if (!$config) {
            $config = [];
            foreach (model('config')->select() as $v) {
                $config[$v['group']][$v['name']] = $v['value'];
            }
            cache('db_config_data', $config);
        }
        config($config);
        $col = self::where(['id'=>$id])->find();
        $domain = model('domain')->where(['userid'=>session('user_auth.user_id')])->find();
        if($domain){
            $domain = 'http://'.$domain['domain'];
        }else{
            $domain = '';
        }
        //获取规则
        if(config('website.cat_rewrite')=='0'){//
            $url = $domain.'/index/index/lists/?id='.$col['id'];
        }else if(config('website.cat_rewrite')=='1'){
            $url = $domain.'/lists/'.$col['catdir'].'.html';
        }else{
            $url = $domain.'/lists/'.$col['id'].'.html';
        }
        self::where(['id'=>$id])->update(['url'=>$url]);
        return $url;
    }
}