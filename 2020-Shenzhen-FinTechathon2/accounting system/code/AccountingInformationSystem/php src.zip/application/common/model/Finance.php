<?php

namespace app\common\model;
use think\Model;
use think\Request;

class Finance extends Model
{
    protected $autoWriteTimestamp = true;
    protected $type = [
       
    ];
    protected function base($query)
    {
        $request= Request::instance();
        $query->where('sid', ShopId());
        //不显示回收站
        if($request->controller() != 'Recovery'){
            $query->where('delete_time','0');
        }
    }
    protected function _initialize()
    {
        parent::_initialize();
        
    }
    
}