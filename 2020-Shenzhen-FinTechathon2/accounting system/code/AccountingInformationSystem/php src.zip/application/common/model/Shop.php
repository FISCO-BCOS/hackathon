<?php

namespace app\common\model;

use think\Model;
use think\Request;

class Shop extends Model
{
    protected $autoWriteTimestamp = true;
    protected $type = [
        'exp_time' => 'timestamp:Y-m-d',
    ];
    protected function base($query)
    {
        //$query->where('userid', session('user_auth.user_id'));
        $request= Request::instance();
        //不显示回收站
        if($request->controller() != 'Recovery'){
            $query->where('delete_time','0');
        }
    }
    protected function _initialize()
    {
        parent::_initialize();
        
    }
    
}