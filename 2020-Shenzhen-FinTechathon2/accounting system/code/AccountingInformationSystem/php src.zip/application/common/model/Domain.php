<?php

namespace app\common\model;

use think\Model;

class Domain extends Model
{

}