<?php

namespace app\common\model;

use think\Model;

class AuthRule extends Model
{

}