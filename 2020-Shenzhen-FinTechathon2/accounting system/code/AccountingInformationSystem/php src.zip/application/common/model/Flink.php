<?php

namespace app\common\model;

use think\Model;

class Flink extends Model
{
    protected $type = [

    ];
    protected function base($query)
    {
        $query->where('userid', session('user_auth.user_id'));
    }
    protected function _initialize()
    {
        parent::_initialize();
        
    }
}