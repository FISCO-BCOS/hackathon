<?php

namespace app\common\model;
use think\Request;
use think\Model;

class UserAuthGroup extends Model
{
    protected function base($query)
    {
        $request= Request::instance();
        if($request->module() != 'admin'){
            $query->where('sid', ShopId());
        }
        //不显示回收站
        if($request->controller() != 'Recovery'){
            $query->where('delete_time','0');
        }
    }
}