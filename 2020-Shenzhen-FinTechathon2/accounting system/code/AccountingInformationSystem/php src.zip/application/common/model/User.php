<?php

namespace app\common\model;
use think\Request;
use think\Model;

class User extends Model
{
    protected $autoWriteTimestamp = true;
    
    protected function base($query)
    {
        $request= Request::instance();
        if($request->module() != 'admin' and $request->action() != 'login'){
            $query->where('sid', ShopId());
        }
        //不显示回收站
        if($request->controller() != 'Recovery'){
            $query->where('delete_time','0');
        }
    }
    public function setPasswordAttr($value)
    {
        return md5($value);
    }
    public function userAuthGroupAccess()
    {
        return $this->belongsTo('userAuthGroupAccess', 'id', 'uid')->bind('group_id');
    }

    public function userAuthGroup()
    {
        return $this->belongsTo('userAuthGroup', 'group_id', 'id')->bind('name');
    }
    
}