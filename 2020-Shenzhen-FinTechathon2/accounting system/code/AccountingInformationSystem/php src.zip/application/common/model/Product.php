<?php

namespace app\common\model;

use think\Model;

class Product extends Model
{
    protected $type = [

    ];
    protected function base($query)
    {
        $query->where('userid', session('user_auth.user_id'));
    }
    protected $autoWriteTimestamp = true;

    public function setPhotoAttr($value)
    {
        return serialize($value);
    }

    public function getPhotoAttr($value)
    {
        return unserialize($value);
    }

    public function setContentAttr($value)
    {
        return htmlspecialchars_decode($value);
    }

    public function category()
    {
        return $this->belongsTo('category', 'cid', 'id')->bind('category_name');
    }
    static function geturl($id) {
        !config('website_status') && die(config('colse_explain'));
        $config = cache('db_config_data');
        if (!$config) {
            $config = [];
            foreach (model('config')->select() as $v) {
                $config[$v['group']][$v['name']] = $v['value'];
            }
            cache('db_config_data', $config);
        }
        config($config);
        $col = self::where(['id'=>$id])->find();
        //获取规则
        if(config('website.art_rewrite')=='1'){//
            $url = '/product_show/'.$col['id'].'.html';
        }else{
            $url = '/index/product/show?id='.$col['id'];
        }
        self::where(['id'=>$id])->update(['url'=>$url]);
        return $url;
    }
}