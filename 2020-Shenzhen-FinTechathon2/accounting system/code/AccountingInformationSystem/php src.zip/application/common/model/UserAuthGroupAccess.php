<?php

namespace app\common\model;

use think\Model;

class UserAuthGroupAccess extends Model
{
    public function UserAuthGroup()
    {
        return $this->belongsTo('UserAuthGroup', 'group_id', 'id')->bind('rules');
    }
}