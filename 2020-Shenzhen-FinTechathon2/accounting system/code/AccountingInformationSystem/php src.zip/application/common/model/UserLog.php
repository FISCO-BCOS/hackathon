<?php

namespace app\common\model;
use think\Request;
use think\Model;

class UserLog extends Model
{
    protected function base($query)
    {
        $request= Request::instance();
        if($request->module() != 'admin'){
            $query->where('sid', ShopId());
        }
    }
}