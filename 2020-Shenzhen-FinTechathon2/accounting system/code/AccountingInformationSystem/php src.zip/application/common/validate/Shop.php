<?php

namespace app\common\validate;
use think\Validate;

class Shop extends Validate
{
    protected $rule = [
        'name'   => 'require',
        'simplename' => 'require',
        'exp_time' => 'require',
    ];

    protected $message = [
        'name'   => '学校全称不能为空',
        'simplename' => '学校简称不能为空',
        'exp_time' => '过期时间不能为空',
    ];
}
