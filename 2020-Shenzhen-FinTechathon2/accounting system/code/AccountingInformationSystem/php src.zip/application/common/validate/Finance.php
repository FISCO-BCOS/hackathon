<?php

namespace app\common\validate;
use think\Validate;

class Finance extends Validate
{
    protected $rule = [
        'price'   => 'require',
    ];

    protected $message = [
        'price.require' => '金额不能为空',
    ];
}
