<?php

namespace app\common\validate;

use think\Validate;

class UserAuthGroup extends Validate
{
    protected $rule = [

    ];

    protected $message = [
        //'username.require' => '用户名不能为空',

    ];
}
