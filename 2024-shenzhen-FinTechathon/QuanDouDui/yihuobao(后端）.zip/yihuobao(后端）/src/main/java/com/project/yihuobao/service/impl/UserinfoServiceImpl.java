package com.project.yihuobao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.yihuobao.VO.UserInfoVO;
import com.project.yihuobao.VO.UserVO;
import com.project.yihuobao.entity.Adminuser;
import com.project.yihuobao.entity.Userinfo;
import com.project.yihuobao.form.Register;
import com.project.yihuobao.mapper.AdminuserMapper;
import com.project.yihuobao.mapper.UserinfoMapper;
import com.project.yihuobao.service.AdminuserService;
import com.project.yihuobao.service.UserinfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author admin
 * @since 2024-11-18
 */
@Service
public class UserinfoServiceImpl extends ServiceImpl<UserinfoMapper, Userinfo> implements UserinfoService {
     @Autowired
     private UserinfoMapper userinfoMapper;
     @Autowired
     private AdminuserMapper adminuserMapper;



    @Override
     public boolean registers(Register register){
         LambdaQueryWrapper<Userinfo> qw = new LambdaQueryWrapper<Userinfo>()
                 .eq(Userinfo::getPhonenumber, register.getPhonenumber());
         Userinfo userinfo = this.userinfoMapper.selectOne(qw);
         if(userinfo != null){
             return false;
         }else{
             Userinfo userinfo1 = new Userinfo();
             userinfo1.setName(register.getName());
             userinfo1.setFirmname(register.getFirmname());
             userinfo1.setType(register.getType());
             userinfo1.setPhonenumber(register.getPhonenumber());
             userinfo1.setEmail(register.getEmail());
             userinfo1.setKey(register.getKey());
             int insert1 = this.userinfoMapper.insert(userinfo1);

             Adminuser adminuser = new Adminuser();
             adminuser.setUsername(register.getName());
             adminuser.setUserkey(register.getKey());
             adminuser.setPublickey(register.getKey());
             int insert2 = this.adminuserMapper.insert(adminuser);

             if(insert1 !=1 ) return false;
             if(insert2 !=1 ) return false;
         }
         return true;
     }

     @Override
    public List<UserInfoVO> getuser(){
         QueryWrapper<Userinfo> queryWrapper = new QueryWrapper<>();
         List<Userinfo> userinfoList = this.userinfoMapper.selectList(queryWrapper);
         List<UserInfoVO> userInfoVOList = new ArrayList<>();
         for(Userinfo userinfo : userinfoList){
             UserInfoVO userInfoVO = new UserInfoVO();
             userInfoVO.setName(userinfo.getName());
             userInfoVO.setFirmname(userinfo.getFirmname());
             userInfoVO.setPhonenumber(userinfo.getPhonenumber());
             userInfoVO.setEmail(userinfo.getEmail());
             userInfoVO.setType(userinfo.getType());
             userInfoVO.setKey(userinfo.getKey());
             userInfoVOList.add(userInfoVO);
         }
         return userInfoVOList;
     }
}

