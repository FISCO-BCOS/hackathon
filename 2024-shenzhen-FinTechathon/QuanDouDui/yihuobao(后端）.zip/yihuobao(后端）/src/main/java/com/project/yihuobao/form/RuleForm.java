package com.project.yihuobao.form;

import lombok.Data;

import java.util.List;
import java.util.Map;


@Data

public class RuleForm {
    private List<String> type;
    private String goodsnumber;
    private String companyname;
    private String represon;
    private String phone;
    private String buyplace;
    private String buyday;
    private Integer stayday;
    private String stayamout;
    private String buyerstone;
    private String buyernumber;
    private String numberamout;
    private String processplace;
    private String bag;
    private String processerstone;
    private String processdata;
    private String beginplace;
    private String endingplace;
    private String ice;
    private String processpreson;
    private String buyer;
    private String driver;
    private String drivernumber;
    private String seedpreson;
    private String seedstone;
    private String seed;
    private String seson;
    private String nomal;
    private String goodsname;
    private String username;
    private String key;
}
