package com.project.yihuobao.service;

import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.VO.UserInfoVO;
import com.project.yihuobao.entity.Userinfo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.yihuobao.form.Register;
import com.project.yihuobao.util.ResultVOutil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author admin
 * @since 2024-11-18
 */
public interface UserinfoService extends IService<Userinfo> {
  public boolean registers(Register register);
  public List<UserInfoVO> getuser();
}
