package com.project.yihuobao.service;

import com.project.yihuobao.VO.GoodslistVO;
import com.project.yihuobao.VO.ReportVO;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.entity.Reports;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.yihuobao.form.Judge;
import com.project.yihuobao.form.LoginForm;
import com.project.yihuobao.form.RuleForm;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author admin
 * @since 2024-09-02
 */
public interface ReportsService extends IService<Reports> {
    public boolean judgement(Judge judge);
    public List<ReportVO> reports();
}