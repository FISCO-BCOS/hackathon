package com.project.yihuobao.VO;

import lombok.Data;

@Data
public class UserInfoVO {
    private String name;
    private String firmname;
    private String phonenumber;
    private String email;
    private String type;
    private String key;
}
