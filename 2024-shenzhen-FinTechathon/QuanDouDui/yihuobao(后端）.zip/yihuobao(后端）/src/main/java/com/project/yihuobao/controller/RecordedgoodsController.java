package com.project.yihuobao.controller;


import com.project.yihuobao.VO.Blockidea;
import com.project.yihuobao.VO.ReportVO;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.service.RecordedgoodsService;
import com.project.yihuobao.util.ResultVOutil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author admin
 * @since 2024-11-17
 */
@RestController
@RequestMapping("/Recordedgoods")
public class RecordedgoodsController {
//    @Autowired
//    private RecordedgoodsService recordedgoodsService;
//    @GetMapping("/Blockrecord/{goodsnumber}")
//    public ResultVO getchain(@PathVariable("goodsnumber") String goodsnumber){
//        List<Blockidea> getreports = this.recordedgoodsService.getchain(goodsnumber);
//        return ResultVOutil.success(getreports);
//    }
}

