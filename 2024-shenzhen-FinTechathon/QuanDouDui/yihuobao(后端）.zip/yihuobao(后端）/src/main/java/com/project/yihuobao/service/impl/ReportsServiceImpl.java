package com.project.yihuobao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.yihuobao.VO.GoodslistVO;
import com.project.yihuobao.VO.ReportVO;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.entity.Adminuser;
import com.project.yihuobao.entity.Goodslist;
import com.project.yihuobao.entity.Reports;
import com.project.yihuobao.form.Judge;
import com.project.yihuobao.form.RuleForm;
import com.project.yihuobao.mapper.GoodslistMapper;
import com.project.yihuobao.mapper.ReportsMapper;
import com.project.yihuobao.service.ReportsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.yihuobao.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author admin
 * @since 2024-09-02
 */
@Service
public class ReportsServiceImpl extends ServiceImpl<ReportsMapper, Reports> implements ReportsService {
    @Autowired
    private GoodslistMapper goodslistMapper;
    @Autowired
    private ReportsMapper reportsMapper;

    @Override
    public boolean judgement(Judge judge) {
        //1.判断商品码是否存在
        QueryWrapper<Goodslist> qw = new QueryWrapper<>();
        qw.eq("goodsnumber", judge.getGoodsnumber());
        Goodslist goodslist = this.goodslistMapper.selectOne(qw);
        if (goodslist == null) {
            return false;
        } else {
            Reports reports = new Reports();
            reports.setGoodsnumber(judge.getGoodsnumber());
            reports.setGoodsname(judge.getGoodsname());
            reports.setCompanyname(judge.getCompanyname());
            reports.setRepreson(judge.getRepreson());
            reports.setPhone(judge.getPhone());
            reports.setCreatedAt(CommonUtil.createDate());
            int insert = this.reportsMapper.insert(reports);
            if (insert != 1) return false;
        }
        return true;
    }
    @Override
    public List<ReportVO> reports() {
        QueryWrapper<Reports> queryWrapper = new QueryWrapper<>();
        //   queryWrapper.eq("publickey",publickey);
        List<Reports> reportsList = this.reportsMapper.selectList(queryWrapper);
        List<ReportVO> reportVOList = new ArrayList<>();
        for (Reports reports : reportsList) {
            ReportVO reportVO = new ReportVO();
            reportVO.setGoodsnumber(reports.getGoodsnumber());
            reportVO.setGoodsname(reports.getGoodsname());
            reportVO.setCompanyname(reports.getCompanyname());
            reportVO.setRepreson(reports.getRepreson());
            reportVO.setPhone(reports.getPhone());
            reportVO.setCreatat(reports.getCreatedAt());
            reportVOList.add(reportVO);
        }
        return reportVOList;
    }
}