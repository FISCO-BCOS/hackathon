package com.project.yihuobao.service;

import com.project.yihuobao.VO.Mcrecord;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.VO.UserVO;
import com.project.yihuobao.entity.Adminuser;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.yihuobao.form.LoginForm;

import java.util.List;

/**
 * <p>
 * 管理用户表 服务类
 * </p>
 *
 * @author admin
 * @since 2024-07-21
 */
public interface AdminuserService extends IService<Adminuser> {
  public ResultVO login(LoginForm loginForm);
  public List<UserVO> userlist(String username,String userkey);
}
