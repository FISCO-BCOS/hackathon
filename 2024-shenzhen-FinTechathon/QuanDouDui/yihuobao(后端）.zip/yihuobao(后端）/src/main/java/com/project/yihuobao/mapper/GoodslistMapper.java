package com.project.yihuobao.mapper;

import com.project.yihuobao.entity.Goodslist;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author admin
 * @since 2024-08-01
 */
public interface GoodslistMapper extends BaseMapper<Goodslist> {

}
