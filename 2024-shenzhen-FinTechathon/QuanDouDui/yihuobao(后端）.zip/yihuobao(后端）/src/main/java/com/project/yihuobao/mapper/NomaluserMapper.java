package com.project.yihuobao.mapper;

import com.project.yihuobao.entity.Nomaluser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 普通用户表 Mapper 接口
 * </p>
 *
 * @author admin
 * @since 2024-07-22
 */
public interface NomaluserMapper extends BaseMapper<Nomaluser> {

}
