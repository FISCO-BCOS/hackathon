package com.project.yihuobao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.yihuobao.VO.GoodslistVO;
import com.project.yihuobao.VO.Mcrecord;
import com.project.yihuobao.entity.Adminuser;
import com.project.yihuobao.entity.Goodslist;
import com.project.yihuobao.form.RuleForm;
import com.project.yihuobao.mapper.AdminuserMapper;
import com.project.yihuobao.mapper.GoodslistMapper;
import com.project.yihuobao.service.GoodslistService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.yihuobao.util.CommonUtil;
import com.project.yihuobao.util.IOUtil;
import lombok.SneakyThrows;
import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author admin
 * @since 2024-07-30
 */
@Service
public class GoodslistServiceImpl extends ServiceImpl<GoodslistMapper, Goodslist> implements GoodslistService {
    @Autowired
    private GoodslistMapper goodslistMapper;
    @Autowired
    private AdminuserMapper adminuserMapper;
    public final String configFile = "src/main/resources/config-example.toml";
    @Override
    public boolean upchain(GoodslistVO goodslistVO) throws Exception {

        // 初始化BcosSDK对象
        BcosSDK sdk = BcosSDK.build("src/main/resources/config-example.toml");
        // 获取Client对象，此处传入的群组ID为1
        Client client = sdk.getClient(Integer.valueOf(1));
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = client.getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, keyPair, "src/main/resources/abi/", "src/main/resources/bin/");

        List<Object> params1 = new ArrayList<>();
        params1.add(goodslistVO.getGoodsnumber());
        params1.add(goodslistVO.getGoodsname());
        TransactionResponse transactionResponse1 = transactionProcessor.sendTransactionAndGetResponse("0xaff2fc5de75fa2aa4a58bd3361af9a3586d1b428", IOUtil.readResourceAsString("abi/Creatrecord.abi"), "addGoods",params1);
//
        List<Object> params2 = new ArrayList<>();
        params2.add(goodslistVO.getGoodsnumber());
        params2.add(goodslistVO.getBag());
        TransactionResponse transactionResponse2 = transactionProcessor.sendTransactionAndGetResponse("0xb9b04425b63f3ae975b111e6f8d0b711a4f69b5b", IOUtil.readResourceAsString("abi/bag.abi"), "addGoods",params2);

        List<Object> params3 = new ArrayList<>();
        params3.add(goodslistVO.getGoodsnumber());
        params3.add(goodslistVO.getBeginplace());
        TransactionResponse transactionResponse3 = transactionProcessor.sendTransactionAndGetResponse("0x02bce2d2ac0209bd810ad866502d808464e33954", IOUtil.readResourceAsString("abi/beginplace.abi"), "addGoods",params3);
//
        List<Object> params4 = new ArrayList<>();
        params4.add(goodslistVO.getGoodsnumber());
        params4.add(goodslistVO.getBuyday());
        TransactionResponse transactionResponse4 = transactionProcessor.sendTransactionAndGetResponse("0x28880e4a1cba43f81da3f7ae06345a0667df98e3", IOUtil.readResourceAsString("abi/buyday.abi"), "addGoods",params4);
//
        List<Object> params5 = new ArrayList<>();
        params5.add(goodslistVO.getGoodsnumber());
        params5.add(goodslistVO.getBuyer());
        TransactionResponse transactionResponse5 = transactionProcessor.sendTransactionAndGetResponse("0x9bc226df49f260d40ce45eb54b5467ead3de6e66", IOUtil.readResourceAsString("abi/buyer.abi"), "addGoods",params5);
//
        List<Object> params6 = new ArrayList<>();
        params6.add(goodslistVO.getGoodsnumber());
        params6.add(goodslistVO.getBuyernumber());
        TransactionResponse transactionResponse6 = transactionProcessor.sendTransactionAndGetResponse("0x2ec3b395746e602b3e5854b39c0098adcfcbcef7", IOUtil.readResourceAsString("abi/buyernumber.abi"), "addGoods",params6);
////
        List<Object> params7 = new ArrayList<>();
        params7.add(goodslistVO.getGoodsnumber());
        params7.add(goodslistVO.getBuyerstone());
        TransactionResponse transactionResponse7 = transactionProcessor.sendTransactionAndGetResponse("0x48459e796776cbd58b816526e1a967541a102c72", IOUtil.readResourceAsString("abi/buyerstone.abi"), "addGoods",params7);
//
        List<Object> params8 = new ArrayList<>();
        params8.add(goodslistVO.getGoodsnumber());
        params8.add(goodslistVO.getBuyplace());
        TransactionResponse transactionResponse8 = transactionProcessor.sendTransactionAndGetResponse("0x8e12e7dd7093c28a4b29ac7b1506a5d9dda0b1a4", IOUtil.readResourceAsString("abi/buyplace.abi"), "addGoods",params8);
//
        List<Object> params9 = new ArrayList<>();
        params9.add(goodslistVO.getGoodsnumber());
        params9.add(goodslistVO.getDriver());
        TransactionResponse transactionResponse9 = transactionProcessor.sendTransactionAndGetResponse("0x52c0e7116377cce76a556bbd68f2917d467f9629", IOUtil.readResourceAsString("abi/driver.abi"), "addGoods",params9);
//
        List<Object> params10 = new ArrayList<>();
        params10.add(goodslistVO.getGoodsnumber());
        params10.add(goodslistVO.getDrivernumber());
        TransactionResponse transactionResponse10 = transactionProcessor.sendTransactionAndGetResponse("0x08575c92844adf8d6f57fc333687200622667004", IOUtil.readResourceAsString("abi/drivernumber.abi"), "addGoods",params10);
////
        List<Object> params11 = new ArrayList<>();
        params11.add(goodslistVO.getGoodsnumber());
        params11.add(goodslistVO.getEndingplace());
        TransactionResponse transactionResponse11 = transactionProcessor.sendTransactionAndGetResponse("0x5563d18cab26940ee7439aba1233822caa76e11c", IOUtil.readResourceAsString("abi/endingplace.abi"), "addGoods",params11);
//
        List<Object> params12 = new ArrayList<>();
        params12.add(goodslistVO.getGoodsnumber());
        params12.add(goodslistVO.getIce());
        TransactionResponse transactionResponse12 = transactionProcessor.sendTransactionAndGetResponse("0xa1074f8d328a40f0d13ac3c866b961e34a712f4e", IOUtil.readResourceAsString("abi/ice.abi"), "addGoods",params12);

        List<Object> params13 = new ArrayList<>();
        params13.add(goodslistVO.getGoodsnumber());
        params13.add(goodslistVO.getNomal());
        TransactionResponse transactionResponse13 = transactionProcessor.sendTransactionAndGetResponse("0x1e4753d5f0ffbbfee3f1732cc9917309044d9266", IOUtil.readResourceAsString("abi/nomal.abi"), "addGoods",params13);

        List<Object> params14 = new ArrayList<>();
        params14.add(goodslistVO.getGoodsnumber());
        params14.add(goodslistVO.getNumberamout());
        TransactionResponse transactionResponse14 = transactionProcessor.sendTransactionAndGetResponse("0xf348eeac06baf76e8c016eaf8c27088b5c5d334c", IOUtil.readResourceAsString("abi/numberamount.abi"), "addGoods",params14);

        List<Object> params15 = new ArrayList<>();
        params15.add(goodslistVO.getGoodsnumber());
        params15.add(goodslistVO.getProcessdata());
        TransactionResponse transactionResponse15 = transactionProcessor.sendTransactionAndGetResponse("0xbe69339256de96fd547f6fe088a5506f86e4badd", IOUtil.readResourceAsString("abi/processdata.abi"), "addGoods",params15);
//
        List<Object> params16 = new ArrayList<>();
        params16.add(goodslistVO.getGoodsnumber());
        params16.add(goodslistVO.getProcesserstone());
        TransactionResponse transactionResponse16 = transactionProcessor.sendTransactionAndGetResponse("0xf9a79fa047f625daeb93bcfd9e745533451c359b", IOUtil.readResourceAsString("abi/processerstone.abi"), "addGoods",params16);

        List<Object> params17 = new ArrayList<>();
        params17.add(goodslistVO.getGoodsnumber());
        params17.add(goodslistVO.getProcessplace());
        TransactionResponse transactionResponse17 = transactionProcessor.sendTransactionAndGetResponse("0xec98be71974c86e91e0ab5ea5c1ad0e488e63059", IOUtil.readResourceAsString("abi/processplace.abi"), "addGoods",params17);

        List<Object> params18 = new ArrayList<>();
        params18.add(goodslistVO.getGoodsnumber());
        params18.add(goodslistVO.getProcesspreson());
        TransactionResponse transactionResponse18 = transactionProcessor.sendTransactionAndGetResponse("0x66ad0a2fb987cd5bfa93b27b5b7967aac6182a00", IOUtil.readResourceAsString("abi/processpreson.abi"), "addGoods",params18);
//
        List<Object> params19 = new ArrayList<>();
        params19.add(goodslistVO.getGoodsnumber());
        params19.add(goodslistVO.getSeed());
        TransactionResponse transactionResponse19 = transactionProcessor.sendTransactionAndGetResponse("0x9bde1a8c860ee96404d7bf919d31a0360b7ba9a4", IOUtil.readResourceAsString("abi/seed.abi"), "addGoods",params19);

        List<Object> params20 = new ArrayList<>();
        params20.add(goodslistVO.getGoodsnumber());
        params20.add(goodslistVO.getSeedpreson());
        TransactionResponse transactionResponse20 = transactionProcessor.sendTransactionAndGetResponse("0xbe557585d0ebafdf78a9f07fb49e74a8a1e0b21b", IOUtil.readResourceAsString("abi/seedpreson.abi"), "addGoods",params20);
//
        List<Object> params21 = new ArrayList<>();
        params21.add(goodslistVO.getGoodsnumber());
        params21.add(goodslistVO.getSeedstone());
        TransactionResponse transactionResponse21 = transactionProcessor.sendTransactionAndGetResponse("0x353c99ab6f992e4295afdf81b7986360fc224b00", IOUtil.readResourceAsString("abi/seedstone.abi"), "addGoods",params21);

        List<Object> params22 = new ArrayList<>();
        params22.add(goodslistVO.getGoodsnumber());
        params22.add(goodslistVO.getSeson());
        TransactionResponse transactionResponse22 = transactionProcessor.sendTransactionAndGetResponse("0xeaa23fa67ba590fe8c5645b076f410a3cc913eda", IOUtil.readResourceAsString("abi/seson.abi"), "addGoods",params22);

        List<Object> params23 = new ArrayList<>();
        params23.add(goodslistVO.getGoodsnumber());
        params23.add("14");
        TransactionResponse transactionResponse23 = transactionProcessor.sendTransactionAndGetResponse("0x1a1311ac1b76c01447bbd5fbb49d5765f6189314", IOUtil.readResourceAsString("abi/stayday.abi"), "addGoods",params23);
        QueryWrapper<Goodslist> qw=new QueryWrapper<>();
        qw.eq("goodsnumber",goodslistVO.getGoodsnumber());
        Goodslist goodslist=this.goodslistMapper.selectOne(qw);
        goodslist.setAfirm(1);
        return true;
    }
        public boolean create(RuleForm ruleForm){
        //1.判断商品码是否存在
        QueryWrapper<Adminuser> qw =new QueryWrapper<>();
        qw.eq("publickey",ruleForm.getKey());
        Adminuser adminuser=this.adminuserMapper.selectOne(qw);
                if(adminuser==null) {
                    return false;
                }else {
                    Goodslist goodslist = new Goodslist();
                    goodslist.setGoodsnumber(ruleForm.getGoodsnumber());
                    goodslist.setCompanyname(ruleForm.getCompanyname());
                    goodslist.setRepreson(ruleForm.getRepreson());
                    goodslist.setPhone(ruleForm.getPhone());
                    goodslist.setBuyplace(ruleForm.getBuyplace());
                    goodslist.setPublickey(ruleForm.getKey());
                    goodslist.setBuyday(ruleForm.getBuyday());
                    goodslist.setStayday(ruleForm.getStayday());
                    goodslist.setStayamout(ruleForm.getStayamout());
                    goodslist.setBuyerstone(ruleForm.getBuyerstone());
                    goodslist.setBuyernumber(ruleForm.getBuyernumber());
                    goodslist.setNumberamout(ruleForm.getNumberamout());
                    goodslist.setProcessplace(ruleForm.getProcessplace());
                    goodslist.setBag(ruleForm.getBag());
                    goodslist.setProcesserstone(ruleForm.getProcesserstone());
                    goodslist.setProcessdata(ruleForm.getProcessdata());
                    goodslist.setBeginplace(ruleForm.getBeginplace());
                    goodslist.setEndingplace(ruleForm.getEndingplace());
                    goodslist.setIce(ruleForm.getIce());
                    goodslist.setProcesspreson(ruleForm.getProcesspreson());
                    goodslist.setBuyer(ruleForm.getBuyer());
                    goodslist.setDriver(ruleForm.getDriver());
                    goodslist.setDrivernumber(ruleForm.getDrivernumber());
                    goodslist.setSeedpreson(ruleForm.getSeedpreson());
                    goodslist.setSeedstone(ruleForm.getSeedstone());
                    goodslist.setSeed(ruleForm.getSeed());
                    goodslist.setSeson(ruleForm.getSeson());
                    goodslist.setNomal(ruleForm.getNomal());
                    goodslist.setGoodsname(ruleForm.getGoodsname());
                    goodslist.setAfirm(0);
                    goodslist.setCreattime(CommonUtil.createDate());
                    int insert = this.goodslistMapper.insert(goodslist);
                    if(insert !=1 ) return false;

        }
        //2。商品存在，查询商品id+输入内容

        return true;
    }

    @Override
    public List<GoodslistVO> goodslist() {
          QueryWrapper<Goodslist> queryWrapper= new QueryWrapper<>();
     //   queryWrapper.eq("publickey",publickey);
        List<Goodslist> goodslistList = this.goodslistMapper.selectList(queryWrapper);
        List<GoodslistVO> goodslistVOList = new ArrayList<>();
        for (Goodslist goodslist : goodslistList) {
            GoodslistVO goodslistVO = new GoodslistVO();
            goodslistVO.setGoodsnumber(goodslist.getGoodsnumber());
            goodslistVO.setBuyplace(goodslist.getBuyplace());
            goodslistVO.setBuyday(goodslist.getBuyday());
            goodslistVO.setStayday(goodslist.getStayday());
            goodslistVO.setStayamout(goodslist.getStayamout());
            goodslistVO.setBuyerstone(goodslist.getBuyerstone());
            goodslistVO.setBuyernumber(goodslist.getBuyernumber());
            goodslistVO.setNumberamout(goodslist.getNumberamout());
            goodslistVO.setProcessplace(goodslist.getProcessplace());
            goodslistVO.setBag(goodslist.getBag());
            goodslistVO.setProcesserstone(goodslist.getProcesserstone());
            goodslistVO.setProcessdata(goodslist.getProcessdata());
            goodslistVO.setBeginplace(goodslist.getBeginplace());
            goodslistVO.setEndingplace(goodslist.getEndingplace());
            goodslistVO.setIce(goodslist.getIce());
            goodslistVO.setProcesspreson(goodslist.getProcesspreson());
            goodslistVO.setBuyer(goodslist.getBuyer());
            goodslistVO.setDriver(goodslist.getDriver());
            goodslistVO.setDrivernumber(goodslist.getDrivernumber());
            goodslistVO.setSeedpreson(goodslist.getSeedpreson());
            goodslistVO.setSeedstone(goodslist.getSeedstone());
            goodslistVO.setSeed(goodslist.getSeed());
            goodslistVO.setSeson(goodslist.getSeson());
            goodslistVO.setNomal(goodslist.getNomal());
            goodslistVO.setGoodsname(goodslist.getGoodsname());
            goodslistVO.setAfirm(goodslist.getAfirm());
            goodslistVO.setGoodsid(goodslist.getGoodsid());
            goodslistVO.setCreattime(goodslist.getCreattime());
            goodslistVO.setPublickey(goodslist.getPublickey());
            goodslistVO.setCompanyname(goodslist.getCompanyname());
            goodslistVO.setRepreson(goodslist.getRepreson());
            goodslistVO.setPhone(goodslist.getPhone());
            goodslistVOList.add(goodslistVO);
        }
        return goodslistVOList;
    }

    @Override
    public List<Mcrecord> mcgoodslist(String publickey) {
        QueryWrapper<Goodslist> queryWrapper= new QueryWrapper<>();
        queryWrapper.eq("publickey",publickey);
        List<Goodslist> goodslistList = this.goodslistMapper.selectList(queryWrapper);
        List<Mcrecord> mcrecordList = new ArrayList<>();
        for (Goodslist goodslist : goodslistList) {
            Mcrecord mcrecord = new Mcrecord();
            mcrecord.setGoodsnumber(goodslist.getGoodsnumber());
            mcrecord.setBuyplace(goodslist.getBuyplace());
            mcrecord.setBuyday(goodslist.getBuyday());
            mcrecord.setStayday(goodslist.getStayday());
            mcrecord.setStayamout(goodslist.getStayamout());
            mcrecord.setBuyerstone(goodslist.getBuyerstone());
            mcrecord.setBuyernumber(goodslist.getBuyernumber());
            mcrecord.setNumberamout(goodslist.getNumberamout());
            mcrecord.setProcessplace(goodslist.getProcessplace());
            mcrecord.setBag(goodslist.getBag());
            mcrecord.setProcesserstone(goodslist.getProcesserstone());
            mcrecord.setProcessdata(goodslist.getProcessdata());
            mcrecord.setBeginplace(goodslist.getBeginplace());
            mcrecord.setEndingplace(goodslist.getEndingplace());
            mcrecord.setIce(goodslist.getIce());
            mcrecord.setProcesspreson(goodslist.getProcesspreson());
            mcrecord.setBuyer(goodslist.getBuyer());
            mcrecord.setDriver(goodslist.getDriver());
            mcrecord.setDrivernumber(goodslist.getDrivernumber());
            mcrecord.setSeedpreson(goodslist.getSeedpreson());
            mcrecord.setSeedstone(goodslist.getSeedstone());
            mcrecord.setSeed(goodslist.getSeed());
            mcrecord.setSeson(goodslist.getSeson());
            mcrecord.setNomal(goodslist.getNomal());
            mcrecord.setGoodsname(goodslist.getGoodsname());
            mcrecord.setAfirm(goodslist.getAfirm());
            mcrecord.setGoodsid(goodslist.getGoodsid());
            mcrecord.setCreattime(goodslist.getCreattime());
            mcrecord.setPublickey(goodslist.getPublickey());
            mcrecord.setCompanyname(goodslist.getCompanyname());
            mcrecord.setRepreson(goodslist.getRepreson());
            mcrecord.setPhone(goodslist.getPhone());
            mcrecordList.add(mcrecord);
        }
        return mcrecordList;
    }
}
