package com.project.yihuobao.VO;

public class Blockidea {
    private String goodsnumber;
    private String goodsname;
    private String buyer;
    private String buyplace;
    private String buyday;
    private String stayday;
    private String buyerstone;
    private String buyernumber;
    private String numberamount;
    private String processpreson;
    private String processdata;
    private String processplace;
    private String bag;
    private String processerstone;
    private String driver;
    private String beginplace;
    private String endingplace;
    private String ice;
    private String drivernumber;
    private String seedpreson;
    private String seedstone;
    private String seed;
    private String seson;
    private String nomal;
}
