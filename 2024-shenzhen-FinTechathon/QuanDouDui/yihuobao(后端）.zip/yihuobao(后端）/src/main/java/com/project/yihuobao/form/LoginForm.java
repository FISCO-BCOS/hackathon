package com.project.yihuobao.form;

import lombok.Data;

@Data
public class LoginForm {

    private String name;
    private String password;
    private String type;
    private String key;

}
