package com.project.yihuobao.controller;


import com.project.yihuobao.VO.ReportVO;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.VO.UserInfoVO;
import com.project.yihuobao.entity.Goodslist;
import com.project.yihuobao.form.Judge;
import com.project.yihuobao.form.Register;
import com.project.yihuobao.service.ReportsService;
import com.project.yihuobao.service.UserinfoService;
import com.project.yihuobao.util.ResultVOutil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author admin
 * @since 2024-11-18
 */
@RestController
@RequestMapping("/userinfo")
public class UserinfoController {
    @Autowired
    private UserinfoService userinfoService;

    @PostMapping("/register")
    public ResultVO registers(@RequestBody Register register) {
        Boolean registers = this.userinfoService.registers(register);
        if(!registers) return ResultVOutil.fail();
        return ResultVOutil.success(null);
    }

    @GetMapping("/getuser")
    public ResultVO getuser(){
        List<UserInfoVO> getusers = this.userinfoService.getuser();
        return ResultVOutil.success(getusers);
    }


}

