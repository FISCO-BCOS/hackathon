package com.project.yihuobao.controller;


import com.project.yihuobao.VO.GoodslistVO;
import com.project.yihuobao.VO.ReportVO;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.form.Judge;
import com.project.yihuobao.form.LoginForm;
import com.project.yihuobao.form.RuleForm;
import com.project.yihuobao.service.NomaluserService;
import com.project.yihuobao.service.ReportsService;
import com.project.yihuobao.util.ResultVOutil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author admin
 * @since 2024-09-02
 */
@RestController
@RequestMapping("/reports")
public class ReportsController {
    @Autowired
    private ReportsService reportsService;
    @PostMapping ("/judgement")
    public ResultVO judgement(@RequestBody Judge judge){
        Boolean judgement = this.reportsService.judgement(judge);
        if(!judgement) return ResultVOutil.fail();
        return ResultVOutil.success(null);
    }
    @GetMapping("/getreport")
    public ResultVO getreport(){
        List<ReportVO> getreports = this.reportsService.reports();
        return ResultVOutil.success(getreports);
    }

}
