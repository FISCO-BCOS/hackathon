package com.project.yihuobao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.yihuobao.VO.Mcrecord;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.VO.UserVO;
import com.project.yihuobao.entity.Adminuser;
import com.project.yihuobao.entity.Goodslist;
import com.project.yihuobao.form.LoginForm;
import com.project.yihuobao.mapper.AdminuserMapper;
import com.project.yihuobao.service.AdminuserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 管理用户表 服务实现类
 * </p>
 *
 * @author admin
 * @since 2024-07-21
 */
@Service
public class AdminuserServiceImpl extends ServiceImpl<AdminuserMapper, Adminuser> implements AdminuserService {
    @Autowired
    private AdminuserMapper adminuserMapper;
    @Override
    public ResultVO login(LoginForm loginForm) {
        //1.判断是否存在(用户名）
        QueryWrapper<Adminuser> qw =new QueryWrapper<>();
        qw.eq("username",loginForm.getName());//具体查询哪一行
        Adminuser adminuser=this.adminuserMapper.selectOne(qw);//获取结果
        ResultVO<Adminuser> resultVO = new ResultVO<>();
        if(adminuser == null){
             resultVO.setCode(-1);
            //2.密码是否正确
        } else {
                if(!adminuser.getUserkey().equals(loginForm.getKey())) {
                    resultVO.setCode(-2);
                }else{
                    resultVO.setCode(0);
                    resultVO.setData(adminuser);
                }

            }
        return resultVO;
        //3.密钥是否正确
    }
    @Override
    public List<UserVO> userlist(String username,String userkey) {
        QueryWrapper<Adminuser> queryWrapper= new QueryWrapper<>();
        queryWrapper.eq("username", username)
                .eq("userkey", userkey);
        List<Adminuser> adminuserList = this.adminuserMapper.selectList(queryWrapper);
        List<UserVO> userVOList = new ArrayList<>();
        for (Adminuser adminuser : adminuserList) {
            UserVO userVO= new UserVO();
            userVO.setUsername(adminuser.getUsername());
            userVO.setUserkey(adminuser.getUserkey());
            userVO.setPublickey(adminuser.getPublickey());
            userVOList.add(userVO);
        }
        return userVOList;
    }

}
