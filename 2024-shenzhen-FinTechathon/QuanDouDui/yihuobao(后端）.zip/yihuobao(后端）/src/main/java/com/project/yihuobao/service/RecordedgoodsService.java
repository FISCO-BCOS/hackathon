package com.project.yihuobao.service;

import com.project.yihuobao.VO.Blockidea;
import com.project.yihuobao.entity.Recordedgoods;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author admin
 * @since 2024-11-17
 */
public interface RecordedgoodsService extends IService<Recordedgoods> {
//  void getchain();
}
