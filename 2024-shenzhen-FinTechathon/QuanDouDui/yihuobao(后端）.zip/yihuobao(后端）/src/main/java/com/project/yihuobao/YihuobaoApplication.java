package com.project.yihuobao;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.project.yihuobao.mapper")
public class YihuobaoApplication {

    public static  void main(String[] args) {
        SpringApplication.run(YihuobaoApplication.class, args);
    }

}
