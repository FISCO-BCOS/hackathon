package com.project.yihuobao.service;

import com.project.yihuobao.VO.GoodslistVO;
import com.project.yihuobao.VO.Mcrecord;
import com.project.yihuobao.entity.Goodslist;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.yihuobao.form.RuleForm;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author admin
 * @since 2024-07-30
 */
public interface GoodslistService extends IService<Goodslist> {
    public boolean create(RuleForm ruleForm);
    public List<GoodslistVO> goodslist();
    public List<Mcrecord> mcgoodslist(String publickey);
    public boolean upchain(GoodslistVO goodslistVO) throws Exception ;
}
