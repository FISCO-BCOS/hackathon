package com.project.yihuobao.VO;
import lombok.Data;
@Data
public class GoodslistVO {
    private Integer goodsid;
    private String goodsnumber;
    private String represon;
    private String companyname;
    private String phone;
    private String buyplace;
    private String buyday;
    private Integer stayday;
    private String stayamout;
    private String buyerstone;
    private String buyernumber;
    private String numberamout;
    private String processplace;
    private String bag;
    private String processerstone;
    private String processdata; // 处理数据
    private String beginplace;
    private String endingplace;
    private String ice;
    private String processpreson;
    private String buyer;
    private String driver;
    private String drivernumber;
    private String seedpreson;
    private String seedstone;
    private String seed;
    private String seson;
    private String nomal;
    private String goodsname;
    private String creattime;
    private Integer afirm;
    private String publickey;
}
