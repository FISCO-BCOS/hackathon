package com.project.yihuobao.VO;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ResultVO<T> {
    private Integer code;
    private T data;
    public ResultVO(T data) {
        this.data = data;
    }
}
