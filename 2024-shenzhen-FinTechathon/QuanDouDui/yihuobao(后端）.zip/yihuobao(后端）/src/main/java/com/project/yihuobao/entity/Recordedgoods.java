package com.project.yihuobao.entity;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author admin
 * @since 2024-11-17
 */
@Data
  @EqualsAndHashCode(callSuper = false)
    public class Recordedgoods implements Serializable {

    private static final long serialVersionUID=1L;

    private String goodsnumber;

    private String goodsname;

    private String buyer;

    private String buyplace;

    private String buyday;

    private String stayday;

    private String buyerstone;

    private String buyernumber;

    private String numberamount;

    private String processpreson;

    private String processdata;

    private String processplace;

    private String bag;

    private String processerstone;

    private String driver;

    private String beginplace;

    private String endingplace;

    private String ice;

    private String drivernumber;

    private String seedpreson;

    private String seedstone;

    private String seed;

    private String seson;

    private String nomal;


}
