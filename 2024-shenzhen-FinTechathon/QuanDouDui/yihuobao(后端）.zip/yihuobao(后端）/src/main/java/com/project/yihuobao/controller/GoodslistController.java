package com.project.yihuobao.controller;


import com.project.yihuobao.VO.GoodslistVO;
import com.project.yihuobao.VO.Mcrecord;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.entity.Goodslist;
import com.project.yihuobao.form.RuleForm;
import com.project.yihuobao.service.GoodslistService;
import com.project.yihuobao.util.IOUtil;
import com.project.yihuobao.util.ResultVOutil;
import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author admin
 * @since 2024-07-30
 */
@RestController
@RequestMapping("/goodslist")
public class GoodslistController {
    // 初始化BcosSDK对象
    BcosSDK sdk;
    // 获取Client对象，此处传入的群组ID为1
    Client client;
    // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
    CryptoKeyPair keyPair;
    AssembleTransactionProcessor transactionProcessor;

    @PostConstruct
    public void init() throws Exception {
        // 初始化BcosSDK对象
        sdk = BcosSDK.build("src/main/resources/config-example.toml");
        // 获取Client对象，此处传入的群组ID为1
        client = sdk.getClient(Integer.valueOf(1));
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        keyPair = client.getCryptoSuite().createKeyPair();
        transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, keyPair, "src/main/resources/abi/", "src/main/resources/bin/");

    }

    @Autowired
    private GoodslistService goodslistService;
    //新建档案
    @PutMapping("/create")
    public ResultVO create(@RequestBody RuleForm ruleForm){
        Boolean create = this.goodslistService.create(ruleForm);
        if(!create) return ResultVOutil.fail();
        return ResultVOutil.success(null);
    }

    @GetMapping("/goodslistlist")
    public ResultVO goodslistlist(){
        List<GoodslistVO> goodslistList = this.goodslistService.goodslist();
        return ResultVOutil.success(goodslistList);
    }

    @GetMapping("/mclist/{publickey}")
    public ResultVO mclist(@PathVariable("publickey") String publickey){
        List<Mcrecord> mcrecordList = this.goodslistService.mcgoodslist(publickey);
        return ResultVOutil.success(mcrecordList);
    }

    @GetMapping("/findById/{id}")
    public ResultVO findById(@PathVariable("id") Integer id){
        Goodslist goodslist = this.goodslistService.getById(id);
        return ResultVOutil.success(goodslist);
    }

    @PutMapping("/updata")
    public ResultVO updata(@RequestBody Goodslist goodslist){
        boolean updata = this.goodslistService.updateById(goodslist);
        if(!updata) return  ResultVOutil.fail();
        return ResultVOutil.success(null);
    }

    @DeleteMapping("/deleteById/{id}")
    public  ResultVO deleteById(@PathVariable("id") Integer id){
        boolean remove = this.goodslistService.removeById(id);
        if(!remove)return ResultVOutil.fail();
        return ResultVOutil.success(null);
    }

    @PostMapping("/upchain")
    public boolean upchain(@RequestBody GoodslistVO goodslistVO)throws Exception {
        boolean upchains  = this.goodslistService.upchain(goodslistVO);
        return true;
    }

    @GetMapping("/searchByNumber")
    public  ResultVO<GoodslistVO> searchByNumber(String goodsnumber) throws Exception {

        List<Object> pr2 = new ArrayList<>();
        pr2.add(goodsnumber);
//调用record合约的「getRecord」函数，参数为recordid
        TransactionResponse ts1 = transactionProcessor.sendTransactionAndGetResponse("0xaff2fc5de75fa2aa4a58bd3361af9a3586d1b428", IOUtil.readResourceAsString("abi/Creatrecord.abi"), "getGoods",pr2);
        TransactionResponse ts2 = transactionProcessor.sendTransactionAndGetResponse("0xb9b04425b63f3ae975b111e6f8d0b711a4f69b5b", IOUtil.readResourceAsString("abi/bag.abi"), "getGoods",pr2);
        TransactionResponse ts3 = transactionProcessor.sendTransactionAndGetResponse("0x02bce2d2ac0209bd810ad866502d808464e33954", IOUtil.readResourceAsString("abi/beginplace.abi"), "getGoods",pr2);
        TransactionResponse ts4 = transactionProcessor.sendTransactionAndGetResponse("0x28880e4a1cba43f81da3f7ae06345a0667df98e3", IOUtil.readResourceAsString("abi/buyday.abi"), "getGoods",pr2);
        TransactionResponse ts5 = transactionProcessor.sendTransactionAndGetResponse("0x9bc226df49f260d40ce45eb54b5467ead3de6e66", IOUtil.readResourceAsString("abi/buyer.abi"), "getGoods",pr2);
        TransactionResponse ts6 = transactionProcessor.sendTransactionAndGetResponse("0x2ec3b395746e602b3e5854b39c0098adcfcbcef7", IOUtil.readResourceAsString("abi/buyernumber.abi"), "getGoods",pr2);
        TransactionResponse ts7 = transactionProcessor.sendTransactionAndGetResponse("0x48459e796776cbd58b816526e1a967541a102c72", IOUtil.readResourceAsString("abi/buyerstone.abi"), "getGoods",pr2);
        TransactionResponse ts8 = transactionProcessor.sendTransactionAndGetResponse("0x8e12e7dd7093c28a4b29ac7b1506a5d9dda0b1a4", IOUtil.readResourceAsString("abi/buyplace.abi"), "getGoods",pr2);
        TransactionResponse ts9 = transactionProcessor.sendTransactionAndGetResponse("0x52c0e7116377cce76a556bbd68f2917d467f9629", IOUtil.readResourceAsString("abi/driver.abi"), "getGoods",pr2);
        TransactionResponse ts10 = transactionProcessor.sendTransactionAndGetResponse("0x08575c92844adf8d6f57fc333687200622667004", IOUtil.readResourceAsString("abi/drivernumber.abi"), "getGoods",pr2);
        TransactionResponse ts11 = transactionProcessor.sendTransactionAndGetResponse("0x5563d18cab26940ee7439aba1233822caa76e11c", IOUtil.readResourceAsString("abi/endingplace.abi"), "getGoods",pr2);
        TransactionResponse ts12 = transactionProcessor.sendTransactionAndGetResponse("0xa1074f8d328a40f0d13ac3c866b961e34a712f4e", IOUtil.readResourceAsString("abi/ice.abi"), "getGoods",pr2);
        TransactionResponse ts13 = transactionProcessor.sendTransactionAndGetResponse("0x0d452fb56ac8c99e01b77d90fe3ba1f9a9b7cbf1", IOUtil.readResourceAsString("abi/nomal.abi"), "getGoods",pr2);
        TransactionResponse ts14 = transactionProcessor.sendTransactionAndGetResponse("0xf348eeac06baf76e8c016eaf8c27088b5c5d334c", IOUtil.readResourceAsString("abi/numberamount.abi"), "getGoods",pr2);
        TransactionResponse ts15 = transactionProcessor.sendTransactionAndGetResponse("0xbe69339256de96fd547f6fe088a5506f86e4badd", IOUtil.readResourceAsString("abi/processdata.abi"), "getGoods",pr2);
        TransactionResponse ts16 = transactionProcessor.sendTransactionAndGetResponse("0xf9a79fa047f625daeb93bcfd9e745533451c359b", IOUtil.readResourceAsString("abi/processerstone.abi"), "getGoods",pr2);
        TransactionResponse ts17 = transactionProcessor.sendTransactionAndGetResponse("0xec98be71974c86e91e0ab5ea5c1ad0e488e63059", IOUtil.readResourceAsString("abi/processplace.abi"), "getGoods",pr2);
        TransactionResponse ts18 = transactionProcessor.sendTransactionAndGetResponse("0x66ad0a2fb987cd5bfa93b27b5b7967aac6182a00", IOUtil.readResourceAsString("abi/processpreson.abi"), "getGoods",pr2);
        TransactionResponse ts19 = transactionProcessor.sendTransactionAndGetResponse("0x9bde1a8c860ee96404d7bf919d31a0360b7ba9a4", IOUtil.readResourceAsString("abi/seed.abi"), "getGoods",pr2);
        TransactionResponse ts20 = transactionProcessor.sendTransactionAndGetResponse("0xbe557585d0ebafdf78a9f07fb49e74a8a1e0b21b", IOUtil.readResourceAsString("abi/seedpreson.abi"), "getGoods",pr2);
        TransactionResponse ts21 = transactionProcessor.sendTransactionAndGetResponse("0x353c99ab6f992e4295afdf81b7986360fc224b00", IOUtil.readResourceAsString("abi/seedstone.abi"), "getGoods",pr2);
        TransactionResponse ts22 = transactionProcessor.sendTransactionAndGetResponse("0xeaa23fa67ba590fe8c5645b076f410a3cc913eda", IOUtil.readResourceAsString("abi/seson.abi"), "getGoods",pr2);
        TransactionResponse ts23 = transactionProcessor.sendTransactionAndGetResponse("0x1a1311ac1b76c01447bbd5fbb49d5765f6189314", IOUtil.readResourceAsString("abi/stayday.abi"), "getGoods",pr2);

        //打印返回值
        List<Object> returnValues1 = ts1.getReturnObject();
        List<Object> returnValues2 = ts2.getReturnObject();
        List<Object> returnValues3 = ts3.getReturnObject();
        List<Object> returnValues4 = ts4.getReturnObject();
        List<Object> returnValues5 = ts5.getReturnObject();
        List<Object> returnValues6 = ts6.getReturnObject();
        List<Object> returnValues7 = ts7.getReturnObject();
        List<Object> returnValues8 = ts8.getReturnObject();
        List<Object> returnValues9 = ts9.getReturnObject();
        List<Object> returnValues10 = ts10.getReturnObject();
        List<Object> returnValues11 = ts11.getReturnObject();
        List<Object> returnValues12 = ts12.getReturnObject();
        List<Object> returnValues13 = ts13.getReturnObject();
        List<Object> returnValues14 = ts14.getReturnObject();
        List<Object> returnValues15 = ts15.getReturnObject();
        List<Object> returnValues16 = ts16.getReturnObject();
        List<Object> returnValues17 = ts17.getReturnObject();
        List<Object> returnValues18 = ts18.getReturnObject();
        List<Object> returnValues19 = ts19.getReturnObject();
        List<Object> returnValues20 = ts20.getReturnObject();
        List<Object> returnValues21 = ts21.getReturnObject();
        List<Object> returnValues22 = ts22.getReturnObject();
        List<Object> returnValues23 = ts23.getReturnObject();
        GoodslistVO result = new GoodslistVO();
        if (returnValues1.size() == 1) {
            String goodsname = (String)returnValues1.get(0);
            result.setGoodsname(goodsname);
        }
        if (returnValues2.size() == 1) {
            String bag = (String)returnValues2.get(0);
            result.setBag(bag);
        }
        if (returnValues3.size() == 1) {
            String beginpalce= (String)returnValues3.get(0);
            result.setBeginplace(beginpalce);
        }
        if (returnValues4.size() == 1) {
            String buyday = (String)returnValues4.get(0);
            result.setBuyday(buyday);
        }
        if (returnValues5.size() == 1) {
            String buyer = (String)returnValues5.get(0);
            result.setBuyer(buyer);
        }
        if (returnValues6.size() == 1) {
            String buyernumber= (String)returnValues6.get(0);
            result.setBuyernumber(buyernumber);
        }
        if (returnValues7.size() == 1) {
            String buyerstone = (String)returnValues7.get(0);
            result.setBuyerstone(buyerstone);
        }
        if (returnValues8.size() == 1) {
            String buyplace = (String)returnValues8.get(0);
            result.setBuyplace(buyplace);
        }
        if (returnValues9.size() == 1) {
            String driver= (String)returnValues9.get(0);
            result.setDriver(driver);
        }
        if (returnValues10.size() == 1) {
            String drivernumber = (String)returnValues10.get(0);
            result.setDrivernumber(drivernumber);
        }
        if (returnValues11.size() == 1) {
            String endingplace = (String)returnValues11.get(0);
            result.setEndingplace(endingplace);
        }
        if (returnValues12.size() == 1) {
            String ice= (String)returnValues12.get(0);
            result.setIce(ice);
        }
        if (returnValues13.size() == 1) {
            String nomal = (String)returnValues13.get(0);
            result.setNomal(nomal);
        }
        if (returnValues14.size() == 1) {
            String numberamount= (String)returnValues14.get(0);
            result.setNumberamout(numberamount);
        }
        if (returnValues15.size() == 1) {
            String processdata = (String)returnValues15.get(0);
            result.setProcessdata(processdata);
        }
        if (returnValues16.size() == 1) {
            String processerstone = (String)returnValues16.get(0);
            result.setProcesserstone(processerstone);
        }
        if (returnValues17.size() == 1) {
            String processplace= (String)returnValues17.get(0);
            result.setProcessplace(processplace);
        }
        if (returnValues18.size() == 1) {
            String processpreson = (String)returnValues18.get(0);
            result.setProcesspreson(processpreson);
        }
        if (returnValues19.size() == 1) {
            String seed = (String)returnValues19.get(0);
            result.setSeed(seed);
        }
        if (returnValues20.size() == 1) {
            String seedpreson= (String)returnValues20.get(0);
            result.setSeedpreson(seedpreson);
        }
        if (returnValues21.size() == 1) {
            String seedstone = (String)returnValues21.get(0);
            result.setSeedstone(seedstone);
        }
        if (returnValues22.size() == 1) {
            String seson = (String)returnValues22.get(0);
            result.setSeson(seson);
        }
        if (returnValues23.size() == 1) {
            String stayday = (String)returnValues23.get(0);
            result.setStayday(14);
        }

        System.out.println("Goodsname: " + result.getGoodsname());
        System.out.println("Bag: " + result.getBag());
        System.out.println("Beginplace: " + result.getBeginplace());
        System.out.println("Buyday: " + result.getBuyday());
        System.out.println("Buyer: " + result.getBuyer());
        System.out.println("Buyernumber: " + result.getBuyernumber());
        System.out.println("Buyerstone: " + result.getBuyerstone());
        System.out.println("Buyplace: " + result.getBuyplace());
        System.out.println("Driver: " + result.getDriver());
        System.out.println("Drivernumber: " + result.getDrivernumber());
        System.out.println("Endingplace: " + result.getEndingplace());
        System.out.println("Ice: " + result.getIce());
        System.out.println("Nomal: " + result.getNomal());
        System.out.println("Numberamount: " + result.getNumberamout());
        System.out.println("Processdata: " + result.getProcessdata());
        System.out.println("Processerstone: " + result.getProcesserstone());
        System.out.println("Processplace: " + result.getProcessplace());
        System.out.println("Processpreson: " + result.getProcesspreson());
        System.out.println("Seed: " + result.getSeed());
        System.out.println("Seedpreson: " + result.getSeedpreson());
        System.out.println("Seedstone: " + result.getSeedstone());
        System.out.println("Seson: " + result.getSeson());
        System.out.println("Stayday: " + result.getStayday());

        return new ResultVO(result);
    }
}



