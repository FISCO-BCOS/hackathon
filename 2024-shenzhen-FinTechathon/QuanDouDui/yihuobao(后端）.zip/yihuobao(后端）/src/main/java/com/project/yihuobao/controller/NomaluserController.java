package com.project.yihuobao.controller;


import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.entity.Nomaluser;
import com.project.yihuobao.form.LoginForm;
import com.project.yihuobao.service.AdminuserService;
import com.project.yihuobao.service.NomaluserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 普通用户表 前端控制器
 * </p>
 *
 * @author admin
 * @since 2024-07-22
 */
@RestController
@RequestMapping("/nomaluser")
public class NomaluserController {
    @Autowired
    private NomaluserService nomaluserService;
    @GetMapping("/login")
    public ResultVO login(LoginForm loginForm){
        ResultVO resultVO = this.nomaluserService.login(loginForm);
        return resultVO;
    }


}

