package com.project.yihuobao.form;

import lombok.Data;

@Data
public class Judge {
        private String goodsnumber;
        private String goodsname;
        private String companyname;
        private String represon;
        private String phone;
}
