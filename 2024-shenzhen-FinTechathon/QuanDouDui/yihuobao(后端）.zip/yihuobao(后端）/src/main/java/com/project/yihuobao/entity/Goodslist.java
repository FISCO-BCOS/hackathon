package com.project.yihuobao.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author admin
 * @since 2024-08-01
 */
@Data
  @EqualsAndHashCode(callSuper = false)
    public class Goodslist implements Serializable {

    private static final long serialVersionUID=1L;

      @TableId(value = "goodsid", type = IdType.AUTO)
      private Integer goodsid;

      /**
     * 商品身份码
     */
      private String goodsnumber;

      /**
     * 商品名称
     */
      private String goodsname;

      /**
     * 公司名
     */
      private String companyname;

      /**
     * 负责人
     */
      private String represon;

      /**
     * 负责人手机
     */
      private String phone;

      /**
     * 采购方购买人
     */
      private String buyer;

      /**
     * 购买地
     */
      private String buyplace;

      /**
     * 购买日期
     */
      private String buyday;

      /**
     * 保质期
     */
      private Integer stayday;

      /**
     * 保质期单位
     */
      private String stayamout;

      /**
     * 购买方贮存仓库地址
     */
      private String buyerstone;

      /**
     * 购买方仓库数量
     */
      private String buyernumber;

      /**
     * 购买方仓库单位
     */
      private String numberamout;

      /**
     * 生产人
     */
      private String processpreson;

      /**
     * 生产日期
     */
      private String processdata;

      /**
     * 生产地址
     */
      private String processplace;

      /**
     * 包装材料
     */
      private String bag;

      /**
     * 生产方贮存仓库
     */
      private String processerstone;

      /**
     * 司机
     */
      private String driver;

      /**
     * 出发地
     */
      private String beginplace;

      /**
     * 目的地
     */
      private String endingplace;

      /**
     * 冷藏方式
     */
      private String ice;

      /**
     * 运输批号
     */
      private String drivernumber;

      /**
     * 原料提供人
     */
      private String seedpreson;

      /**
     * 原料贮存仓库
     */
      private String seedstone;

      /**
     * 原料
     */
      private String seed;

      /**
     * 调味料
     */
      private String seson;

      /**
     * 执行标准
     */
      private String nomal;

      /**
     * 确认值
     */
      private Integer afirm;

      /**
     * 创立时间
     */
      private String creattime;

    private String publickey;


}
