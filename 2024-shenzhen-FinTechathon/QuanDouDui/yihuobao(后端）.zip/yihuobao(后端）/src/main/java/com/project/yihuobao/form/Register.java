package com.project.yihuobao.form;

import lombok.Data;
@Data
public class Register {
    private String name;
    private String firmname;
    private String phonenumber;
    private String email;
    private String type;
    private String key;
}
