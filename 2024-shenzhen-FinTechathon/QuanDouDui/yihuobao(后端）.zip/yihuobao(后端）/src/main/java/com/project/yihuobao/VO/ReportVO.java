package com.project.yihuobao.VO;

import lombok.Data;

@Data
public class ReportVO {
    private String goodsnumber;
    private String goodsname;
    private String companyname;
    private String represon;
    private String phone;
    private String creatat;
}
