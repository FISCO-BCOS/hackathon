package com.project.yihuobao.mapper;

import com.project.yihuobao.entity.Reports;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author admin
 * @since 2024-09-02
 */
public interface ReportsMapper extends BaseMapper<Reports> {

}
