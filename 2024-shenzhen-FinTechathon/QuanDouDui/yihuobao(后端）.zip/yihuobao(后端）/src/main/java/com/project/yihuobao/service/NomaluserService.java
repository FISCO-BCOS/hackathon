package com.project.yihuobao.service;

import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.entity.Nomaluser;
import com.baomidou.mybatisplus.extension.service.IService;
import com.project.yihuobao.form.LoginForm;

/**
 * <p>
 * 普通用户表 服务类
 * </p>
 *
 * @author admin
 * @since 2024-07-22
 */
public interface NomaluserService extends IService<Nomaluser> {
    public ResultVO login(LoginForm loginForm);
}
