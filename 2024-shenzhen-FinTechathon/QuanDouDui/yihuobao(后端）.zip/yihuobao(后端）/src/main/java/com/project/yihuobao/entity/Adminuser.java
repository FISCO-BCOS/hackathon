package com.project.yihuobao.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 管理用户表
 * </p>
 *
 * @author admin
 * @since 2024-07-21
 */
@Data
  @EqualsAndHashCode(callSuper = false)
    public class Adminuser implements Serializable {

    private static final long serialVersionUID=1L;

      /**
     * 用户id
     */
        @TableId(value = "userid", type = IdType.AUTO)
      private Long userid;

      /**
     * 用户名
     */
      private String username;

      /**
     * 密钥
     */
      private String userkey;

      /**
     * 公钥
     */
      private String publickey;


}
