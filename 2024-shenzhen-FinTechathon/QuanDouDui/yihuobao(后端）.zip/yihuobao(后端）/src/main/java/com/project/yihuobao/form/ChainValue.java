package com.project.yihuobao.form;

public class ChainValue {
    private String address;
}
