package com.project.yihuobao.mapper;

import com.project.yihuobao.entity.Recordedgoods;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author admin
 * @since 2024-11-17
 */
public interface RecordedgoodsMapper extends BaseMapper<Recordedgoods> {

}
