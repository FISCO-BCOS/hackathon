package com.project.yihuobao.controller;


import com.project.yihuobao.VO.Mcrecord;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.VO.UserVO;
import com.project.yihuobao.form.LoginForm;
import com.project.yihuobao.service.AdminuserService;
import com.project.yihuobao.util.ResultVOutil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 管理用户表 前端控制器
 * </p>
 *
 * @author admin
 * @since 2024-07-21
 */
@RestController
@RequestMapping("/adminuser")
public class AdminuserController {
  @Autowired
    private AdminuserService adminuserService;
    @GetMapping("/login")
    public ResultVO login(LoginForm loginForm){
        ResultVO resultVO = this.adminuserService.login(loginForm);
        return resultVO;
    }
    @GetMapping("/getuser/{username}/{userkey}")
    public ResultVO getuser(@PathVariable("username") String username,@PathVariable("userkey") String userkey){
        List<UserVO> userVOList = this.adminuserService.userlist(username,userkey);
        return ResultVOutil.success(userVOList);
    }


}

