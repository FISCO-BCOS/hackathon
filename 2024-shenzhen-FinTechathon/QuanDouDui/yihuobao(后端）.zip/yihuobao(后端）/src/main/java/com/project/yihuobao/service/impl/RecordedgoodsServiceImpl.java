package com.project.yihuobao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.yihuobao.VO.Blockidea;
import com.project.yihuobao.VO.ReportVO;
import com.project.yihuobao.entity.Recordedgoods;
import com.project.yihuobao.entity.Reports;
import com.project.yihuobao.mapper.RecordedgoodsMapper;
import com.project.yihuobao.service.RecordedgoodsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author admin
 * @since 2024-11-17
 */
@Service
public class RecordedgoodsServiceImpl extends ServiceImpl<RecordedgoodsMapper, Recordedgoods> implements RecordedgoodsService {
//    @Override
//    public void getchain() {
//
//    }
}
