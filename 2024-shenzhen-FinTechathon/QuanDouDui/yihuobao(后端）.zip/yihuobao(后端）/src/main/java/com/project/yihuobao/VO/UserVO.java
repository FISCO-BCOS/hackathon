package com.project.yihuobao.VO;

import lombok.Data;

@Data
public class UserVO {
    private String username;
    private String userpassword;
    private String userkey;
    private String publickey;
}
