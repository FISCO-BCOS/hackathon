package com.project.yihuobao.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.project.yihuobao.VO.ResultVO;
import com.project.yihuobao.entity.Adminuser;
import com.project.yihuobao.entity.Nomaluser;
import com.project.yihuobao.form.LoginForm;
import com.project.yihuobao.mapper.AdminuserMapper;
import com.project.yihuobao.mapper.NomaluserMapper;
import com.project.yihuobao.service.NomaluserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 普通用户表 服务实现类
 * </p>
 *
 * @author admin
 * @since 2024-07-22
 */
@Service
public class NomaluserServiceImpl extends ServiceImpl<NomaluserMapper, Nomaluser> implements NomaluserService {
    @Autowired
    private NomaluserMapper nomaluserMapper;
    @Override
    public ResultVO login(LoginForm loginForm) {
        //1.判断是否存在(用户名）
        QueryWrapper<Nomaluser> qw =new QueryWrapper<>();
        qw.eq("username",loginForm.getName());//具体查询哪一行
        Nomaluser nomaluser=this.nomaluserMapper.selectOne(qw);//获取结果
        ResultVO resultVO = new ResultVO();
        if(nomaluser == null){
            resultVO.setCode(-1);
            //2.密码是否正确
        }else{
            if(!nomaluser.getUserpassword().equals(loginForm.getPassword())) {
                resultVO.setCode(-2);
            }else {
                    resultVO.setCode(0);
                    resultVO.setData(nomaluser);
                }

            }
        return resultVO;
    }
}
