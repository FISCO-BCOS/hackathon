INSERT INTO `reports` (`id`, `goodsnumber`, `goodsname`, `companyname`, `represon`, `phone`, `created_at`) VALUES (1, '00001', '玉米猪肉', '深圳大学', '明显变质了，一点都不新鲜！', '13590663649', '2024-09-07');
INSERT INTO `reports` (`id`, `goodsnumber`, `goodsname`, `companyname`, `represon`, `phone`, `created_at`) VALUES (2, '00002', '龙虾盖浇饭', '深圳大学', '食之无味，弃之可惜！', '13590663649', '2024-09-07');
INSERT INTO `reports` (`id`, `goodsnumber`, `goodsname`, `companyname`, `represon`, `phone`, `created_at`) VALUES (7, '00001', '玉米猪肉', '深圳大学', '庄明湖说非常难吃，下次不会再买了', '13590663649', '2024-09-07');
INSERT INTO `reports` (`id`, `goodsnumber`, `goodsname`, `companyname`, `represon`, `phone`, `created_at`) VALUES (8, '00002', '红烧肉', '深恨大学', '非常油腻', '13590663649', '2024-11-12');
