INSERT INTO `nomaluser` (`userid`, `username`, `userpassword`) VALUES (1, '白晨', '12345678');
INSERT INTO `nomaluser` (`userid`, `username`, `userpassword`) VALUES (2, '钟逸', '12345678');
INSERT INTO `nomaluser` (`userid`, `username`, `userpassword`) VALUES (3, '庄明湖', '12345678');
INSERT INTO `nomaluser` (`userid`, `username`, `userpassword`) VALUES (4, '政政狗', '12345678');
