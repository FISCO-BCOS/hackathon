package org.com.fisco;

import com.project.yihuobao.service.UserinfoService;
import com.project.yihuobao.util.IOUtil;
import org.fisco.bcos.sdk.BcosSDK;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.transaction.manager.AssembleTransactionProcessor;
import org.fisco.bcos.sdk.transaction.manager.TransactionProcessorFactory;
import org.fisco.bcos.sdk.transaction.model.dto.TransactionResponse;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;


public class RecordTest
{
    public final String configFile = "src/main/resources/config-example.toml";
    @Test
    public void test() throws Exception {
        // 初始化BcosSDK对象
        BcosSDK sdk = BcosSDK.build("src/main/resources/config-example.toml");
        // 获取Client对象，此处传入的群组ID为1
        Client client = sdk.getClient(Integer.valueOf(1));
        // 构造AssembleTransactionProcessor对象，需要传入client对象，CryptoKeyPair对象和abi、binary文件存放的路径。abi和binary文件需要在上一步复制到定义的文件夹中。
        CryptoKeyPair keyPair = client.getCryptoSuite().createKeyPair();
        AssembleTransactionProcessor transactionProcessor = TransactionProcessorFactory.createAssembleTransactionProcessor(client, keyPair, "src/main/resources/abi/", "src/main/resources/bin/");

//
//        //同步方式发送交易
//        //创建调用交易函数的参数
//        String goodsnumber = "00001";
//        String goodsname = "玉米饺子";
//        String buyer = "白晨";
//        String buyplace = "深圳大学隔壁仓库";
//        String buyday = "2024-07-29";
//        String stayday = "365天";
//        String buyerstone = "深圳大学饭堂";
//        String buyernumber = "100";
//        String numberamount = "斤";
//        String processpreson = "白晨";
//        String processdata = "2024-07-29";
//        String processplace = "深圳大学饭堂";
//        String bag = "食品级包装袋";
//        String processerstone = "深圳大学饭堂";
//        String driver = "白晨";
//        String beginplace = "广州";
//        String endingplace = "深圳";
//        String ice = "液氮速冻";
//        String drivernumber = "00001";
//        String seedpreson = "白晨";
//        String seedstone = "深圳大学饭堂";
//        String seed = "玉米/面粉/猪肉";
//        String seson = "盐/酱油";
//        String nomal = "21312321";
////
////
//            List<Object> params1 = new ArrayList<>();
//            params1.add(goodsnumber);
//            params1.add(goodsname);
//        TransactionResponse transactionResponse1 = transactionProcessor.sendTransactionAndGetResponse("0x342b81287a780f03d50fe1c3c429dc51d25a1af2", IOUtil.readResourceAsString("abi/Creatrecord.abi"), "addGoods",params1);
////
//        List<Object> params2 = new ArrayList<>();
//        params2.add(goodsnumber);
//        params2.add(bag);
//        TransactionResponse transactionResponse2 = transactionProcessor.sendTransactionAndGetResponse("0x7ccbe8501d3db11e293f143e6d507815d158d833", IOUtil.readResourceAsString("abi/bag.abi"), "addGoods",params2);
//
//        List<Object> params3 = new ArrayList<>();
//        params3.add(goodsnumber);
//        params3.add(beginplace);
//        TransactionResponse transactionResponse3 = transactionProcessor.sendTransactionAndGetResponse("0xc72233edec6dca1cdd9d64f2277149aaaad50e35", IOUtil.readResourceAsString("abi/beginplace.abi"), "addGoods",params3);
////
//        List<Object> params4 = new ArrayList<>();
//        params4.add(goodsnumber);
//        params4.add(buyday);
//        TransactionResponse transactionResponse4 = transactionProcessor.sendTransactionAndGetResponse("0x23853048280376ed7a8c683d78068467f8edf9c5", IOUtil.readResourceAsString("abi/buyday.abi"), "addGoods",params4);
////
//        List<Object> params5 = new ArrayList<>();
//        params5.add(goodsnumber);
//        params5.add(buyer);
//        TransactionResponse transactionResponse5 = transactionProcessor.sendTransactionAndGetResponse("0x01cf339909a2707fc024d720110b48a5df79f725", IOUtil.readResourceAsString("abi/buyer.abi"), "addGoods",params5);
////
//        List<Object> params6 = new ArrayList<>();
//        params6.add(goodsnumber);
//        params6.add(buyernumber);
//        TransactionResponse transactionResponse6 = transactionProcessor.sendTransactionAndGetResponse("0x1543711132e484462616b61d6363adb46de5378b", IOUtil.readResourceAsString("abi/buyernumber.abi"), "addGoods",params6);
//////
//        List<Object> params7 = new ArrayList<>();
//        params7.add(goodsnumber);
//        params7.add(buyerstone);
//        TransactionResponse transactionResponse7 = transactionProcessor.sendTransactionAndGetResponse("0xee1362140a695503f97029b66c7ee9212ad66979", IOUtil.readResourceAsString("abi/buyerstone.abi"), "addGoods",params7);
////
//        List<Object> params8 = new ArrayList<>();
//        params8.add(goodsnumber);
//        params8.add(buyplace);
//        TransactionResponse transactionResponse8 = transactionProcessor.sendTransactionAndGetResponse("0x8fd6a83fba0daa1730d5ada19252335709aad626", IOUtil.readResourceAsString("abi/buyplace.abi"), "addGoods",params8);
////
//        List<Object> params9 = new ArrayList<>();
//        params9.add(goodsnumber);
//        params9.add(driver);
//        TransactionResponse transactionResponse9 = transactionProcessor.sendTransactionAndGetResponse("0x175d64aaa349f727ad649111754c8218284b4cee", IOUtil.readResourceAsString("abi/driver.abi"), "addGoods",params9);
////
//        List<Object> params10 = new ArrayList<>();
//        params10.add(goodsnumber);
//        params10.add(drivernumber);
//        TransactionResponse transactionResponse10 = transactionProcessor.sendTransactionAndGetResponse("0x22efea0e1ebadc6a506f68b9f0792e38f5624ff2", IOUtil.readResourceAsString("abi/drivernumber.abi"), "addGoods",params10);
//////
//        List<Object> params11 = new ArrayList<>();
//        params11.add(goodsnumber);
//        params11.add(endingplace);
//        TransactionResponse transactionResponse11 = transactionProcessor.sendTransactionAndGetResponse("0x20f11bc8259a5ca324db67333a0b8151aa00ae3b", IOUtil.readResourceAsString("abi/endingplace.abi"), "addGoods",params11);
////
//        List<Object> params12 = new ArrayList<>();
//        params12.add(goodsnumber);
//        params12.add(ice);
//        TransactionResponse transactionResponse12 = transactionProcessor.sendTransactionAndGetResponse("0xd804d5d2ca69442485a58c71cc767fae8b486f03", IOUtil.readResourceAsString("abi/ice.abi"), "addGoods",params12);
//
//        List<Object> params13 = new ArrayList<>();
//        params13.add(goodsnumber);
//        params13.add(nomal);
//        TransactionResponse transactionResponse13 = transactionProcessor.sendTransactionAndGetResponse("0xdc787ef19ca058eb8ec6bc21026fc0a719a58b07", IOUtil.readResourceAsString("abi/nomal.abi"), "addGoods",params13);
//
//        List<Object> params14 = new ArrayList<>();
//        params14.add(goodsnumber);
//        params14.add(numberamount);
//        TransactionResponse transactionResponse14 = transactionProcessor.sendTransactionAndGetResponse("0xf99febd096c4658075c28045ecd9be02acc91994", IOUtil.readResourceAsString("abi/numberamount.abi"), "addGoods",params14);
//
//        List<Object> params15 = new ArrayList<>();
//        params15.add(goodsnumber);
//        params15.add(processdata);
//        TransactionResponse transactionResponse15 = transactionProcessor.sendTransactionAndGetResponse("0x3cf41de747d4492795f065456b417c4f2ed9c1ce", IOUtil.readResourceAsString("abi/processdata.abi"), "addGoods",params15);
////
//        List<Object> params16 = new ArrayList<>();
//        params16.add(goodsnumber);
//        params16.add(processerstone);
//        TransactionResponse transactionResponse16 = transactionProcessor.sendTransactionAndGetResponse("0x1979bf40949ed29e87911ddf596c11942c96f1d1", IOUtil.readResourceAsString("abi/processerstone.abi"), "addGoods",params16);
//
//        List<Object> params17 = new ArrayList<>();
//        params17.add(goodsnumber);
//        params17.add(processplace);
//        TransactionResponse transactionResponse17 = transactionProcessor.sendTransactionAndGetResponse("0x66629866f77721b276be691f32c1e4e70cea7569", IOUtil.readResourceAsString("abi/processplace.abi"), "addGoods",params17);
//
//        List<Object> params18 = new ArrayList<>();
//        params18.add(goodsnumber);
//        params18.add(processpreson);
//        TransactionResponse transactionResponse18 = transactionProcessor.sendTransactionAndGetResponse("0x0663432c7db8d95d03f1389d719e0942a0554258", IOUtil.readResourceAsString("abi/processpreson.abi"), "addGoods",params18);
////
//        List<Object> params19 = new ArrayList<>();
//        params19.add(goodsnumber);
//        params19.add(seed);
//        TransactionResponse transactionResponse19 = transactionProcessor.sendTransactionAndGetResponse("0x2e001f9f8d142537b55f703bea2dedfc92bbd83c", IOUtil.readResourceAsString("abi/seed.abi"), "addGoods",params19);
//
//        List<Object> params20 = new ArrayList<>();
//        params20.add(goodsnumber);
//        params20.add(seedpreson);
//        TransactionResponse transactionResponse20 = transactionProcessor.sendTransactionAndGetResponse("0xb1d86cbaea641a63878ed070db762b9d5acaf99b", IOUtil.readResourceAsString("abi/seedpreson.abi"), "addGoods",params20);
////
////        List<Object> params21 = new ArrayList<>();
////        params21.add(goodsnumber);
////        params21.add(seedstone);
////        TransactionResponse transactionResponse21 = transactionProcessor.sendTransactionAndGetResponse("0x96c256d2a086574cdc0df9d0f9feca4ff5c1aab5", IOUtil.readResourceAsString("abi/seedstone.abi"), "addGoods",params21);
//
//        List<Object> params22 = new ArrayList<>();
//        params22.add(goodsnumber);
//        params22.add(seson);
//        TransactionResponse transactionResponse22 = transactionProcessor.sendTransactionAndGetResponse("0x4615d57f3e4e5a0ed93b384d0bcbc7c3048aa961", IOUtil.readResourceAsString("abi/seson.abi"), "addGoods",params22);
//
//        List<Object> params23 = new ArrayList<>();
//        params23.add(goodsnumber);
//        params23.add(stayday);
//        TransactionResponse transactionResponse23 = transactionProcessor.sendTransactionAndGetResponse("0xb233da7d0b9c40510ef7901083ca2523b9363b59", IOUtil.readResourceAsString("abi/stayday.abi"), "addGoods",params23);

// //       params.add(buyer);
////        params.add(buyplace);
////        params.add(buyday);
//            params.add(stayday);
 //           params.add(stayamount);
//////        params.add(buyerstone);
//////        params.add(buyernumber);
//////        params.add(numberamount);
//////        params.add(processpreson);
//////        params.add(processdata);
//////        params.add(processplace);
//////        params.add(bag);
//////        params.add(processerstone);
//////        params.add(driver);
//////        params.add(beginplace);
//////        params.add(endingplace);
//////        params.add(ice);
//////        params.add(drivernumber);
//////        params.add(seedpreson);
//////        params.add(seedstone);
//////        params.add(seed);
 //             params.add(seson);
//////        params.add(nomal);
//////        params.add(afirm);
//////        params.add(creattime);
////
////调用record合约，调用函数名为「addRecord」，函数参数类型为params
//        TransactionResponse ts1 = transactionProcessor.sendTransactionAndGetResponse("0x342b81287a780f03d50fe1c3c429dc51d25a1af2", IOUtil.readResourceAsString("abi/Creatrecord.abi"), "getGoods",params1);
//
////打印返回值
//        List<Object> returnValues1 = ts1.getReturnObject();
//        if (returnValues1 != null) {
//            for (Object value : returnValues1) {
//                System.out.println("上链返回值：" + value.toString());
//            }
//        }


////调用合约查询接口
        List<Object> pr2 = new ArrayList<>();
        pr2.add("00001");
//调用record合约的「getRecord」函数，参数为recordid
        TransactionResponse ts1 = transactionProcessor.sendTransactionAndGetResponse("0x4d7a1182d7f5be7910de1e080186192d4fe7191a", IOUtil.readResourceAsString("abi/Creatrecord.abi"), "getGoods",pr2);
        TransactionResponse ts2 = transactionProcessor.sendTransactionAndGetResponse("0x7ccbe8501d3db11e293f143e6d507815d158d833", IOUtil.readResourceAsString("abi/bag.abi"), "getGoods",pr2);
        TransactionResponse ts3 = transactionProcessor.sendTransactionAndGetResponse("0xc72233edec6dca1cdd9d64f2277149aaaad50e35", IOUtil.readResourceAsString("abi/beginplace.abi"), "getGoods",pr2);
        TransactionResponse ts4 = transactionProcessor.sendTransactionAndGetResponse("0x23853048280376ed7a8c683d78068467f8edf9c5", IOUtil.readResourceAsString("abi/buyday.abi"), "getGoods",pr2);
        TransactionResponse ts5 = transactionProcessor.sendTransactionAndGetResponse("0x01cf339909a2707fc024d720110b48a5df79f725", IOUtil.readResourceAsString("abi/buyer.abi"), "getGoods",pr2);
        TransactionResponse ts6 = transactionProcessor.sendTransactionAndGetResponse("0x1543711132e484462616b61d6363adb46de5378b", IOUtil.readResourceAsString("abi/buyernumber.abi"), "getGoods",pr2);
        TransactionResponse ts7 = transactionProcessor.sendTransactionAndGetResponse("0xee1362140a695503f97029b66c7ee9212ad66979", IOUtil.readResourceAsString("abi/buyerstone.abi"), "getGoods",pr2);
        TransactionResponse ts8 = transactionProcessor.sendTransactionAndGetResponse("0x8fd6a83fba0daa1730d5ada19252335709aad626", IOUtil.readResourceAsString("abi/buyplace.abi"), "getGoods",pr2);
        TransactionResponse ts9 = transactionProcessor.sendTransactionAndGetResponse("0x175d64aaa349f727ad649111754c8218284b4cee", IOUtil.readResourceAsString("abi/driver.abi"), "getGoods",pr2);
        TransactionResponse ts10 = transactionProcessor.sendTransactionAndGetResponse("0x22efea0e1ebadc6a506f68b9f0792e38f5624ff2", IOUtil.readResourceAsString("abi/drivernumber.abi"), "getGoods",pr2);
        TransactionResponse ts11 = transactionProcessor.sendTransactionAndGetResponse("0x20f11bc8259a5ca324db67333a0b8151aa00ae3b", IOUtil.readResourceAsString("abi/endingplace.abi"), "getGoods",pr2);
        TransactionResponse ts12 = transactionProcessor.sendTransactionAndGetResponse("0xd804d5d2ca69442485a58c71cc767fae8b486f03", IOUtil.readResourceAsString("abi/ice.abi"), "getGoods",pr2);
        TransactionResponse ts13 = transactionProcessor.sendTransactionAndGetResponse("0xdc787ef19ca058eb8ec6bc21026fc0a719a58b07", IOUtil.readResourceAsString("abi/nomal.abi"), "getGoods",pr2);
        TransactionResponse ts14 = transactionProcessor.sendTransactionAndGetResponse("0xf99febd096c4658075c28045ecd9be02acc91994", IOUtil.readResourceAsString("abi/numberamount.abi"), "getGoods",pr2);
        TransactionResponse ts15 = transactionProcessor.sendTransactionAndGetResponse("0x3cf41de747d4492795f065456b417c4f2ed9c1ce", IOUtil.readResourceAsString("abi/processdata.abi"), "getGoods",pr2);
        TransactionResponse ts16 = transactionProcessor.sendTransactionAndGetResponse("0x1979bf40949ed29e87911ddf596c11942c96f1d1", IOUtil.readResourceAsString("abi/processerstone.abi"), "getGoods",pr2);
        TransactionResponse ts17 = transactionProcessor.sendTransactionAndGetResponse("0x66629866f77721b276be691f32c1e4e70cea7569", IOUtil.readResourceAsString("abi/processplace.abi"), "getGoods",pr2);
        TransactionResponse ts18 = transactionProcessor.sendTransactionAndGetResponse("0x0663432c7db8d95d03f1389d719e0942a0554258", IOUtil.readResourceAsString("abi/processpreson.abi"), "getGoods",pr2);
        TransactionResponse ts19 = transactionProcessor.sendTransactionAndGetResponse("0x2e001f9f8d142537b55f703bea2dedfc92bbd83c", IOUtil.readResourceAsString("abi/seed.abi"), "getGoods",pr2);
        TransactionResponse ts20 = transactionProcessor.sendTransactionAndGetResponse("0xb1d86cbaea641a63878ed070db762b9d5acaf99b", IOUtil.readResourceAsString("abi/seedpreson.abi"), "getGoods",pr2);
        TransactionResponse ts21 = transactionProcessor.sendTransactionAndGetResponse("0x96c256d2a086574cdc0df9d0f9feca4ff5c1aab5", IOUtil.readResourceAsString("abi/seedstone.abi"), "getGoods",pr2);
        TransactionResponse ts22 = transactionProcessor.sendTransactionAndGetResponse("0x4615d57f3e4e5a0ed93b384d0bcbc7c3048aa961", IOUtil.readResourceAsString("abi/seson.abi"), "getGoods",pr2);
        TransactionResponse ts23 = transactionProcessor.sendTransactionAndGetResponse("0xb233da7d0b9c40510ef7901083ca2523b9363b59", IOUtil.readResourceAsString("abi/stayday.abi"), "getGoods",pr2);

        //打印返回值
        List<Object> returnValues1 = ts1.getReturnObject();
        List<Object> returnValues2 = ts2.getReturnObject();
        List<Object> returnValues3 = ts3.getReturnObject();
        List<Object> returnValues4 = ts4.getReturnObject();
        List<Object> returnValues5 = ts5.getReturnObject();
        List<Object> returnValues6 = ts6.getReturnObject();
        List<Object> returnValues7 = ts7.getReturnObject();
        List<Object> returnValues8 = ts8.getReturnObject();
        List<Object> returnValues9 = ts9.getReturnObject();
        List<Object> returnValues10 = ts10.getReturnObject();
        List<Object> returnValues11 = ts11.getReturnObject();
        List<Object> returnValues12 = ts12.getReturnObject();
        List<Object> returnValues13 = ts13.getReturnObject();
        List<Object> returnValues14 = ts14.getReturnObject();
        List<Object> returnValues15 = ts15.getReturnObject();
        List<Object> returnValues16 = ts16.getReturnObject();
        List<Object> returnValues17 = ts17.getReturnObject();
        List<Object> returnValues18 = ts18.getReturnObject();
        List<Object> returnValues19 = ts19.getReturnObject();
        List<Object> returnValues20 = ts20.getReturnObject();
        List<Object> returnValues21 = ts21.getReturnObject();
        List<Object> returnValues22 = ts22.getReturnObject();
        List<Object> returnValues23 = ts23.getReturnObject();
        System.out.println("goodsnumber:" + pr2);
        if (returnValues1 != null) {
            //检查返回值的长度是否正确
            if (returnValues1.size() == 1) {
                String goodsname = (String)returnValues1.get(0);
                System.out.println("goodsname:" + goodsname);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues2 != null) {
            //检查返回值的长度是否正确
            if (returnValues2.size() == 1) {
                String bag = (String)returnValues2.get(0);
                System.out.println("bag:" + bag);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues3 != null) {
            //检查返回值的长度是否正确
            if (returnValues3.size() == 1) {
                String beginplace = (String)returnValues3.get(0);
                System.out.println("beginplace:" + beginplace);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues4 != null) {
            //检查返回值的长度是否正确
            if (returnValues4.size() == 1) {
                String buyday = (String)returnValues4.get(0);
                System.out.println("buyday:" + buyday);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues5 != null) {
            //检查返回值的长度是否正确
            if (returnValues5.size() == 1) {
                String buyer = (String)returnValues5.get(0);
                System.out.println("buyer:" + buyer);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues6 != null) {
            //检查返回值的长度是否正确
            if (returnValues6.size() == 1) {
                String buyernumber = (String)returnValues6.get(0);
                System.out.println("buyernumber:" + buyernumber);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues7 != null) {
            //检查返回值的长度是否正确
            if (returnValues7.size() == 1) {
                String buyerstone = (String)returnValues7.get(0);
                System.out.println("buyerstone:" + buyerstone);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues8 != null) {
            //检查返回值的长度是否正确
            if (returnValues8.size() == 1) {
                String buyplace = (String)returnValues8.get(0);
                System.out.println("buyplace:" + buyplace);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues9 != null) {
            //检查返回值的长度是否正确
            if (returnValues9.size() == 1) {
                String driver = (String)returnValues9.get(0);
                System.out.println("driver:" + driver);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues10 != null) {
            //检查返回值的长度是否正确
            if (returnValues10.size() == 1) {
                String drivernumber = (String)returnValues10.get(0);
                System.out.println("drivernumber:" + drivernumber);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues11 != null) {
            //检查返回值的长度是否正确
            if (returnValues11.size() == 1) {
                String endingplace = (String)returnValues11.get(0);
                System.out.println("endingplace:" + endingplace);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues12 != null) {
            //检查返回值的长度是否正确
            if (returnValues12.size() == 1) {
                String ice = (String)returnValues12.get(0);
                System.out.println("ice:" + ice);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues13 != null) {
            //检查返回值的长度是否正确
            if (returnValues13.size() == 1) {
                String nomal = (String)returnValues13.get(0);
                System.out.println("nomal:" + nomal);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues14 != null) {
            //检查返回值的长度是否正确
            if (returnValues14.size() == 1) {
                String numberamount = (String)returnValues14.get(0);
                System.out.println("numberamount:" + numberamount);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues15 != null) {
            //检查返回值的长度是否正确
            if (returnValues15.size() == 1) {
                String processdata = (String)returnValues15.get(0);
                System.out.println("processdata:" + processdata);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues16 != null) {
            //检查返回值的长度是否正确
            if (returnValues16.size() == 1) {
                String processerstone = (String)returnValues16.get(0);
                System.out.println("processerstone:" + processerstone);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues17 != null) {
            //检查返回值的长度是否正确
            if (returnValues17.size() == 1) {
                String processplace = (String)returnValues17.get(0);
                System.out.println("processplace:" + processplace);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues18 != null) {
            //检查返回值的长度是否正确
            if (returnValues18.size() == 1) {
                String processplace = (String)returnValues18.get(0);
                System.out.println("processplace:" + processplace);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues19 != null) {
            //检查返回值的长度是否正确
            if (returnValues19.size() == 1) {
                String seed = (String)returnValues19.get(0);
                System.out.println("seed:" + seed);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues20 != null) {
            //检查返回值的长度是否正确
            if (returnValues20.size() == 1) {
                String seedpreson = (String)returnValues20.get(0);
                System.out.println("seedpreson:" + seedpreson);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues21 != null) {
            //检查返回值的长度是否正确
            if (returnValues21.size() == 1) {
                String seedstone = (String)returnValues21.get(0);
                System.out.println("seedstone:" + seedstone);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues22 != null) {
            //检查返回值的长度是否正确
            if (returnValues22.size() == 1) {
                String seedstone = (String)returnValues22.get(0);
                System.out.println("seedstone:" + seedstone);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }

        if (returnValues23 != null) {
            //检查返回值的长度是否正确
            if (returnValues23.size() == 1) {
                String stayday = (String)returnValues23.get(0);
                System.out.println("stayday:" + stayday);
            }
            else {
                System.out.println("返回值长度不正确");
            }
        }
    }
}
