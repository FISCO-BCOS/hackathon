package com.project.yihuobao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YihuobaoApplicationTests {

    @Test
    void contextLoads() {
    }

}
