package com.project.yihuobao.service;

import static org.junit.jupiter.api.Assertions.*;

class AdminuserServiceTest {

}