<template>
  <!--  -->
  <!-- 医生页面的主题框架 -->
  <!--  -->
  <el-container class="home-container">
    <!-- 头部 -->
    <el-header>
      <div>
        <img src="../../assets/医生 (2).svg" alt="" class="tupian" />
        <span>医元疗诊断系统</span>
      </div>
      <!-- 右上角 -->
      <el-dropdown class="userInfo" @command="handleCommand">
        <span class="el-dropdown-link">
          <i
            ><img
              class="zj_img"
              src="../../assets/微信图片_20221105230018.jpg"
              alt=""
          /></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="userInfo">个人中心</el-dropdown-item>
          <el-dropdown-item command="logout">注销登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </el-header>
    <!-- 主体 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside :width="isCollapse ? '64px' : '200px'">
        <div class="toggle-button" @click="toggleCollapse">
          <img src="../../assets/展开 (1).svg" alt="" class="expend_icon" />
        </div>
        <!-- 侧边栏菜单区 -->
        <el-menu
          background-color="#59C2E2"
          text-color="#fff"
          active-text-color="#333333"
          unique-opened
          :collapse="isCollapse"
          :collapse-transition="false"
          default-active="/home"
          router
        >
          <!-- 一级菜单 -->
          <el-menu-item index="/home">
            <template slot="title">
              <i class="el-icon-s-home"/>
              首页
            </template>
          </el-menu-item>

          <el-submenu index="1">
            <template slot="title">
              <!-- 图标 -->
              <i class="el-icon-user"></i>
              <!-- 文本 -->
              <span>患者管理</span>
            </template>
            <!-- 二级菜单 -->
            <!-- 因为el-menu中的router为true所以这里的跳转将以index为索引进行 -->
            <el-menu-item
              :index="'/' + subitem[0]"
              @click="saveNavState('/' + subitem[0])"
              ><template slot="title">
                <!-- 图标 -->
                <i class="el-icon-c-scale-to-original"></i>
                <!-- 文本 -->
                <span>患者名单</span>
              </template></el-menu-item
            >
          </el-submenu>
          <el-menu-item index="/records" disabled>
            <template slot="title">
              <!-- 图标 -->
              <i class="el-icon-document-copy"></i>
              <!-- 文本 -->
              <span>历史病历</span>
            </template>
            <!-- 二级菜单 -->
<!--            <el-menu-item index="1-4-1"-->
<!--              ><template slot="title">-->
<!--                &lt;!&ndash; 图标 &ndash;&gt;-->
<!--                <i class="el-icon-location"></i>-->
<!--                &lt;!&ndash; 文本 &ndash;&gt;-->
<!--                <span>子导航一</span>-->
<!--              </template></el-menu-item-->
<!--            >-->
          </el-menu-item>
          <el-menu-item index="/w-record" disabled>
              <!-- 图标 -->
              <i class="el-icon-data-analysis"></i>
              <!-- 文本 -->
              <span>病历撰写</span>
<!--            &lt;!&ndash; 二级菜单 &ndash;&gt;-->
<!--            <el-menu-item index="1-4-1"-->
<!--              ><template slot="title">-->
<!--                &lt;!&ndash; 图标 &ndash;&gt;-->
<!--                <i class="el-icon-location"></i>-->
<!--                &lt;!&ndash; 文本 &ndash;&gt;-->
<!--                <span>子导航一</span>-->
<!--              </template></el-menu-item-->
<!--            >-->
          </el-menu-item>
          <el-menu-item index="/authorized">
            <i class="el-icon-location"/>
            <span>已授权病历</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <!-- 详情页面 -->
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  data() {
    return {
      isCollapse: false,
      subitem: ['user'],
      activepath: '',
    }
  },
  methods: {
    handleCommand(command) {
      if (command === 'logout') {
        window.localStorage.clear()
        this.$router.push('./login')
      }
    },
    toggleCollapse() {
      this.isCollapse = !this.isCollapse
    },
    saveNavState(activepath) {
      console.log(activepath)
      window.sessionStorage.setItem('activepath', activepath)
      this.activepath = activepath
    },
  },
}
</script>

<style lang="less" scoped>
.home-container {
  height: 100%;
}
.el-header {
  display: flex;
  background-color: #6ec8f2;
  justify-content: space-between;
  padding-left: 5px;
  align-items: center;
  color: #fff;
  font-size: 20px;
  > div {
    display: flex;
    align-items: center;
    span {
      margin-left: 15px;
    }
  }
}
.el-aside {
  background-color: rgb(89, 194, 226);
  .el-menu {
    border-right: 0;
  }
}
.el-main {
  background-color: #fff;
}
.tupian {
  margin-top: 5px;
  width: 45px;
  height: 45px;
}
.zj_img {
  width: 50px;
  height: 50px;
  border-radius: 25px;
  margin-top: 5px;
}
.userInfo {
  cursor: pointer;
}
.expend_icon {
  width: 40px;
  height: 20px;
  margin-top: 5px;
}
.toggle-button {
  background-color: #99ccff;
  font-size: 10px;
  line-height: 24px;
  text-align: center;
  color: #fff;
  letter-spacing: 0.2em;
  cursor: pointer;
}
</style>
