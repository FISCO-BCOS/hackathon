<template>
  <!--  -->
  <!-- 体检页面的主题框架 -->
  <!--  -->
  <el-container class="home-container">
    <!-- 头部 -->
    <el-header>
      <div>
        <img src="../../assets/卡通医疗图标.svg" alt="" class="tupian" />
        <span>体检医师界面</span>
      </div>
      <!-- 右上角 -->
      <el-dropdown class="userInfo" @command="handleCommand">
        <span class="el-dropdown-link">
          <i
            ><img
              class="zj_img"
              src="../../assets/微信图片_20221106174605.jpg"
              alt=""
          /></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="userInfo">个人中心</el-dropdown-item>
          <el-dropdown-item command="logout">注销登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </el-header>
    <!-- 主体 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside width="200px">
        <!-- 侧边栏菜单区 -->
        <el-menu
          background-color="#68DFCB"
          text-color="#fff"
          active-text-color="#ffd04b"
        >
          <!-- 一级菜单 -->

          <el-menu-item index="0">
            <i class="el-icon-date"/>
            <template slot="title">
              提交体检报告
            </template>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <!-- 详情页面 -->
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  data() {
    return {}
  },
  methods: {
    handleCommand(command) {
      if ((command = 'logout')) {
        window.sessionStorage.clear()
        this.$router.push('./login')
      }
    },
  },
}
</script>

<style lang="less" scoped>
.home-container {
  height: 100%;
}
.el-header {
  display: flex;
  background-color: #19caad;
  justify-content: space-between;
  padding-left: 5px;
  align-items: center;
  color: #fff;
  font-size: 20px;
  > div {
    display: flex;
    align-items: center;
    span {
      margin-left: 15px;
    }
  }
}
.el-aside {
  background-color: #00f5cc;
}
.el-main {
  background-color: #fff;
}
.tupian {
  margin-top: 5px;
  width: 45px;
  height: 45px;
}
.zj_img {
  width: 50px;
  height: 50px;
  border-radius: 25px;
  margin-top: 5px;
}
.userInfo {
  cursor: pointer;
}
</style>
