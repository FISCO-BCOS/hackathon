<template>
  <el-card style="margin-top: 1vw; cursor: pointer;">
    <div style="display: flex; justify-content: center" @click="checkDetail">
      <el-descriptions style="margin: 1rem;">
        <el-descriptions-item label="姓名">{{ record.name }}</el-descriptions-item>
        <el-descriptions-item label="性别">{{ record.sex }}</el-descriptions-item>
        <el-descriptions-item label="年龄">{{ record.age }}</el-descriptions-item>
        <el-descriptions-item label="症状">
          <span>{{ record.symptom }}</span>
        </el-descriptions-item>
        <el-descriptions-item label="生命体征">{{ record.vital }}</el-descriptions-item>
      </el-descriptions>
      <el-descriptions style="margin: 1rem" direction="vertical">
        <el-descriptions-item label="处方药">
          <span>{{record.prescribe}}</span>
        </el-descriptions-item>
        <el-descriptions-item label="手术操作">
          <span>{{record.operator}}</span>
        </el-descriptions-item>
      </el-descriptions>
    </div>
  </el-card>
</template>

<script>
export default {
  name: "e-records",
  data() {
    return {}
  },
  props: {
    record: Object
  },
  methods: {
    checkDetail() {
      console.log(this.record);
    }
  }
}
</script>

<style scoped>
.label {
  font-weight: bolder;
}
</style>
