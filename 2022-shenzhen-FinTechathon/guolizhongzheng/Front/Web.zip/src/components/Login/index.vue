<template>
  <!--  -->
  <!-- 登录页面 -->
  <!--  -->
  <div class="login_container">
    <el-button type="primary" class="register" @click="dialog = true"
      >注册用户</el-button
    >
    <div class="login-register">
      <div class="contain">
        <div class="big-box" :class="{ active: isLogin }">
          <div class="big-contain" key="bigContainLogin" v-if="isLogin">
            <img src="../../assets/医生 (2).svg" alt="" class="doctor_icon" />
            <div class="btitle">医生登录</div>
            <div class="bform">
              <input
                type="email"
                placeholder="账号"
                v-model.trim="loginform.add"
              />
              <span class="errTips" v-if="emailError">* 账号填写错误 *</span>
              <input
                type="password"
                placeholder="密码"
                v-model.trim="loginform.cipher"
              />
              <span class="errTips" v-if="emailError">* 密码填写错误 *</span>
            </div>
            <!-- 以下为医生登录 -->
            <button class="bbutton" @click="submit">登录</button>
          </div>
          <!-- 右边 -->
          <div class="big-contain" key="bigContainRegister" v-else>
            <img
              src="../../assets/卡通医疗图标.svg"
              alt=""
              class="doctor_icon"
            />
            <div class="btitle">体检医师登录</div>
            <div class="bform">
              <input
                type="email"
                placeholder="账号"
                v-model="userform.add"
              />
              <input
                type="password"
                placeholder="密码"
                v-model="userform.cipher"
              />
            </div>
            <!-- 以下为体检医生登录 -->
            <button class="bbutton" @click="userLogin">体检医师登录</button>
          </div>
        </div>
        <div class="small-box" :class="{ active: isLogin }">
          <div class="small-contain" key="smallContainRegister" v-if="isLogin">
            <div class="stitle">你好，医疗工作者!</div>
            <p class="scontent">开始登录，和我们一起</p>
            <el-button class="sbutton" @click="changeType">体检医师<i class="el-icon-right el-icon--right"/></el-button>
          </div>
          <div class="small-contain" key="smallContainLogin" v-else>
            <div class="stitle">欢迎您!</div>
            <p class="scontent">与医生保持联系，请登录</p>
            <el-button class="sbutton" @click="changeType" icon="el-icon-back">医生</el-button>
          </div>
        </div>
      </div>
    </div>
    <!-- 注册弹出层 -->

    <el-drawer
      title="请填入相关信息以完成注册  ！"
      :before-close="handleClose"
      :visible.sync="dialog"
      custom-class="demo-drawer"
      ref="drawer"
    >
      <div class="demo-drawer__content">
        <el-progress
          :text-inside="true"
          :stroke-width="24"
          :percentage="100"
          status="success"
          class="progressBar"
        ></el-progress>
        <el-form :model="regisForm">
          <el-form-item label="活动名称" label-width="80px">
            <el-input
              v-model="regisForm.name"
              autocomplete="off"
              style="width: 180px"
            ></el-input>
          </el-form-item>
          <el-form-item label="活动区域" label-width="80px">
            <el-select v-model="regisForm.region" placeholder="请选择活动区域">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div class="demo-drawer__footer">
          <el-button @click="cancelForm">取 消</el-button>
          <el-button
            type="primary"
            @click="$refs.drawer.closeDrawer()"
            :loading="loading"
            >{{ loading ? '提交中 ...' : '确 定' }}</el-button
          >
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script>
import { login } from '@/api'
export default {
  name: 'login-register',
  data() {
    return {
      isLogin: false,
      emailError: false,
      passwordError: false,
      existed: false,
      loginform: {
        add: '0xa003E05b890641b967f36756BF18348130DE0743',
        cipher: '123456',
      },
      userform: {
        add: '0xc5363662FF505C757862bACa0Ee9B2Ea23fCf8c9',
        cipher: '123456',
      },
      regisForm: {
        name: '',
        region: '',
      },
      dialog: false,
      loading: false,
      timer: null,
    }
  },
  methods: {
    async userLogin1111() {
      console.log(this.userform111)
      const res = await this.$http.post('stuRegister', this.userform111)
      console.log(res)
    },
    changeType() {
      this.isLogin = !this.isLogin
    },
    // 以下为两个的完全不同的登录请求方法，第一个为mock数据，第二个为请求服务器数据
    // 1.医生登录
    submit() {
      this.$http.post('DoctorEnter', this.loginform).then(({data}) => {
        if (data.code === '200') {
          window.localStorage.setItem('doctorID', this.loginform.add)
          console.log(window.localStorage.getItem('doctorID'));
          this.$router.push('/doctor')
        }
      })
    },
    // 2.体检医师登录
    userLogin() {
      // const self = this
      // if (self.userform.username !== '' && self.userform.password !== '') {
      //   const { data: res } = await self.$http.post('login', this.userform)
      //   if (res.meta.status !== 200) {
      //     return this.$message.error('密码错误!!')
      //   }
      //   this.$message({
      //     message: '恭喜你，还记得密码',
      //     type: 'success',
      //   })
      //   window.sessionStorage.setItem('token', res.data.token) //存入数据到浏览器，
      this.$http({
        url: 'TestDoctorEnter',
        method: 'post',
        data: this.userform
      }).then(({data}) => {
        console.log(data);
        window.localStorage.setItem('medicalID', this.userform.add)
        this.$router.push('/admin')
      })
      // } else {
      //   this.$message.error('填写不能为空')
      // }
    },
    registerUser() {
      console.log('注册成功')
    },
    // 以下为注册弹出框
    handleClose(done) {
      if (this.loading) {
        return
      }
      this.$confirm('确定要提交表单吗？')
        .then((_) => {
          // 以下为点击注册确认后的事件
          console.log(this.regisForm)
          this.loading = true
          this.timer = setTimeout(() => {
            done()
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false
            }, 400)
          }, 2000)
        })
        .catch((_) => {})
    },
    cancelForm() {
      this.loading = false
      this.dialog = false
      clearTimeout(this.timer)
      console.log('object')
    },
  },
}
</script>

<style scoped lang="less">
.login_container {
  background: url('../../assets/VCG41N898842112.jpg') no-repeat center center
    fixed;
  background-size: cover;
}
.login-register {
  width: 100vw;
  height: 100vh;
  box-sizing: border-box;
}
.contain {
  width: 60%;
  height: 60%;
  position: relative;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  border-radius: 20px;
  box-shadow: 0 0 3px #f0f0f0, 0 0 6px #f0f0f0;
}
.big-box {
  width: 70%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 30%;
  transform: translateX(0%);
  transition: all 1s;
}
.big-contain {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.btitle {
  font-size: 1.5em;
  font-weight: bold;
  color: rgb(30, 144, 255);
}
.bform {
  width: 100%;
  height: 40%;
  padding: 2em 0;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
}
.bform .errTips {
  display: block;
  width: 50%;
  text-align: left;
  color: red;
  font-size: 0.7em;
  margin-left: 1em;
}
.bform input {
  width: 50%;
  height: 30px;
  border: none;
  outline: none;
  border-radius: 10px;
  padding-left: 2em;
  background-color: #f0f0f0;
}
.bbutton {
  width: 20%;
  height: 40px;
  border-radius: 24px;
  border: none;
  outline: none;
  background-color: rgb(30, 144, 255);
  color: #fff;
  font-size: 0.9em;
  cursor: pointer;
  margin-bottom: 1rem;
}
.small-box {
  width: 30%;
  height: 100%;
  background: linear-gradient(135deg, rgb(30, 144, 255), rgb(56, 183, 145));
  position: absolute;
  top: 0;
  left: 0;
  transform: translateX(0%);
  transition: all 1s;
  border-top-left-radius: inherit;
  border-bottom-left-radius: inherit;
}
.small-contain {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.stitle {
  font-size: 1.5em;
  font-weight: bold;
  color: #fff;
}
.scontent {
  font-size: 0.8em;
  color: #fff;
  text-align: center;
  padding: 2em 4em;
  line-height: 1.7em;
}
.sbutton {
  width: 60%;
  height: 40px;
  border-radius: 24px;
  border: 1px solid #fff;
  outline: none;
  background-color: transparent;
  color: #fff;
  font-size: 0.9em;
  cursor: pointer;
}

.big-box.active {
  left: 0;
  transition: all 0.5s;
}
.small-box.active {
  left: 100%;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-top-right-radius: inherit;
  border-bottom-right-radius: inherit;
  transform: translateX(-100%);
  transition: all 1s;
}
.register {
  margin: 15px;
  float: right;
}
.doctor_icon {
  width: 100px;
  height: 100px;
  margin: 15px;
}
.progressBar {
  margin: 0 auto 60px;
  width: 800px;
}
.demo-drawer__footer {
  margin: 70px 70px 70px 150px;
}
.progressBar {
  margin: 17px auto;
  width: 380px;
}
</style>
