<template>
  <div>

    <el-card>
      <div slot="header">
        <span>填写电子病历</span>
      </div>
      <div>
        <el-steps :space="300" :active="activeIndex" finish-status="success" align-center>
          <el-step title="就诊基本信息"/>
          <el-step title="症状描述及生命体征"/>
          <el-step title="开药方"/>
          <el-step title="医嘱及手术操作"/>
          <el-step title="电子病历价值及稀有度"/>
          <el-step title="病历预览"/>
        </el-steps>
        <el-form :model="record" ref="addRecord" label-width="100px" label-position="left" style="min-height: 60vh">
          <el-tabs :tab-position="'left'" v-model="activeIndex" :before-leave="beforeTabLeave">
            <el-tab-pane label="就诊基本信息" name="0">
              <el-form-item label="姓名">
                <el-input v-model="name" style="width: 20%"/>
              </el-form-item>
              <el-form-item label="性别">
                <el-select v-model="sex" placeholder="选择性别" style="width: 10%">
                  <el-option v-for="(item, index) in ['男', '女']" :key="index" :label="item" :value="item"/>
                </el-select>
              </el-form-item>
              <el-form-item label="年龄">
                <el-input v-model="age" style="width: 10%"/>
              </el-form-item>
              <el-form-item label="就诊时间">
                <el-input v-model="clinic_time" style="width: 20%;" disabled/>
              </el-form-item>
            </el-tab-pane>
            <el-tab-pane label="症状描述及生命体征" name="1">
              <el-form-item label="症状描述">
                <el-input type="textarea" v-model="record.symptom" :rows="10" placeholder="请输入症状描述"/>
              </el-form-item>
              <el-form-item label="生命体征">
                <el-input type="textarea" v-model="record.vital" :rows="10" placeholder="请输入患者生命体征"/>
              </el-form-item>
            </el-tab-pane>
            <!--            <el-tab-pane label="诊断结果">-->
            <!--              <el-form-item label="诊断结果">-->
            <!--                <el-input type="textarea" v-model="record.diagnosis_results" :rows="15"-->
            <!--                          placeholder="请输入您的诊断结果"/>-->
            <!--              </el-form-item>-->
            <!--            </el-tab-pane>-->
            <el-tab-pane label="开药方">
              <el-form-item label="开处方药">
                <!--                <el-button icon="el-icon-plus" type="primary" @click="addDrug" style="float: right">添加药品-->
                <!--                </el-button>-->
                <!--                <el-form :model="record.prescribe" :inline="true"-->
                <!--                         v-for="(item, index) in record.prescribe" :key="index">-->
                <!--                  <el-form-item :label="index + 1 === 1 ? '药品名称' : `药品(${index + 1})名称`">-->
                <!--                    <el-input v-model="item.drug_name"/>-->
                <!--                  </el-form-item>-->
                <!--                  <el-form-item :label="index + 1 === 1 ? '药品数量' : `药品(${index + 1})数量`">-->
                <!--                    <el-input v-model="item.num"/>-->
                <!--                  </el-form-item>-->
                <!--                </el-form>-->
                <el-input v-model="record.prescribe" type="textarea" :rows="10"/>
              </el-form-item>
            </el-tab-pane>
            <el-tab-pane label="医嘱及手术操作">
              <el-form-item label="医嘱">
                <el-input type="textarea" :rows="5" v-model="record.advice" placeholder="请输入医嘱"/>
              </el-form-item>
              <el-form-item label="手术操作">
                <el-input type="textarea" :rows="5" v-model="record.operator" placeholder="请输入手术操作"/>
              </el-form-item>
            </el-tab-pane>
            <el-tab-pane label="电子病历价值及稀有度">
              <el-form-item label="病历价值">
                <el-select v-model="record.value">
                  <el-option :value="1" label="1"/>
                  <el-option :value="2" label="2"/>
                  <el-option :value="3" label="3"/>
                </el-select>
              </el-form-item>
              <el-form-item label="病历稀有度">
                <el-select v-model="record.scarity">
                  <el-option :value="1" label="1"/>
                  <el-option :value="2" label="2"/>
                  <el-option :value="3" label="3"/>
                </el-select>
              </el-form-item>
            </el-tab-pane>
            <el-tab-pane label="病历预览">
              <el-descriptions :title="`${name}的电子病历`" :column="2" border>
                <template slot="extra">
                  <el-button type="primary" size="small" @click="submit">提交</el-button>
                </template>
                <el-descriptions-item>
                  <template slot="label">
                    姓名
                  </template>
                  {{ name }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    性别
                  </template>
                  {{ sex }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    年龄
                  </template>
                  {{ age }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    症状描述
                  </template>
                  {{ record.symptom }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    生命体征
                  </template>
                  {{ record.vital }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    药方
                  </template>
                  {{ record.prescribe }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    医嘱
                  </template>
                  {{ record.advice }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    手术操作
                  </template>
                  {{ record.operator }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    病历价值
                  </template>
                  {{ record.value }}
                </el-descriptions-item>
                <el-descriptions-item>
                  <template slot="label">
                    病历稀有度
                  </template>
                  {{ record.scarity }}
                </el-descriptions-item>
              </el-descriptions>
            </el-tab-pane>
          </el-tabs>
        </el-form>
      </div>
    </el-card>
  </div>
</template>

<script>

export default {
  name: "index",
  data() {
    return {
      activeIndex: 0,
      record: {
        eviAdd: window.localStorage.getItem('eviadd'),
        symptom: '',
        vital: '',
        prescribe: '',
        advice: '',
        operator: '',
        docAdd: window.localStorage.getItem('doctorID'),
        value: null,
        scarity: null
      },
      name: '',
      sex: '',
      age: null,
      dialogVisible: true,
      clinic_time: `${new Date().getFullYear()}年${new Date().getMonth() + 1}月${new Date().getDate()}日  ${new Date().getHours()}时${new Date().getMinutes()}分`
    }
  },
  methods: {
    beforeTabLeave(activeName, oldActiveName) {
      const {eviAdd, symptom, vital, prescribe, advice, operator, value, scarity} = this.record
      if (Number(oldActiveName) > Number(activeName)) {
        this.activeIndex++
        return true
      } else if (oldActiveName === '0' && (this.name === '' || this.sex === '' || this.age === null)) {
        this.$message.warning('请完整填写患者信息')
        return false
      } else if (oldActiveName === '1' && (symptom === '' || vital === '')) {
        this.$message.warning('请完整填写患者症状和生命体征')
        return false
      } else if (oldActiveName === '2' && prescribe === '') {
        this.$message.warning('请填写您的处理药方')
        return false
      } else if (oldActiveName === '3' && (advice === '' || operator === '')) {
        this.$message.warning('请填写您的医嘱和手术操作')
      } else if (oldActiveName === '4' && (value === null || scarity === null)) {
        this.$message.warning('请填写电子病历的价值以及稀有度')
      } else {
        this.activeIndex++
        return true
      }
    },
    submit() {
      console.log('record', this.record);
      this.$http({
        url: 'AttendDoctor',
        method: 'post',
        data: this.record
      }).then(({data}) => {
        console.log(data);
        this.$router.push('/home')
        this.$message.success('诊断完成')
      })
    },
    created() {
      this.record.eviAdd = window.localStorage.getItem('eviadd')
      console.log('eviadd', this.record.eviAdd);
    }
  }
}
</script>

<style scoped>

</style>
