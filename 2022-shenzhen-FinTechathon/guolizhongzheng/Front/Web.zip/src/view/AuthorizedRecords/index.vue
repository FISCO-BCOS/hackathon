<template>
  <div>
    <el-card>
      <template slot="header">
        <strong>已授权电子病历</strong>
      </template>
      <el-table :data="renderRecords" border>
        <el-table-column label="序号" width="100%">
          <template slot-scope="scope">
            <span>{{ scope.$index + 1 }}</span>
          </template>
        </el-table-column>
        <el-table-column label="患者病历记录地址" prop="address"/>
        <el-table-column label="查看详情">
          <template slot-scope="scope">
            <el-button type="success" icon="el-icon-search" @click="checkDetail(scope.row)">查看</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog
        title="电子病历信息"
        :visible.sync="dialogVisible"
        width="50%">
      <el-descriptions border>
        <el-descriptions-item>
          <template slot="label">
            症状
          </template>
          {{ aimRecord.symptom }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            生命体征
          </template>
          {{ aimRecord.vital }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            开处方药
          </template>
          {{ aimRecord.prescribe }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            医嘱
          </template>
          {{ aimRecord.advice }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            手术操作
          </template>
          {{ aimRecord.operator }}
        </el-descriptions-item>
      </el-descriptions>
      <span slot="footer" class="dialog-footer">
        <el-button @click="invite">邀请别人</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
        title="输入ID"
        :visible.sync="inputVisible">
      <el-input v-model="aimDoctor" placeholder="请输入医生ID"/>
      <span slot="footer">
        <el-button type="primary" @click="check">邀请</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "index",
  data() {
    return {
      records: [],
      renderRecords: [],
      aimRecord: {
        symptom: '',
        vital: '',
        prescribe: '',
        advice: '',
        operator: ''
      },
      dialogVisible: false,
      inputVisible: false,
      aimDoctor: '',
      aimRecordID: ''
    }
  },
  methods: {
    checkDetail(row) {
      console.log(row);
      const {address: eviadd} = row
      this.aimRecordID = eviadd
      this.$http({
        url: 'QuerEviMessage',
        method: 'post',
        data: {
          patAdd: window.localStorage.getItem('doctorID'),
          eviadd
        }
      }).then(({data}) => {
        console.log('data', data);
        let temp = data.data[0].split(',')
        this.aimRecord = {
          symptom: temp[0],
          vital: temp[1],
          prescribe: temp[2],
          advice: temp[3],
          operator: temp[4]
        }
        console.log(this.aimRecord);
        this.dialogVisible = true
      })
    },
    invite() {
      this.dialogVisible = false
      this.inputVisible = true
    },
    check() {
      this.$http({
        url: 'HolEvidDoctor',
        method: 'post',
        data: {
          docAdd: window.localStorage.getItem('doctorID'),
          toDocAdd: this.aimDoctor,
          eviAdd: this.aimRecordID
        }
      }).then(({data}) => {
        this.inputVisible = false
        this.$message.success('添加成功')
        console.log(data);
      })
    }
  },
  created() {
    this.$http({
      url: 'QueryDoctor',
      method: 'post',
      data: {
        docAdd: window.localStorage.getItem('doctorID')
      }
    }).then(({data}) => {
      console.log(data);
      this.records = data.data[5]
      this.records.forEach((item) => {
        this.renderRecords.push({address: item})
      })
      console.log(this.renderRecords);
    })
  }
}
</script>

<style scoped>

</style>
