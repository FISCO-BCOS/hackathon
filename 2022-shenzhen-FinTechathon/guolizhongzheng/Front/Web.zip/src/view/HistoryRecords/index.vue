<template>
  <el-card>
    <div slot="header">
      <strong>电子病历</strong>
      <el-button style="float: right; padding: 3px 0; font-size: large" type="text" @click="back">
        返回<i class="el-icon-d-arrow-right el-icon--right"/>
      </el-button>
    </div>
    <e-records :record="record" v-for="(record, index) in records" :key="index"/>
  </el-card>
</template>

<script>
import ERecords from "@/components/records/e-records";

export default {
  name: "index",
  data() {
    return {
      records: []
    }
  },
  components: {
    ERecords
  },
  created() {
    const {address} = this.$store.state.checkedPatientAddress
    console.log('患者地址', address);
    this.$http({
      url: 'QueryPat',
      method: 'post',
      data: {
        patAdd: address
      }
    }).then(({data}) => {
      // console.log(data);
      const bookID = data.data[2]
      console.log('bookID', bookID);
      this.$http({
        url: 'QueryAllEvi',
        method: 'post',
        data: {
          patAdd: bookID
        }
      }).then(({data}) => {
        console.log('QueryAllEvi', data.data);
        for (let i = 0; i < data.data[0].length; ++i) {
          this.$http({
            url: 'QuerEviMessage',
            method: 'post',
            data: {
              patAdd: window.localStorage.getItem('doctorID'),
              eviadd: data.data[0][i]
            }
          }).then(({data}) => {
            console.log('QuerEviMessage', data);
            let patientInfoArr = data.data[0].split(",")
            let names = data.data[2].replace(/"/g, "").split("|")
            const record = {
              name: names[0],
              sex: names[1],
              age: names[2],
              symptom: patientInfoArr[0],
              vital: patientInfoArr[1],
              prescribe: patientInfoArr[2],
              advice: patientInfoArr[3],
              operator: patientInfoArr[4]
            }
            this.records.push(record)
          })
        }
      })
    })
  },
  methods: {
    back() {
      this.$router.push('/user')
    }
  }
}
</script>

<style scoped>

</style>
