<template>
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{path: '/'}">首页</el-breadcrumb-item>
      <el-breadcrumb-item>提交体检结果</el-breadcrumb-item>
    </el-breadcrumb>
    <el-card>
      <el-alert
          title="请填写患者体检结果"
          type="info"
          center
          show-icon
          :closable="false"
      >
      </el-alert>
      <div style="border: 1px solid #c5b9b9; border-radius: 5px; margin-top: 1rem">
        <h1 style="text-align: center; font-size: 35px; letter-spacing: 30px">体检报告单</h1>
        <el-form>
          <el-form-item style="display: flex; justify-content: center">
            &nbsp;&nbsp;&nbsp;&nbsp;姓名：&nbsp;&nbsp;
            <el-input v-model="name" style="width: 15%" size="small"/>
            &nbsp;&nbsp;&nbsp;&nbsp;性别：&nbsp;&nbsp;
            <el-select v-model="sex" size="small" placeholder="请选择患者性别" style="width: 150px">
              <el-option value="男" label="男"/>
              <el-option value="女" label="女"/>
            </el-select>
            &nbsp;&nbsp;&nbsp;&nbsp;年龄：&nbsp;&nbsp;
            <el-input v-model="age" style="width: 10%" size="small"/>
          </el-form-item>
        </el-form>
        <el-divider/>
        <div
            style="margin: 1rem; padding: 1rem; display: flex; justify-content: space-around">
          <el-form :model="report" label-position="left" label-width="100px">
            <el-form-item label="体温：">
              <el-input v-model="temperature" style="width: 40%"/>&nbsp;&nbsp;&nbsp;&nbsp;&deg;C
            </el-form-item>
            <el-form-item label="体检本ID">
              <el-input v-model="report.reportadd" placeholder="请输入体检本ID" style="width: 100%"/>
            </el-form-item>
            <el-form-item label="医生ID">
              <el-input v-model="report.docAdd" style="width: 100%" disabled/>
            </el-form-item>
            <el-form-item label="血压">
              <el-input v-model="report.bloodpress" style="width: 100%"/>
            </el-form-item>
            <el-form-item label="血红蛋白">
              <el-input v-model="report.hemoglobin" style="width: 100%"/>
            </el-form-item>
            <el-form-item label="尿检">
              <el-input v-model="report.urinalysis" style="width: 100%"/>
            </el-form-item>
            <el-form-item label="BMI值">
              <el-input v-model="report.bmi" style="width: 100%"/>
            </el-form-item>
          </el-form>
          <el-form :model="report" label-position="left" label-width="100px">
            <el-form-item label="白细胞">
              <el-input v-model="report.hemameba" style="width: 100%"/>
            </el-form-item>
            <el-form-item label="报告价值">
              <el-select v-model="report.value">
                <el-option :value="1" label="1"/>
                <el-option :value="2" label="2"/>
                <el-option :value="3" label="3"/>
              </el-select>
            </el-form-item>
            <el-form-item label="报告稀有度">
              <el-select v-model="report.scarity">
                <el-option :value="1" label="1"/>
                <el-option :value="2" label="2"/>
                <el-option :value="3" label="3"/>
              </el-select>
            </el-form-item>
            <el-form-item label="体检报告：">
              <!--          <el-upload action="https://jsonplaceholder.typicode.com/posts/" list-type="picture-card" :on-preview="handlePDFPreview" :on-remove="handleRemove">-->
              <!--            <i class="el-icon-plus"/>-->
              <!--          </el-upload>-->
              <div class="content">
                <el-upload
                    class="avatar-uploader"
                    action="https://jsonplaceholder.typicode.com/posts/"
                    :show-file-list="false"
                    :on-success="handleAvatarSuccess"
                    :before-upload="beforeAvatarUpload">
                  <i class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
                <div style="margin-left: 25%">
                  <a href="javascript:" class="file">
                    选择文件
                    <input type="file" @change="uploadPdf($event)">
                  </a>
                </div>
                <div
                    style="border: 1px solid #938f8f; border-radius: 5px; width: 22vw; text-align: center; margin: 1rem"
                    v-if="pdfName">
            <span @click="gotoPdf(pdfUrl)">{{ pdfName }} <span
            /><i class="el-icon-close close" @click.stop.prevent="delPdf()"/></span>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </div>
        <div style="display: flex; justify-content: center; margin: 1rem">
          <el-button size="large" type="primary" style="width: 100px" @click="submit">提交</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
// import pdf from 'vue-pdf'

export default {
  name: 'index',
  data() {
    return {
      dialogVisible: false,
      pdfName: '',
      pdfUrl: '',
      report: {
        reportadd: '',
        docAdd: window.localStorage.getItem('medicalID'),
        bloodpress: '',
        hemoglobin: '',
        urinalysis: '',
        bmi: '',
        hemameba: '',
        value: null,
        scarity: null
      },
      name: '',
      sex: '',
      age: '',
      temperature: ''
    }
  },
  methods: {
    handlePDFPreview(file, fileList) {
      console.log(file, fileList);
    },
    handleRemove(file) {
      this.pdfUrl = file.url
      this.dialogVisible = true
    },
    uploadPdf(event) {
      console.log(event)
      if (event.target.files[0].type !== 'application/pdf') {
        return this.$message.warning('请选择上传pdf文件')
      }
      // if (this.ie9()) {
      //   this.$message.warning('iE9及以下版本IE浏览器暂不支持该功能，请升级IE浏览器或者用其他浏览器操作。')
      //   return
      // }
      //iE9及以下版本IE浏览器暂不支持该功能，请升级IE浏览器或者用其他浏览器操作。
      let inputDOM = event.target
      let _this = this
      const reader = new FileReader();
      reader.readAsDataURL(event.target.files[0])//读取文件
      reader.onload = function (e) {
        _this.getPdfUrl(event.target.files[0])//将得到的blob传出读取
        _this.pdfName = event.target.files[0].name
        inputDOM.value = null //将input置空 否则上传相同文件无反应 (不过置空后28行的打印 就看不到 event.target.files 文件数据（可以先注释此行看下数据--就是pdf文件）   )
      }
    },
    //通过读取pdf得到url
    getPdfUrl(file) {
      let url = URL.createObjectURL(file) //将blob文件转化成url
      this.pdfUrl = url  //赋值给url
      console.log(url)  // blob:http://localhost:8080/f2049a9d-31a6-4bd9-8a94-23dee457218f
      return url
    },
    // 打开pdf
    gotoPdf(pdfUrl) {
      // window.location.href = pdfUrl
      window.open(pdfUrl)
    },
    // 删除pdf
    delPdf() {
      this.pdfName = ''
      this.pdfUrl = ''
    },
    beforeAvatarUpload() {

    },
    handleAvatarSuccess() {

    },
    submit() {
      console.log(this.report);
      this.$http.post('PhyDoctor', {
        docAdd: this.report.docAdd,
        reportadd: this.report.reportadd,
        bloodpress: this.report.bloodpress,
        hemoglobin: this.report.hemoglobin,
        urinalysis: this.report.urinalysis,
        bmi: this.report.bmi,
        hemameba: this.report.hemameba,
        value: this.report.value,
        scarity: this.report.scarity
      }).then(({data}) => {
        console.log(data);
        this.$message.success('提交成功')
        this.report = null
        this.name = ''
        this.age = ''
        this.sex = ''
      })
    }
  }
}
</script>

<style scoped>
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}

.avatar-uploader .el-upload:hover {
  border-color: #409EFF;
}

.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}

.file {
  position: relative;
  display: inline-block;
  background: #D0EEFF;
  border: 1px solid #99D3F5;
  border-radius: 4px;
  padding: 4px 12px;
  overflow: hidden;
  color: #1E88C7;
  text-decoration: none;
  text-indent: 0;
  line-height: 20px;
}

.file input {
  position: absolute;
  font-size: 100px;
  right: 0;
  top: 0;
  opacity: 0;
}

.file:hover {
  background: #AADFFD;
  border-color: #78C3F3;
  color: #004974;
  text-decoration: none;
}

.close:hover {
  color: #409EFF;
  font-size: x-large;
}
</style>
