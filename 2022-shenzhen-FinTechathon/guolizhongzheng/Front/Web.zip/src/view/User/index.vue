<template>
  <div>
    <el-card style="min-height: 85vh">
      <div slot="header">
        <span>患者名单</span>
      </div>
      <div v-if="!isEmpty">
        <el-table height="378"
                  :data="patients.length > pageSize ? patients.slice((currentPage - 1) * pageSize, currentPage * pageSize) : patients "
                  border stripe>
          <el-table-column label="序号" width="60%">
            <template slot-scope="row">
              {{ patients.indexOf(row.row) + 1 }}
            </template>
          </el-table-column>
          <el-table-column prop="name" label="姓名" width="100%"/>
          <el-table-column prop="age" label="年龄" width="50%"/>
          <el-table-column prop="sex" label="性别" width="50%"/>
          <el-table-column prop="id" label="身份证号"/>
          <el-table-column prop="address" label="患者地址"/>
          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button type="info" icon="el-icon-search" @click="checkPatient(scope.row)">
                查看
              </el-button>
              <el-button type="primary" icon="el-icon-edit" @click="pickUp(scope.row)">接号</el-button>
            </template>
          </el-table-column>
          <el-table-column label="状态">
            <template slot-scope="scope">
              <i style="font-size: x-large" v-if="scope.$index === patients.length - 1" class="el-icon-loading"/>
              <i style="font-size: x-large" v-else class="el-icon-check"/>
            </template>
          </el-table-column>
        </el-table>
        <div style="display: flex; justify-content: center; margin-top: 5vh">
          <el-pagination
              layout="total, sizes, prev, pager, next, jumper"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 10, 20]"
              :page-size="5"
              :page-count="5"
              :total="patients.length"/>
        </div>
      </div>
      <el-empty v-else description="表格数据为空"/>
    </el-card>

    <el-dialog
        title="电子病历"
        :visible.sync="dialogVisible"
    >
      <el-descriptions border>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            姓名
          </template>
          {{ checkedPatients.name }}
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            性别
          </template>
          男
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            年龄
          </template>
          19
        </el-descriptions-item>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            手机号
          </template>
          12345678910
        </el-descriptions-item>
      </el-descriptions>
      <span slot="footer">
        <el-button type="primary" @click="dialogVisible = false">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      patients: [],
      currentPage: 1,
      pageSize: 5,
      dialogVisible: false,
      checkedPatients: {},
      isEmpty: false
    }
  },
  methods: {
    //每页条数改变时触发 选择一页显示多少行
    handleSizeChange(val) {
      this.currentPage = 1;
      this.pageSize = val;
    },

    //当前页改变时触发 跳转其他页
    handleCurrentChange(val) {
      this.currentPage = val;
    },

    pickUp(row) {
      const {address} = row
      this.$http({
        url: 'QueryPat',
        method: 'post',
        data: {
          patAdd: address
        }
      }).then(({data}) => {
        // console.log(data);
        const bookID = data.data[2]
        // console.log('bookID', bookID);
        this.$http({
          url: 'QueryAllEvi',
          method: 'post',
          data: {
            patAdd: bookID
          }
        }).then(({data}) => {
          let length = data.data[0].length
          window.localStorage.setItem('eviadd', data.data[0][length - 1])
          this.$http({
            url: 'QuerEviMessage',
            method: 'post',
            data: {
              patAdd: window.localStorage.getItem('doctorID'),
              eviadd: data.data[0][length - 1]
            }
          }).then(({data}) => {
            console.log('new QuerEviMessage', data);
          })
        })
      })
      this.$router.push('/w-record')
    },
    checkPatient(row) {
      this.$store.state.checkedPatientAddress = row
      this.$router.push('/records')
    }
  },
  created() {
    const docAdd = window.localStorage.getItem('doctorID')
    this.$http({
      url: 'QueryDoctor',
      method: 'post',
      data: {
        docAdd: docAdd
      }
    }).then(async ({data}) => {
      let patientIDs = data.data[1]
      console.log('患者ID', patientIDs);
      for (let i = 0; i < patientIDs.length; ++i) {
        console.log(patientIDs[i]);
        const {data: res} = await this.$http.post('QueryPat', {patAdd: patientIDs[i]})
        const info = res.data[4]
        const patientInfo = info.replace(/"/g, '').split('|')
        const singleInfo = {
          name: patientInfo[0],
          sex: patientInfo[1],
          age: patientInfo[2],
          id: patientInfo[3],
          address: patientIDs[i]
        }
        console.log(singleInfo);
        this.patients.push(singleInfo)
      }
      console.log(this.patients);
      this.isEmpty = this.patients.length === 0;
    })
  }
}
</script>

<style lang="scss" scoped></style>
