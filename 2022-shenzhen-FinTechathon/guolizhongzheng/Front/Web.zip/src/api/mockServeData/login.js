import Mock from 'mockjs'
export default {
  login: (config) => {
    console.log('hello2')
    console.log(config)
    console.log(config.body)
    const { username, password } = JSON.parse(config.body)
    if (username === 'admin' && password === '123456') {
      return {
        code: 200,
      }
    } else {
      return 404
    }
  },
}
