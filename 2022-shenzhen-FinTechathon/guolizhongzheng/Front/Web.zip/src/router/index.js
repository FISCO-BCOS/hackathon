import Vue from 'vue'
import VueRouter from 'vue-router'
import {Loading} from 'element-ui'

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    component: () => import('../components/Login'),
  },
  {
    path: '/',
    redirect: '/login',
  },
  {
    path: '/doctor',
    component: () => import('../components/Doctor'),
    redirect: '/home',
    children: [
      {
        path: '/home',
        name: 'home',
        component: () => import('../view/Home/index.vue'),
      },
      {
        path: '/user',
        name: 'user',
        component: () => import('../view/User/index.vue'),
      },
      {
        path: '/records',
        name: 'Medical records',
        component: () => import('@/view/HistoryRecords')
      },
      {
        path: '/w-record',
        name: 'write record',
        component: () => import('@/view/WriteRecord')
      },
      {
        path: '/authorized',
        name: 'Authorized Record',
        component: () => import('@/view/AuthorizedRecords')
      }
    ],
  },
  {
    path: '/admin',
    component: () => import('../components/Admin'),
    children: [
      {
        path: '/admin',
        name: 'admin',
        component: () => import('../view/Submit/index.vue'),
      },
    ],
  },
]

const router = new VueRouter({
  routes,
})
//用来验证登录，因后端技术不行暂时放弃，但是可以在sessionStorage存address用来当做全局数据使用
// router.beforeEach((to, from, next) => {
//   if (to.path === '/login') return next()
//   const tokenStr = window.sessionStorage.getItem('token')
//   if (!tokenStr) return next('/login')
//   next()
// })

// 路由跳转页面加载效果(1s)
const option = {
  lock: true,
  text: 'Loading',
  spinner: 'el-icon-loading',
  background: 'rgba(255,255,255,0.5)'
}
router.beforeEach((to, from, next) => {
  let loadingInstance = Loading.service(option)
  setTimeout(() => {
    loadingInstance.close()
    next()
  }, 1000)
})
export default router
