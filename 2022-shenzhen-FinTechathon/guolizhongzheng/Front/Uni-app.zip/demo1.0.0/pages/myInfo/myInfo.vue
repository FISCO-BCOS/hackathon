<template>
	<view class="index">
		<view class="flex-row section_3">
			<image
				class="image_6"
				src="https://codefun-proj-user-res-1256085488.cos.ap-guangzhou.myqcloud.com/5eedc9543259190011441867/60c321996d32e90012f09dd0/16238397302692763017.png"
			/>
			<p>&nbsp;{{ storename[0] }}</p>
			<p class="text_3">
				性别: {{ storename[1] }} 共享积分：
				<text class="fenshufont">{{ fenshu }}</text>
			</p>
		</view>
		<!-- 电子病历卡片1 -->
		<u-divider text="我的电子病历" textPosition="left" textColor="#19d08b" lineColor="#19d08b"></u-divider>
		<view class="flex-col items-center image-wrapper_1" @click="tests">
			<image
				class="image_5"
				src="https://project-user-resource-1256085488.cos.ap-guangzhou.myqcloud.com/60c325b4767e240013341755/60c3218d6d32e90012f09dc8/16551312673699756247.png"
			/>
		</view>
		<!-- 电子病历卡片2 -->
		<u-divider text="我的电子体检表" textPosition="left" textColor="#19d08b" lineColor="#19d08b"></u-divider>
		<view class="flex-col items-center image-wrapper_2" @click="tijianinfoid">
			<image
				class="image_5"
				src="https://project-user-resource-1256085488.cos.ap-guangzhou.myqcloud.com/60c325b4767e240013341755/60c3218d6d32e90012f09dc8/16551312673699756247.png"
			/>
		</view>
	</view>
</template>

<script>
import { forEach } from 'axios/lib/utils';
import { created } from '../../uni_modules/uview-ui/libs/mixin/mixin';
export default {
	data() {
		return {
			namedata: [],
			storename: this.$store.name.replace(/"/g, '').split('|'),
			fenshu: 0
		};
	},
	methods: {
		async tests() {
			const { data: res } = await this.$http.post('QueryAllEvi', { patAdd: this.$store.bookid });
			console.log('res.data', res.data);
			console.log('rea.data[0]', res.data[0], typeof res.data[0]);
			let data = res.data[0];
			// res.data[0].forEach(item => {
			// 	console.log(item);
			// });
			this.$store.bookiddata = res.data;
			for (let i = 0; i < data.length; ++i) {
				this.$http.post('QuerEviMessage', { patAdd: this.$store.useradd, eviadd: data[i] }).then(res => {
					console.log(res.data.data[0]);
					this.namedata.push(res.data.data[0]);
				});
			}
			this.$store.bookiddatastring = this.namedata;
			uni.navigateTo({
				url: '/pages/infosCardMessage/bingliCardInfo'
			});
		},
		async tijianinfoid() {
			const { data: res } = await this.$http.post('QueryAllReport', { patAdd: this.$store.tijianbenid });
			console.log('res', res.data);
			console.log('resdata', res.data[0]);
			this.$store.tijianbeniddata = res.data[0];
			console.log('tijianbeniddata', this.$store.tijianbeniddata);
			uni.navigateTo({
				url: '/pages/infosCardMessage/tijianCardInfo'
			});
		}
	},
	async created() {
		const { data: res } = await this.$http.post('QueryPat', { patAdd: this.$store.useradd });
		console.log('hahahaha--------------------', res);
		console.log(res.data[1]);
		this.fenshu = res.data[1];
		console.log(this.fenshu);
	}
};
</script>

<style>
.index {
	/* background-color: #eaedf1; */
}
.section_3 {
	padding: 41rpx 32rpx 40rpx;
	background-color: #ffffff;
}
.image_6 {
	filter: drop-shadow(0px 2rpx 3rpx #0000000a);
	width: 112rpx;
	height: 112rpx;
}
.text_3 {
	margin-top: 20px;
	margin-left: 12rpx;
	align-self: center;
	color: #333333;
	font-size: 25rpx;
	font-family: 'PingFangSC-Medium';
	font-weight: 500;
	line-height: 44rpx;
}
/* 电子病历卡片 */
.image-wrapper_1 {
	margin: 0 30rpx;
	padding: 271rpx 0 22rpx;
	border-radius: 16rpx;
	background-image: url('http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5gdTpZ8xISHd8WS2YPR6u1Blxn3MWP37x2gyjmI.KSO1T03UumLqAZpXwl*rU9nA9YFRriqNSUw9t7wQxWkx1jM!/b&bo=AAQAAwAAAAABByc!&rf=viewer_4');
	background-size: 100% 100%;
	background-repeat: no-repeat;
}
.image-wrapper_2 {
	margin: 0 30rpx;
	padding: 271rpx 0 22rpx;
	border-radius: 16rpx;
	background-image: url('http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5gdTpZ8xISHd8WS2YPR6u1D9*XMJ0Ly1IC.Rsx6YpmGVzbv7UMQqq7Pw*sZkp5FV7t1r8ddGa7R7Hm46PytOZG4!/b&bo=AASrAgAAAAABB40!&rf=viewer_4');
	background-size: 100% 100%;
	background-repeat: no-repeat;
}
.image_5 {
	width: 40rpx;
	height: 7rpx;
}
.fenshufont {
	color: #19d08b;
}
</style>
