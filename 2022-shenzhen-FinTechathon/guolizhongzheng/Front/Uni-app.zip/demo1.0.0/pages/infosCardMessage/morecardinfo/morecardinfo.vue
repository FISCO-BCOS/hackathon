<template>
	<view>
		<view class="list-item index">
			<view class="justify-between">
				<text class="text_4">###</text>
				<text class="text_6">{{ hahaha[0] }}</text>
			</view>
			<view class="justify-between group_7"><text class="text_10">签名有效</text></view>

			<view class="justify-between">
				<text class="text_12">症状&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : {{ userinfos[0] }}</text>
			</view>
			<hr />
			<view class="justify-between">
				<text class="text_12">生命体征: {{ userinfos[1] }}</text>
			</view>
			<hr />
			<view class="justify-between">
				<text class="text_12">开药处方: {{ userinfos[2] }}</text>
			</view>
			<hr />
			<view class="justify-between">
				<text class="text_12">医嘱&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : {{ userinfos[3] }}</text>
			</view>
			<hr />
			<view class="justify-between">
				<text class="text_12">手术操作: {{ userinfos[4] }}</text>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			hahaha: [],
			userinfos: []
		};
	},
	methods: {},
	async mounted() {
		console.log('allindex', this.$store.allindex);
		const { data: res } = await this.$http.post('QuerEviMessage', { patAdd: this.$store.useradd, eviadd: this.$store.allindex });
		this.hahaha = res.data[2].replace(/"/g, '').split(',');
		this.userinfos = res.data[0].split(',');
	}
};
</script>

<style>
.index {
	position: relative;
}
.list-item {
	padding: 39rpx 0 37rpx;
	border-bottom: solid 2rpx #f1f1f2;
}
.group_7 {
	margin-top: 7rpx;
}
.text_12 {
	margin-top: 8rpx;
	align-self: flex-start;
	color: #19d08b;
	font-size: 24rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 33rpx;
	margin-left: 12px;
}
.text_4 {
	color: #0acffe;
	font-size: 34rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 48rpx;
	position: absolute;
	right: 5%;
}
.text_6 {
	color: #292d4d;
	font-size: 34rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 48rpx;
	margin-left: 12px;
}
.text_8 {
	color: #a6a7b4;
	font-size: 24rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 33rpx;
	margin-left: 12px;
}
.text_10 {
	color: #a6a7b4;
	font-size: 24rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 33rpx;
	position: absolute;
	right: 5%;
}
</style>
