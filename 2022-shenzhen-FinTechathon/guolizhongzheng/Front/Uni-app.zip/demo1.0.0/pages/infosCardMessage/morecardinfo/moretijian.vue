<template>
	<view>
		<view class="list-item index">
			<view class="justify-between">
				<text class="text_4">###</text>
				<text class="text_6">{{ name }}</text>
			</view>
			<view class="justify-between group_7">
				<text class="text_8">属性</text>
				<text class="text_10">签名有效</text>
			</view>

			<view class="justify-between">
				<text class="text_12">血压&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : {{ data[0] }}</text>
			</view>
			<view class="justify-between">
				<text class="text_12">血红蛋白: {{ data[1] }}</text>
			</view>
			<view class="justify-between">
				<text class="text_12">我的尿检: {{ data[2] }}</text>
			</view>
			<view class="justify-between">
				<text class="text_12">bmi值&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : {{ data[3] }}</text>
			</view>
			<view class="justify-between">
				<text class="text_12">白细胞值: {{ data[4] }}</text>
			</view>
		</view>
	</view>
</template>

<script>
import { data } from '../../../uni_modules/uview-ui/libs/mixin/mixin';
export default {
	data() {
		return {
			data: [],
			name: this.$store.name
		};
	},
	methods: {},
	async mounted() {
		console.log('resssssss', this.$store.tijianallindex);
		const { data: res } = await this.$http.post('QuerReportMessage', { patAdd: this.$store.useradd, repadd: this.$store.tijianallindex });
		console.log(res.data[2]);
		this.data = res.data[2].split(',');
		console.log(this.data);
	}
};
</script>

<style>
.index {
	position: relative;
}
.list-item {
	padding: 39rpx 0 37rpx;
	border-bottom: solid 2rpx #f1f1f2;
}
.group_7 {
	margin-top: 7rpx;
}
.text_12 {
	margin-top: 8rpx;
	align-self: flex-start;
	color: #19d08b;
	font-size: 24rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 33rpx;
	margin-left: 12px;
}
.text_4 {
	color: #0acffe;
	font-size: 34rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 48rpx;
	position: absolute;
	right: 5%;
}
.text_6 {
	color: #292d4d;
	font-size: 34rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 48rpx;
	margin-left: 12px;
}
.text_8 {
	color: #a6a7b4;
	font-size: 24rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 33rpx;
	margin-left: 12px;
}
.text_10 {
	color: #a6a7b4;
	font-size: 24rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 33rpx;
	position: absolute;
	right: 5%;
}
</style>
