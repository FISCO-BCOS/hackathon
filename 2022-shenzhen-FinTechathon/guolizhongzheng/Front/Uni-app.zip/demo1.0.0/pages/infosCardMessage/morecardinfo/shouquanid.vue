<template>
	<view class="index">
		<view class="card" @click="moreinfo(index)" v-for="(item, index) in cardTitleInfo">
			<view class="myinfotext">
				<p class="title">症状：{{ item[0] }}</p>
				<p class="title">医嘱 {{ item[3] }}</p>
			</view>

			<img
				src="http://a1.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5tCbnwLSpsBI5bLkVW9ZxUO.YnKc5Io6Hk8mwSv5G0lNQMzMg68uAJ5Z8D3EWawZIg5.3PmbHEXjrXILdkdXi2w!/c&ek=1&kp=1&pt=0&bo=yADIAAAAAAADFzI!&tl=1&vuin=2279265610&tm=1669604400&dis_t=1669605860&dis_k=53ae6362caa30e3458985e6bbeb80fbc&sce=60-2-2&rf=viewer_4"
				alt=""
				class="imgclass"
			/>
		</view>
		<!-- 弹出层 -->
		<uni-popup ref="popup" background-color="#fff" type="dialog" class="father">
			<u-button type="primary" ripple @click="shouquan1" class="child0" size="medium">病历授权</u-button>
			<u-button type="primary" ripple @click="xiugai">权限修改</u-button>
			<u-button type="primary" ripple @click="deletes">权限删除</u-button>
		</uni-popup>

		<!-- 输入框 -->
		<uni-popup ref="inputDialog" type="dialog">
			<uni-popup-dialog ref="inputClose" mode="input" title="请输入要授权的级别" placeholder="请再次确认" @confirm="dialogInputConfirm"></uni-popup-dialog>
		</uni-popup>
		<uni-popup ref="inputDialog1" type="dialog">
			<uni-popup-dialog ref="inputClose" mode="input" title="请输入修改授权的级别" placeholder="请再次确认" @confirm="dialogInputConfirm1"></uni-popup-dialog>
		</uni-popup>
	</view>
</template>

<script>
export default {
	data() {
		return {
			mydata: this.$store.bookiddatastring,
			renderData: [],
			emptydata: [],
			cardTitleInfo: [],
			levle: 0
		};
	},
	methods: {
		async moreinfo(index) {
			// this.$http({
			// 	url: 'QueryAllEvi',
			// 	method: 'post',
			// 	data: {
			// 		patAdd: this.$store.bookid
			// 	}
			// }).then(res => {
			// 	console.log('res.data.data[0]', res.data.data[0]);
			// 	this.$store.allindex = res.data.data[0][index];
			// 	console.log('eviAdd', this.$store.allindex);
			// });
			const res = await this.$http.post('QueryAllEvi', { patAdd: this.$store.bookid });
			console.log('hahahaahha', res.data.data[0][index]);
			this.$store.allindex = res.data.data[0][index];
			console.log('useradd', this.$store.useradd);
			console.log('eviAdd', this.$store.allindex);
			console.log('add', this.$store.shouquanDocvalue);
			this.$refs.popup.open('bottom');
			// this.$refs[index].open();
			// uni.navigateTo({
			// 	url: '/pages/infosCardMessage/morecardinfo/morecardinfo'
			// });
		},
		shouquan1() {
			this.$refs.popup.close();
			this.$refs.inputDialog.open();
		},
		async dialogInputConfirm(value) {
			this.$refs.inputDialog.close();
			console.log('-------');
			console.log(this.levle);
			console.log(this.$store.allindex);
			console.log(this.$store.useradd);
			const { data: res } = await this.$http.post('ShareData', {
				patAdd: this.$store.useradd,
				eviAdd: this.$store.allindex,
				add: this.$store.shouquanDocvalue,
				levle: parseInt(value)
			});
			console.log(res);
		},
		xiugai() {
			this.$refs.popup.close();
			this.$refs.inputDialog1.open();
		},
		async dialogInputConfirm1(value) {
			const { data: res } = await this.$http.post('ModifyEviAuthority', {
				eviadd: this.$store.allindex,
				add: this.$store.shouquanDocvalue,
				levle: parseInt(value)
			});
			console.log(res);
			this.$refs.inputDialog1.close();
		},
		async deletes() {
			const { data: res } = await this.$http.post('DeleteDocdd', {
				docadd: this.$store.shouquanDocvalue,
				eviadd: this.$store.allindex
			});
			console.log(res);
		}
	},
	async mounted() {
		console.log('renderdata', this.renderData);
		console.log('bookiddata', this.$store.bookiddata);
		for (let i = 0; i < this.$store.bookiddata[0].length; ++i) {
			const { data: res } = await this.$http.post('QuerEviMessage', { patAdd: this.$store.useradd, eviadd: this.$store.bookiddata[0][i] });
			console.log('res', res.data[0]);
			let everyRecordInfo = res.data[0].split(',');
			this.cardTitleInfo.push(everyRecordInfo);
		}
		console.log('cardTitleInfo', this.cardTitleInfo);
	}
};
</script>

<style lang="scss">
.index {
	/* background-color: #808080; */
}
.card {
	/*卡片的宽度*/
	width: 90%;
	/*左外边距，这里代表距离最左边的距离*/
	margin-left: 5%;
	/*卡片的高度。*/
	height: 200rpx;
	/*背景色，可以自己更换*/
	background: rgb(248, 247, 252);
	/* radius是卡片的边框的圆润c程度
    shadow是阴影效果，四个值分别为水平阴影，垂直阴影，模糊距离，阴影的颜色。
 */
	border-radius: 10rpx;
	box-shadow: 5px 5px 5px #cdcfcf;
	position: relative;
	margin-top: 15rpx;
	position: relative;
}
.title {
	margin: 15px;
	font-size: 20rpx;
	// font-weight: bold;
	width: 280px;
}
.doctorName {
	font-size: 25rpx;
	font-weight: normal;
	position: absolute;
	top: 130%;
}
.miaoshu {
	position: absolute;
	top: 240%;
	font-size: 20rpx;
	font-weight: normal;
	color: #19d08b;
}
.imgclass {
	width: 110rpx;
	height: 110rpx;
	position: absolute;
	top: 23%;
	right: 4%;
}
.mybutton {
	margin: 15px;
}
.myinfotext {
	position: relative;
	top: 10%;
	left: 5%;
}
</style>
