<template>
	<view class="index">
		<view class="card" @click="moreinfo(index)" v-for="(item, index) in cardTitleInfo">
			<p class="title0">姓名：{{ storename[0] }}</p>
			<view class="title1">
				<p class="title">症状：{{ item[0] }}</p>
				<p class="title">医嘱：{{ item[3] }}</p>
			</view>

			<img
				src="http://a1.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5tCbnwLSpsBI5bLkVW9ZxUO.YnKc5Io6Hk8mwSv5G0lNQMzMg68uAJ5Z8D3EWawZIg5.3PmbHEXjrXILdkdXi2w!/c&ek=1&kp=1&pt=0&bo=yADIAAAAAAADFzI!&tl=1&vuin=2279265610&tm=1669604400&dis_t=1669605860&dis_k=53ae6362caa30e3458985e6bbeb80fbc&sce=60-2-2&rf=viewer_4"
				alt=""
				class="imgclass"
			/>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			mydata: this.$store.bookiddatastring,
			renderData: [],
			emptydata: [],
			cardTitleInfo: [],
			storename: this.$store.name.replace(/"/g, '').split('|')
		};
	},
	methods: {
		moreinfo(index) {
			this.$http({
				url: 'QueryAllEvi',
				method: 'post',
				data: {
					patAdd: this.$store.bookid
				}
			}).then(res => {
				this.$store.allindex = res.data.data[0][index];
			});
			uni.navigateTo({
				url: '/pages/infosCardMessage/morecardinfo/morecardinfo'
			});
		}
	},
	async mounted() {
		console.log('renderdata', this.renderData);
		console.log('bookiddata', this.$store.bookiddata);
		for (let i = 0; i < this.$store.bookiddata[0].length; ++i) {
			const { data: res } = await this.$http.post('QuerEviMessage', { patAdd: this.$store.useradd, eviadd: this.$store.bookiddata[0][i] });
			console.log('res', res.data[0]);
			let everyRecordInfo = res.data[0].split(',');
			this.cardTitleInfo.push(everyRecordInfo);
		}
		console.log(this.cardTitleInfo);
	}
};
</script>

<style>
.index {
	/* background-color: #808080; */
}
.card {
	/*卡片的宽度*/
	width: 90%;
	/*左外边距，这里代表距离最左边的距离*/
	margin-left: 5%;
	/*卡片的高度。*/
	height: 200rpx;
	/*背景色，可以自己更换*/
	background: rgb(248, 247, 252);
	/* radius是卡片的边框的圆润c程度
    shadow是阴影效果，四个值分别为水平阴影，垂直阴影，模糊距离，阴影的颜色。
 */
	border-radius: 10rpx;
	box-shadow: 5px 5px 5px #cdcfcf;
	position: relative;
	margin-top: 15rpx;
	position: relative;
}
.title {
	margin-top: 50px;
	margin: 15px;
	font-size: 20rpx;
	width: 280px;
}
.title0 {
	position: absolute;
	top: 7%;
	left: 5%;
	font-weight: 700;
}
.title1 {
	position: absolute;
	top: 18%;
	left: 2%;
}
.doctorName {
	font-size: 25rpx;
	font-weight: normal;
	position: absolute;
	top: 130%;
}
.miaoshu {
	position: absolute;
	top: 240%;
	font-size: 20rpx;
	font-weight: normal;
	color: #19d08b;
}
.imgclass {
	width: 110rpx;
	height: 110rpx;
	position: absolute;
	top: 23%;
	right: 4%;
}
</style>
