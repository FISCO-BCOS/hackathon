<template>
	<view>
		<view class="card" v-for="(item, index) in tijiandata" @click="chuangindex(item)">
			<p class="title">{{ item }}</p>

			<img
				src="http://a1.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5kBxxpHDNJpymduep00P3MDHhcmiRwPtX4kC8sDmr6DadrE5AboaaZKw2F2RNGhe.ERFoozYwYLg.hzjomMixr8!/c&ek=1&kp=1&pt=0&bo=yADIAAAAAAADFzI!&tl=1&vuin=2279265610&tm=1669730400&dis_t=1669733490&dis_k=67e5d5e6ffd4ca42acfb662a688ed61b&sce=60-2-2&rf=viewer_4"
				alt=""
				class="imgclass"
			/>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			tijiandata: []
		};
	},
	methods: {
		chuangindex(value) {
			(this.$store.tijianallindex = value),
				uni.navigateTo({
					url: '/pages/infosCardMessage/morecardinfo/moretijian'
				});
		}
	},
	mounted() {
		this.tijiandata = this.$store.tijianbeniddata;
		console.log('tijiandata', this.tijiandata);
	}
};
</script>

<style>
.index {
	/* background-color: #808080; */
}
.card {
	/*卡片的宽度*/
	width: 90%;
	/*左外边距，这里代表距离最左边的距离*/
	margin-left: 5%;
	/*卡片的高度。*/
	height: 200rpx;
	/*背景色，可以自己更换*/
	background: rgb(248, 247, 252);
	/* radius是卡片的边框的圆润c程度
	    shadow是阴影效果，四个值分别为水平阴影，垂直阴影，模糊距离，阴影的颜色。
	 */
	border-radius: 10rpx;
	box-shadow: 5px 5px 5px #cdcfcf;
	position: relative;
	margin-top: 15rpx;
}
.title {
	margin: 15px;
	font-size: 25rpx;
	font-weight: bold;
}
.doctorName {
	font-size: 25rpx;
	font-weight: normal;
	position: absolute;
	top: 130%;
}
.miaoshu {
	position: absolute;
	top: 240%;
	font-size: 20rpx;
	font-weight: normal;
	color: #19d08b;
}
.imgclass {
	width: 110rpx;
	height: 110rpx;
	position: absolute;
	top: 23%;
	right: 4%;
}
</style>
