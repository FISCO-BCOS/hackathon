<template>
	<view><uni-steps :options="numList" active="1" /></view>
</template>

<script>
export default {
	data() {
		return {
			numList: [
				{
					title: '下单'
				},
				{
					title: '出库'
				},
				{
					title: '运输'
				},
				{
					title: '签收'
				}
			]
		};
	},
	methods: {}
};
</script>

<style></style>
