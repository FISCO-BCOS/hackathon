<template>
	<view>
		<uni-card
			:title="docNameInfos[1][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei01.cfp.cn/creative/vcg/800/version23/VCG21gic20015720.jpg"
			:extra="docNameInfos[1][1]"
			note="Tips"
			@click="tests2(docNameInfos[1][3])"
		>
			{{ docNameInfos[1][2] }} {{ docNameInfos[1][3] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[2][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei01.cfp.cn/creative/vcg/800/version23/VCG21gic20015720.jpg"
			:extra="docNameInfos[2][1]"
			note="Tips"
			@click="tests2(docNameInfos[2][3])"
		>
			{{ docNameInfos[2][2] }} {{ docNameInfos[2][3] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[3][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei01.cfp.cn/creative/vcg/800/version23/VCG21gic20015720.jpg"
			:extra="docNameInfos[3][1]"
			note="Tips"
			@click="tests2(docNameInfos[3][3])"
		>
			{{ docNameInfos[3][2] }} {{ docNameInfos[3][3] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[4][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei01.cfp.cn/creative/vcg/800/version23/VCG21gic20015720.jpg"
			:extra="docNameInfos[4][1]"
			note="Tips"
			@click="tests2(docNameInfos[4][3])"
		>
			{{ docNameInfos[4][2] }} {{ docNameInfos[4][3] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[5][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei01.cfp.cn/creative/vcg/800/version23/VCG21gic20015720.jpg"
			:extra="docNameInfos[5][1]"
			note="Tips"
			@click="tests2(docNameInfos[5][3])"
		>
			{{ docNameInfos[5][2] }} {{ docNameInfos[5][3] }}
		</uni-card>

		<!-- 提示框 -->
		<view>
			<!-- 输入框示例 -->
			<uni-popup ref="inputDialog" type="dialog">
				<uni-popup-dialog ref="inputClose" mode="input" title="挂号成功" :value="doctorId" placeholder="请再次确认" @confirm="dialogInputConfirm"></uni-popup-dialog>
			</uni-popup>
		</view>
	</view>
</template>

<script>
import { created, onLoad } from '../../uni_modules/uview-ui/libs/mixin/mixin';
export default {
	data() {
		return {
			show: false,
			content: '是否选择该医生并挂号',
			doctorId: '',
			docNameInfos: []

			// data0: this.docNameInfos[1],
			// data0: this.docNameInfos[2],
			// data0: this.docNameInfos[3],
			// data0: this.docNameInfos[4],
			// data0: this.docNameInfos[5]
		};
	},
	methods: {
		tests(index) {
			uni.showToast({
				title: index.index,
				icon: 'success'
			});
			console.log(index.index);
		},
		async tests2(value) {
			// %%%%%%%%%
			const { data: res } = await this.$http.post('QueryAllEvi', { patAdd: this.$store.bookid });
			console.log('res.data', res.data);
			console.log('rea.data[0]', res.data[0], typeof res.data[0]);
			let data = res.data[0];
			// res.data[0].forEach(item => {
			// 	console.log(item);
			// });
			this.$store.bookiddata = res.data;
			for (let i = 0; i < data.length; ++i) {
				this.$http.post('QuerEviMessage', { patAdd: this.$store.useradd, eviadd: data[i] }).then(res => {
					console.log(res.data.data[0]);
					this.namedata.push(res.data.data[0]);
				});
			}
			this.$store.bookiddatastring = this.namedata;

			// %%%%%%%%%
			this.$store.shouquanDocvalue = value;
			console.log('shouquanDocvalue', this.$store.shouquanDocvalue);
			setTimeout(() => {
				uni.navigateTo({
					url: './morecardinfo/shouquanid'
				});
			}, 1000);
		},
		async dialogInputConfirm(value) {
			const { data: res } = await this.$http.post('Registration', { patAdd: this.$store.useradd, docterAddress: value });
			console.log(res);
			this.$refs.inputDialog.close();
			uni.switchTab({
				url: '/pages/index/index'
			});
		}
	},
	async onLoad() {
		// const that = this;
		// const { data: res } = await this.$http.post('QueryAllDoc');
		// console.log(res.data[0]);
		// const docInfo = res.data[0];
		// for (let i = 1; i < docInfo.length; ++i) {
		// 	this.$http({
		// 		url: 'QueryDoctor',
		// 		method: 'post',
		// 		data: {
		// 			docAdd: docInfo[i]
		// 		}
		// 	}).then(({ data }) => {
		// 		console.log('request data', data);
		// 		let nameInfo = data.data[0].replace(/"/g, '').split('|');
		// 		that.docNameInfos[i] = nameInfo;
		// 	});
		// }
		// console.log('doc', this.docNameInfos);
		this.$http({
			url: 'QueryAllDoc',
			method: 'post'
		}).then(async ({ data }) => {
			console.log(data);
			for (let i = 0; i < data.data[0].length; ++i) {
				console.log(data.data[0][i]);
				const { data: res } = await this.$http.post('QueryDoctor', data.data[0][i]);
				console.log('res', res.data[0]);
				let temp = res.data[0].replace(/"/g, '').split('|');
				temp.push(data.data[0][i]);
				this.docNameInfos.push(temp);
			}
		});
		console.log(this.docNameInfos);
	}
};
</script>

<style></style>
