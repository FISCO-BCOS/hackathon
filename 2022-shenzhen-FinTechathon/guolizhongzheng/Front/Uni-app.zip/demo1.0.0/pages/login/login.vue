<template>
	<view>
		<view class="img-a">
			<view class="t-b">
				您好，
				<br />
				欢迎使用医元疗
			</view>
		</view>
		<view class="login-view" style="">
			<view class="t-login">
				<form class="cl">
					<view class="t-a">
						<text class="txt">账号</text>
						<input placeholder="请输入您的账号" v-model="loginForm.add" />
					</view>
					<view class="t-a">
						<text class="txt">密码</text>
						<input type="password" name="code" maxlength="18" placeholder="请输入您的密码" v-model="loginForm.cipher" />
					</view>
					<button @tap="login()">登 录</button>
					<view class="reg" @tap="reg()">注 册</view>
				</form>
				<view class="t-f"><text>—————— 第三方账号登录 ——————</text></view>
				<view class="t-e cl">
					<view class="t-g" @tap="wxLogin()"><image src="@/static/wx.png"></image></view>
					<view class="t-g" @tap="zfbLogin()"><image src="@/static/qq.png"></image></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			loginForm: {
				add: '0x844485F1fb025072522BcfA196c60Cb358d759c0',
				cipher: '123456'
			}
		};
	},
	methods: {
		reg() {
			uni.navigateTo({
				url: '/pages/register/register'
			});
		},
		async login() {
			console.log('已点击');
			console.log(this.loginForm);
			this.$store.useradd = this.loginForm.add;
			console.log('useradd', this.$store.useradd);
			const { data: res } = await this.$http.post('PatientEnter', this.loginForm);
			const { data: res1 } = await this.$http.post('QueryPat', { patAdd: this.$store.useradd });

			this.$store.bookid = res1.data[2];
			this.$store.tijianbenid = res1.data[3];
			this.$store.name = res1.data[4];
			console.log('name', res1.data[4]);
			console.log('tijianbenid', this.$store.tijianbenid);
			console.log('bookid', this.$store.bookid);

			uni.showToast({
				icon: 'success',
				title: '登录成功'
			});
			uni.switchTab({
				url: '/pages/index/index'
			});
		},
		wxLogin() {
			uni.showToast({
				icon: 'none',
				title: '暂未开发'
			});
		},
		zfbLogin() {
			uni.showToast({
				icon: 'none',
				title: '暂未开发'
			});
		}
	}
};
</script>

<style>
.txt {
	font-size: 32rpx;
	font-weight: bold;
	color: #333333;
}
.img-a {
	width: 100%;
	height: 450rpx;
	background-image: url('http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5iIla*rtJox9bMkotATLuwmfR6EebLjjhw9z.RNHlMjDuwpw09JspWivlhvMSe*wyFm60zfE*YdR03bGNgnQmKM!/b&bo=7gLPAQAAAAADBwA!&rf=viewer_4');
	background-size: 100%;
}
.reg {
	font-size: 28rpx;
	color: #fff;
	height: 90rpx;
	line-height: 90rpx;
	border-radius: 50rpx;
	font-weight: bold;
	background: #f5f6fa;
	color: #000000;
	text-align: center;
	margin-top: 30rpx;
}

.login-view {
	width: 100%;
	position: relative;
	margin-top: -120rpx;
	background-color: #ffffff;
	border-radius: 8% 8% 0% 0;
}

.t-login {
	width: 600rpx;
	margin: 0 auto;
	font-size: 28rpx;
	padding-top: 80rpx;
}

.t-login button {
	font-size: 28rpx;
	background: #2796f2;
	color: #fff;
	height: 90rpx;
	line-height: 90rpx;
	border-radius: 50rpx;
	font-weight: bold;
}

.t-login input {
	height: 90rpx;
	line-height: 90rpx;
	margin-bottom: 50rpx;
	border-bottom: 1px solid #e9e9e9;
	font-size: 28rpx;
}

.t-login .t-a {
	position: relative;
}

.t-b {
	text-align: left;
	font-size: 42rpx;
	color: #ffffff;
	padding: 130rpx 0 0 70rpx;
	font-weight: bold;
	line-height: 70rpx;
}

.t-login .t-c {
	position: absolute;
	right: 22rpx;
	top: 22rpx;
	background: #5677fc;
	color: #fff;
	font-size: 24rpx;
	border-radius: 50rpx;
	height: 50rpx;
	line-height: 50rpx;
	padding: 0 25rpx;
}

.t-login .t-d {
	text-align: center;
	color: #999;
	margin: 80rpx 0;
}

.t-login .t-e {
	text-align: center;
	width: 250rpx;
	margin: 80rpx auto 0;
}

.t-login .t-g {
	float: left;
	width: 50%;
}

.t-login .t-e image {
	width: 50rpx;
	height: 50rpx;
}

.t-login .t-f {
	text-align: center;
	margin: 150rpx 0 0 0;
	color: #666;
}

.t-login .t-f text {
	margin-left: 20rpx;
	color: #aaaaaa;
	font-size: 27rpx;
}

.t-login .uni-input-placeholder {
	color: #aeaeae;
}

.cl {
	zoom: 1;
}

.cl:after {
	clear: both;
	display: block;
	visibility: hidden;
	height: 0;
	content: '\20';
}
</style>
