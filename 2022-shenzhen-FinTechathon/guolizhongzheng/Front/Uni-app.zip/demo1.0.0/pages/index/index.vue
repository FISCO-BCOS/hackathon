<template>
	<view class="index">
		<u-swiper :list="list1" previousMargin="30" nextMargin="30" circular :autoplay="false" radius="5" bgColor="#ffffff" height="200px" autoplay indicator></u-swiper>
		<!-- 分割线 -->
		<u-divider text="快捷功能" textPosition="right" textColor="#2979ff" lineColor="#2979ff"></u-divider>

		<view class="nav-list margin-top">
			<view open-type="navigate" hover-class="none" class="nav-li bg-kuxuan1" style="width: 130px; margin: 0;" @click="test"><view class="nav-name">点击扫码</view></view>
			<view open-type="navigate" hover-class="none" class="nav-li bg-kuxuan2" style="width: 130px; margin: 0;" @click="creatQrCode">
				<view class="nav-name">我的二维码</view>
			</view>
		</view>
		<!-- 分割线 -->
		<u-divider text="我的服务" textColor="#2979ff" lineColor="#2979ff"></u-divider>
		<!-- 小组件 -->
		<view class="grid">
			<view class="flex-col items-center grid-item" @click="tests">
				<image
					class="image_6"
					src="http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5tCbnwLSpsBI5bLkVW9ZxUNEGpo*5IF9B7UlMwuq8c6ZRwwH84MHq6fGjIRj4ttEToHSJi9VVeWHVT5SNJUETtM!/b&bo=yADIAAAAAAADByI!&rf=viewer_4"
				/>
				<text class="text_4">我的评价</text>
			</view>
			<view class="flex-col items-center grid-item" @click="toflow">
				<image
					class="image_6"
					src="http://a1.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5lhQBSgtv0Wkz8aeRBPCrrxlXgjjUaApp00NLyNCYcnP7QU6Ixsl4FhXes7Whk*SAZNRNCyFAmHQysrQvZ7jxiI!/c&ek=1&kp=1&pt=0&bo=yADIAAAAAAADFzI!&tl=1&vuin=2279265610&tm=1669604400&dis_t=1669607637&dis_k=8377c28193599752834b272eeb6ce1f9&sce=60-2-2&rf=viewer_4"
				/>
				<text class="text_4">我的就诊</text>
			</view>
			<view class="flex-col items-center grid-item" @click="shouquan">
				<image
					class="image_6"
					src="http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5mkiAYTp8c7OcVwzXltudEAS3oaFr6SlpFQrk1mfVIOrMOHt*17N2FEKifqolptVgQHMPkWl43H69fLpWQleBC8!/b&bo=yADIAAAAAAADByI!&rf=viewer_4"
				/>
				<text class="text_4">我的授权</text>
			</view>
			<view class="flex-col items-center grid-item">
				<image
					class="image_6"
					src="http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5m2fiVcMnDs7VT4KVY8UUwFdcZQB7b1S6NYXS4A8EVZ5H7.lxCBHQ2Uwp9QoGbdalF4PwDvVgoNuo1DkHIs3oN0!/b&bo=yADIAAAAAAADByI!&rf=viewer_4"
				/>
				<text class="text_4">我的积分</text>
			</view>
			<view class="flex-col items-center grid-item">
				<image
					class="image_6"
					src="https://project-user-resource-1256085488.cos.ap-guangzhou.myqcloud.com/60c325b4767e240013341755/60c3218d6d32e90012f09dc8/16551312686374492447.png"
				/>
				<text class="text_4">历史记录</text>
			</view>
			<view class="flex-col items-center grid-item">
				<image
					class="image_6"
					src="https://project-user-resource-1256085488.cos.ap-guangzhou.myqcloud.com/60c325b4767e240013341755/60c3218d6d32e90012f09dc8/16551312686385327556.png"
				/>
				<text class="text_4">我的处方</text>
			</view>
			<view class="flex-col items-center grid-item">
				<image
					class="image_6"
					src="https://project-user-resource-1256085488.cos.ap-guangzhou.myqcloud.com/60c325b4767e240013341755/60c3218d6d32e90012f09dc8/16551312686398207680.png"
				/>
				<text class="text_4">我的药方</text>
			</view>
			<view class="flex-col items-center grid-item">
				<image
					class="image_6"
					src="https://project-user-resource-1256085488.cos.ap-guangzhou.myqcloud.com/60c325b4767e240013341755/60c3218d6d32e90012f09dc8/16551312686395995286.png"
				/>
				<text class="text_4">我的健康</text>
			</view>
		</view>
		<!-- 小组件  -->

		<!-- 弹出层 -->
		<u-popup :show="qrShow" :round="20" mode="center" closeOnClickOverlay="false" closeable @close="closePopup">
			<view class="qr-box" v-show="qrShow"><canvas canvas-id="qrcode" style="width: 300rpx;margin: 0 auto;" /></view>
		</u-popup>
	</view>
</template>

<script>
import uQRCode from '@/common/uqrcode.js'; //引入uqrcode.js
export default {
	data() {
		return {
			qrShow: false,
			title: 'https://www.baidu.com',
			list1: [
				'http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5vPA8Za2jCIgo89dTB6HhKzNgahW4rom5F*fL3DFysCTiOtgOPGKGuxkD1hMeo8YfTQCy8eosevYUMc9l7a4e98!/b&bo=wwYxBAAAAAADB9I!&rf=viewer_4',
				'http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5iIla*rtJox9bMkotATLuwk9x26E1Sn6C8KIcbD9Po8t.rZ8OeDlHsJKnhbIgyQy8qooAJDGILh24DCXvA7d7CU!/b&bo=VAY4BAAAAAADB0w!&rf=viewer_4',
				'http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5tyL.UNvOQkXZEF*suYhPuSKgaLuNvBg*KxZnszS1.6ILh.FI.VEaHnSVQUDayyRu.vNRCjbPqQAfLuVyi.Aex4!/b&bo=wwYxBAAAAAADJ*I!&rf=viewer_4',
				'http://m.qpic.cn/psc?/V13duKFv4FTPWc/ruAMsa53pVQWN7FLK88i5tyL.UNvOQkXZEF*suYhPuRFcVD1UbqM6l*4f8BW3C6eP8Hbyh2wjznjvHcYarscythKTe8eVq.KrmZ2VSYym6I!/b&bo=wwYxBAAAAAADB9I!&rf=viewer_4'
			]
		};
	},
	onLoad() {},
	created() {
		uQRCode.make({
			canvasId: 'qrcode',
			componentInstance: this,
			text: this.title,
			size: 150,
			margin: 0,
			backgroundColor: '#ffffff',
			foregroundColor: '#000000',
			fileType: 'jpg',
			errorCorrectLevel: uQRCode.errorCorrectLevel.H,
			success: res => {}
		});
	},
	methods: {
		closePopup() {
			this.qrShow = false;
		},
		test() {
			uni.scanCode({
				success: function(res) {
					console.log(res);
					uni.showToast({
						icon: 'success',
						title: '扫码成功' + res.result
					});
				}
			});
		},
		creatQrCode() {
			this.qrShow = true;
		},
		tests() {
			uni.showToast({
				icon: 'success',
				title: this.$store.state.userinfo
			});
		},
		toflow() {
			uni.navigateTo({
				url: '/pages/infosCardMessage/flow'
			});
		},
		shouquan() {
			uni.navigateTo({
				url: '/pages/infosCardMessage/shouquan'
			});
		}
	}
};
</script>

<style>
.index {
	margin-top: 30rpx;
}

.bg-kuxuan1 {
	background-color: #0acffe;
	color: #fff;
}

.bg-kuxuan2 {
	background-color: #19d08b;
	color: #fff;
}

.nav-list {
	display: flex;
	flex-wrap: wrap;
	padding: 0px 40upx 0px;
	justify-content: space-between;
}

.nav-name {
	font-size: 28upx;
	text-transform: Capitalize;
	margin-top: 20upx;
	position: relative;
}

.nav-name::before {
	content: '';
	position: absolute;
	display: block;
	width: 40upx;
	height: 6upx;
	background: #fff;
	bottom: 0;
	right: 0;
	opacity: 0.5;
}

.nav-name::after {
	content: '';
	position: absolute;
	display: block;
	width: 100upx;
	height: 1px;
	background: #fff;
	bottom: 0;
	right: 40upx;
	opacity: 0.3;
}

.nav-name::first-letter {
	font-weight: bold;
	font-size: 36upx;
	margin-right: 1px;
}
.nav-li {
	padding: 30upx;
	border-radius: 12upx;
	width: 45%;
	margin: 0 2.5% 40upx;
	background-size: cover;
	background-position: center;
	position: relative;
	z-index: 1;
}

.nav-li::after {
	content: '';
	position: absolute;
	z-index: -1;
	background-color: inherit;
	width: 100%;
	height: 100%;
	left: 0;
	bottom: -10%;
	border-radius: 10upx;
	opacity: 0.2;
	transform: scale(0.9, 0.9);
}

.nav-li.cur {
	color: #fff;
	background: rgb(94, 185, 94);
	box-shadow: 4upx 4upx 6upx rgba(94, 185, 94, 0.4);
}
.qr-box {
	width: 400rpx;
	height: 460rpx;
	margin: 0 auto;
	margin-top: 120rpx;
}
/* 小组件 */

.grid {
	padding: 0 14.5rpx;
	height: 344rpx;
	display: grid;
	grid-template-columns: repeat(4, 1fr);
}
.grid-item {
	padding: 12rpx 0 15rpx;
	margin: 0 45rpx;
}
.image_6 {
	border-radius: 50%;
	width: 85rpx;
	height: 85rpx;
	margin: 0;
}
.text_4 {
	color: #000000;
	font-size: 23rpx;
	font-family: 'PingFangSC-Regular';
	line-height: 40rpx;
	margin: 9rpx 0;
	text-align: center;
}
</style>
