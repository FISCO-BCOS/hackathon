<template>
	<view>
		<u-sticky bgColor="#fff"><u-tabs :list="list1" @click="tests()"></u-tabs></u-sticky>

		<uni-card
			:title="docNameInfos[1][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei01.cfp.cn/creative/vcg/800/version23/VCG21gic20015720.jpg"
			:extra="docNameInfos[1][1]"
			note="Tips"
			@click="tests2(docNameInfos[1][3])"
		>
			{{ docNameInfos[1][2] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[2][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://tenfei04.cfp.cn/creative/vcg/nowarter800/new/VCG21gic20070468.jpg?x-oss-process=image/format,webp"
			:extra="docNameInfos[2][1]"
			note="Tips"
			@click="tests2(docNameInfos[2][3])"
		>
			{{ docNameInfos[2][2] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[3][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://alifei02.cfp.cn/creative/vcg/nowater800/new/VCG21gic20015720.jpg?x-oss-process=image/format,webp"
			:extra="docNameInfos[3][1]"
			note="Tips"
			@click="tests2(docNameInfos[3][3])"
		>
			{{ docNameInfos[3][2] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[4][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://alifei02.cfp.cn/creative/vcg/nowarter800/new/VCG41587522568.jpg?x-oss-process=image/format,webp"
			:extra="docNameInfos[4][1]"
			note="Tips"
			@click="tests2(docNameInfos[4][3])"
		>
			{{ docNameInfos[4][2] }}
		</uni-card>
		<uni-card
			:title="docNameInfos[5][0]"
			mode="style"
			:is-shadow="true"
			thumbnail="https://alifei05.cfp.cn/creative/vcg/nowarter800/new/VCG211264412607.jpg?x-oss-process=image/format,webp"
			:extra="docNameInfos[5][1]"
			note="Tips"
			@click="tests2(docNameInfos[5][3])"
		>
			{{ docNameInfos[5][2] }}
		</uni-card>

		<!-- 提示框 -->
		<view>
			<!-- 输入框示例 -->
			<uni-popup ref="inputDialog" type="dialog">
				<uni-popup-dialog ref="inputClose" mode="input" title="挂号成功" :value="doctorId" placeholder="请再次确认" @confirm="dialogInputConfirm"></uni-popup-dialog>
			</uni-popup>
		</view>
	</view>
</template>

<script>
import { created, onLoad } from '../../uni_modules/uview-ui/libs/mixin/mixin';
export default {
	data() {
		return {
			list1: [
				{
					name: '智能推荐'
				},
				{
					name: '内科'
				},
				{
					name: '外科'
				},
				{
					name: '儿科'
				},
				{
					name: '脑科'
				},
				{
					name: '骨科'
				},
				{
					name: '神经科'
				},
				{
					name: '牙科'
				},
				{
					name: '胸外科'
				}
			],
			show: false,
			content: '是否选择该医生并挂号',
			doctorId: '',
			docNameInfos: []

			// data0: this.docNameInfos[1],
			// data0: this.docNameInfos[2],
			// data0: this.docNameInfos[3],
			// data0: this.docNameInfos[4],
			// data0: this.docNameInfos[5]
		};
	},
	methods: {
		tests(index) {
			uni.showToast({
				title: index.index,
				icon: 'success'
			});
			console.log(index.index);
		},
		async tests2(value) {
			const { data: res } = await this.$http.post('Registration', { patAdd: this.$store.useradd, docterAddress: value });
			console.log('ressssss', res);
			uni.showToast({
				icon: 'success',
				title: '挂号成功'
			});
			setTimeout(() => {
				uni.switchTab({
					url: '/pages/index/index'
				});
			}, 1000);
		},
		async dialogInputConfirm(value) {
			const { data: res } = await this.$http.post('Registration', { patAdd: this.$store.useradd, docterAddress: value });
			console.log(res);
			this.$refs.inputDialog.close();
			uni.switchTab({
				url: '/pages/index/index'
			});
		}
	},
	async onLoad() {
		// const that = this;
		// const { data: res } = await this.$http.post('QueryAllDoc');
		// console.log(res.data[0]);
		// const docInfo = res.data[0];
		// for (let i = 1; i < docInfo.length; ++i) {
		// 	this.$http({
		// 		url: 'QueryDoctor',
		// 		method: 'post',
		// 		data: {
		// 			docAdd: docInfo[i]
		// 		}
		// 	}).then(({ data }) => {
		// 		console.log('request data', data);
		// 		let nameInfo = data.data[0].replace(/"/g, '').split('|');
		// 		that.docNameInfos[i] = nameInfo;
		// 	});
		// }
		// console.log('doc', this.docNameInfos);
		this.$http({
			url: 'QueryAllDoc',
			method: 'post'
		}).then(async ({ data }) => {
			console.log(data);
			for (let i = 0; i < data.data[0].length; ++i) {
				console.log(data.data[0][i]);
				const { data: res } = await this.$http.post('QueryDoctor', data.data[0][i]);
				console.log('res', res.data[0]);
				let temp = res.data[0].replace(/"/g, '').split('|');
				temp.push(data.data[0][i]);
				this.docNameInfos.push(temp);
			}
		});
		console.log('docNameInfos', this.docNameInfos);
	}
};
</script>

<style></style>
