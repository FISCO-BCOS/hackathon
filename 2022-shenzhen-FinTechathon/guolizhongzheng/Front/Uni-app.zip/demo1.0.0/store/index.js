import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);


export default new Vuex.Store({
	state: {
		useradd: '', //用户地址
		bookid: '', //病历本ID
		bookiddata: [], //病历本ID里的记录ID
		bookiddatastring: [], //病历本ID里的记录ID的字符
		allindex: '', //单个病历本ID里的记录ID、授权
		tijianbenid: '', //患者体检本ID,
		tijianbeniddata: [], //患者体检本ID的记录数组
		tijianallindex: '',
		name: '', //用户姓名
		shouquanDocvalue: '' //授权医生的地址
	},
	mutations: {

	},
	actions: {},
	getters: {}
})
