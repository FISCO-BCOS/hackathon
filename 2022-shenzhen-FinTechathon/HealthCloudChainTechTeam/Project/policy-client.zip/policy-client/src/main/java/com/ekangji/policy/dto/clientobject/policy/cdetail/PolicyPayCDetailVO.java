package com.ekangji.policy.dto.clientobject.policy.cdetail;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyPayCDetailVO implements Serializable {

    @ApiModelProperty(value = "年保费")
    private BigDecimal yearPremium;

    @ApiModelProperty(value = "每次应缴未交的保费")
    private BigDecimal perPremium;

    @ApiModelProperty(value = "总保费")
    private BigDecimal totalPremium;

    @ApiModelProperty(value = "已缴费次数")
    private Integer paidTimes;

    @ApiModelProperty(value = "未交费次数")
    private Integer unPaidTimes;

    @ApiModelProperty(value = "缴费日期")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date payDate;

    @ApiModelProperty(value = "缴费标签集合")
    private List<PayLabelDetail> payLabelList;

    @Data
    public static class PayLabelDetail implements Serializable{

        @ApiModelProperty(value = "缴费标签")
        @JsonSerialize(using = ToStringSerializer.class)
        private Long payLabelId;

        @ApiModelProperty(value = "缴费标签")
        private String payLabel;

        @ApiModelProperty(value = "缴费状态(1:已缴费,0:未缴费)")
        private Integer status;
    }
}
