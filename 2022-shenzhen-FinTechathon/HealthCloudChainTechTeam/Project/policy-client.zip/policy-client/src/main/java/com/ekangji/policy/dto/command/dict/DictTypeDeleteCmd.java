package com.ekangji.policy.dto.command.dict;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-01 10:35:47
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DictTypeDeleteCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 字典主键
     */
    @ApiModelProperty(value = "字典ID",required = true)
    @NotNull(message = "字典ID不能为空")
    private Long dictId;

}