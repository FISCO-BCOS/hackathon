package com.ekangji.policy.dto.command.safeguardinsurance;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author xintao.li
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceCommonQry implements Serializable {


    /**
     * 父类别编码
     */
    @ApiModelProperty(value = "父类别编码")
    private String parentType;

    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    private Integer ageBracket;


}
