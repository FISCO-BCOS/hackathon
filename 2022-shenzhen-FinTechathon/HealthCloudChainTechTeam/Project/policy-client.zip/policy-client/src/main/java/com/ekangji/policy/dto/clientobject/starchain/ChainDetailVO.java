package com.ekangji.policy.dto.clientobject.starchain;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author 李鑫涛
 * @date 7/12/22 10:31 AM
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class ChainDetailVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 星链ID
     */
    @ApiModelProperty(value = "星链ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long starChainId;

    /**
     * 文案
     */
    @ApiModelProperty(value = "文案")
    private Map<String,Integer> content;

    /**
     * 星球列表
     */
    @ApiModelProperty(value = "星球列表")
    private List<StarVO> starList;



}
