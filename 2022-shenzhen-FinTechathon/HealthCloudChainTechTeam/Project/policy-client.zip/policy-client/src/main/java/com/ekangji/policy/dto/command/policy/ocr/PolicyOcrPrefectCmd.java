package com.ekangji.policy.dto.command.policy.ocr;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 简单保单OCR完善信息
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "简单保单OCR完善对象")
public class PolicyOcrPrefectCmd extends PolicyOcrAddCmd implements Serializable {

    @ApiModelProperty(value = "保单ID")
    @NotNull(message = "保单ID不能为空")
    private Long policyId;
}
