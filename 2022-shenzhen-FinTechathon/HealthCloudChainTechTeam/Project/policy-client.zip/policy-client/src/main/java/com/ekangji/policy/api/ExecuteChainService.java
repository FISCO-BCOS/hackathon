
package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.common.enums.MaterialTypeEnum;
import com.ekangji.policy.dto.command.policy.ChainEditCmd;
import com.ekangji.policy.dto.command.policy.UserStarAddCmd;
import com.ekangji.policy.dto.command.user.LoginUserInfo;

public interface ExecuteChainService {


    /**
     * 上链
     * @param materialTypeEnum
     * @return
     */
    ApiResult chainGateWay(ChainEditCmd chainEditCmd, MaterialTypeEnum materialTypeEnum);
}
