package com.ekangji.policy.dto.clientobject.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class InsuredRankingVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "所在排行")
    private Long rankingNum;

    @ApiModelProperty(value = "总参保数")
    private Long sumNum;

    @ApiModelProperty(value = "被保人姓名")
    private String name;

    @ApiModelProperty(value = "玉惠保期数 1 一期 2 二期 ...")
    private String stage;

    @ApiModelProperty(value = "订单状态 0 无效 1 已支付 2 已承保")
    private String orderStatus;

    private String quotationNo;

    private String idNo;


}
