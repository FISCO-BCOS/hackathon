package com.ekangji.policy.dto.command.safeguardoverview;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author xintao.li
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class SafeguardOverviewEditRadarCmd implements Serializable {


    /**
     * 产品类别编码
     */
    @ApiModelProperty(value = "一级类别编码")
    @NotBlank(message = "一级类别编码不为空")
    private String oneLevelTypeCode;

    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    @NotNull(message = "年龄段不能为空")
    private Integer ageBracket;


    /**
     * 雷达图最大值
     */
    @ApiModelProperty(value = "雷达图最大值")
    @NotNull(message = "雷达图最大值不能为空")
    private Integer radarMapMaxValue;

}
