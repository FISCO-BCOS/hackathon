package com.ekangji.policy.dto.command.policy.familyreport;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 被保人统计信息查询
 * @date 2022-5-16 14:30:25
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MemberTotalInfoQry extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "成员(被保人)ID")
    private Long memberId;
}
