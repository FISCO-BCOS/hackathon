package com.ekangji.policy.dto.command.producttypemapping;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *
 * @author xintao.li
 * @Description 根据父类编码查出所有子类
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class ParentCodeQry implements Serializable {

    /**
     * 父产品类别编码
     */
    @ApiModelProperty(value = "父产品类别编码")
    private String parentCode;
}
