package com.ekangji.policy.dto.command.starchain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 
 * @author   xintao.li
 * @date   2021-12-01 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class StarChainAddOneLengthCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 星链ID
     */
    @ApiModelProperty(value = "星链ID")
    @NotNull(message = "星链ID不为空")
    private Long chainId;

    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID",hidden = true)
    private String userId;

    /**
     * 星球ID
     */
    @ApiModelProperty(value = "星球ID")
    @NotNull(message = "星球ID不为空")
    private Long starId;
}