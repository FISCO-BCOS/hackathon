package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 保单编辑
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "数字保单编辑对象")
public class DigitalPolicyCmd  implements Serializable {

    @ApiModelProperty(value = "用户ID")
    private String userId;

    @ApiModelProperty(value = "富媒体文件id列表 逗号分割")
    private String mediaFileIds;

    @ApiModelProperty(value = "富媒体寄语")
    private String mediaContent;

    @ApiModelProperty(value = "保单id")
    private Long policyId;

    @ApiModelProperty(value = "保单产品名称")
    private String productName;

    @ApiModelProperty(value = "海报文件id")
    private String fileId;

    @ApiModelProperty(value = "星球id")
    private Long starId;
}
