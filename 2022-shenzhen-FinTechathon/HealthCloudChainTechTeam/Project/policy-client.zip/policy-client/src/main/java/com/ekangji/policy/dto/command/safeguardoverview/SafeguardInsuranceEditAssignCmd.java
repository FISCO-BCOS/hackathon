package com.ekangji.policy.dto.command.safeguardoverview;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author xintao.li
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class SafeguardInsuranceEditAssignCmd implements Serializable {

    /**
     * 保障图业务id
     */
    @ApiModelProperty(value = "保障图业务id")
    @NotBlank(message = "保障图业务id不为空")
    private String insuranceId;

    /**
     * 产品类别编码
     */
    @ApiModelProperty(value = "产品类别编码")
    @NotBlank(message = "产品类别编码")
    private String productTypeCode;

    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    @NotNull(message = "年龄段不能为空")
    private Integer ageBracket;


    /**
     * 指定值
     */
    @ApiModelProperty(value = "指定值")
    @NotNull(message = "指定值不能为空")
    private Integer assignValue;

}
