package com.ekangji.policy.dto.command.member;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author heshuai
 * @Description 批量新增贡献值详细规则
 * @date 2022-02-21 14:56:45
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnsuredReadConfigBatchEditCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty
    @NotEmpty(message = "请填写各项值")
    private List<EnsuredReadConfigEditCmd> editCmdList;

}