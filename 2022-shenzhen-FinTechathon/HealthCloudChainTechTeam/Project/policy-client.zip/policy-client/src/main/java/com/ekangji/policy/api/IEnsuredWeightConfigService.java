package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.EnsuredWeightConfigVO;
import com.ekangji.policy.dto.clientobject.policy.FamilyEnsureVO;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberVO;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigBatchEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigEditCmd;
import com.ekangji.policy.dto.command.member.FamilyEnsuredCalcCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredQry;
import com.ekangji.policy.dto.command.policy.family.UserFamilyQry;

import java.util.List;

public interface IEnsuredWeightConfigService {

    ApiResult<Integer> ensuredWeightSet(EnsuredWeightConfigBatchEditCmd ensuredWeightConfigBatchEditCmd);

    ApiResult<List<EnsuredWeightConfigVO>> findEnsuredWeightList();
}
