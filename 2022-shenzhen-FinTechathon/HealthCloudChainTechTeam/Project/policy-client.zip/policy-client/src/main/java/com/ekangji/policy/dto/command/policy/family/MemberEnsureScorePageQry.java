package com.ekangji.policy.dto.command.policy.family;

import com.ekangji.policy.common.page.Page;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

/**
 * @author 李鑫涛
 * @date 4/14/22 11:13 AM
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MemberEnsureScorePageQry extends Page implements Serializable {

    /**
     * 用户手机号
     */
    @ApiModelProperty(value = "手机号码",required = true)
    @Pattern(regexp = "^[1][3,4,5,6,7,8,9][0-9]{9}$", message = "手机号格式有误")
    private String phoneNumber;


    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id",required = true)
    private String userId;
    /**
     * 成员id
     */
    @ApiModelProperty(value = "成员id",required = true)
    private String memberId;
    /**
     * 所属渠道平台
     */
    @ApiModelProperty(value = "所属渠道平台",required = true)
    private Integer channelType;

    /**
     *家庭保障分最小值
     */
    @ApiModelProperty(value = "家庭保障分最小值",required = true)
    @Min(value = 0,message = "请输入0-100范围的整数")
    @Max(value = 100,message = "请输入0-100范围的整数")
    private Integer familyMinScore;

    /**
     *家庭保障分最大值
     */
    @ApiModelProperty(value = "家庭保障分最大值",required = true)
    @Min(value = 0,message = "请输入0-100范围的整数")
    @Max(value = 100,message = "请输入0-100范围的整数")
    private Integer familyMaxScore;

    /**
     *成员保障分最小值
     */
    @ApiModelProperty(value = "成员保障分最小值",required = true)
    @Min(value = 0,message = "请输入0-100范围的整数")
    @Max(value = 100,message = "请输入0-100范围的整数")
    private Integer memberMinScore;

    /**
     *成员保障分最大值
     */
    @ApiModelProperty(value = "成员保障分最大值",required = true)
    @Min(value = 0,message = "请输入0-100范围的整数")
    @Max(value = 100,message = "请输入0-100范围的整数")
    private Integer memberMaxScore;


    /**
     *成员创建时间开始时间
     */
    @ApiModelProperty(value = "成员创建时间开始时间",required = true)
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date memberCreateTimeStart;

    /**
     *成员创建时间结束时间
     */
    @ApiModelProperty(value = "成员创建时间结束时间",required = true)
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date memberCreateTimeEnd;
}
