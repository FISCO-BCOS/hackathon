package com.ekangji.policy.dto.clientobject.starchain;

import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.dto.clientobject.common.CommonVO;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   xintao.li
 * @date   2022-07-11 14:54:28
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class StarChainVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 星链ID
     */
    @ApiModelProperty(value = "星链ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long starChainId;

    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID")
    private String userId;

    /**
     * 星链长度
     */
    @ApiModelProperty(value = "星链长度")
    private Integer length;

    /**
     * 星链名称
     */
    @ApiModelProperty(value = "星链名称")
    private String name;

}