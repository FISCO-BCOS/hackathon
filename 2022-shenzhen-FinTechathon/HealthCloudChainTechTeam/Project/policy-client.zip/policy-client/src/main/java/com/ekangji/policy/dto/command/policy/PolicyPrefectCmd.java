package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 简单保单完善信息
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "简单保单完善对象")
public class PolicyPrefectCmd extends PolicyCmd implements Serializable {

    @ApiModelProperty(value = "保单ID")
    @NotNull(message = "保单ID不能为空")
    private Long policyId;
}
