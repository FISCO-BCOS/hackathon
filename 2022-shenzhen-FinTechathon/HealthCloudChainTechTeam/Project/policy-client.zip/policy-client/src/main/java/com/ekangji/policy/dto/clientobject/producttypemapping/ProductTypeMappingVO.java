package com.ekangji.policy.dto.clientobject.producttypemapping;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: xintao.li
 * @Desc: 产品类别映射
 * @Date: 2022/05/16 11:50
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ProductTypeMappingVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增id
     */
    @ApiModelProperty(value = "自增id")
    private Long id;

    /**
     * 产品类型匹配id
     */
    @ApiModelProperty(value = "产品类型匹配id")
    private String mappingId;

    /**
     * 产品类型编码
     */
    @ApiModelProperty(value = "产品类型编码")
    private String code;

    /**
     * 产品类型名称
     */
    @ApiModelProperty(value = "产品类型名称")
    private String name;

    /**
     * 父产品类别编码
     */
    @ApiModelProperty(value = "父产品类别编码")
    private String parentCode;

    /**
     * 产品库对应的产品类别编码
     */
    @ApiModelProperty(value = "产品库对应的产品类别编码")
    private String mappingCode;

    /**
     * 产品库对应的产品类别名称
     */
    @ApiModelProperty(value = "产品库对应的产品类别名称")
    private String mappingName;

    /**
     * 排序
     */
    @ApiModelProperty(value = "排序")
    private Integer sort;

    /**
     * 状态  0：无效 1:有效
     */
    @ApiModelProperty(value = "状态  0：无效 1:有效")
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    @ApiModelProperty(value = "逻辑删除 0：已删除 1：未删除")
    private Integer delFlag;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /**
     * 更新人
     */
    @ApiModelProperty(value = "更新人")
    private String updateBy;


}
