package com.ekangji.policy.dto.clientobject.insurance.product;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 产品ID
     */
    @ApiModelProperty(value = "产品ID")
    private String productId;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 公司ID
     */
    @ApiModelProperty(value = "公司ID")
    private String companyId;
    /**
     * 公司名称
     */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /**
     * 一级产品类别
     */
    @ApiModelProperty(value = "一级产品类别")
    private String oneLevelType;

    /**
     * 二级产品类别
     */
    @ApiModelProperty(value = "二级产品类别")
    private String twoLevelType;

    /**
     * 三级产品类别
     */
    @ApiModelProperty(value = "三级产品类别")
    private String threeLevelType;

    /**
     * 四级产品类别
     */
    @ApiModelProperty(value = "四级产品类别")
    private String fourLevelType;

    /**
     * 产品类别
     */
    @ApiModelProperty(value = "产品类别desc")
    private String productTypeDesc;

    /**
     * 设计类型 ProdDesiCode_00 传统型产品 ProdDesiCode_01 新型产品
     */
    @ApiModelProperty(value = "设计类型")
    private String designType;

    @ApiModelProperty(value = "设计类型desc")
    private String designTypeDesc;

    /**
     * 产品特殊属性 00 航空意外险 01 学生平安险 02 女性专属产品 03 少儿专属产品 04 老年专属产品
     */
    @ApiModelProperty(value = "产品特殊属性")
    private String productSpecial;

    @ApiModelProperty(value = "产品特殊属性desc")
    private String productSpecialDesc;

    /**
     * 保期类型 00 短期（一年及一年以下）01 长期（超过一年或含有保证续保条款）
     */
    @ApiModelProperty(value = "保期类型")
    private String timeType;

    /**
     * 保期类型 00 短期（一年及一年以下）01 长期（超过一年或含有保证续保条款）
     */
    @ApiModelProperty(value = "保期类型desc")
    private String timeTypeDesc;

    /**
     * 条款编码
     */
    @ApiModelProperty(value = "条款编码")
    private String clauseCode;

    /**
     * 条款文件名
     */
    @ApiModelProperty(value = "条款文件名")
    private String clauseFileName;

    /**
     * 条款文件
     */
    @ApiModelProperty(value = "条款文件")
    private String clauseFileId;

    /**
     * 承保方式 00 团队 01 个人
     */
    @ApiModelProperty(value = "承保方式")
    private String insuranceStyle;

    /**
     * 承保方式 00 团队 01 个人
     */
    @ApiModelProperty(value = "承保方式desc")
    private String insuranceStyleDesc;

    /**
     * 交费方式 00 一次性缴费 01 分起交费 02 分期交费一次性交费兼有 03灵活交费
     */
    @ApiModelProperty(value = "交费方式")
    private String payWay;

    /**
     * 交费方式 00 一次性缴费 01 分起交费 02 分期交费一次性交费兼有 03灵活交费
     */
    @ApiModelProperty(value = "交费方式desc")
    private String payWayDesc;

    /**
     * 停售日期
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value = "停售/停售日期")
    private Date stopDate;

    /**
     * 01 在售 02 停售 03 停用
     */
    @ApiModelProperty(value = "销售状态")
    private String saleStatus;

    /**
     * 01 在售 02 停售 03 停用
     */
    @ApiModelProperty(value = "销售状态Desc")
    private String saleStatusDesc;

    /**
     * 是否拆解 0 否 1是
     */
    @ApiModelProperty(value = "是否拆解 0 否 1是")
    private Integer isDismantle;

    /**
     * 是否拆解 否 是
     */
    @ApiModelProperty(value = "是否拆解 否 是")
    private String isDismantleDesc;

    /**
     * 是否有效 （0：无效 ，1：有效）
     */
    @ApiModelProperty(value = "是否有效 （0：无效 ，1：有效）")
    private Integer status;

    /**
     * 产品类别list
     */
    @ApiModelProperty(value = "产品类别list")
    private List<String> category;



}