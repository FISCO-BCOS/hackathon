package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.starchain.RelStarChainVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.starchain.RelStarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.RelStarChainQry;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 星链星球关联记录
 */
public interface RelStarChainService {

    /**
     * 新增星链星球关联记录
     * @param cmd
     * @return
     */
    ApiResult add(RelStarChainAddCmd cmd);

    /**
     * 列表查询
     * @param qry
     * @return
     */
    List<RelStarChainVO> queryList(RelStarChainQry qry);

}
