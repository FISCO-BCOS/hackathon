package com.ekangji.policy.dto.clientobject.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 待接收保单返回
 * @Date: 2022/05/16 11:50
 */
@Data
public class PolicyBackupValidationVO implements Serializable {

    @ApiModelProperty(value = "已接收数量")
    private Integer ReceivedCount;

    @ApiModelProperty(value = "待接收保单数量")
    private Integer waitReceiveCount;

    @ApiModelProperty(value = "此次可备份的保单ID数组")
    private List<Long> allowBackupPolicyIds;

    @ApiModelProperty(value = "可备份保单简述：被保人XX的XX险")
    private List<String> allowBackupPolicyDesc;

}
