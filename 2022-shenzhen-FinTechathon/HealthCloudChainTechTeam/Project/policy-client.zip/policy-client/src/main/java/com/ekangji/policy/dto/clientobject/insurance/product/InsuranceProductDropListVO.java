package com.ekangji.policy.dto.clientobject.insurance.product;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;


@Data
public class InsuranceProductDropListVO implements Serializable {

    /**
     * 产品ID
     */
    @ApiModelProperty(value = "产品ID")
    private String productId;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;
}
