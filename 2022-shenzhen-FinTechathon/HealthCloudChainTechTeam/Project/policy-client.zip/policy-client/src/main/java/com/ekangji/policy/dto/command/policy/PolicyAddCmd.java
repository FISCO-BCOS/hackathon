package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 保单快速录入
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "保单对象")
public class PolicyAddCmd extends PolicyCmd implements Serializable {

    @ApiModelProperty(value = "所属平台(0:微信，1:抖音)")
    @NotNull(message = "所属平台有误")
    @Range(min = 0,max = 10,message = "所属平台参数错误")
    private Integer platform;

}
