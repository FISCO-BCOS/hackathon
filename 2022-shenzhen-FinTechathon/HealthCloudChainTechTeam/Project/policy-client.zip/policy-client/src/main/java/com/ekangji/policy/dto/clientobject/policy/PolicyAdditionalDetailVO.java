package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyAdditionalDetailVO implements Serializable {

    /**
     * 附加险名称
     */
    @ApiModelProperty(value = "附加险名称")
    private String additionalProductName;

    /**
     * 附加险产品类型编号
     */
    @ApiModelProperty(value = "附加险产品类型编号")
    private String additionalProductType;


    /**
     * 附加险产品类型名称
     */
    @ApiModelProperty(value = "附加险产品类型名称")
    private String additionalProductTypeName;

    /**
     * 附加险保单状态
     */
    @ApiModelProperty(value = "附加险保单状态")
    private Integer additionalStatus;
    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = "保单状态（1:保障中,0:未在保障中）")
    private String additionalStatusName;

    /**
     * 附加险保障期限
     */
    @ApiModelProperty(value = "附加险保障期限")
    private Integer additionalGuaranteePeriod;
    /**
     * 附加险保障期限
     */
    @ApiModelProperty(value = "附加险保障期限单位")
    private Integer additionalGuaranteePeriodUnit;

    /**
     * 附加险保障结束日期
     */
    @ApiModelProperty(value = "附加险保障结束日期")
    private Date additionalGuaranteeEndDate;


    /**
     * 附加险缴费期间
     */
    @ApiModelProperty(value = "附加险缴费期间")
    private Integer additionalPayPeriod;
    /**
     * 附加险缴费期间
     */
    @ApiModelProperty(value = "附加险缴费期间单位")
    private Integer additionalPayPeriodUnit;

    /**
     * 附加险单次保费
     */
    @ApiModelProperty(value = "附加险单次保费")
    private BigDecimal additionalSinglePremium;
    /**
     * 附加险保额
     */
    @ApiModelProperty(value = "附加险保额")
    private BigDecimal additionalInsuredAmount;
}
