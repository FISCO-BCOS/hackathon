package com.ekangji.policy.dto.clientobject.insurance.product;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;

@Data
public class InsuranceProductTypeVO implements Serializable {

    @ApiModelProperty(value = "产品类别集合(顺序类推)")
    private List<String> levelTypeList;

    @ApiModelProperty(value = "产品类型描述")
    private String productTypeDesc;
}
