package com.ekangji.policy.dto.clientobject.policy.familyreport;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 家庭成员（被保人）总计信息
 * @Date: 2022/05/25 10:18
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FamilyMemberTotalInfoVO implements Serializable {

    @ApiModelProperty(value = "家庭被保人保单总计信息集合")
    private List<InsurantTotalInfoVO> insurantTotalInfoList;
}
