package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 用户星球对象
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "用户星球对象")
public class UserStarAddCmd implements Serializable {

    @ApiModelProperty(value = "用户ID")
    private String userId;

    @ApiModelProperty(value = "微信昵称")
    @NotNull(message = "昵称不能为空")
    private String nickName;


    @ApiModelProperty(value = "星球图片id")
    private Long materialId;
}
