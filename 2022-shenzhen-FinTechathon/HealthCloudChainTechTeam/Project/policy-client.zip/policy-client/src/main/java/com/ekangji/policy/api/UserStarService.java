package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.star.StarStatisticsVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.ekangji.policy.dto.command.policy.UserStarAddCmd;
import com.ekangji.policy.dto.command.policy.UserStarEditCmd;
import com.ekangji.policy.dto.command.star.UserStarPageQry;
import com.ekangji.policy.dto.command.star.UserStarQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.github.pagehelper.PageInfo;

public interface UserStarService {

    /**
     * 检查用户是否有星球(1:有,0:无)
     * @param loginUserInfo
     * @return
     */
    ApiResult checkUserHaveStar(LoginUserInfo loginUserInfo);

    /**
     * 星球上链
     * @param userStarAddCmd
     * @return
     */
    ApiResult buildUserStar(UserStarAddCmd userStarAddCmd);

    /**
     * 获取用户星球
     * @param userStarQry
     * @return
     */
    ApiResult<StarVO> queryUserStar(UserStarQry userStarQry);

    /**
     * 编辑用户星球
     * @param userStarEditCmd
     * @return
     */
    ApiResult<Integer> editUserStar(UserStarEditCmd userStarEditCmd);

    /**
     * 运营后台查询用户星球信息列表
     * @param
     * @return
     */
    ApiResult<PageInfo<StarStatisticsVO>> queryUserStarPage(UserStarPageQry qry);

    /**
     * 获取星球用户数
     * @return
     */
    ApiResult<String> queryTotalStarNum();
}
