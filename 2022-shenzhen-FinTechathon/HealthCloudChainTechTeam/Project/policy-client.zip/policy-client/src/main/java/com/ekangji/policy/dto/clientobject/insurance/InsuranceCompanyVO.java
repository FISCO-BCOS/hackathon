package com.ekangji.policy.dto.clientobject.insurance;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;


@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceCompanyVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 公司ID
     */
    @ApiModelProperty(value = "公司ID")
    private String companyId;

    /**
     * 公司名称
     */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /**
     * 公司简称
     */
    @ApiModelProperty(value = "公司简称")
    private String companyNameShort;

    /**
     * 公司英文名
     */
    @ApiModelProperty(value = "公司英文名")
    private String companyNameEn;

    /**
     * 图标
     */
    @ApiModelProperty(value = "图标")
    private String fileId;

    /**
     * 公司类型
     */
    @ApiModelProperty(value = "公司类型")
    private String companyType;

    /**
     * 公司类型-描述
     */
    @ApiModelProperty(value = "公司类型描述")
    private String companyTypeDesc;

    /**
     * 省
     */
    @ApiModelProperty(value = "省")
    private String provinceCode;

    /**
     * 市
     */
    @ApiModelProperty(value = "市")
    private String cityCode;

    /**
     * 省
     */
    @ApiModelProperty(value = "省-描述")
    private String provinceDesc;

    /**
     * 市
     */
    @ApiModelProperty(value = "市-描述")
    private String cityDesc;

    /**
     * 客服电话
     */
    @ApiModelProperty(value = "客服电话")
    private String phone;

}