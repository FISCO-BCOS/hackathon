

package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.common.page.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * 某家庭成员保单列表查询
 * @author 何帅
 * @date 2022-06-07 08:48:51
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FamilyMemberPolicyQry extends Page implements Serializable {

    /**
     * 家庭成员ID
     */
    @ApiModelProperty(value = "家庭成员ID",required = true)
    private Long familyMemberId;
}
