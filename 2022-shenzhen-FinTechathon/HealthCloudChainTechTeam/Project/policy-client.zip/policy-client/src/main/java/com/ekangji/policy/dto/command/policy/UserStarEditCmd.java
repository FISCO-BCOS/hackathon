package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 用户星球编辑对象
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "用户星球编辑对象")
public class UserStarEditCmd implements Serializable {

    @ApiModelProperty(value = "星球ID")
    private Long starId;

    @ApiModelProperty(value = "星球昵称")
    private String nickName;

}
