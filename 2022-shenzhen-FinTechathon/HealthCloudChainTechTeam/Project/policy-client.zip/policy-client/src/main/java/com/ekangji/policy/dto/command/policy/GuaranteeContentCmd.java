package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@ApiModel(description = "保障内容")
public class GuaranteeContentCmd implements Serializable {

    @ApiModelProperty(value = "附加险集合")
    private List<PolicyAdditionalAddCmd> additional;

    @ApiModelProperty(value = "缴费卡号")
    private String payCardNumber;

    @ApiModelProperty(value = "开户行")
    private String bankName;

    @ApiModelProperty(value = "经办人")
    private String handler;

    @ApiModelProperty(value = "经办人手机号")
    private String handlerPhone;

    @ApiModelProperty(value = "备注")
    private String remark;
}
