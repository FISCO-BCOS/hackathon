package com.ekangji.policy.dto.clientobject.star;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author   liuchen
 * @date   2022-07-12 14:55:47
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class StarStatisticsVO implements Serializable {

    @ApiModelProperty(value = "星球ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long starId;

    @ApiModelProperty(value = "星球昵称(持有者)")
    private String nickName;

    @ApiModelProperty(value = "用户ID")
    private String userId;

    @ApiModelProperty(value = "用户手机号")
    private String userPhone;

    @ApiModelProperty(value = "唯一序号")
    private String sequence;

    @ApiModelProperty(value = "链上HASH地址")
    private String chainAddr;

    @ApiModelProperty(value = "区块链图片url")
    private String pictureUrl;

    @ApiModelProperty(value = "OSS文件id")
    private String fileId;

    @ApiModelProperty(value = "星球领取时间")
    private Date createTime;

    @ApiModelProperty(value = "星链长度")
    private Integer length;

    @ApiModelProperty(value = "数字保单个数")
    private Integer digitalNum;

    @ApiModelProperty(value = "邀请用户数")
    private Integer inviteNum;
}
