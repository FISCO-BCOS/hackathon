package com.ekangji.policy.dto.clientobject.client;

public interface TestApi {

}
