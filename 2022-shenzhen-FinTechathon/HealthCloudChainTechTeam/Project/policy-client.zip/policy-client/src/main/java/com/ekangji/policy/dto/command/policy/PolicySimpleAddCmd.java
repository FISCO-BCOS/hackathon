package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author liuchen
 * @Description 保单简单录入
 * @date 2022-07-12 14:30:25
 */
@Data
@ApiModel(description = "保单对象")
public class PolicySimpleAddCmd extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "保险公司ID")
    private String companyId;

    @ApiModelProperty(value = "保险公司全称")
    @NotBlank(message = "保险公司名称必填")
    @Length(min = 2,max = 50,message = "保险公司名称最小2个字符最大50个字符")
    private String companyName;

    @ApiModelProperty(value = "保险公司简称")
    private String companyNameShort;

    @ApiModelProperty(value = "保险产品ID")
    private String productId;

    @ApiModelProperty(value = "保险产品名称")
    @NotBlank(message = "保险产品名称必填")
    @Length(min = 2,max = 50,message = "保险产品名称最小2个字符最大50个字符")
    private String productName;

    @ApiModelProperty(value = "产品类型ID集合")
    private List<String> productTypeList;

    @ApiModelProperty(value = "被保人")
    @NotBlank(message = "被保人必填")
    @Length(min = 2,max = 20,message = "被保人姓名最小2个字符最大20个字符")
    private String insurantName;

    @ApiModelProperty(value = "所属平台(0:微信，1:抖音)")
    @NotNull(message = "所属平台有误")
    @Range(min = 0,max = 10,message = "所属平台参数错误")
    private Integer platform;

}
