package com.ekangji.policy.dto.command.material;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author   xintao.li
 * @date   2022-07-12-01 13:00:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PictureMaterialAddCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 图片地址ID
     */
    @ApiModelProperty("图片地址ID")
    private String fileId;

    /**
     * 图片名称
     */
    @ApiModelProperty("图片名称")
    @Length(min = 1, max = 20,message = "图片名(包含后缀)长度不能超过20个字符")
    private String pictureName;

    /**
     * 素材类型(1:星球图片,2:保单图片)
     */
    @ApiModelProperty("素材类型(1:星球图片,2:保单图片)")
    private Integer materialType;

}
