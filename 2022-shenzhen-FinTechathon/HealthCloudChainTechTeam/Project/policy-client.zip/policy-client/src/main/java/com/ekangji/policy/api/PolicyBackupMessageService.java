package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.PolicyBackupValidationVO;
import com.ekangji.policy.dto.clientobject.policy.ToReceivePolicyVO;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageAddCmd;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.backup.ToBeBackupPolicyQry;
import com.ekangji.policy.dto.command.policy.backup.ToReceivePolicyQry;

import java.util.List;

/**
 * @Desc: 保单备份服务
 */
public interface PolicyBackupMessageService {
    /**
     * 备份保单前置校验
     * @param qry
     * @return
     */
    ApiResult<PolicyBackupValidationVO> validateBeforeBackup(ToBeBackupPolicyQry qry);


    /**
     * 获取用户待接收的保单信息
     * @param qry
     * @return
     */
    ApiResult<ToReceivePolicyVO> getToReceivePolicyByUserId(ToReceivePolicyQry qry);

    /**
     * 备份保单处理（接收/不接收）
     * @param cmd
     * @return
     */
    ApiResult policyBackupHandling(PolicyBackupMessageEditCmd cmd);

    /**
     * 发起备份保单
     * @param cmd
     * @return
     */
    ApiResult launchBackupPolicy(PolicyBackupMessageAddCmd cmd);


    /**
     * 查找待备份的保单
     * @param cmd
     * @return
     */
    List<Long> selectToReceivePolicy(PolicyBackupMessageEditCmd cmd,String receiveUserPhone);

    /**
     * 更新备份消息状态
     * @param cmd
     * @return
     */
    ApiResult updateMessageStatus(PolicyBackupMessageEditCmd cmd,String receiveUserPhone);
}
