package com.ekangji.policy.dto.command.dict;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-01 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DictDataDeleteCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 字典编码
     */
    @ApiModelProperty(value = "字典编码",required = true)
    @NotNull(message = "字典编码不能为空")
    private Long dictCode;


}