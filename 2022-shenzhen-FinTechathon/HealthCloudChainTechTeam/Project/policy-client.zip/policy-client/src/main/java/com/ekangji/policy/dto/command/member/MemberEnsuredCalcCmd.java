package com.ekangji.policy.dto.command.member;

import com.ekangji.policy.common.enums.ScoreTypeEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 * @author sunqihua
 * @Description 保障分计算
 * @date 2022-05-16 14:56:32
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberEnsuredCalcCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "保额",required = true)
    private BigDecimal insuredAmount;

    @ApiModelProperty(value = "成员id",required = true)
    private Long memberId;

    @ApiModelProperty(value = "所属用户id",required = true)
    private String userId;

    @ApiModelProperty(value = "产品一级类别id集合",required = true)
    private Set<String> prodTypeCodes;


}