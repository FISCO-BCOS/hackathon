package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.material.PictureMaterialVO;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.command.material.*;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;

import java.util.List;

public interface PictureMaterialService {

    /**
     * 客户端获取星球素材
     * @param qry
     * @return
     */
    ApiResult<List<PictureMaterialVO>> queryMaterialList(PictureMaterialQry qry);

    /**
     * 后台获取星球素材
     * @param qry
     * @return
     */
    ApiResult<List<PictureMaterialVO>> queryList(PictureMaterialQry qry);

    /**
     * 启用、禁用
     * @param qry
     * @return
     */
    ApiResult enableOrDisable(PictureMaterialEnableCmd qry);

    /**
     * 编辑
     * @param qry
     * @return
     */
    ApiResult edit(PictureMaterialEditCmd qry);


    /**
     * 图片添加
     * @param cmd
     * @return
     */
    ApiResult add(PictureMaterialAddCmd cmd);

    /**
     * 批量删除
     * @param cmd
     * @return
     */
    ApiResult delete(PictureMaterialDeleteCmd cmd);
}
