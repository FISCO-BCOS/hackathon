package com.ekangji.policy.dto.command.member;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author liuchen
 * @Description 更新备份保单消息
 * @date 2022-5-16 14:30:25
 */
@Data
public class EnsuredReadConfigEditCmd implements Serializable {



    @ApiModelProperty(value = "主键id")
    private Long id;

    @ApiModelProperty(value = "'最小保障分'")
    @NotEmpty(message = "最小保障分不能为空")
    @Min(value = 0,message = "请输入0-100范围的整数")
    @Max(value = 100,message = "请输入0-100范围的整数")
    private Integer minScore;


    @ApiModelProperty(value = "'最大保障分'")
    @NotEmpty(message = "最大保障分不能为空")
    @Min(value = 0,message = "请输入0-100范围的整数")
    @Max(value = 100,message = "请输入0-100范围的整数")
    private Integer maxScore;


    @ApiModelProperty(value = "'封面文案'")
    @NotEmpty(message = "封面文案不能为空")
    @Length(min=0, max=12)
    private String coverTitle;


    @ApiModelProperty(value = "'解读文案'")
    @NotEmpty(message = "解读文案不能为空")
    @Length(min=0, max=200)
    private String readContent;



}
