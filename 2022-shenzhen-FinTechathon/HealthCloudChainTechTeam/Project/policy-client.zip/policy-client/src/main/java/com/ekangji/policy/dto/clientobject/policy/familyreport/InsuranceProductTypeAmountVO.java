package com.ekangji.policy.dto.clientobject.policy.familyreport;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 保险子类别保额集合
 * @Date: 2022/05/24 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceProductTypeAmountVO implements Serializable {

//    @ApiModelProperty(value = "当前tab编号")
//    private String currentProductTopType;
    @ApiModelProperty(value = "前端是否显示对比值 0：不显示，1：显示")
    private Integer shownCompareValue;

    @ApiModelProperty(value = "被保险人保额")
    private List<InsuranceProductTypeDataVO> insurantAmount;

    @ApiModelProperty(value = "同龄保额均值")
    private List<InsuranceProductTypeDataVO> sameAgeAmount;
}
