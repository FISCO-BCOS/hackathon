package com.ekangji.policy.dto.clientobject.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: liuchen
 * @Desc: 待接收保单返回
 * @Date: 2022/05/16 11:50
 */
@Data
public class UserMemberRelationVO implements Serializable {


    @ApiModelProperty(value = "关系id")
    private Integer relationId;

    @ApiModelProperty(value = "关系")
    private String relationName;


}
