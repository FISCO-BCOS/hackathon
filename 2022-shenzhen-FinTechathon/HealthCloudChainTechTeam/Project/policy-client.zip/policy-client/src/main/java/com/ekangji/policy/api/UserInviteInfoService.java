

package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteDetailVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteVO;
import com.ekangji.policy.dto.command.policy.*;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 用户邀请服务
 */
public interface UserInviteInfoService {


    /**
     * 获取邀请人列表
     * @param qry
     * @return
     */
    ApiResult<PageInfo<UserInviteDetailVO>> queryInviteList(UserInviteQry qry);

    /**
     * 获取邀请人信息
     * @param qry
     * @return
     */
    ApiResult<UserInviteVO> queryInviteInfo(UserInviteQry qry);
    /**
     * 获取邀请人列表
     * @param cmd
     * @return
     */
    ApiResult<Long> AddInviteRelation(InviteAddCmd cmd);
}
