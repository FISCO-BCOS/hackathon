package com.ekangji.policy.dto.clientobject.insurance.product;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;


@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ProductDismantleTemplateVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 产品ID
     */
    @ApiModelProperty(value = "产品ID")
    private String productId;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 一级产品类别
     */
    @ApiModelProperty(value = "一级产品类别")
    private String oneLevelType;

    /**
     * 二级产品类别
     */
    @ApiModelProperty(value = "二级产品类别")
    private String twoLevelType;

    /**
     * 三级产品类别
     */
    @ApiModelProperty(value = "三级产品类别")
    private String threeLevelType;

    /**
     * 四级产品类别
     */
    @ApiModelProperty(value = "四级产品类别")
    private String fourLevelType;

    /**
     * 产品类别描述
     */
    @ApiModelProperty(value = "产品类别描述")
    private String productTypeDesc;

    /**
     * 模板集合
     */
    @ApiModelProperty(value = "模板集合")
    private List<DismantleTemplateVO> templateVOList;

}