package com.ekangji.policy.dto.command.starchain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;

/**
 * 
 * @author   xintao.li
 * @date   2021-12-01 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RelStarChainQry implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 星链ID
     */
    @ApiModelProperty(value = "星链ID")
    private Long chainId;

}