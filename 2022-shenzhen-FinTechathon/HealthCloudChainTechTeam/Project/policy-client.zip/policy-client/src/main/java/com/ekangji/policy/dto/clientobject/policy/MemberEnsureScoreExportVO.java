package com.ekangji.policy.dto.clientobject.policy;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.alibaba.excel.annotation.write.style.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: liuchen
 * @Desc: 待接收保单返回
 * @Date: 2022/05/16 11:50
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints=12)
@ContentStyle(horizontalAlignment= HorizontalAlignment.CENTER,verticalAlignment= VerticalAlignment.CENTER)
public class MemberEnsureScoreExportVO implements Serializable {

    @ExcelProperty(value = "成员id", index = 0)
    @NumberFormat(value = "#")
    @ApiModelProperty(value = "成员id")
    private Long memberId;

    @ExcelProperty(value = "成员名称", index = 1)
    @ApiModelProperty(value = "成员名称")
    private String memberName;

    @ExcelProperty(value = "所属平台", index = 2)
    @ApiModelProperty(value = "所属平台")
    private String channelName;


    @ExcelProperty(value = "所属用户昵称", index = 3)
    @ApiModelProperty(value = "所属用户昵称")
    private String userNickName;

    @ExcelProperty(value = "所属用户id", index = 4)
    @ApiModelProperty(value = "所属用户id")
    private String userId;

    @ExcelProperty(value = "所属用户手机号", index = 5)
    @ApiModelProperty(value = "所属用户手机号")
    private String userPhoneNumber;

    @ExcelProperty(value = "家庭保障分", index = 6)
    @ApiModelProperty(value = "家庭保障分")
    private Integer familyScore;


    @ExcelProperty(value = "关系", index = 7)
    @ApiModelProperty(value = "关系")
    private String relationName;

    @ExcelProperty(value = "作为被保人的保单份数", index = 8)
    @ApiModelProperty(value = "作为被保人的保单份数")
    private Integer policyNum;

    @ExcelProperty(value = "成员创建时间", index = 9)
    @ApiModelProperty(value = "成员创建时间")
    private Date memberCreateTime;

    @ExcelProperty(value = "成员保障分", index = 10)
    @ApiModelProperty(value = "成员保障分")
    private Integer memberScore;


}
