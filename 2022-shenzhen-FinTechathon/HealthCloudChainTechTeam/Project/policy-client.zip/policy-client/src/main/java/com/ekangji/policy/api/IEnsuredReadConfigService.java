package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.EnsuredReadConfigVO;
import com.ekangji.policy.dto.clientobject.policy.EnsuredWeightConfigVO;
import com.ekangji.policy.dto.command.member.EnsuredReadConfigBatchEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigBatchEditCmd;

import java.util.List;

public interface IEnsuredReadConfigService {

    ApiResult<Integer> ensuredReadSet(EnsuredReadConfigBatchEditCmd ensuredReadConfigBatchEditCmd);

    ApiResult<List<EnsuredReadConfigVO>> findEnsuredReadList();
}
