package com.ekangji.policy.dto.clientobject.policy.cdetail;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyCDetailVO implements Serializable {

    @ApiModelProperty(value = "主键")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    @ApiModelProperty(value = "保单ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;

    @ApiModelProperty(value = "状态（1:保障中,0:未在保障中）")
    private Integer status;

    @ApiModelProperty(value = "来源类型(1:OCR 2:快速录入 3:邮箱识别)")
    private Integer sourceType;

    @ApiModelProperty(value = "保司ID")
    private String companyId;

    @ApiModelProperty(value = "保司名称")
    private String companyName;

    @ApiModelProperty(value = "保司简称")
    private String companyNameShort;

    @ApiModelProperty(value = "产品ID")
    private String productId;

    @ApiModelProperty(value = "产品名称")
    private String productName;

    @ApiModelProperty(value = "产品一级类型编号")
    private String productTopTypeCode;

    @ApiModelProperty(value = "产品一级类型名称")
    private String productTopTypeName;

    @ApiModelProperty(value = "产品类型集合")
    private List<String> productTypeList;


    /*****************************/
    /*********保单基本信息**********/
    /*****************************/

//    @ApiModelProperty(value = "投保人姓名")
//    private String policyHolderName;

    @ApiModelProperty(value = "投保人信息")
    private MemberDetailVO policyHolder;

//    @ApiModelProperty(value = "被保人姓名")
//    private String insurantName;

    @ApiModelProperty(value = "被保人信息")
    private MemberDetailVO insurant;

    @ApiModelProperty(value = "受益人类型(1:法定收益人,2:指定收益人)")
    private Integer beneficiaryType;

    @ApiModelProperty(value = "指定受益人信息")
    private List<MemberDetailVO> beneficiaryList;

    @ApiModelProperty(value = "保单号")
    private String policyNumber;

    @ApiModelProperty(value = "主险保额(单位:万元)")
    private BigDecimal insuredAmount;

    @ApiModelProperty(value = "主险保额(单位:元)")
    private BigDecimal insuredAmountYuan;

    @ApiModelProperty(value = "保单生效日期")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date effectiveDate;

    @ApiModelProperty(value = "保障期限")
    private Integer guaranteePeriod;

    @ApiModelProperty(value = "保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)")
    private Integer guaranteePeriodUnit;

    @ApiModelProperty(value = "保障结束日期")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date guaranteeEndDate;

    @ApiModelProperty(value = "附加险集合")
    private List<PolicyAdditionalCDetailVO> additionalList;

    @ApiModelProperty(value = "缴费周期(1:月缴,2:半年缴,3:年缴,4:一次性交清)")
    private Integer payCycle;

    @ApiModelProperty(value = "缴费期间")
    private Integer payPeriod;

    @ApiModelProperty(value = "缴费期间单位(1:月 2:半年 3:年 4:至**岁)")
    private Integer payPeriodUnit;

    @ApiModelProperty(value = "单次保费")
    private BigDecimal singlePremium;

    @ApiModelProperty(value = "缴费详情")
    private PolicyPayCDetailVO payDetail;


    /*****************其他信息*********************/
    @ApiModelProperty(value = "缴费银行")
    private String bankName;

    @ApiModelProperty(value = "缴费银行卡号")
    private String payCardNumber;

    @ApiModelProperty(value = "经办人")
    private String handler;

    @ApiModelProperty(value = "经办人手机号")
    private String handlerPhone;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "附件ID集合")
    private List<String> fileId;

    @ApiModelProperty(value = "附件对象集合")
    private List<FileCInfoVO> fileList;

    @ApiModelProperty(value = "图片附件对象集合")
    private List<FileCInfoVO> imgFileList;

    @ApiModelProperty(value = "是否已存在数字保单(1:存在,0:不存在)")
    private Integer digitalFlag;

}
