package com.ekangji.policy.dto.clientobject.common;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 公共VO
 *
 * @author zhangjun
 * @date 2021/12/19 20:14
 */
@Data
public class CommonVO implements Serializable {

    /**
     * 状态（1正常 0停用）
     */
    @ApiModelProperty(value = "状态（1正常 0停用）")
    private Integer status;

    /**
     * 角色状态（1正常 0停用）
     */
    @ApiModelProperty(value = "状态描述（1正常 0停用）")
    private String statusDesc;

    /**
     * 创建者
     */
    @ApiModelProperty(value = "创建者")
    private String createBy;

    /**
     * 创建者
     */
    @ApiModelProperty(value = "创建者姓名")
    private String createName;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 更新者
     */
    @ApiModelProperty(value = "更新者")
    private String updateBy;

    /**
     * 更新者
     */
    @ApiModelProperty(value = "更新者姓名")
    private String updateName;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

}
