package com.ekangji.policy.dto.command.policy.backup;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.*;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 更新备份保单消息
 * @date 2022-5-16 14:30:25
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PolicyBackupMessageEditCmd extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "接收或不接收(接收:2,不接收:3)",required = true)
    @NotNull(message = "状态参数不能为空")
    @Range(min = 2,max = 3,message = "状态参数错误")
    private Integer status;

    @ApiModelProperty(value = "发起备份保单用户ID",required = true)
    @NotBlank(message = "发备份用户userId不能为空")
    private String launchUserId;

}
