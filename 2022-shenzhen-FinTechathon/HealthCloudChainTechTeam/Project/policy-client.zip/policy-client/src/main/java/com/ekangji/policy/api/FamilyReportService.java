package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.familyreport.FamilyMemberTotalInfoVO;
import com.ekangji.policy.dto.clientobject.policy.familyreport.FamilyReportTotalInfoVO;
import com.ekangji.policy.dto.clientobject.policy.familyreport.InsuranceProductTypeAmountVO;
import com.ekangji.policy.dto.command.policy.familyreport.MemberProductTypeAmountQry;
import com.ekangji.policy.dto.command.policy.familyreport.MemberTotalInfoQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;

/**
 * @Desc: 家庭报告服务
 */
public interface FamilyReportService {

    /**
     * 家庭保单总计信息
     * @param qry
     * @return
     */
    ApiResult<FamilyReportTotalInfoVO> findFamilyReportTotalInfo(LoginUserInfo qry);

    /**
     * 家庭成员(被保人)保单统计信息及全部保障数据
     * @param qry
     * @return
     */
    ApiResult<FamilyMemberTotalInfoVO> findFamilyMemberTotalInfo(MemberTotalInfoQry qry);

    /**
     * 家庭成员（被保人）保险保额统计按类别查询
     * @param qry
     * @return
     */
    ApiResult<InsuranceProductTypeAmountVO> findMemberProductTypeAmountInfo(MemberProductTypeAmountQry qry);
}
