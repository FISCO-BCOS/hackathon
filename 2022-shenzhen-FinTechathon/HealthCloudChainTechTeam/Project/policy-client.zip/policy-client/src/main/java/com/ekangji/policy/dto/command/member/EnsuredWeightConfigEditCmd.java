package com.ekangji.policy.dto.command.member;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author liuchen
 * @Description 更新备份保单消息
 * @date 2022-5-16 14:30:25
 */
@Data
public class EnsuredWeightConfigEditCmd  implements Serializable {



    @ApiModelProperty(value = "主键id")
    private Long id;

    @ApiModelProperty(value = "'一级产品类别'")
    @NotEmpty(message = "一级产品类别不能为空")
    private String oneLevelType;

    @ApiModelProperty(value = "'0-18岁权重值'")
    @DecimalMin(value = "0.01",message = "请输入0.01-0.99范围的数字")
    @DecimalMax(value = "0.99",message = "请输入0.01-0.99范围的数字")
    private BigDecimal firstStage;

    @ApiModelProperty(value = "'18-25岁权重值'")
    @DecimalMin(value = "0.01",message = "请输入0.01-0.99范围的数字")
    @DecimalMax(value = "0.99",message = "请输入0.01-0.99范围的数字")
    private BigDecimal secondStage;

    @ApiModelProperty(value = "'25-35岁权重值'")
    @DecimalMin(value = "0.01",message = "请输入0.01-0.99范围的数字")
    @DecimalMax(value = "0.99",message = "请输入0.01-0.99范围的数字")
    private BigDecimal thirdStage;

    @ApiModelProperty(value = "'35-50岁权重值'")
    @DecimalMin(value = "0.01",message = "请输入0.01-0.99范围的数字")
    @DecimalMax(value = "0.99",message = "请输入0.01-0.99范围的数字")
    private BigDecimal fourthStage;


    @ApiModelProperty(value = "''50岁以上权重值''")
    @DecimalMin(value = "0.01",message = "请输入0.01-0.99范围的数字")
    @DecimalMax(value = "0.99",message = "请输入0.01-0.99范围的数字")
    private BigDecimal fifthStage;

}
