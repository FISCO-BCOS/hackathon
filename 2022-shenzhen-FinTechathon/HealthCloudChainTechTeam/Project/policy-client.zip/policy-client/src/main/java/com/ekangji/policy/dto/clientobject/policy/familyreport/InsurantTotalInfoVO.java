package com.ekangji.policy.dto.clientobject.policy.familyreport;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 保险类别信息
 * @Date: 2022/05/24 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsurantTotalInfoVO implements Serializable {

    @ApiModelProperty(value = "被保人姓名")
    private String name;

    @ApiModelProperty(value = "被保人ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long memberId;

    @ApiModelProperty(value = "被保人头像")
    private String userPhoto;

    @ApiModelProperty(value = "有效保单数")
    private Integer effectivePolicyNum;

    @ApiModelProperty(value = "今年保费")
    private BigDecimal premium;

    @ApiModelProperty(value = "tab一级保险类别信息")
    private List<InsuranceProductTypeInfoVO> productType;

    @ApiModelProperty(value = "当前tab编号")
    private String currentProductTypeCode;

    @ApiModelProperty(value = "被保险人保额")
    private List<InsuranceProductTypeDataVO> insurantAmount;

    @ApiModelProperty(value = "前端是否显示对比值 0：不显示，1：显示")
    private Integer shownCompareValue;

    @ApiModelProperty(value = "同龄保额均值")
    private List<InsuranceProductTypeDataVO> sameAgeAmount;

    /**
     * 以下两个字段做排序使用
     */

    @ApiModelProperty(value = "关系顺序")
    private Integer relation;

    @ApiModelProperty(value = "成员创建时间")
    private Date memberCreateTime;
}
