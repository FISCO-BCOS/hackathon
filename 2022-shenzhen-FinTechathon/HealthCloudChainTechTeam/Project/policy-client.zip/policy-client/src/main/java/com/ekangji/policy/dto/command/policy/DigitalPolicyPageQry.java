
package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.common.page.Page;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

/**
 * @author 李鑫涛
 * @date 4/14/22 11:13 AM
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DigitalPolicyPageQry extends Page implements Serializable {

    /**
     * 数字保单产品名称
     */
    @ApiModelProperty(value = "数字保单产品名称")
    private String productName;

    /**
     *数字保单创建时间开始时间
     */
    @ApiModelProperty(value = "数字保单创建时间开始时间")
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date digitalPolicyCreateTimeStart;

    /**
     *数字保单创建时间结束时间
     */
    @ApiModelProperty(value = "数字保单创建时间结束时间")
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date digitalPolicyCreateTimeEnd;

    /**
     * 是否推荐
     */
    @ApiModelProperty(value = "0都可见 1仅自己可见")
    private Integer recommendFlag;
    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id")
    private String userId;


    /**
     * 用户手机号
     */
    @ApiModelProperty(value = "用户手机号")
    private String phoneNumber;
}
