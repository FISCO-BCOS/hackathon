package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Desc: 待接收保单返回
 */
@Data
public class EnsuredReadConfigVO implements Serializable {


    @ApiModelProperty(value = "主键id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    @ApiModelProperty(value = "'最小运算符'")
    private String minOperator;

    @ApiModelProperty(value = "'最大运算符'")
    private String maxOperator;



    @ApiModelProperty(value = "'最小保障分'")
    private Integer minScore;


    @ApiModelProperty(value = "'最大保障分'")
    private Integer maxScore;


    @ApiModelProperty(value = "'封面文案'")
    private String coverTitle;


    @ApiModelProperty(value = "'解读文案'")
    private String readContent;
}
