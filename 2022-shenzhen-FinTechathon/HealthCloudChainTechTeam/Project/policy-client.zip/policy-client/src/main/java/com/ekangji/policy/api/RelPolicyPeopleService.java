package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.InsuredRankingVO;
import com.ekangji.policy.dto.clientobject.policy.RelPolicyPeopleVO;
import com.ekangji.policy.dto.command.policy.EditRelPolicyPeopleCmd;
import com.ekangji.policy.dto.command.policy.QueryPolicyPeopleCmd;

import java.util.List;

/**
 * 保单解析
 */
public interface RelPolicyPeopleService {



    /**
     * 查询保单人员信息
     * @param cmd
     * @return
     */
    ApiResult<List<RelPolicyPeopleVO>> queryPolicyPeopleInfo(QueryPolicyPeopleCmd cmd);

    /**
     * 取消保单
     * @param cmd
     * @return
     */
    ApiResult<String> edit(EditRelPolicyPeopleCmd cmd);

    /**
     * 查询被保人所在排行
     * @param id
     * @return
     */
    ApiResult<InsuredRankingVO> queryInsuredRanking(Long id);
}
