package com.ekangji.policy.dto.clientobject.policy.cdetail;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BeneficiaryDetailVO implements Serializable {

    @ApiModelProperty(value = "受益人姓名")
    private String name;

    @ApiModelProperty(value = "受益比例")
    private BigDecimal benefitRatio;

}
