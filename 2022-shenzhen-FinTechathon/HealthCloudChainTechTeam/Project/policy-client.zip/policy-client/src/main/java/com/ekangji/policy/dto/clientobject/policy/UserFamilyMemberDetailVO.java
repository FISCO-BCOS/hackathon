package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: liuchen
 * @Desc: 待接收保单返回
 * @Date: 2022/05/16 11:50
 */
@Data
public class UserFamilyMemberDetailVO implements Serializable {


    @ApiModelProperty(value = "用户昵称")
    private String nickName;

    @ApiModelProperty(value = "成员id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long memberId;

    @ApiModelProperty(value = "关系")
    private Integer relation;

    @ApiModelProperty(value = "真实姓名")
    private String name;

    @ApiModelProperty(value = "是否是备份 1 是 0否 ")
    private Integer backFlag;

    @ApiModelProperty(value = "有无社保")
    private Integer socialSecurityFlag;

    @ApiModelProperty(value = "证件类型")
    private Integer identityCardType;

    @ApiModelProperty(value = "证件号码")
    private String identityCardNumber;

    @ApiModelProperty(value = "手机号码")
    private String phoneNumber;

    @ApiModelProperty(value = "性别")
    private Integer sex;

    @ApiModelProperty(value = "出生日期")
    private String birthday;

    @ApiModelProperty(value = "用户头像")
    private String userPhoto;
}
