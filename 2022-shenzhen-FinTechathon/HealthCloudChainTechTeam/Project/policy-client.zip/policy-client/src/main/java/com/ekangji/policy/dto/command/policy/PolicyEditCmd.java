package com.ekangji.policy.dto.command.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 保单编辑
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "保单编辑对象")
public class PolicyEditCmd extends PolicyCmd implements Serializable {

    @ApiModelProperty(value = "保单ID")
    @NotNull(message = "保单ID不能为空")
    private Long policyId;
}
