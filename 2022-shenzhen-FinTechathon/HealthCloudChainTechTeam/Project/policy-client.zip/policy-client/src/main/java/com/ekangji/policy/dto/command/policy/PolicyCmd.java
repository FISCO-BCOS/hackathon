package com.ekangji.policy.dto.command.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 *
 * @author liuchen
 * @Description 保单公共基础对象
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "保单公共基础对象")
public class PolicyCmd extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "保险公司ID")
    private String companyId;

    @ApiModelProperty(value = "保险公司全称")
    @NotBlank(message = "保险公司名称必填")
    @Length(min = 2,max = 50,message = "保险公司名称不能超过50个字")
    private String companyName;

    @ApiModelProperty(value = "保险公司简称")
    private String companyNameShort;

    @ApiModelProperty(value = "保险产品ID")
    private String productId;

    @ApiModelProperty(value = "保险产品名称")
    @NotBlank(message = "保险产品名称必填")
    @Length(min = 2,max = 50,message = "保险产品名称不能超过50个字")
    private String productName;

    @ApiModelProperty(value = "产品类型ID集合")
    private List<String> productTypeList;

    @ApiModelProperty(value = "投保人ID")
    @NotNull(message = "投保人必填")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyHolderId;

    @ApiModelProperty(value = "被保人集合")
    @NotEmpty(message = "被保人必填")
    private List<PolicyInsurantAddCmd> insurant;

    @ApiModelProperty(value = "受益人类型(1:法定收益人,2:指定收益人)")
    @NotNull(message = "受益人类型必填")
    @Range(min = 1,max = 2,message = "受益人类型参数错误")
    private Integer beneficiaryType;

    @ApiModelProperty(value = "受益人集合")
    private List<PolicyBeneficiaryAddCmd> beneficiary;

    @ApiModelProperty(value = "保单号")
    private String policyNumber;

    @ApiModelProperty(value = "保单生效日期")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @NotNull(message = "保单生效日期必填")
    private Date effectiveDate;

    @ApiModelProperty(value = "保障期限")
    private Integer guaranteePeriod;

    @ApiModelProperty(value = "保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)")
    @NotNull(message = "保障期限单位必填")
    @Range(min = 1,max = 6,message = "保障期限单位参数错误")
    private Integer guaranteePeriodUnit;

    @ApiModelProperty(value = "保障结束日期(当保障期限为其他时有)")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date guaranteeEndDate;

    @ApiModelProperty(value = "缴费周期(1:月缴,2:半年缴,3:年缴,4:一次性交清)")
    @NotNull(message = "缴费周期必填")
    @Range(min = 1,max = 4,message = "缴费周期参数错误")
    private Integer payCycle;

    @ApiModelProperty(value = "缴费期间")
    private Integer payPeriod;

    @ApiModelProperty(value = "缴费期间单位(1:月 2:半年 3:年 4:至**岁)")
    private Integer payPeriodUnit;

    @ApiModelProperty(value = "单次保费")
    @Digits(integer = 10,fraction = 2,message = "保费整数最大【{integer}】位数,小数部分不能超过【{fraction}】位数")
    @NotNull(message = "保费数值有误")
    private BigDecimal singlePremium;

    @ApiModelProperty(value = "主险保额")
    @Digits(integer = 10,fraction = 2,message = "保费整数最大【{integer}】位数,小数部分不能超过【{fraction}】位数")
    @NotNull(message = "保额数值有误")
    private BigDecimal insuredAmount;

    @ApiModelProperty(value = "附加险集合")
    private List<PolicyAdditionalAddCmd> additional;

    @ApiModelProperty(value = "缴费卡号")
    private String payCardNumber;

    @ApiModelProperty(value = "开户行")
    private String bankName;

    @ApiModelProperty(value = "经办人")
    private String handler;

    @ApiModelProperty(value = "经办人手机号")
    private String handlerPhone;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "附件集合")
    private List<String> fileId;
}
