package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.safeguardinsurance.SafeguardInsuranceVO;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardinsurance.SafeguardInsuranceEditCompareValueCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardInsuranceEditAssignCmd;

import java.util.List;
import java.util.Map;

/**
 * 保障图配置
 */
public interface SafeguardInsuranceService {



    /**
     * 查询列表
     */
    ApiResult<List<SafeguardInsuranceVO>> queryList(InsuranceCommonQry qry);

    /**
     * 获取某一级类别下的所有子类别的用户同龄保额的对比值
     */
    Map<String,Integer> listChildrenCompareValue(InsuranceCommonQry qry);

    /**
     * 获取父类别下的所有子类别的用户同龄保额的对比值
     */
    Map<String,Integer> listParentCompareValue(InsuranceCommonQry qry);

    /**
     * 更新保障图数据
     */
    ApiResult updateInsurance();

    /**
     * 更新数据（只更新雷达图最大值）
     * @param cmd
     * @return
     */
    ApiResult updateAssignValue(List<SafeguardInsuranceEditAssignCmd> cmd);

    /**
     *更新数据（更新对比值）
     * @param cmd
     * @return
     */
    ApiResult updateCompareValue(SafeguardInsuranceEditCompareValueCmd cmd);

    /**
     * 更新健康险数据-定时任务
     * @return
     */
    ApiResult updateHealth();

    /**
     * 更新人寿险数据-定时任务
     * @return
     */
    ApiResult updateLifeInsurance();

    /**
     * 更新意外险数据-定时任务
     * @return
     */
    ApiResult updateUnexpected();

    /**
     * 更新年金险数据-定时任务
     * @return
     */
    ApiResult updateAnnuity();
}
