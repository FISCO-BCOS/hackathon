package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyDataVO implements Serializable {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 保单ID 雪花算法生产
     */
    @ApiModelProperty(value = "保单ID 雪花算法生产")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;
    /**
     * 所属渠道平台
     */
    @ApiModelProperty(value = "所属渠道平台",required = true)
    private Integer channelType;
    /**
     * 所属渠道平台名称
     */
    @ApiModelProperty(value = "所属渠道平台名称",required = true)
    private String channelName;



    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id",required = true)
    private String userId;


    /**
     * 用户手机号
     */
    @ApiModelProperty(value = "手机号码",required = true)
    private String phoneNumber;


    /**
     * 保险公司
     */
    @ApiModelProperty(value = "保险公司",required = true)
    private String companyName;
    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称",required = true)
    private String productName;
    /**
     * 产品类别
     */
    @ApiModelProperty(value = "产品类别",required = true)
    private String productType;


    /**
     * 投保人
     */
    @ApiModelProperty(value = "投保人",required = true)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyHolderId;
    /**
     * 被保人
     */
    @ApiModelProperty(value = "被保人",required = true)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long insurantId;
    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long beneficiaryId;

    /**
     * 投保人
     */
    @ApiModelProperty(value = "投保人",required = true)
    private String policyHolderName;
    /**
     * 被保人
     */
    @ApiModelProperty(value = "被保人",required = true)
    private String insurantName;
    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    private String beneficiaryName;
    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = "保单状态（1:保障中,0:未在保障中）")
    private Integer policeStatus;

    /**
     * 保费
     */
    @ApiModelProperty(value = "保费")
    private BigDecimal singlePremium;
    /**
     * 保额
     */
    @ApiModelProperty(value = "保额")
    private BigDecimal insuredAmount;


    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    @ApiModelProperty(value = "创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份",required = true)
    private Integer sourceType;


    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    @ApiModelProperty(value = "创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份",required = true)
    private String sourceName;
    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;


    /**
     * 最后一次更新时间
     */
    @ApiModelProperty(value = "最后一次更新时间")
    private Date updateTime;

}
