package com.ekangji.policy.dto.command.policy.ocr;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author liuchen
 * @Description 保单成员基础对象
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "保单公共基础对象")
public class FamilyMemberCmd implements Serializable {

    @ApiModelProperty(value = "成员id")
    private Long memberId;

    @ApiModelProperty(value = "用户昵称")
    @NotNull(message = "用户昵称不能为空")
    private String nickName;

    @ApiModelProperty(value = "关系")
    private Integer relation;

    @ApiModelProperty(value = "真实姓名")
    private String name;

    @ApiModelProperty(value = "证件类型")
    private Integer identityCardType;

    @ApiModelProperty(value = "证件号码")
    private String identityCardNumber;

    @ApiModelProperty(value = "手机号码")
    @Pattern(regexp = "^[1][3,4,5,6,7,8,9][0-9]{9}$", message = "手机号格式有误")
    private String phoneNumber;

    @ApiModelProperty(value = "性别")
    private Integer sex;

    @ApiModelProperty(value = "出生日期")
    private String birthday;

    @ApiModelProperty(value = "受益比例")
    @Digits(integer = 6,fraction = 2,message = "受益比例【{6}】位数,小数部分不能超过【{fraction}】位数")
    @Range(min = 0,max = 100)
    private BigDecimal benefitRatio;
}
