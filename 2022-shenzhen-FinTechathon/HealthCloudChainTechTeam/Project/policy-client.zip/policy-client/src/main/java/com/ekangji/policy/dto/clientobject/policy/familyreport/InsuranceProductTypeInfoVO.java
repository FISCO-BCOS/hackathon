package com.ekangji.policy.dto.clientobject.policy.familyreport;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @Author: liuchen
 * @Desc: 保险类别信息
 * @Date: 2022/05/24 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceProductTypeInfoVO implements Serializable {

    @ApiModelProperty(value = "保险分类名称")
    private String productTypeName;

    @ApiModelProperty(value = "保险类别编号")
    private String productTypeCode;
}
