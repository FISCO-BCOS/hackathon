package com.ekangji.policy.dto.command.insurance.product;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 *
 * @author   liuchen
 * @date   2022-05-17 17:06:58
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductByCompanyIdQry implements Serializable {

    @ApiModelProperty(value = "保司ID",required = true)
    @NotBlank(message = "保司ID不能为空")
    private String companyId;
}
