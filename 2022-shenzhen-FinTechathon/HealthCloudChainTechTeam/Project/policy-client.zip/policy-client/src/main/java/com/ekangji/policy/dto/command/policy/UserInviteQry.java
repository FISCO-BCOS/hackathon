

package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.common.page.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author 李鑫涛
 * @date 4/14/22 11:13 AM
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserInviteQry  extends Page implements Serializable {

    /**
     *邀请人id
     */
    @ApiModelProperty(value = "邀请人id",required = true)
    private String inviterUserId;
}
