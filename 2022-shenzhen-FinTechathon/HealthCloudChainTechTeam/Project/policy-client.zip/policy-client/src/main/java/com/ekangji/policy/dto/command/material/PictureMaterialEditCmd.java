package com.ekangji.policy.dto.command.material;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.*;
import java.io.Serializable;

/**
 *
 * @author   xintao.li
 * @date   2022-07-12-01 13:00:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PictureMaterialEditCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "雪花id")
    @NotNull(message = "雪花id不能为空")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long materialId;

    /**
     * 藏品编号
     */
    @ApiModelProperty(value = "藏品编号")
    @NotBlank(message = "藏品编号或总量不符合规则，请重新填写")
    @Min(value = 0,message = "藏品编号或总量不符合规则，请重新填写")
    @Max(value = 100000,message = "藏品编号或总量不符合规则，请重新填写")
    private String collectionNumber;

    /**
     * 藏品总量
     */
    @ApiModelProperty(value = "藏品总量")
    @NotNull(message = "藏品编号或总量不符合规则，请重新填写")
    @Min(value = 0,message = "藏品编号或总量不符合规则，请重新填写数")
    @Max(value = 1000000,message = "藏品编号或总量不符合规则，请重新填写")
    private Integer totalNum;

    /**
     * 图片名称
     */
    @ApiModelProperty(value = "图片名称")
    private String pictureName;

}
