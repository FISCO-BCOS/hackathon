package com.ekangji.policy.dto.command.insurance.product;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author   李鑫涛
 * @date   2022-2-9 17:06:58
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductQry implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 公司名称
     */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /**
     * 一级产品类别
     */
    @ApiModelProperty(value = "一级产品类别")
    private String oneLevelType;

    /**
     * 二级产品类别
     */
    @ApiModelProperty(value = "二级产品类别")
    private String twoLevelType;

    /**
     * 三级产品类别
     */
    @ApiModelProperty(value = "三级产品类别")
    private String threeLevelType;

    /**
     * 四级产品类别
     */
    @ApiModelProperty(value = "四级产品类别")
    private String fourLevelType;

    /**
     * 设计类型 ProdDesiCode_00 传统型产品 ProdDesiCode_01 新型产品
     */
    @ApiModelProperty(value = "设计类型")
    private String designType;

    /**
     * 产品特殊属性 00 航空意外险 01 学生平安险 02 女性专属产品 03 少儿专属产品 04 老年专属产品
     */
    @ApiModelProperty(value = "产品特殊属性")
    private String productSpecial;

    /**
     * 保期类型 00 短期（一年及一年以下）01 长期（超过一年或含有保证续保条款）
     */
    @ApiModelProperty(value = "保期类型")
    private String timeType;

    /**
     * 条款编码
     */
    @ApiModelProperty(value = "条款编码")
    private String clauseCode;

    /**
     * 条款文件名
     */
    @ApiModelProperty(value = "条款文件名")
    private String clauseFileName;

    /**
     * 承保方式 00 团队 01 个人
     */
    @ApiModelProperty(value = "承保方式")
    private String insuranceStyle;

    /**
     * 交费方式 00 一次性缴费 01 分起交费 02 分期交费一次性交费兼有 03灵活交费
     */
    @ApiModelProperty(value = "交费方式")
    private List<String> payWays;

    /**
     * 01 在售 02 停售 03 停用
     */
    @ApiModelProperty(value = "销售状态（01 在售 02 停售 03 停用）")
    private String saleStatus;

    /**
     * 是否拆解 0 否 1是
     */
    @ApiModelProperty(value = "是否拆解 0 否 1是")
    private Integer isDismantle;


    /**
     * 是否有效 （0：无效 ，1：有效）
     */
    @ApiModelProperty(value = "是否有效（0：无效 ，1：有效）")
    private Integer status;

    /**
     * 产品条款是否关联产品信息 （1：关联，0：未关联）
     */
    @ApiModelProperty(value = "产品条款是否关联产品信息（1：关联，0：未关联）")
    private Integer associated;

}