package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductTypeVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductVO;
import com.ekangji.policy.dto.clientobject.insurance.product.ProductDismantleTemplateVO;
import com.ekangji.policy.dto.command.insurance.product.*;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 保险产品接口
 */
public interface IInsuranceProductService {

    /**
     * 列表查询
     * @param qry
     * @return
     */
    ApiResult<List<InsuranceProductVO>> queryList(InsuranceProductQry qry);

    /**
     * 分页查询
     * @param qry
     * @return
     */
    ApiResult<PageInfo<InsuranceProductVO>> queryPage(InsuranceProductPageQry qry);

    /**
     * 通过ID查询
     * @param qry
     * @return
     */
    ApiResult<InsuranceProductVO> queryById(InsuranceProductByIdQry qry);

    /**
     * 获取保司产品列表
     * @param qry
     * @return
     */
    ApiResult<List<InsuranceProductDropListVO>> queryDropList(InsuranceProductByCompanyIdQry qry);

    /**
     * 获取产品类型信息
     * @param qry
     * @return
     */
    ApiResult<InsuranceProductTypeVO> queryProductType(InsuranceProductTypeByProductIdQry qry);

    /**
     * 根据产品名称获取产品
     * @param qry
     * @return
     */
    List<InsuranceProductVO> listByProductName(InsuranceProductQry qry);

    /**
     * 通过productName查询
     * @param qry
     * @return
     */
    InsuranceProductVO queryByProductName(InsuranceProductQry qry);
}
