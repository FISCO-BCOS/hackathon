package com.ekangji.policy.dto.command.star;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;

@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserStarQry extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "星球ID(不传默认取当前用户的星球信息)")
    private Long starId;
}
