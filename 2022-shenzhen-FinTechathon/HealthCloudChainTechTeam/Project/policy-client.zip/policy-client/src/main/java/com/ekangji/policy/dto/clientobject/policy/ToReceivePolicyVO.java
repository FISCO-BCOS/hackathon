package com.ekangji.policy.dto.clientobject.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: liuchen
 * @Desc: 待接收保单返回
 * @Date: 2022/05/16 11:50
 */
@Data
public class ToReceivePolicyVO implements Serializable {

    @ApiModelProperty(value = "发起备份用户手机号")
    private String userPhone;

    @ApiModelProperty(value = "待接收保单数量")
    private Integer policyNum;

    @ApiModelProperty(value = "发起备份用户的userId(接收/拒绝时带回)")
    private String launchUserId;

    @ApiModelProperty(value = "是否是最后一条(1:否,0:是)")
    private Integer lastFlag;

}
