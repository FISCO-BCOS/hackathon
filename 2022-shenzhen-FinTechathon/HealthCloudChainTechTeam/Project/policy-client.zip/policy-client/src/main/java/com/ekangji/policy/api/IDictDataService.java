package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.command.dict.*;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 字典数据
 */
public interface IDictDataService {

    /**
     * 新增字典数据
     * @param cmd
     * @return
     */
    ApiResult add(DictDataAddCmd cmd);

    /**
     * 删除字典数据
     * @param cmd
     * @return
     */
    ApiResult delete(DictDataDeleteCmd cmd);

    /**
     * 编辑字典数据
     * @param cmd
     * @return
     */
    ApiResult edit(DictDataEditCmd cmd);

    /**
     * 列表查询
     * @param qry
     * @return
     */
    ApiResult<List<DictDataVO>> queryList(DictDataQry qry);

    /**
     * 分页查询
     * @param qry
     * @return
     */
    ApiResult<PageInfo<DictDataVO>> queryPage(DictDataPageQry qry);

    /**
     * 批量删除字典
     * @param cmd
     * @return
     */
    ApiResult batchDelete(DictDataBatchDeleteCmd cmd);
}
