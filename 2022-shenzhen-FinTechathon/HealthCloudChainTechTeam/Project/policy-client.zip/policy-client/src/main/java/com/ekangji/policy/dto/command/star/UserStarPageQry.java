package com.ekangji.policy.dto.command.star;

import com.ekangji.policy.common.page.Page;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * @author   liuchen
 * @date   2022-07-14 17:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserStarPageQry extends Page implements Serializable {

    @ApiModelProperty(value = "星球昵称")
    private String nickName;

    @ApiModelProperty(value = "星球领取开始日期")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startDate;

    @ApiModelProperty(value = "星球领取结束日期")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endDate;

    @ApiModelProperty(value = "用户ID")
    private String userId;

    @ApiModelProperty(value = "用户手机号")
    private String userPhone;
}
