package com.ekangji.policy.dto.command.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@ApiModel(description = "指定受益人对象")
public class PolicyBeneficiaryAddCmd implements Serializable {

    @ApiModelProperty(value = "家庭成员ID")
    @NotNull(message = "家庭成员必填")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long memberId;

    @ApiModelProperty(value = "受益比例")
    @Digits(integer = 6,fraction = 2,message = "受益比例【{6}】位数,小数部分不能超过【{fraction}】位数")
    @Range(min = 0,max = 100)
    private BigDecimal benefitRatio;
}
