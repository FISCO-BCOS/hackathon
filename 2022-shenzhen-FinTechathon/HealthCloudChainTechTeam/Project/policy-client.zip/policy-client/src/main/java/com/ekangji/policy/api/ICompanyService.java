package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyEditCmd;
import com.ekangji.policy.dto.command.insurance.company.CompanyPageQry;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 保险公司
 */
public interface ICompanyService {


    /**
     * 编辑保险公司
     * @param cmd
     * @return
     */
    ApiResult edit(CompanyEditCmd cmd);

    /**
     * 列表查询
     * @param qry
     * @return
     */
    ApiResult<List<InsuranceCompanyDropListVO>> queryList(CompanyQry qry);

    /**
     * 分页查询
     * @param qry
     * @return
     */
    ApiResult<PageInfo<InsuranceCompanyVO>> queryPage(CompanyPageQry qry);

}
