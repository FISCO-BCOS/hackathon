package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.ekangji.policy.dto.clientobject.starchain.ChainDetailVO;
import com.ekangji.policy.dto.clientobject.starchain.CommandContentVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.starchain.*;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

/**
 * 星链
 *
 */
public interface StarChainService {

    /**
     * 新增星链
     * @param cmd
     * @return
     */
    ApiResult<Long> add(StarChainAddCmd cmd);


    /**
     * 查询星链详情
     * @param qry
     * @return
     */
    ApiResult<ChainDetailVO> queryDetail(StarChainQry qry);

    /**
     * 运营后台查询星链下星球列表
     * @param qry
     * @return
     */
    ApiResult<List<StarVO>> queryChainStarList(StarChainQry qry);

    /**
     * 推荐内容
      * @param qry
     * @return
     */
    ApiResult<PageInfo<DigitalPolicyVO>> commandContent(Page qry);

    /**
     * 星链内容
     * @param qry
     * @return
     */
    ApiResult<PageInfo<DigitalPolicyVO>> chainContent(StarChainContentPageQry qry);

    /**
     * 获取领取星球积分规则
     * @return
     */
    Integer getReceiveStarJf();

    /**
     * 生成二维码
     * @return
     */
    ApiResult createIntoChainQrCode(String scene,String page,Boolean checkPath,String envVersion,Integer width);


        /**
         * 生成星链邀请海报
         * @return
         */
    ApiResult<Map<String,Object>> getPostFileIdAndJf(StarChainInvaiteCmd cmd);

    /**
     * 星链长度加一
     * @param qry
     * @return
     */
    ApiResult lengthAddOne(StarChainAddOneLengthCmd qry);

    /**
     * 星链长度每加10，加指定数量的保豆，并且增加星链长度
     * @param qry
     * @return
     */
    ApiResult addBaoDouAndLength(StarChainAddOneLengthCmd qry);
}
