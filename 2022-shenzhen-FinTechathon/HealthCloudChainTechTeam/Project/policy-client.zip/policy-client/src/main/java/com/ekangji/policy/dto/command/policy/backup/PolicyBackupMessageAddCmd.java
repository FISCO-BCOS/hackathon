package com.ekangji.policy.dto.command.policy.backup;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author liuchen
 * @Description 要备份的保单ID数组和接收人信息
 * @date 2022-06-09 10:09:30
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PolicyBackupMessageAddCmd extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "接收人手机号",required = true)
    @NotEmpty(message = "接收人手机号不能为空")
    private String receiverPhoneNumber;

    @ApiModelProperty(value = "要备份的保单ID数组",required = true)
    @NotEmpty(message = "要备份的保单ID数组不能为空")
    @Size(max = 9, message = "一次最多可选择9张保单")
    private List<Long> policyIds;
}
