package com.ekangji.policy.dto.clientobject.policy.cdetail;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberDetailVO implements Serializable {

    @ApiModelProperty(value = "成员ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long memberId;

    @ApiModelProperty(value = "真实姓名")
    private String name;

    @ApiModelProperty(value = "姓名")
    private String nickName;

    @ApiModelProperty(value = "受益比例")
    private BigDecimal benefitRatio;

   // @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @ApiModelProperty(value = "出生日期")
    private Date birthday;

    @ApiModelProperty(value = "证件类型")
    private Integer identityCardType;

    @ApiModelProperty(value = "证件号码")
    private String identityCardNumber;
}
