package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 邀请对象
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "邀请对象")
public class InviteAddCmd  implements Serializable {

    @ApiModelProperty(value = "被邀请人用户id")
    @NotNull(message = "被邀请人用户id不能为空")
    private String inviteeUserId;

    @ApiModelProperty(value = "邀请人用户id不能为空")
    @NotNull(message = "邀请人用户id不能为空")
    private String inviterUserId;
}
