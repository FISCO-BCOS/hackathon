package com.ekangji.policy.dto.command.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.models.auth.In;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 保单缴费详情编辑
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "保单编辑对象")
public class PolicyPayLabelEditCmd implements Serializable {

    @ApiModelProperty(value = "缴费标签ID")
    @NotNull(message = "缴费标签ID不能为空")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long payLabelId;

    @ApiModelProperty(value = "缴费状态(1:已缴费,0:未缴费)")
    @NotNull(message = "缴费状态必填")
    private Integer status;
}
