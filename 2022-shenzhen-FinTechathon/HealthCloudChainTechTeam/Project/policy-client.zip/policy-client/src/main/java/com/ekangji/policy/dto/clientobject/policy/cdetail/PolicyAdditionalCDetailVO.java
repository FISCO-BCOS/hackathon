package com.ekangji.policy.dto.clientobject.policy.cdetail;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyAdditionalCDetailVO implements Serializable {


    @ApiModelProperty(value = "产品ID")
    private String productId;

    @ApiModelProperty(value = "产品名称")
    private String productName;

    @ApiModelProperty(value = "保障期限")
    private Integer guaranteePeriod;

    @ApiModelProperty(value = "保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)")
    private Integer guaranteePeriodUnit;


    @ApiModelProperty(value = "缴费期间")
    private Integer payPeriod;

    @ApiModelProperty(value = "缴费期间单位(1:月 2:半年 3:年 4:至**岁)")
    private Integer payPeriodUnit;

    @ApiModelProperty(value = "单次保费")
    private BigDecimal singlePremium;


    @ApiModelProperty(value = "保障开始日")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date effectiveDate;

    @ApiModelProperty(value = "保障结束日")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date guaranteeEndDate;

    @ApiModelProperty(value = "保额(单位:万元)")
    private BigDecimal insuredAmount;

    @ApiModelProperty(value = "保额(单位:元)")
    private BigDecimal insuredAmountYuan;
}
