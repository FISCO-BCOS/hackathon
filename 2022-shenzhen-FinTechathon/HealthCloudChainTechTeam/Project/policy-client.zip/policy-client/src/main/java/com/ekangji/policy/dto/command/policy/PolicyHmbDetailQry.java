

package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author liuchen
 * @date 2022-08-12 15:13
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PolicyHmbDetailQry implements Serializable {

    @ApiModelProperty(value = "投保单号")
    private String quotationNo;

    @ApiModelProperty(value = "产品编码")
    private String productCode;

    @ApiModelProperty(value = "保费")
    private BigDecimal premium;

    @ApiModelProperty(value = "被保人名称")
    private String insuredName;

    @ApiModelProperty(value = "被保人身份证号")
    private String insuredIdNo;

    @ApiModelProperty(value = "投保人名称")
    private String name;

    @ApiModelProperty(value = "投保人身份证号")
    private String idNo;

    @ApiModelProperty(value = "投保人手机号")
    private String holderMobile;

    @ApiModelProperty(value = "订单类型 1:一期 2:二期 默认1")
    private String orderType;

}
