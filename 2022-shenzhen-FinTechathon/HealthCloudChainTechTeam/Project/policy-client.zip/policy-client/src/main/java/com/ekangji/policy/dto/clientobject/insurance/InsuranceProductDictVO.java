package com.ekangji.policy.dto.clientobject.insurance;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;


@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductDictVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @ApiModelProperty(value = "id")
    private Long id;

    /**
     * 字典类型
     */
    @ApiModelProperty(value = "dictType")
    private String dictType;

    /**
     * 字典值
     */
    @ApiModelProperty(value = "dictValue")
    private String dictValue;

    /**
     * 字典名
     */
    @ApiModelProperty(value = "dictName")
    private String dictName;

    /**
     * 父ID
     */
    @ApiModelProperty(value = "parentId")
    private Long parentId;

    /**
     * 是否是末级
     */
    @ApiModelProperty(value = "isLeaf")
    private Boolean isLeaf = true;

}