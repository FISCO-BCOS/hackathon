package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author 何帅
 * @Description 保单删除
 * @date 2022-06-02 11:20:36
 */
@Data
@ApiModel(description = "保单删除对象")
public class PolicyDeleteCmd extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "保单ID",required = true)
    @NotNull(message = "保单ID不能为空")
    private Long policyId;
}
