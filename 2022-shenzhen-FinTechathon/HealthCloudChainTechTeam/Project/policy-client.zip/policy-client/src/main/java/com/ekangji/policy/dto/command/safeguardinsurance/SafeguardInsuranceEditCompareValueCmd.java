package com.ekangji.policy.dto.command.safeguardinsurance;

import com.ekangji.policy.dto.clientobject.safeguardinsurance.SafeguardInsuranceVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author xintao.li
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class SafeguardInsuranceEditCompareValueCmd implements Serializable {

    /**
     * 父类别编码
     */
    @ApiModelProperty(value = "父类别编码")
    private String parentType;
    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    @NotNull(message = "年龄段不能为空")
    private Integer ageBracket;

    /**
     * 对比列 1：用户均值，2：中位数值，3：指定值
     */
    @ApiModelProperty(value = "对比值 1：用户均值，2：中位数值，3：指定值")
    @NotNull(message = "对比值 1：用户均值，2：中位数值，3：指定值")
    private Integer compareColumn;

    /**
     * 指定值
     */
    List<AssignValueEdit> assigns;
}
