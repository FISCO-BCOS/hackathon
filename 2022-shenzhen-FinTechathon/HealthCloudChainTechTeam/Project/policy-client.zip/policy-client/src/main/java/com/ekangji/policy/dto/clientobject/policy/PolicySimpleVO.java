package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 家庭保单列表对象 用于C端的保单列表展示

 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicySimpleVO implements Serializable {

    /**
     * 保单ID 雪花算法生成
     */
    @ApiModelProperty(value = "保单ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;

    /**
     * 保司名称
     */
    @ApiModelProperty(value = "保司名称")
    private String companyName;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 产品一级类型编号
     */
    @ApiModelProperty(value = "产品一级类型编号")
    private String productTopTypeCode;

    /**
     * 产品一级类型编号名称
     */
    @ApiModelProperty(value = "产品一级类型编号名称")
    private String productTopTypeName;

    /**
     * 投保人ID
     */
    @ApiModelProperty(value = "投保人ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyHolderId;

    /**
     * 投保人名称
     */
    @ApiModelProperty(value = "投保人名称")
    private String policyHolderName;

    /**
     * 被保人ID
     */
    @ApiModelProperty(value = "被保人ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long insurantId;

    /**
     * 被保人名称
     */
    @ApiModelProperty(value = "被保人名称")
    private String insurantName;

    /**
     * 保单生效日期
     */
    @ApiModelProperty(value = "保单生效日期")
    @JsonFormat(pattern = "yyyy.MM.dd")
    private Date effectiveDate;

    /**
     * 保障结束日期
     */
    @ApiModelProperty(value = "保障结束日期")
    @JsonFormat(pattern = "yyyy.MM.dd")
    private Date guaranteeEndDate;

    /**
     * 是否终身保障 1是0否
     */
    @ApiModelProperty(value = "是否终身保障 1是0否")
    private Integer isGuaranteeAllLife;

    /**
     * 总保费(单位:元)
     */
    @ApiModelProperty(value = "总保费(单位:元)")
    private String totalAmount;

    /**
     * 基本保额(单位:元)
     */
    @ApiModelProperty(value = "基本保额(单位:元)")
    private String basicAmount;

    /**
     * 状态 1保障中/0未在保障中
     */
    @ApiModelProperty(value = "状态 1保障中/0未在保障中")
    private Integer status;

    /**
     * 状态文本（保障中/未在保障中）
     */
    @ApiModelProperty(value = "状态文本（保障中/未在保障中）")
    private String statusDesc;

    /**
     * 保单是否来自备份 1是0否
     */
    @ApiModelProperty(value = "保单是否来自备份 1是0否")
    private Integer isFromBackup;

    /**
     * 备份人手机尾号
     */
    @ApiModelProperty(value = "备份人手机尾号")
    private String tailPhoneNumber;

    /**
     * 前端让加的 置为false就行
     */
    @ApiModelProperty
    private Boolean checked = false;


}
