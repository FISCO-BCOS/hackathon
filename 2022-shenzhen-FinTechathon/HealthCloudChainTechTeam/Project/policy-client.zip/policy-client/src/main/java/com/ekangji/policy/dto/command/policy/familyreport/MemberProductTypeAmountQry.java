package com.ekangji.policy.dto.command.policy.familyreport;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 被保人保险类别保额查询
 * @date 2022-5-16 14:30:25
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MemberProductTypeAmountQry extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "成员ID",required = true)
    @NotNull(message = "成员ID不能为空")
    private Long memberId;

    @ApiModelProperty(value = "一级类别编号")
    @NotBlank(message = "一级类别编号不能为空")
    private String productTypeCode;

}
