package com.ekangji.policy.dto.clientobject.insurance.product;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.Date;


@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class
DismantleTemplateVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 模板ID
     */
    @ApiModelProperty(value = "模板ID")
    private String templateId;

    /**
     * 模板名称
     */
    @ApiModelProperty(value = "模板名称")
    private String templateName;

    /**
     * 是否拆解完成
     */
    @ApiModelProperty(value = "是否拆解完成")
    private String finished;

    /**
     * 首次拆解时间
     */
    @ApiModelProperty(value = "首次拆解时间")
    private Date createTime;

    /**
     * 最后一次修改时间
     */
    @ApiModelProperty(value = "最后一次修改时间")
    private Date updateTime;

    /**
     * 最后一次修改人
     */
    @ApiModelProperty(value = "最后一次修改人")
    private String updateBy;

}