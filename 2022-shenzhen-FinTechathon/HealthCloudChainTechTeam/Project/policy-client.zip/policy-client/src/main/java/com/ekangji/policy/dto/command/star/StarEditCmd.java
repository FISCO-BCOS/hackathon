package com.ekangji.policy.dto.command.star;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author   liuchen
 * @date   2022-07-13 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class StarEditCmd extends LoginUserInfo implements Serializable {


    @ApiModelProperty(value = "星球ID",required = true)
    @NotNull(message = "星球ID不能为空")
    private Long starId;

    @ApiModelProperty(value = "星球昵称",required = true)
    @NotBlank(message = "星球昵称不能为空")
    private String nickName;
}
