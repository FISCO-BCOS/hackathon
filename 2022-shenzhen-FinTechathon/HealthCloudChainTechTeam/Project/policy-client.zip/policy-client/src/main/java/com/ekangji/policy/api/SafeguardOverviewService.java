package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyVO;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyEditCmd;
import com.ekangji.policy.dto.command.insurance.company.CompanyPageQry;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditCompareCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditRadarCmd;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 保障总图
 */
public interface SafeguardOverviewService {


    /**
     * 更新保障总图数据
     */
    ApiResult updateOverview();

    /**
     * 更新数据（只更新雷达图最大值）
     * @param cmd
     * @return
     */
    ApiResult updateRadarValue(List<SafeguardOverviewEditRadarCmd> cmd);

    /**
     *更新数据（更新是否显示对比列）
     * @param cmd
     * @return
     */
    ApiResult updateCompareColumn(SafeguardOverviewEditCompareCmd cmd);

    /**
     * 查询列表
     * @param qry
     * @return
     */
    ApiResult<List<SafeguardOverviewVO>> queryList(OverviewQry qry);

    /**
     *获取某年龄段的单项分对比额
     * @param qry
     * @return
     */
    ApiResult<Integer> getCompareColumn(OverviewCommonQry qry);
}
