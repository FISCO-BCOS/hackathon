package com.ekangji.policy.dto.command.policy.family;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

/**
 * @Author: liuchen
 * @Desc: 待接收保单返回
 * @Date: 2022/05/16 11:50
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserFamilyMemberEditCmd implements Serializable {

    @ApiModelProperty(value = "所属用户id")
    private String belongUserId;

    @ApiModelProperty(value = "用户昵称")
    @NotNull(message = "用户昵称不能为空")
    private String nickName;

    @ApiModelProperty(value = "成员id")
    private String memberId;

    @ApiModelProperty(value = "关系")
    @NotNull(message = "关系不能为空")
    private Integer relation;

    @ApiModelProperty(value = "真实姓名")
    private String name;

    @ApiModelProperty(value = "渠道平台")
    private Integer channelType;

    @ApiModelProperty(value = "有无社保")
    private Integer socialSecurityFlag;

    @ApiModelProperty(value = "证件类型")
    private Integer identityCardType;

    @ApiModelProperty(value = "证件号码")
    private String identityCardNumber;

    @ApiModelProperty(value = "手机号码")
    private String phoneNumber;

    @ApiModelProperty(value = "性别")
    private Integer sex;

    @ApiModelProperty(value = "出生日期")
    @NotNull(message = "出生日期不能为空")
    private String birthday;


    @ApiModelProperty(value = "照片上传后的文件id")
    private String userPhoto;

    @ApiModelProperty(value = "是否是备份 1是 0否")
    private Integer backFlag;
}
