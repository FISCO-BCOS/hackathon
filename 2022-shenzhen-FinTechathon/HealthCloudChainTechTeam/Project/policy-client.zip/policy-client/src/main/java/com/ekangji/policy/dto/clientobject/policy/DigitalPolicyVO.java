package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Desc: 数字保单
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class DigitalPolicyVO implements Serializable {


    @ApiModelProperty(value = "数字保单id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long digitalId;

    @ApiModelProperty(value = "序号")
    private String sequence;

    @ApiModelProperty(value = "存证时间")
    private Date createTime;

    @ApiModelProperty(value = "数据hash")
    private String chainAddr;

    @ApiModelProperty(value = "富媒体文字")
    private String mediaContent;

    @ApiModelProperty(value = "富媒体文件id集合 逗号分割")
    private String mediaImage;

    @ApiModelProperty(value = "保单产品名称")
    private String productName;

    @ApiModelProperty(value = "图片的文件id")
    private String fileId;

    @ApiModelProperty(value = "富媒体文件id对应的路径 逗号分割")
    private String mediaImageObjectName;

    @ApiModelProperty(value = "图片的文件id对应的路径")
    private String fileObjectName;

    @ApiModelProperty(value = "电子保单ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;

    @ApiModelProperty(value = "持有者(星球昵称)")
    private String nickName;

    @ApiModelProperty(value = "仅自己可见(1:是,0:否)")
    private Integer selfFlag;

    @ApiModelProperty(value = "是否推荐(1:推荐,0:不推荐)")
    private Integer recommendFlag;

    @ApiModelProperty(value = "状态(1:启用,0:禁用)")
    private Integer status;

    @ApiModelProperty(value = "待完善保单(1:是,0:否)")
    private Integer bePerfect;

    @ApiModelProperty(value = "提示信息")
    private String toastMsg;

    @ApiModelProperty(value = "推荐时间")
    private Date recommendTime;

    @ApiModelProperty(value = "用户id")
    private String userId;

    @ApiModelProperty(value = "用户手机号")
    private String phoneNumber;

    /**
     * 链上图片url
     */
    @ApiModelProperty(value = "链上图片url")
    private String starPictureUrl;

    /**
     * oss服务fileId
     */
    @ApiModelProperty(value = "oss服务fileId")
    private String starFileId;


    /**
     * 星球唯一序号(根据产品规则生成)
     */
    @ApiModelProperty(value = "星球唯一序号")
    private String starSequence;

    /**
     * 星球ID
     */
    @ApiModelProperty(value = "星球ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long starId;
}
