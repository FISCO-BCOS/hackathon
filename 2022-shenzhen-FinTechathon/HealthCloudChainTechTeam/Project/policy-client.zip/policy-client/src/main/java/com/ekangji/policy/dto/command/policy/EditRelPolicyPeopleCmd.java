package com.ekangji.policy.dto.command.policy;

import lombok.Data;

import java.io.Serializable;

/**
 * 查询玉惠保保单解析人员参保信息
 */

@Data
public class EditRelPolicyPeopleCmd implements Serializable {

    /**
     * 投保单号
     */
    private String quotationNo;

    /**
     * 姓名
     */
    private String name;

    /**
     * 身份证号
     */
    private String idNo;

    /**
     * 状态 0 无效 1有效
     */
    private Integer status;

    private static final long serialVersionUID = 1L;

}
