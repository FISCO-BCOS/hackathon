package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.FamilyEnsureVO;
import com.ekangji.policy.dto.command.member.FamilyEnsuredCalcCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredQry;

public interface IFamilyEnsuredInfoService {

    ApiResult<Long> calculateEnsuredScore(FamilyEnsuredCalcCmd familyEnsuredCalcCmd);

    ApiResult<FamilyEnsureVO> myFamilyEnsureDetail(MemberEnsuredQry memberEnsuredQry);
}
