package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyAdditionalVO implements Serializable {
    /**
     * 主键
     */
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 雪花ID
     */
    @JsonSerialize(using = ToStringSerializer.class)
    private Long additionalId;

    /**
     * 保单ID
     */
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品类型编号
     */
    private String productType;

    /**
     * 产品类型一级编号
     */
    private String productTopType;

    /**
     * 保障期限
     */
    private Integer guaranteePeriod;

    /**
     * 保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)
     */
    private Integer guaranteePeriodUnit;

    /**
     * 保障结束日期
     */
    private Date guaranteeEndDate;

    /**
     * 缴费期间
     */
    private Integer payPeriod;

    /**
     * 缴费期间单位(1:月 2:半年 3:年 4:至**岁)
     */
    private Integer payPeriodUnit;

    /**
     * 单次保费
     */
    private BigDecimal singlePremium;

    /**
     * 总保费
     */
    private BigDecimal totalPremium;

    /**
     * 保额(单位:元)
     */
    private BigDecimal insuredAmount;

    /**
     * 附险状态(1:保障中,0:未在保障中)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}
