
package com.ekangji.policy.dto.command.member;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 添加用户信息
 *
 * @author zhangjun
 * @date 2021/11/28 10:10
 */
@Data
public class MemberEnsuredQry implements Serializable {

    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID")
    private String userId;

}
