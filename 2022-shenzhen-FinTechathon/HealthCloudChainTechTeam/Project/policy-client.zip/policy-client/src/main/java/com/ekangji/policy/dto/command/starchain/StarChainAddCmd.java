package com.ekangji.policy.dto.command.starchain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 
 * @author   xintao.li
 * @date   2021-12-01 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class StarChainAddCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID",hidden = true)
    private String userId;

    /**
     * 星链名称
     */
    @ApiModelProperty(value = "星链名称")
    private String name;

}