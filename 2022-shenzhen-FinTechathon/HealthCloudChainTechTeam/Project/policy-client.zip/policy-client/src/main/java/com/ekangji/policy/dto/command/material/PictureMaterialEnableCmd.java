package com.ekangji.policy.dto.command.material;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author   xintao.li
 * @date   2022-07-12-01 13:00:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PictureMaterialEnableCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "雪花id")
    @NotNull(message = "雪花id不能为空")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long materialId;

    @ApiModelProperty(value = "状态(1:启用,2:禁用)")
    @NotNull(message = "状态不能为空")
    private Integer status;

}
