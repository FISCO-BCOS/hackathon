package com.ekangji.policy.dto.clientobject.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class RelPolicyPeopleVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增ID
     */
    private Long id;

    /**
     * 投保单号
     */
    @ApiModelProperty(value = "投保单号")
    private String quotationNo;

    /**
     * 姓名
     */
    @ApiModelProperty(value = "姓名")
    private String name;

    /**
     * 身份证号
     */
    @ApiModelProperty(value = "身份证号")
    private String idNo;

    /**
     * 在保单中角色 1 投保人 2 被保人
     */
    @ApiModelProperty(value = "在保单中角色 1 投保人 2 被保人")
    private Integer roleFlag;

    /**
     * 手机号
     */
    @ApiModelProperty(value = "手机号")
    private String mobile;

    /**
     * 玉惠保期数
     */
    @ApiModelProperty(value = "玉惠保期数 1 一期 2 二期 ...")
    private String stage;

    /**
     * 订单状态 0 无效 1 已支付 2 已承保
     */
    @ApiModelProperty(value = "订单状态 0 无效 1 已支付 2 已承保")
    private String orderStatus;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 最后修改者
     */
    private String updateBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 状态 0 无效 1有效
     */
    @ApiModelProperty(value = "状态 0 无效 1有效")
    private Integer status;

    /**
     * 删除表示 1 存在 0 删除
     */
    @ApiModelProperty(value = "删除表示 1 存在 0 删除")
    private Integer delFlag;


}
