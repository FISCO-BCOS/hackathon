package com.ekangji.policy.dto.command.policy.backup;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import lombok.*;

import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 待接收备份保单查询
 * @date 2022-5-16 14:30:25
 */
@Data
@NoArgsConstructor
@ToString
public class ToReceivePolicyQry extends LoginUserInfo implements Serializable {

}
