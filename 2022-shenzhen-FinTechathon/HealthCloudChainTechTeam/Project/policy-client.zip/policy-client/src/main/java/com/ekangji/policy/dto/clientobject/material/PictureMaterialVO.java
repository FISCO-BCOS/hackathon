package com.ekangji.policy.dto.clientobject.material;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 图片素材信息
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PictureMaterialVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "素材ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long materialId;

    @ApiModelProperty(value = "藏品编号")
    private String collectionNumber;

    @ApiModelProperty(value = "藏品总量")
    private Integer totalNum;

    @ApiModelProperty(value = "藏品已用量")
    private Integer usedNum;

    @ApiModelProperty(value = "图片地址ID")
    private String fileId;

    @ApiModelProperty(value = "图片名称")
    private String pictureName;

    @ApiModelProperty(value = "素材类型")
    private Integer materialType;

    @ApiModelProperty(value = "状态(1:启用,0:禁用)")
    private Integer status;

    @ApiModelProperty(value = "状态描述(1:启用,0:禁用)")
    private String statusDesc;

    @ApiModelProperty(value = "删除标识(1:正常 0:已删除)")
    private Integer delFlag;

    @ApiModelProperty(value = "上传时间")
    private Date createTime;

    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    @ApiModelProperty(value = "是否可用(1:可用,0:不可用)")
    private Integer isAvailable;

    /**
     * 是否启用过，0未启用过，1启用过
     */
    private Integer hasUsed;
}
