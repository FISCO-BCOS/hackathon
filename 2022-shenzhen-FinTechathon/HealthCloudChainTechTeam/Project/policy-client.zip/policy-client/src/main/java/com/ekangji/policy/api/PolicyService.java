package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.*;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyCDetailVO;
import com.ekangji.policy.dto.command.policy.*;

import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrAddCmd;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrPrefectCmd;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * @Desc: 保单服务
 */
public interface PolicyService {

    /**
     * 保单快速录入
     * @param cmd
     * @return
     */
    ApiResult add(PolicyAddCmd cmd);

    /**
     * 保单ocr识别录入
     * @param cmd
     * @return
     */
    ApiResult ocrAdd(PolicyOcrAddCmd cmd);

    /**
     * 保单编辑
     * @param cmd
     * @return
     */
    ApiResult edit(PolicyEditCmd cmd) throws Exception;

    /**
     * 删除保单
     * 逻辑删除 其实就是更新del_flag字段
     * @param cmd
     * @return
     */
    ApiResult logicDelete(PolicyDeleteCmd cmd);

    /**
     * 查询指定年龄段、指定险种在保障中的用户数量
     * @param qry
     * @return
     */
    Integer countUserWithGuarantee(OverviewCommonQry qry);

    /**
     * 根据年龄段和险种查询保单记录
     * @param qry
     * @return
     */
    List<PolicyVO> queryPolicyByAgeBracketAndProdType(OverviewCommonQry qry);

    /**
     * 根据条件查询出保单信息
     * @param qry
     * @return
     */
    ApiResult<PageInfo<PolicyVO>> queryPolicyPageByCondition(PolicyPageQry qry);

    /**
     * 根据家庭成员ID查询该成员保单列表
     * @param qry
     * @return
     */
    ApiResult<List<PolicySimpleVO>> queryFamilyMemberPolicyList(FamilyMemberPolicyQry qry);

    ApiResult<PolicyDetailVO> policyDetail(PolicyQry policyQry);

    /**
     * 补偿没有保司ID，产品ID，产品类别的保单数据
     * @return
     */
    ApiResult compensatePolicy();

    /**
     * C端保单详情
     * @param policyQry
     * @return
     */
    ApiResult<PolicyCDetailVO> policyCDetail(PolicyQry policyQry);

    /**
     * 统计家庭成员的保单数量及今年保费
     * @param userId
     * @param memberId
     */
    void statisticsMemberInfo(String userId,Long memberId);

    /**
     * 更新家庭成员各类保险有效保额
     * @return
     */
    ApiResult updateInsuranceAmount();

    /**
     * 根据保单id查用户id
     * @param policyId
     * @return
     */
    String getUserIdByPolicyId(Long policyId);

    /**
     * 更新单个被保人的有效保额
     * @return
     */
    void updateSingleInsuranceAmount(Long insurantId);


    /**
     * 导出excel
     *
     * @return
     */
    List<PolicyExcelExportVO> exportExcel(PolicyPageExportQry qry);

    /**
     * 备份保单处理接收或者不接收
     * @param cmd
     * @return
     */
    ApiResult policyBackupHandling(PolicyBackupMessageEditCmd cmd);

    /**
     * 标签缴费状态更新
     * @param cmd
     * @return
     */
    ApiResult updatePayLabelStatus(PolicyPayLabelEditCmd cmd);
    /**
     * 更新主险和附加险保单状态-定时任务
     * @return
     */
    ApiResult updatePolicyStatus();
    /**
     * 更新主险和附加险有效保单数和保费-定时任务
     * @return
     */
    ApiResult updatePolicyNumAndAmount();


    /**
     * 用户保单信息
     * @param qry
     * @return
     */
    ApiResult<Integer> userPolicyInfo(PolicyPageQry qry);

    /**
     * 保单简单录入
     * @param cmd
     * @return
     */
    ApiResult simpleAdd(PolicySimpleAddCmd cmd);

    /**
     * C端简单上传保单详情
     * @param policyQry
     * @return
     */
    ApiResult<PolicyCDetailVO> policyCSimpleDetail(PolicyQry policyQry);

    /**
     * 简单保单完善信息
     * @param cmd
     * @return
     */
    ApiResult simplePrefect(PolicyPrefectCmd cmd);

    /**
     * 简单保单ocr完善信息
     * @param cmd
     * @return
     */
    ApiResult simpleOcrPrefect(PolicyOcrPrefectCmd cmd);

    /**
     * 保单信息
     * @param hmbPolicyDetailQry
     * @return
     */
    ApiResult<PolicyCDetailVO> hmbPolicyDetail(PolicyHmbDetailQry hmbPolicyDetailQry);

    /**
     * 无保单时提示文案
     * @param hmbPolicyDetailQry
     * @return
     */
    ApiResult<PolicyTipsVO> hmbTips(PolicyHmbDetailQry hmbPolicyDetailQry);

    /**
     * 选择保单列表
     * @param qry
     * @return
     */
    ApiResult<PageInfo<PolicyVO>> queryChoicePolicyPage(PolicyPageQry qry);

    /**
     * 批量导入保单
     * @param cmd
     * @return
     */
    ApiResult policyImport(PolicyImportAddCmd cmd);
}
