package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: sunqh
 * @Desc: 用户邀请
 * @Date: 2022/07/16 11:50
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class UserInviteDetailVO implements Serializable {

    /**
     * 被邀请人用户id
     */
    @ApiModelProperty(value = "被邀请人用户id")
    private String inviteeUserId;

    @ApiModelProperty(value = "微信昵称")
    private String wechatName;

    @ApiModelProperty(value = "生成数字保单状态 0未生成 1已生成 2 非新用户")
    private Integer policyStatus;

    @ApiModelProperty(value = "受邀时间")
    private Date createTime;

}
