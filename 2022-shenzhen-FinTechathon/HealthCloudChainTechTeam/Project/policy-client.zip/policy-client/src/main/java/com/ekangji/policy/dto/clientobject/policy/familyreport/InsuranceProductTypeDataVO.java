package com.ekangji.policy.dto.clientobject.policy.familyreport;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: liuchen
 * @Desc: 保险子类别详细数据对象
 * @Date: 2022/05/24 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceProductTypeDataVO implements Serializable {

//    @ApiModelProperty(value = "名称类型(1:保额,2:同龄保额均值)")
//    private Integer type;
//
//    @ApiModelProperty(value = "名称(保额或同龄保额均值)")
//    private String name;
//
//    @ApiModelProperty(value = "保额")
//    private List<BigDecimal> insuredAmount;

    @ApiModelProperty(value = "类别名称")
    private String productTypeName;

    @ApiModelProperty(value = "类别code")
    private String productTypeCode;

    @ApiModelProperty(value = "类别保额")
    private BigDecimal insuredAmount;

    @ApiModelProperty(value = "保额最大值(运营后台控制)")
    private BigDecimal maxInsuredAmount;

    @ApiModelProperty(value = "前端是否显示对比值 0：不显示，1：显示(此处无用忽略，对比值使用上一级的此属性)")
    private Integer shownCompareValue;
}
