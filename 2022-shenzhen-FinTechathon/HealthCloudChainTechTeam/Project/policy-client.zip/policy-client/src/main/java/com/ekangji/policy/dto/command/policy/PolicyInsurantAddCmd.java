package com.ekangji.policy.dto.command.policy;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

@Data
@Validated
@ApiModel(description = "被保人")
public class PolicyInsurantAddCmd implements Serializable {

    @ApiModelProperty(value = "被保人ID")
    @NotNull(message = "被保人必填")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long insurantId;

//    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
//    @ApiModelProperty(value = "被保人出生日期")
//    private Date insurantBirthday;
}
