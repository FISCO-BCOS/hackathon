package com.ekangji.policy.dto.command.safeguardoverview;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author xintao.li
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class OverviewCommonQry implements Serializable {

    /**
     * 产品类别编码
     */
    @ApiModelProperty(value = "产品类别编码")
    @NotBlank(message = "产品类别编码不为空")
    private String typeCode;

    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    @NotNull(message = "年龄段不能为空")
    private Integer ageBracket;

    /**
     * 是否是顶级类别（0否，1是）
     */
    @ApiModelProperty(value = "是否是顶级类别（0否，1是）")
    @NotNull(message = "是否是顶级类别（0否，1是）")
    private Integer topLevel;

    /**
     * 状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = " 是否在保障中（0否，1是）")
    private Integer status;
}
