package com.ekangji.policy.dto.clientobject.policy.familyreport;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: liuchen
 * @Desc: 家庭报告总计信息
 * @Date: 2022/05/24 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FamilyReportTotalInfoVO implements Serializable {

    @ApiModelProperty(value = "家庭总保单数（包含未在保障中的）")
    private Integer policyNumTotal;

    @ApiModelProperty(value = "今年总保费")
    private BigDecimal premiumTotal;

}
