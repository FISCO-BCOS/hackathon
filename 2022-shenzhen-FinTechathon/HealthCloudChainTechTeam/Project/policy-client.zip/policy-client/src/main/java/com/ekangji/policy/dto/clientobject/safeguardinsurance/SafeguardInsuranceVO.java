package com.ekangji.policy.dto.clientobject.safeguardinsurance;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author 李鑫涛
 * @date 5/24/22 4:27 PM
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SafeguardInsuranceVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增id
     */
    @ApiModelProperty(value = "自增id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 保险业务id
     */
    @ApiModelProperty(value = "保险业务id")
    private String insuranceId;

    /**
     * 产品类别编码
     */
    @ApiModelProperty(value = "产品类别编码")
    private String productTypeCode;

    /**
     * 产品类别描述
     */
    @ApiModelProperty(value = "产品类别描述")
    private String productTypeDesc;

    /**
     * 父类别编码
     */
    @ApiModelProperty(value = "父类别编码")
    private String parentType;

    /**
     * 用户均值
     */
    @ApiModelProperty(value = "用户均值")
    private Integer averValue;

    /**
     * 中位数值
     */
    @ApiModelProperty(value = "自增id")
    private Integer medianValue;

    /**
     * 最小值
     */
    @ApiModelProperty(value = "最小值")
    private Integer minValue;

    /**
     * 最大值
     */
    @ApiModelProperty(value = "最大值")
    private Integer maxValue;

    /**
     * 指定值
     */
    @ApiModelProperty(value = "指定值")
    private Integer assignValue;

    /**
     * 对比列 1：用户均值，2：中位数值，3:指定值
     */
    @ApiModelProperty(value = "对比列 1：用户均值，2：中位数值，3:指定值")
    private Integer compareColumn;

    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    private Integer ageBracket;

    /**
     * 状态  0：无效 1:有效
     */
    @ApiModelProperty(value = "状态  0：无效 1:有效")
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    @ApiModelProperty(value = "逻辑删除 0：已删除 1：未删除")
    private Integer delFlag;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /**
     * 更新人
     */
    @ApiModelProperty(value = "更新人")
    private String updateBy;
}
