package com.ekangji.policy.dto.clientobject.starchain;

import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.dto.clientobject.common.CommonVO;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   xintao.li
 * @date   2022-07-11 14:55:47
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class RelStarChainVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 关联ID
     */
    @ApiModelProperty(value = "关联ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long relId;

    /**
     * 星球ID
     */
    @ApiModelProperty(value = "星球ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long starId;

    /**
     * 星链ID
     */
    @ApiModelProperty(value = "星链ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long chainId;

}