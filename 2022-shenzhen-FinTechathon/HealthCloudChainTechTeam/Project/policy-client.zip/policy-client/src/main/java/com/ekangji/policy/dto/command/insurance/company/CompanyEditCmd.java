package com.ekangji.policy.dto.command.insurance.company;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;

/**
 * 
 * @author   李鑫涛
 * @date   2022-02-09 15:37:19
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CompanyEditCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 公司ID
     */
    @ApiModelProperty(value = "公司ID")
    private String companyId;

    /**
     * 公司简称
     */
    @ApiModelProperty(value = "公司简称")
    private String companyNameShort;

    /**
     * 公司英文名
     */
    @ApiModelProperty(value = "公司英文名")
    private String companyNameEn;

    /**
     * 图标
     */
    @ApiModelProperty(value = "图标")
    private String fileId;

    /**
     * 公司类型
     */
    @ApiModelProperty(value = "公司类型")
    private String companyType;

    /**
     * 省
     */
    @ApiModelProperty(value = "省")
    private String provinceCode;

    /**
     * 市
     */
    @ApiModelProperty(value = "市")
    private String cityCode;

    /**
     * 客服电话
     */
    @ApiModelProperty(value = "客服电话")
    private String phone;

}