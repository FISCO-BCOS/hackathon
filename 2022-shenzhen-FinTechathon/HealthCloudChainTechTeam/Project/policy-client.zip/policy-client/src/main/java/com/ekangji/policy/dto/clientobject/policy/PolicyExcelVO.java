package com.ekangji.policy.dto.clientobject.policy;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.alibaba.excel.annotation.write.style.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ContentRowHeight(20)
@HeadRowHeight(20)
@ColumnWidth(20)
@HeadFontStyle(fontHeightInPoints=12)
@ContentStyle(horizontalAlignment= HorizontalAlignment.CENTER,verticalAlignment= VerticalAlignment.CENTER)
public class PolicyExcelVO implements Serializable {


    /**
     * 保单ID 雪花算法生产
     */
    @ApiModelProperty(value = "保单ID 雪花算法生产")
    @ExcelProperty(value = "保单ID", index = 0)
    @NumberFormat(value = "#")
    private Long policyId;


    @ExcelProperty(value = "所属平台", index = 1)
    @ApiModelProperty(value = "所属平台")
    private String channelName;


    /**
     * 用户id
     */
    @ApiModelProperty(value = "所属用户id",required = true)
    @ExcelProperty(value = "所属用户id", index = 2)
    private String userId;

    @ExcelProperty(value = "所属用户昵称", index = 3)
    @ApiModelProperty(value = "所属用户昵称")
    private String userNickName;

    /**
     * 用户手机号
     */
    @ApiModelProperty(value = "所属用户手机号码",required = true)
    @ExcelProperty(value = "所属用户手机号码", index = 4)
    private String phoneNumber;

    /**
     * 保司名称
     */
    @ApiModelProperty(value = "保司名称")
    @ExcelProperty(value = "保司名称", index = 5)
    private String companyName;


    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    @ExcelProperty(value = "产品名称", index = 6)
    private String productName;

    /**
     * 产品类型编号
     */
    @ApiModelProperty(value = "产品类型编号")
    @ExcelProperty(value = "产品类别", index = 7)
    private String productType;



    /**
     * 单次保费
     */
    @ApiModelProperty(value = "单次保费")
    @ExcelProperty(value = "单次保费", index =12)
    private BigDecimal singlePremium;


    /**
     * 保额(单位:元)
     */
    @ApiModelProperty(value = "保额(单位:元)")
    @ExcelProperty(value = "保额", index = 13)
    private BigDecimal insuredAmount;


    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    @ExcelProperty(value = "创建时间", index = 15)
    private Date createTime;


    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    @ExcelProperty(value = "更新时间", index = 16)
    private Date updateTime;







    /**
     * 投保人
     */
    @ApiModelProperty(value = "投保人",required = true)
    @ExcelProperty(value = "投保人", index = 8)
    private String policyHolderName;
    /**
     * 被保人
     */
    @ApiModelProperty(value = "被保人",required = true)
    @ExcelProperty(value = "被保人", index = 9)
    private String insurantName;
    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    @ExcelProperty(value = "受益人", index = 10)
    private String beneficiaryName;
    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = "保单状态（1:保障中,0:未在保障中）")
    @ExcelProperty(value = "保单状态", index = 11)
    private String policeStatusName;


    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    @ApiModelProperty(value = "创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份",required = true)
    @ExcelProperty(value = "创建方式", index = 14)
    private String sourceName;

}
