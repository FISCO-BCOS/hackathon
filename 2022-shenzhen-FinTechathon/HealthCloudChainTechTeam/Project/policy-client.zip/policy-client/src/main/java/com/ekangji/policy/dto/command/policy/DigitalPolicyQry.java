package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description c端数字保单查询
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "c端数字保单查询对象")
public class DigitalPolicyQry extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "星球ID(为空则获取当前登录用户的保单)",required = false)
    private Long starId;

    @ApiModelProperty(value = "数字保单id")
    private Long digitalId;

    @ApiModelProperty(value = "数据hash")
    private String chainAddr;
}
