package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.dict.DictTypeVO;
import com.ekangji.policy.dto.command.dict.*;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 字典类型
 */
public interface IDictTypeService {

    /**
     * 新增字典类型
     * @param cmd
     * @return
     */
    ApiResult add(DictTypeAddCmd cmd);

    /**
     * 删除字典类型
     * @param cmd
     * @return
     */
    ApiResult delete(DictTypeDeleteCmd cmd);

    /**
     * 编辑字典类型
     * @param cmd
     * @return
     */
    ApiResult edit(DictTypeEditCmd cmd);

    /**
     * 列表查询
     * @param qry
     * @return
     */
    ApiResult<List<DictTypeVO>> queryList(DictTypeQry qry);

    /**
     * 分页查询
     * @param qry
     * @return
     */
    ApiResult<PageInfo<DictTypeVO>> queryPage(DictTypePageQry qry);

    /**
     * 批量删除字典
     * @param cmd
     * @return
     */
    ApiResult batchDelete(DictTypeBatchDeleteCmd cmd);

}
