package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.MemberEnsureScoreExportVO;
import com.ekangji.policy.dto.clientobject.policy.MemberEnsureScoreVO;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.ekangji.policy.dto.command.policy.MemberEnsureScoreExportQry;
import com.ekangji.policy.dto.command.policy.family.MemberEnsureScorePageQry;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface IMemberEnsuredInfoService {

    /**
     * 根据条件查询出相关信息
     * @param qry
     * @return
     */
    ApiResult<PageInfo<MemberEnsureScoreVO>> queryPageByCondition(MemberEnsureScorePageQry qry);

    ApiResult<Long> calculateEnsuredScore(MemberEnsuredCalcCmd memberEnsuredCalcCmd);

    /**
     * 导出excel
     *
     * @return
     */
    List<MemberEnsureScoreExportVO> exportExcel(MemberEnsureScoreExportQry qry);

    ApiResult calculateTotalScore();
}
