package com.ekangji.policy.dto.command.dict;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-01 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DictDataAddCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 字典标签
     */
    @ApiModelProperty(value = "字典标签",required = true)
    @NotBlank(message = "字典标签不能为空")
    private String dictLabel;

    /**
     * 字典键值
     */
    @ApiModelProperty(value = "字典键值",required = true)
    @NotBlank(message = "字典键值不能为空")
    private String dictValue;

    /**
     * 字典类型
     */
    @ApiModelProperty(value = "字典类型",required = true)
    @NotBlank(message = "字典类型不能为空")
    private String dictType;

    /**
     * 字典排序
     */
    @ApiModelProperty(value = "字典排序")
    private Integer dictSort;

    /**
     * 样式属性（其他样式扩展）
     */
    @ApiModelProperty(value = "样式属性（其他样式扩展）")
    private String cssClass;

    /**
     * 表格回显样式
     */
    @ApiModelProperty(value = "表格回显样式")
    private String listClass;

    /**
     * 是否默认（1是 0否）
     */
    @ApiModelProperty(value = "是否默认（1是 0否）")
    private Integer isDefault;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 状态（1正常 0停用）
     */
    @ApiModelProperty(value = "状态")
    private Integer status;

}