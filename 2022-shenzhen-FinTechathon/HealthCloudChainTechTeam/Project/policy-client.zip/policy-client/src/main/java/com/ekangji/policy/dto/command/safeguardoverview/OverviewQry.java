package com.ekangji.policy.dto.command.safeguardoverview;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author xintao.li
 * @date 2022-5-16 14:30:25
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class OverviewQry implements Serializable {


    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    @NotNull(message = "年龄段不能为空")
    private Integer ageBracket;

}
