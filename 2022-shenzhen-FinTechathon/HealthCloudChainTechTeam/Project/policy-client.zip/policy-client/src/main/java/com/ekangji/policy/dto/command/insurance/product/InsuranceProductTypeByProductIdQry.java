package com.ekangji.policy.dto.command.insurance.product;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 *
 * @author   liuchen
 * @date   2022-2-9 17:06:58
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductTypeByProductIdQry implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "产品ID",required = true)
    @NotBlank(message = "产品ID不能为空")
    private String productId;

}