package com.ekangji.policy.dto.command.starchain;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-01 10:39:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RelStarChainAddCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     *星链ID
     */
    @ApiModelProperty(value = "星链ID")
    private Long chainId;


    /**
     * 星球ID
     */
    @ApiModelProperty(value = "星球ID")
    private Long starId;




}