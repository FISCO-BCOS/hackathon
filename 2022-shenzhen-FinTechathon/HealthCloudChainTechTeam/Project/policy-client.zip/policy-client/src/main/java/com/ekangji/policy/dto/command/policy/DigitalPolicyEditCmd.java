package com.ekangji.policy.dto.command.policy;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 *
 * @author liuchen
 * @Description 保单编辑
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "数字保单编辑对象")
public class DigitalPolicyEditCmd implements Serializable {

    @ApiModelProperty(value = "数字保单id")
    private Long digitalId;

    @ApiModelProperty(value = "富媒体文件id列表 逗号分割")
    private String mediaImage;

    @ApiModelProperty(value = "富媒体寄语")
    private String mediaContent;

    @ApiModelProperty(value = "0不推荐 1推荐")
    private Integer recommendFlag;

    @ApiModelProperty(value = "0禁用 1启用")
    private Integer status;

    @ApiModelProperty(value = "0都可见 1仅自己可见")
    private Integer selfFlag;
}
