
package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.command.policy.*;
import com.github.pagehelper.PageInfo;
import com.ekangji.policy.dto.command.policy.*;

import java.util.List;

/**
 * 数字保单服务
 */
public interface DigitalPolicyService {


    /**
     * 生成数字保单
     * @param digitalPolicyCmd
     * @return
     */
    ApiResult<DigitalPolicyVO> buildDigitalPolicy(DigitalPolicyCmd digitalPolicyCmd);
    /**
     * 编辑数字保单
     * @param digitalPolicyCmd
     * @return
     */
    ApiResult<Integer> editDigitalPolicy(DigitalPolicyEditCmd digitalPolicyCmd);

    /**
     * C端查询用户数字保单
     * @param qry
     * @return
     */
    ApiResult<List<DigitalPolicyVO>> queryDigitalPolicyList(DigitalPolicyQry qry);

    /**
     * C端查询用户数字保单分页
     * @param qry
     * @return
     */
    ApiResult<PageInfo<DigitalPolicyVO>> queryDigitalPolicyPage(DigitalPolicyPageQry qry);

    /**
     * 新版C端查询用户数字保单
     * @param qry
     * @return
     */
    ApiResult<List<DigitalPolicyVO>> queryDigitalPolicyListNew(DigitalPolicyQry qry);
    /**
     * 运营后台查询数字保单信息
     * @param qry
     * @return
     */
    ApiResult<DigitalPolicyVO> queryDigitalPolicy(DigitalPolicyQry qry);

    /**
     * 根据条件查询出数字保单信息
     * @param qry
     * @return
     */
    ApiResult<PageInfo<DigitalPolicyVO>> queryDigitalPolicyPageByCondition(DigitalPolicyPageQry qry);

    /**
     * 数字保单是否存在(1:存在,0:不存在)
     * @param qry
     * @return
     */
    ApiResult digitalPolicyIsExist(PolicyQry qry);

    /**
     * 统计数字保单份数
     * @param qry
     * @return
     */
    ApiResult<Integer> countDigitalNum(DigitalPolicyPageQry qry);

    /**
     * 后端查询星球数字保单
     * @param qry
     * @return
     */
    ApiResult<DigitalPolicyVO> queryManagerDigitalPolicyList(DigitalPolicyQry qry);

    /**
     * C端通过hash查询链上信息
     * @param qry
     * @return
     */
    ApiResult<DigitalPolicyVO> queryChainByHash(DigitalPolicyQry qry);
}
