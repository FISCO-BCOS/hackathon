package com.ekangji.policy.dto.command.safeguardinsurance;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 李鑫涛
 * @date 5/24/22 4:27 PM
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AssignValueEdit implements Serializable {

    private static final long serialVersionUID = 1L;


    /**
     * 产品类别编码
     */
    @ApiModelProperty(value = "产品类别编码")
    private String productTypeCode;

    /**
     * 指定值
     */
    @ApiModelProperty(value = "指定值")
    private Integer assignValue;

}
