package com.ekangji.policy.dto.command.insurance;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * 
 * @author   wjx
 * @date   2022-2-9 17:06:58
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductDictCmd implements Serializable {

    private static final long serialVersionUID = 1L;


    /**
     * 父级字典ID
     */
    @ApiModelProperty(value = "父级字典ID")
    private Long parentId;


}