package com.ekangji.policy.api;


import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberDetailVO;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberVO;
import com.ekangji.policy.dto.clientobject.policy.UserMemberRelationVO;
import com.ekangji.policy.dto.command.policy.family.UserFamilyDeleteCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyMemberEditCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyQry;

import java.util.List;

public interface UserFamilyInfoService {

    ApiResult<List<UserFamilyMemberVO>> findFamilyListByUserId(UserFamilyQry userFamilyQry);

    /**
     * 根据用户ID查所有有保单的家庭成员
     * @param userFamilyQry
     * @return
     */
    ApiResult<List<UserFamilyMemberVO>> findFamilyListWithPolicyByUserId(UserFamilyQry userFamilyQry);

    ApiResult<UserFamilyMemberDetailVO> findFamilyByMemberId(UserFamilyQry userFamilyQry);

    ApiResult<Integer> deleteFamilyMember(UserFamilyDeleteCmd userFamilyDeleteCmd);

    ApiResult<Long> maintainFamilyMember(UserFamilyMemberEditCmd userFamilyMemberEditCmd);


    /**
     * 用户关系字典
     */
    ApiResult<List<UserMemberRelationVO>> relationList();


    Long saveFamilyMember(UserFamilyMemberEditCmd userFamilyMemberEditCmd);

    ApiResult<String> generateNftPolicy(UserFamilyMemberEditCmd userFamilyMemberEditCmd);
}
