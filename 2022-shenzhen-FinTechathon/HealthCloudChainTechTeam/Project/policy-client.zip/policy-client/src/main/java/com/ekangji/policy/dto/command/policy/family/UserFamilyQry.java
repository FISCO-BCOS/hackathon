package com.ekangji.policy.dto.command.policy.family;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author heshuai
 * @Description 查询回答
 * @date 2022-02-22 14:30:25
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserFamilyQry implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "成员id")
    private Long memberId;

    @ApiModelProperty(value = "用户id")
    private String userId;

}