package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author liuchen
 * @Description 惠民保批量导入
 * @date 2022-5-18 14:30:25
 */
@Data
@ApiModel(description = "惠民保批量导入")
public class PolicyImportAddCmd extends LoginUserInfo implements Serializable {

    @ApiModelProperty(value = "惠民保保单")
    List<PolicyHmbDetailQry> importPolicy;
}
