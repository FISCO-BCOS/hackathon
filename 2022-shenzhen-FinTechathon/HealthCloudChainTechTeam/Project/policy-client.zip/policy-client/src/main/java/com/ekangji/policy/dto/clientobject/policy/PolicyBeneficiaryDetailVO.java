package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBeneficiaryDetailVO implements Serializable {

    /**
     * 受益人身份证件类型 0 身份证 1户口本 2出生证 3护照 4 军官证 5警官证 6 外国人永久居留证 7 港澳台同胞回乡证 8 外国人永久居留身份证 9港澳台居民居住证
     */
    @ApiModelProperty(value = "受益人身份证件类型")
    private Integer beneficiaryIdentityCardType;


    /**
     * 受益人身份证件类型 0 身份证 1户口本 2出生证 3护照 4 军官证 5警官证 6 外国人永久居留证 7 港澳台同胞回乡证 8 外国人永久居留身份证 9港澳台居民居住证
     */
    @ApiModelProperty(value = "受益人身份证件类型名")
    private String beneficiaryIdentityCardTypeName;


    /**
     * 受益人证件号码
     */
    @ApiModelProperty(value = "受益人证件号码")
    private String beneficiaryIdentityCardNumber;

    /**
     * 受益比例
     */
    @ApiModelProperty(value = "受益比例")
    private BigDecimal benefitRatio;

    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long beneficiaryId;
    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    private String beneficiaryName;
}
