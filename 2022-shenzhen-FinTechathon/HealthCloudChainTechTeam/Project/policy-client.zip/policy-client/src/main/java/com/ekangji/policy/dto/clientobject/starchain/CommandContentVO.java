package com.ekangji.policy.dto.clientobject.starchain;

import com.ekangji.policy.dto.clientobject.common.CommonVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author 李鑫涛
 * @date 7/12/22 10:31 AM
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class CommandContentVO extends CommonVO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 星球ID
     */
    @ApiModelProperty(value = "星球ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long starId;

    /**
     * 星球昵称(持有者)
     */
    @ApiModelProperty(value = "星球昵称(持有者)")
    private String nickName;

    /**
     * 用户ID
     */
    @ApiModelProperty(value = "用户ID")
    private String userId;

    /**
     * 数字保单id
     */
    @ApiModelProperty(value = "数字保单id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long digitalId;

    /**
     * 封面文案
     */
    @ApiModelProperty(value = "封面文案")
    private String phoneNumber;
    /**
     * 保单ID
     */
    @ApiModelProperty(value = "保单ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;

    /**
     * 保单产品名称
     */
    @ApiModelProperty(value = "保单产品名称")
    private String productName;

    /**
     * 序号id 按照产品给出的规则生成
     */
    @ApiModelProperty(value = "序号id 按照产品给出的规则生成")
    private String sequence;

    /**
     * 链上hash地址
     */
    @ApiModelProperty(value = "链上hash地址")
    private String chainAddr;

    /**
     * 对应oss上的文件ID
     */
    @ApiModelProperty(value = "对应oss上的文件ID")
    private String fileId;

    /**
     * 链上的图片的url
     */
    @ApiModelProperty(value = "链上的图片的url")
    private String pictureUrl;

    /**
     * 该数字保单上的富媒体文字
     */
    @ApiModelProperty(value = "该数字保单上的富媒体文字")
    private String mediaContent;

    /**
     * 该数字保单上的富媒体图片的文件id 多张的时候 逗号分割存储
     */
    @ApiModelProperty(value = "该数字保单上的富媒体图片的文件id 多张的时候 逗号分割存储")
    private String mediaImage;

    /**
     * 推荐时间
     */
    @ApiModelProperty(value = "推荐时间")
    private Date recommendTime;

}
