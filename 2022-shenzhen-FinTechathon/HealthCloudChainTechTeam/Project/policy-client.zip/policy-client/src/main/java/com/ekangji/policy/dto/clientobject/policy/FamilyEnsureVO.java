package com.ekangji.policy.dto.clientobject.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Desc: 待接收保单返回
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class FamilyEnsureVO implements Serializable {

    @ApiModelProperty(value = "家庭保障分")
    private Integer familyEnsureScore;

    @ApiModelProperty(value = "健康险保障分")
    private Integer healthScore;

    @ApiModelProperty(value = "人寿险保障分")
    private Integer lifeInsuranceScore;

    @ApiModelProperty(value = "意外险保障分")
    private Integer unexpectedScore;

    @ApiModelProperty(value = "年金险保障分")
    private Integer renteScore;

    @ApiModelProperty(value = "社保保障分")
    private Integer socialSecurityScore;

    @ApiModelProperty(value = "封面文案")
    private String coverTitle;

    @ApiModelProperty(value = "解读文案")
    private String readContent;


}
