package com.ekangji.policy.dto;

public class Test {
}
