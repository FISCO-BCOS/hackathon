package com.ekangji.policy.dto.command.dict;

import com.ekangji.policy.common.page.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-01 10:35:47
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DictTypePageQry extends Page implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 字典主键
     */
    @ApiModelProperty(value = "字典主键")
    private Long dictId;

    /**
     * 字典名称
     */
    @ApiModelProperty(value = "字典名称")
    private String dictName;

    /**
     * 字典类型
     */
    @ApiModelProperty(value = "字典类型")
    private String dictType;

    /**
     * 状态（1正常 0停用）
     */
    @ApiModelProperty(value = "状态（1正常 0停用）")
    private Integer status;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;
}