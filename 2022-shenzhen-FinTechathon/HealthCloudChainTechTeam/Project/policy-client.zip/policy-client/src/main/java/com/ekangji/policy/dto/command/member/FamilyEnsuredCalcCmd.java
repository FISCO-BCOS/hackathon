package com.ekangji.policy.dto.command.member;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author sunqihua
 * @Description 保障分计算
 * @date 2022-05-16 14:56:32
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class FamilyEnsuredCalcCmd implements Serializable {

    private static final long serialVersionUID = 1L;


    @ApiModelProperty(value = "用户id",required = true)
    private String  userId;


    /**
     * 健康险保障分
     */
    @ApiModelProperty(value = "健康险保障分",required = true)
    private Integer healthScore;

    /**
     * 人寿险保障分
     */
    @ApiModelProperty(value = "人寿险保障分",required = true)
    private Integer lifeInsuranceScore;

    /**
     * 意外险保障分
     */
    @ApiModelProperty(value = "意外险保障分",required = true)
    private Integer unexpectedScore;

    /**
     * 年金险保障分
     */
    @ApiModelProperty(value = "年金险保障分",required = true)
    private Integer renteScore;

    /**
     * 社保保障分
     */
    @ApiModelProperty(value = "社保保障分",required = true)
    private Integer socialSecurityScore;

    /**
     * 家庭保障总得分
     */
    @ApiModelProperty(value = "家庭保障总得分",required = true)
    private Integer familyTotalScore;

}