package com.ekangji.policy.dto.command.material;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author   xintao.li
 * @date   2022-07-12-01 13:00:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PictureMaterialDeleteCmd implements Serializable {

    private static final long serialVersionUID = 1L;


    /**
     * 雪花ID
     */
    @ApiModelProperty(value = "雪花ID")
    @JsonSerialize(using = ToStringSerializer.class)
    @NotNull(message = "雪花ID不能为空")
    private Long materialId;

}
