
package com.ekangji.policy.dto.command.policy;

import com.ekangji.policy.common.page.Page;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

/**
 * @author 李鑫涛
 * @date 4/14/22 11:13 AM
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PolicyPageQry extends Page implements Serializable {

    /**
     * 用户手机号
     */
    @ApiModelProperty(value = "手机号码",required = true)
    @Pattern(regexp = "^[1][3,4,5,6,7,8,9][0-9]{9}$", message = "手机号格式有误")
    private String phoneNumber;


    /**
     * 用户id
     */
    @ApiModelProperty(value = "用户id",required = true)
    private String userId;
    /**
     * 保单id
     */
    @ApiModelProperty(value = "保单id",required = true)
    private String policyId;

    /**
     * 保险公司
     */
    @ApiModelProperty(value = "保险公司",required = true)
    private String companyName;
    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称",required = true)
    private String productName;
    /**
     * 产品类别
     */
    @ApiModelProperty(value = "产品类别",required = true)
    private String productType;
    /**
     * 所属渠道平台
     */
    @ApiModelProperty(value = "所属渠道平台",required = true)
    private Integer channelType;

    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    @ApiModelProperty(value = "创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份",required = true)
    private Integer sourceType;


    /**
     *保单创建时间开始时间
     */
    @ApiModelProperty(value = "保单创建时间开始时间",required = true)
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date policyCreateTimeStart;

    /**
     *保单创建时间结束时间
     */
    @ApiModelProperty(value = "保单创建时间结束时间",required = true)
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date policyCreateTimeEnd;

    /**
     *保单更新时间开始时间
     */
    @ApiModelProperty(value = "保单更新时间开始时间",required = true)
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date policyUpdateTimeStart;

    /**
     *保单更新时间结束时间
     */
    @ApiModelProperty(value = "保单更新时间结束时间",required = true)
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
    private Date policyUpdateTimeEnd;


    /**
     * 一级类别
     */
    @ApiModelProperty(value = "一级类别",required = true)
    private String oneLevelType;

    /**
     * 二级类别
     */
    @ApiModelProperty(value = "二级类别",required = true)
    private String twoLevelType;

    /**
     * 三级类别
     */
    @ApiModelProperty(value = "三级类别",required = true)
    private String threeLevelType;

    /**
     * 四级类别
     */
    @ApiModelProperty(value = "四级类别",required = true)
    private String fourLevelType;
}
