package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: liuchen
 * @Date: 2022/05/18 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SafeguardOverviewVO implements Serializable {

    /**
     * 自增id
     */
    @ApiModelProperty(value = "自增id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 保障总图业务id
     */
    @ApiModelProperty(value = "保障总图业务id")
    private String overviewId;

    /**
     * 一级类别编码
     */
    @ApiModelProperty(value = "一级类别编码")
    private String oneLevelTypeCode;

    /**
     * 一级类别描述
     */
    @ApiModelProperty(value = "一级类别描述")
    private String oneLevelTypeDesc;

    /**
     * 一级类别对应小程序名称
     */
    @ApiModelProperty(value = "一级类别对应小程序名称")
    private String oneLevelTypeAlias;

    /**
     * 用户均值
     */
    @ApiModelProperty(value = "用户均值")
    private Integer averValue;

    /**
     * 中位数值
     */
    @ApiModelProperty(value = "中位数值")
    private Integer medianValue;

    /**
     * 最小值
     */
    @ApiModelProperty(value = "最小值")
    private Integer minValue;

    /**
     * 最大值
     */
    @ApiModelProperty(value = "最大值")
    private Integer maxValue;

    /**
     * 对比值
     */
    @ApiModelProperty(value = "对比值")
    private Integer compareValue;

    /**
     * 前端是否显示对比值 0：不显示，1：显示
     */
    @ApiModelProperty(value = "前端是否显示对比值 0：不显示，1：显示")
    private Integer shownCompareValue;

    /**
     * 雷达图最大值
     */
    @ApiModelProperty(value = "雷达图最大值")
    private Integer radarMapMaxValue;

    /**
     * 年龄段
     */
    @ApiModelProperty(value = "年龄段")
    private Integer ageBracket;

    /**
     * 状态  0：无效 1:有效
     */
    @ApiModelProperty(value = "状态")
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    @ApiModelProperty(value = "逻辑删除")
    private Integer delFlag;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /**
     * 更新人
     */
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    private static final long serialVersionUID = 1L;
}
