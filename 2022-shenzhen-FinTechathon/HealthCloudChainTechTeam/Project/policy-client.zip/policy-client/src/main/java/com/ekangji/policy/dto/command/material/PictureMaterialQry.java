package com.ekangji.policy.dto.command.material;

import com.ekangji.policy.dto.command.user.LoginUserInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author   liuchen
 * @date   2022-07-12-01 13:00:23
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PictureMaterialQry extends LoginUserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "素材类型(1:星球图片,2:保单图片)")
    @NotNull(message = "素材类型参数不能为空")
    @Range(min = 1,max = 100,message = "素材类型参数错误")
    private Integer materialType;
}
