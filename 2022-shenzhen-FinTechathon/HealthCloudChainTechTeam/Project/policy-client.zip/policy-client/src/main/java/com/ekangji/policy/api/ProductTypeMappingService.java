package com.ekangji.policy.api;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 产品类型映射
 *
 */
public interface ProductTypeMappingService {


    /**
     * 查出所有一级类别
     * @return
     */
    List<ProductTypeMappingVO> listOneLevel();

    /**
     * 根据父类查出所有子类别
     * @return
     */
    ApiResult<List<ProductTypeMappingVO>> listChildrenByParentCode(ParentCodeQry qry);

    /**
     * 分页查询
     * @param qry
     * @return
     */
//    ApiResult<PageInfo<ProductTypeMappingVO>> queryPage(DictDataPageQry qry);

}
