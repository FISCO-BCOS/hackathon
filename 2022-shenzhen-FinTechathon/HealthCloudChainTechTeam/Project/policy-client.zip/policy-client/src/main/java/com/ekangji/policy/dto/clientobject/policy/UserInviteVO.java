package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Author: sunqh
 * @Desc: 用户邀请
 * @Date: 2022/07/16 11:50
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class UserInviteVO implements Serializable {


    @ApiModelProperty(value = "邀请数量")
    private Integer inviteCount;

    @ApiModelProperty(value = "增加的抽奖次数")
    private Long DrawCount;

    @ApiModelProperty(value = "规则标题")
    private String ruleTitle;

    @ApiModelProperty(value = "规则内容")
    private String ruleContent;
}
