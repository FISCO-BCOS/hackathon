package com.ekangji.policy.dto.command.policy.family;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 
 * @author heshuai
 * @Description 删除标签
 * @date 2022-02-19 11:04:09
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserFamilyDeleteCmd implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "成员id")
    @NotNull(message = "成员id不能为空")
    private String memberId;

}