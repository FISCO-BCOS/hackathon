package com.ekangji.policy.dto.clientobject.policy;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Desc: 待接收保单返回
 */
@Data
public class EnsuredWeightConfigVO implements Serializable {


    @ApiModelProperty(value = "主键id")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    @ApiModelProperty(value = "'一级产品类别'")
    private String oneLevelType;

    @ApiModelProperty(value = "'一级产品类别名称'")
    private String firstLevelName;

    @ApiModelProperty(value = "''一级类别对应的小程序名字''")
    private String programName;

    @ApiModelProperty(value = "'0-18岁权重值'")
    private BigDecimal firstStage;

    @ApiModelProperty(value = "'18-25岁权重值'")
    private BigDecimal secondStage;

    @ApiModelProperty(value = "'25-35岁权重值'")
    private BigDecimal thirdStage;

    @ApiModelProperty(value = "'35-50岁权重值'")
    private BigDecimal fourthStage;


    @ApiModelProperty(value = "''50岁以上权重值''")
    private BigDecimal fifthStage;
}
