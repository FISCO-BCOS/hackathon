package com.ekangji.policy.dto.command.user;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 
 * @author liuchen
 * @Description 当前登录用户 查询对象
 * @date 2022-05-16 13:52:04
 */
@Data
public class LoginUserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 当前用户ID 由userToken解析得到 不暴露给前端
     */
    @ApiModelProperty(hidden = true)
    private String userId;

    /**
     * 当前用户所属渠道 由userToken解析得到 不暴露给前端
     */
    @ApiModelProperty(hidden = true)
    private Integer channelType;

}