package com.ekangji.policy.dto.clientobject.policy;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.NumberFormat;
import com.alibaba.excel.annotation.write.style.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyVO implements Serializable {

    /**
     * 主键
     */
    @ApiModelProperty(value = "主键")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 保单ID 雪花算法生产
     */
    @ApiModelProperty(value = "保单ID 雪花算法生产")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyId;

    /**
     * 所属平台(1:微信小程序，2:抖音小程序)
     */
    @ApiModelProperty(value = "所属平台(1:微信小程序，2:抖音小程序)")
    private Integer platform;

    /**
     * 来源类型(1:OCR 2:快速录入 3:邮箱识别 4:备份 5:授权)
     */
    @ApiModelProperty(value = "来源类型(1:OCR 2:快速录入 3:邮箱识别 4:备份 5:授权)")
    private Integer sourceType;

    /**
     * 保单号
     */
    @ApiModelProperty(value = "保单号")
    private String policyNumber;

    /**
     * 保司ID
     */
    @ApiModelProperty(value = "保司ID")
    private String companyId;

    /**
     * 保司名称
     */
    @ApiModelProperty(value = "保司名称")
    private String companyName;

    /**
     * 产品ID
     */
    @ApiModelProperty(value = "产品ID")
    private String productId;

    /**
     * 产品名称
     */
    @ApiModelProperty(value = "产品名称")
    private String productName;

    /**
     * 产品类型编号
     */
    @ApiModelProperty(value = "产品类型编号")
    private String productType;

    /**
     * 产品类型名称
     */
    @ApiModelProperty(value = "产品类型名称")
    private String productTypeName;
    /**
     * 产品一级类型编号
     */
    @ApiModelProperty(value = "产品一级类型编号")
    private String productTopType;

    /**
     * 投保人ID
     */
    @ApiModelProperty(value = "投保人ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long policyHolderId;

    /**
     * 被保人ID
     */
    @ApiModelProperty(value = "被保人ID")
    @JsonSerialize(using = ToStringSerializer.class)
    private Long insurantId;

    /**
     * 受益人类型(1:法定收益人,2:指定收益人)
     */
    @ApiModelProperty(value = "受益人类型(1:法定收益人,2:指定收益人)")
    private Integer beneficiaryType;

    /**
     * 保单生效日期
     */
    @ApiModelProperty(value = "保单生效日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date effectiveDate;

    /**
     * 保障期限
     */
    @ApiModelProperty(value = "保障期限")
    private Integer guaranteePeriod;

    /**
     * 保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)
     */
    @ApiModelProperty(value = "保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)")
    private Integer guaranteePeriodUnit;

    /**
     * 保障结束日期
     */
    @ApiModelProperty(value = "保障结束日期")
    private Date guaranteeEndDate;

    /**
     * 缴费周期(1:月缴,2:半年缴,3:年缴,4:一次性交清)
     */
    @ApiModelProperty(value = "缴费周期(1:月缴,2:半年缴,3:年缴,4:一次性交清)")
    private Integer payCycle;

    /**
     * 缴费期间
     */
    @ApiModelProperty(value = "缴费期间")
    private Integer payPeriod;

    /**
     * 缴费期间单位(1:月缴 2:半年缴 3:年缴 4:至**岁)
     */
    @ApiModelProperty(value = "缴费期间单位(1:月缴 2:半年缴 3:年缴 4:至**岁)")
    private Integer payPeriodUnit;

    /**
     * 单次保费
     */
    @ApiModelProperty(value = "单次保费")
    private BigDecimal singlePremium;

    /**
     * 总保费
     */
    @ApiModelProperty(value = "总保费")
    private BigDecimal totalPremium;

    /**
     * 被保人出生日期
     */
    @ApiModelProperty(value = "被保人出生日期")
    private Date insurantBirthday;

    /**
     * 保额(单位:元)
     */
    @ApiModelProperty(value = "保额(单位:元)")
    private BigDecimal insuredAmount;

    /**
     * 缴费卡号
     */
    @ApiModelProperty(value = "缴费卡号")
    private String payCardNumber;

    /**
     * 开户行
     */
    @ApiModelProperty(value = "开户行")
    private String bankName;

    /**
     * 经办人
     */
    @ApiModelProperty(value = "经办人")
    private String handler;

    /**
     * 经办人手机号
     */
    @ApiModelProperty(value = "经办人手机号")
    private String handlerPhone;

    /**
     * 备注
     */
    @ApiModelProperty(value = "备注")
    private String remark;

    /**
     * 状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = "状态（1:保障中,0:未在保障中）")
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    @ApiModelProperty(value = "删除标识(1:正常 0:已删除)")
    private Integer delFlag;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    /**
     * 更新人
     */
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private Date updateTime;




    /**
     * 所属渠道平台
     */
    @ApiModelProperty(value = "所属渠道平台",required = true)
    private Integer channelType;
    /**
     * 所属渠道平台名称
     */
    @ApiModelProperty(value = "所属渠道平台名称",required = true)
    private String channelName;



    /**
     * 用户id
     */
    @ApiModelProperty(value = "所属用户id",required = true)
    private String userId;

    @ApiModelProperty(value = "所属用户昵称")
    private String userNickName;

    /**
     * 用户手机号
     */
    @ApiModelProperty(value = "所属用户手机号码",required = true)
    private String phoneNumber;



    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long beneficiaryId;

    /**
     * 投保人
     */
    @ApiModelProperty(value = "投保人",required = true)
    private String policyHolderName;
    /**
     * 被保人
     */
    @ApiModelProperty(value = "被保人",required = true)
    private String insurantName;
    /**
     * 受益人
     */
    @ApiModelProperty(value = "受益人",required = true)
    private String beneficiaryName;
    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = "保单状态（1:保障中,0:未在保障中）")
    private Integer policyStatus;

    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    @ApiModelProperty(value = "保单状态（1:保障中,0:未在保障中）")
    private String policyStatusName;
    /**
     * 产品类型四级编号
     */
    @ApiModelProperty(value = "产品类型四级编号")
    private String productFourType;

    /**
     * 产品类型三级编号
     */
    @ApiModelProperty(value = "产品类型三级编号")
    private String productThreeType;

    /**
     * 产品类型二级编号
     */
    @ApiModelProperty(value = "产品类型二级编号")
    private String productTwoType;
    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    @ApiModelProperty(value = "创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份",required = true)
    private String sourceName;


    /**
     * 受益人列表
     */
    @ApiModelProperty(value = "受益人列表",required = true)
    private String beneficiaryIds;

}
