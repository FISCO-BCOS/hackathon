package com.ekangji.policy.dto.clientobject.insurance;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import java.io.Serializable;



@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceCompanyDropListVO implements Serializable {
    /**
     * 公司ID
     */
    @ApiModelProperty(value = "公司ID")
    private String companyId;

    /**
     * 公司名称
     */
    @ApiModelProperty(value = "公司名称")
    private String companyName;

    /**
     * 公司简称
     */
    @ApiModelProperty(value = "公司简称")
    private String companyNameShort;
}
