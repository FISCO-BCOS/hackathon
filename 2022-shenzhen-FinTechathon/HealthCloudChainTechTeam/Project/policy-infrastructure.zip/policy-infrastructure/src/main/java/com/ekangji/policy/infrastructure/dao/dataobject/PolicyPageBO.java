package com.ekangji.policy.infrastructure.dao.dataobject;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 18:01:14
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicyPageBO implements Serializable {


    /**
     * 主键
     */
    private Long id;

    /**
     * 保单ID 雪花算法生产
     */
    private Long policyId;
    /**
     * 所属渠道平台
     */
    private Integer channelType;
    /**
     * 所属渠道平台名称
     */
    private String channelName;



    /**
     * 用户id
     */
    private String userId;


    /**
     * 用户手机号
     */
    private String phoneNumber;


    /**
     * 保险公司
     */
    private String companyName;
    /**
     * 产品名称
     */
    private String productName;
    /**
     * 产品类别
     */
    private String productType;
    /**
     * 产品类型四级编号
     */
    private String productFourType;

    /**
     * 产品类型三级编号
     */
    private String productThreeType;

    /**
     * 产品类型二级编号
     */
    private String productTwoType;
    /**
     * 产品类型一级编号
     */
    private String productTopType;
    /**
     * 投保人
     */
    private Long policyHolderId;
    /**
     * 被保人
     */
    private Long insurantId;
    /**
     * 受益人
     */
    private Long beneficiaryId;

    /**
     * 投保人
     */
    private String policyHolderName;
    /**
     * 被保人
     */
    private String insurantName;
    /**
     * 受益人
     */
    private String beneficiaryName;
    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    private Integer policyStatus;

    /**
     * 保单状态（1:保障中,0:未在保障中）
     */
    private String policeStatusName;
    /**
     * 保费
     */
    private BigDecimal singlePremium;
    /**
     * 保额
     */
    private BigDecimal insuredAmount;


    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    private Integer sourceType;


    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    private String sourceName;
    /**
     * 创建时间
     */
    private Date createTime;


    /**
     * 最后一次更新时间
     */
    private Date updateTime;

    private String beneficiaryIds;

    /**
     * 生效时间
     */
    private Date effectiveDate;
}