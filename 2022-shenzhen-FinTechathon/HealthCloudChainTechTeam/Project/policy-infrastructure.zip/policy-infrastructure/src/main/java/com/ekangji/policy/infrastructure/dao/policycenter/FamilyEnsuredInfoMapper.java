package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface FamilyEnsuredInfoMapper {
    long countByExample(FamilyEnsuredInfoDOExample example);

    int deleteByExample(FamilyEnsuredInfoDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(FamilyEnsuredInfoDO record);

    int insertSelective(FamilyEnsuredInfoDO record);

    List<FamilyEnsuredInfoDO> selectByExampleWithRowbounds(FamilyEnsuredInfoDOExample example, RowBounds rowBounds);

    List<FamilyEnsuredInfoDO> selectByExample(FamilyEnsuredInfoDOExample example);

    FamilyEnsuredInfoDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") FamilyEnsuredInfoDO record, @Param("example") FamilyEnsuredInfoDOExample example);

    int updateByExample(@Param("record") FamilyEnsuredInfoDO record, @Param("example") FamilyEnsuredInfoDOExample example);

    int updateByPrimaryKeySelective(FamilyEnsuredInfoDO record);

    int updateByPrimaryKey(FamilyEnsuredInfoDO record);

    int batchInsert(@Param("list") List<FamilyEnsuredInfoDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<FamilyEnsuredInfoDO> recordList);

    FamilyEnsuredInfoDO selectOneByExample(FamilyEnsuredInfoDOExample example);

    FamilyEnsuredInfoDO selectFamilyByUserId(String userId);
}