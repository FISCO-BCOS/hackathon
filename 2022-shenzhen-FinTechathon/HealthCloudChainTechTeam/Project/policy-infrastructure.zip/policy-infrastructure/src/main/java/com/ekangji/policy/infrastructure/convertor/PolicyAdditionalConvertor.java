package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAdditionalBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAdditionalDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/18 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyAdditionalConvertor {

    PolicyAdditionalDO convert(PolicyAdditional param);

    PolicyAdditional convert(PolicyAdditionalDO param);

    List<PolicyAdditional> convert(List<PolicyAdditionalDO> param);

    PolicyAdditionalBO convert2(PolicyAdditional param);

    PolicyAdditional convert2(PolicyAdditionalBO param);

    List<PolicyAdditional> convert2(List<PolicyAdditionalBO> param);
}
