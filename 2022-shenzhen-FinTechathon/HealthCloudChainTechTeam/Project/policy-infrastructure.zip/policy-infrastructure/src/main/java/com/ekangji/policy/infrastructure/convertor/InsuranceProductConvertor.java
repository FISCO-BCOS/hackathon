package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.insurance.InsuranceProduct;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author 李鑫涛
 * @date 2022/2/15 16:50
 */
@Mapper(componentModel = "spring")
public interface InsuranceProductConvertor {

    InsuranceProductDO convert(InsuranceProduct param);

    InsuranceProduct convert(InsuranceProductDO param);

    List<InsuranceProduct> convert(List<InsuranceProductDO> param);

    PageInfo<InsuranceProduct> convert(PageInfo<InsuranceProductDO> param);

}
