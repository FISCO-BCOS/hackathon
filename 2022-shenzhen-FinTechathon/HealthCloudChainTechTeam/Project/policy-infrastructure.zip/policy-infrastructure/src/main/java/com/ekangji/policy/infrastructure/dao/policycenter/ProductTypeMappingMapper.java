package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDO;
import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface ProductTypeMappingMapper {
    long countByExample(ProductTypeMappingDOExample example);

    int deleteByExample(ProductTypeMappingDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(ProductTypeMappingDO record);

    int insertSelective(ProductTypeMappingDO record);

    List<ProductTypeMappingDO> selectByExampleWithRowbounds(ProductTypeMappingDOExample example, RowBounds rowBounds);

    List<ProductTypeMappingDO> selectByExample(ProductTypeMappingDOExample example);

    ProductTypeMappingDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") ProductTypeMappingDO record, @Param("example") ProductTypeMappingDOExample example);

    int updateByExample(@Param("record") ProductTypeMappingDO record, @Param("example") ProductTypeMappingDOExample example);

    int updateByPrimaryKeySelective(ProductTypeMappingDO record);

    int updateByPrimaryKey(ProductTypeMappingDO record);

    int batchInsert(@Param("list") List<ProductTypeMappingDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<ProductTypeMappingDO> recordList);

    ProductTypeMappingDO selectOneByExample(ProductTypeMappingDOExample example);
}