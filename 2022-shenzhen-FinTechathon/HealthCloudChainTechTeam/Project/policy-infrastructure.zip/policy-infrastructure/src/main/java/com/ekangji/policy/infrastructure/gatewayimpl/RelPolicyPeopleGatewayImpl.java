package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonIfEnum;
import com.ekangji.policy.common.enums.CustomerTypeEnum;
import com.ekangji.policy.common.enums.ProductCodeEnum;
import com.ekangji.policy.domain.gateway.RelPolicyPeopleGateway;
import com.ekangji.policy.domain.policy.RelPolicyPeople;
import com.ekangji.policy.infrastructure.convertor.RelPolicyPeopleConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.RelPolicyPeopleDO;
import com.ekangji.policy.infrastructure.dao.dataobject.RelPolicyPeopleDOExample;
import com.ekangji.policy.infrastructure.dao.primary.RelPolicyPeopleMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wjx
 * @date 2021/1/17 16:00
 */
@Repository
public class RelPolicyPeopleGatewayImpl implements RelPolicyPeopleGateway {

    @Resource
    private RelPolicyPeopleMapper relPolicyPeopleMapper;

    @Resource
    private RelPolicyPeopleConvertor relPolicyPeopleConvertor;

    @Override
    public Long save(RelPolicyPeople relPolicyPeople) {
        return null;
    }

    @Override
    public int delete(RelPolicyPeople relPolicyPeople) {
        return 0;
    }

    @Override
    public int update(RelPolicyPeople relPolicyPeople) {

        RelPolicyPeopleDO relPolicyPeopleDO = relPolicyPeopleConvertor.convert(relPolicyPeople);
        RelPolicyPeopleDOExample example = new RelPolicyPeopleDOExample();
        RelPolicyPeopleDOExample.Criteria criteria = example.createCriteria();
        criteria.andQuotationNoEqualTo(relPolicyPeople.getQuotationNo());
        criteria.andIdNoEqualTo(relPolicyPeople.getIdNo());
        return relPolicyPeopleMapper.updateByExampleSelective(relPolicyPeopleDO,example);
    }

    @Override
    public RelPolicyPeople get(RelPolicyPeople relPolicyPeople) {
        Long id = relPolicyPeople.getId();
        RelPolicyPeopleDO relPolicyPeopleDO = relPolicyPeopleMapper.selectByPrimaryKey(id);
        RelPolicyPeople convert = relPolicyPeopleConvertor.convert(relPolicyPeopleDO);
        return convert;
    }

    @Override
    public List<RelPolicyPeople> list(RelPolicyPeople relPolicyPeople) {
        List<RelPolicyPeopleDO> query = query(relPolicyPeople);
        return relPolicyPeopleConvertor.convertList(query);
    }

    @Override
    public PageInfo<RelPolicyPeople> page(RelPolicyPeople relPolicyPeople) {
        return null;
    }

    private List<RelPolicyPeopleDO> query(RelPolicyPeople relPolicyPeople) {
        RelPolicyPeopleDOExample example = new RelPolicyPeopleDOExample();
        RelPolicyPeopleDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(relPolicyPeople.getName())) {
            criteria.andNameEqualTo(relPolicyPeople.getName());
        }
        if (StringUtils.isNotBlank(relPolicyPeople.getQuotationNo())) {
            criteria.andQuotationNoEqualTo(relPolicyPeople.getQuotationNo());
        }
        if (StringUtils.isNotBlank(relPolicyPeople.getProductCode())) {
            criteria.andProductCodeEqualTo(relPolicyPeople.getProductCode());
        }
        if (StringUtils.isNotBlank(relPolicyPeople.getIdNo())) {
            criteria.andIdNoEqualTo(relPolicyPeople.getIdNo());
        }
        if (relPolicyPeople.getRoleFlag() != null) {
            criteria.andRoleFlagEqualTo(relPolicyPeople.getRoleFlag());
        }
        if (relPolicyPeople.getStatus() != null) {
            criteria.andStatusEqualTo(relPolicyPeople.getStatus());
        }
        criteria.andDelFlagEqualTo(CommonIfEnum.YES.getCode());
        return relPolicyPeopleMapper.selectByExample(example);
    }

    @Override
    public long queryInsuredInLine(Long id) {
        return relPolicyPeopleMapper.queryInsuredInLine(id);
    }

    @Override
    public long countSumLine() {
        RelPolicyPeopleDOExample example = new RelPolicyPeopleDOExample();
        example.createCriteria()
                .andRoleFlagEqualTo(Integer.valueOf(CustomerTypeEnum.INSURED.getCode()))
                .andProductCodeEqualTo(ProductCodeEnum.YHB.getCode());
        long count = relPolicyPeopleMapper.countByExample(example);
        return count;
    }
}
