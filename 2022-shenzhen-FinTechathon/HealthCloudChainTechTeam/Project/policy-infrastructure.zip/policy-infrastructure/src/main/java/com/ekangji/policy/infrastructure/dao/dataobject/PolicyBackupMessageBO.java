package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(callSuper = true)
public class PolicyBackupMessageBO extends PolicyBackupMessageDO{

    /**
     * 保单数量
     */
    private Integer policyNum;
}
