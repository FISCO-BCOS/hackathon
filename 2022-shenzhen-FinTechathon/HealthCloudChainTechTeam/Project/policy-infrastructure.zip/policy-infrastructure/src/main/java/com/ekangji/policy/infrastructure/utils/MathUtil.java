package com.ekangji.policy.infrastructure.utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 李鑫涛
 * @date 5/20/22 11:18 AM
 */
public class MathUtil {

    /**
     * 均值（向下取整）
     * @param list
     * @return
     */
    public static long aver(ArrayList<Long> list,int count) {
        int sum = 0;
        for (int i = 0; i < list.size(); i++) {
            sum += list.get(i);
        }
        return sum / count;
    }

    public static long aver(BigDecimal total, long count) {
        long longValue = total.longValue();
        return count ==0 ?0:longValue / count;
    }

    /**
     * 中位数
     * @param list
     * @return
     */
    public static long median(ArrayList<Long> list) {
        // 先排序
        List<Long> longList = list.stream().sorted().collect(Collectors.toList());
        // 如果是偶数，则为中间两个数的和除以2
        if (longList.size() % 2 == 0) {
            return ((longList.get(longList.size()/2-1) + longList.get(longList.size()/2))) / 2;
        }
        // 否则就是中间这个数
        return longList.get(longList.size()/2);
    }

    /**
     * 中位数
     * @param list
     * @return
     */
    public static long medianDecimal(List<BigDecimal> list) {
        // 先排序
        List<Long> longList = list.stream().sorted().map(v -> v.longValue()).collect(Collectors.toList());
        // 如果是偶数，则为中间两个数的和除以2
        if (longList.size() % 2 == 0) {
            return ((longList.get(longList.size()/2-1) + longList.get(longList.size()/2))) / 2;
        }
        // 否则就是中间这个数
        return longList.get(longList.size()/2);
    }

    /**
     * 最小值
     * @param list
     * @return
     */
    public static long min(List<BigDecimal> list){
        // 先排序
        List<Long> longList = list.stream().sorted().map(v -> v.longValue()).collect(Collectors.toList());
        return longList.get(0);
    }

    /**
     * 最大值
     * @param list
     * @return
     */
    public static long max(List<BigDecimal> list){
        // 先排序
        List<Long> longList = list.stream().sorted().map(v -> v.longValue()).collect(Collectors.toList());
        return longList.get(longList.size()-1);
    }
    /**
     * 获取整数的位数
     * @param num
     * @return
     */
    public static int getNumLength(long num) {
        num = num > 0 ? num : -num;
        if (num == 0) {
            return 1;
        }
        return (int) Math.log10(num) + 1;
    }

}
