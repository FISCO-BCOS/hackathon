package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.ekangji.policy.infrastructure.convertor.PolicyConvertor;
import com.ekangji.policy.infrastructure.convertor.PolicyInsurantConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyBOMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;

@Repository
public class PolicyGatewayImpl implements PolicyGateway {

    @Resource
    private PolicyConvertor policyConvertor;

    @Resource
    private PolicyInsurantConvertor policyInsurantConvertor;

    @Resource
    private PolicyBOMapper policyBOMapper;

    @Override
    public Long save(Policy entity) {
        PolicyDO policyDO = policyConvertor.convert(entity);
        policyBOMapper.insertSelective(policyDO);
        return policyDO.getPolicyId();
    }

    @Override
    public int delete(Policy entity) {
        return 0;
    }

    @Override
    public int update(Policy entity) {
        PolicyDO policyDO = policyConvertor.convert(entity);
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyDO.getPolicyId());
        return policyBOMapper.updateByExampleSelective(policyDO,example);
    }

    @Override
    public Policy get(Policy entity) {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria = example.createCriteria();
        if(Objects.nonNull(entity.getPolicyId())) {
            criteria.andPolicyIdEqualTo(entity.getPolicyId());
        }
        if(Objects.nonNull(entity.getUserId())) {
            criteria.andUserIdEqualTo(entity.getUserId());
        }
        if(Objects.nonNull(entity.getDelFlag())){
            criteria.andDelFlagEqualTo(entity.getDelFlag());
        }
        if(Objects.nonNull(entity.getStatus())){
            criteria.andStatusEqualTo(entity.getStatus());
        }
        PolicyDO policyDO = policyBOMapper.selectOneByExample(example);
        if (Objects.nonNull(policyDO)) {
            return policyConvertor.convert(policyDO);
        }
        return null;
    }

    @Override
    public List<Policy> list(Policy entity) {
        List<PolicyDO> policyDOList = this.query(entity);
        if (CollectionUtils.isNotEmpty(policyDOList)){
            return policyConvertor.convert(policyDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<Policy> page(Policy entity) {
        return null;
    }


    private List<PolicyDO> query(Policy policy) {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria = example.createCriteria();

        if(Objects.nonNull(policy.getStatus())){
            criteria.andStatusEqualTo(policy.getStatus());
        }
        if (StringUtils.isNotBlank(policy.getProductTopType())){
            criteria.andProductTopTypeEqualTo(policy.getProductTopType());
        }
        if (StringUtils.isNotBlank(policy.getProductType())){
            criteria.andProductTopTypeEqualTo(policy.getProductType());
        }
        // 根据userId查询
        if(Objects.nonNull(policy.getUserId())){
            criteria.andUserIdEqualTo(policy.getUserId());
        }
        // 根据保单ID数组查询
        if(CollectionUtils.isNotEmpty(policy.getPolicyIds())){
            criteria.andPolicyIdIn(policy.getPolicyIds());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("status desc,create_time desc");
        List<PolicyDO> policyDOList = policyBOMapper.selectByExample(example);
        return policyDOList;
    }


    @Override
    public Policy selectEntityByInsurantId(Long memberId) {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria = example.createCriteria();
        //criteria.andInsurantIdEqualTo(memberId);
        PolicyDO policyDO = policyBOMapper.selectOneByExample(example);
        if(Objects.nonNull(policyDO)){
            return policyConvertor.convert(policyDO);
        }
        return null;
    }

    @Override
    public Policy selectEntityByPolicyHolderId(Long memberId) {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyHolderIdEqualTo(memberId);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        PolicyDO policyDO = policyBOMapper.selectOneByExample(example);
        if(Objects.nonNull(policyDO)){
            return policyConvertor.convert(policyDO);
        }
        return null;
    }
    @Override
    public List<Policy> queryList(PolicyQueryDTO dto) {
        dto.setPhoneNumber(StringUtils.isBlank(dto.getPhoneNumber())?null:dto.getPhoneNumber());
        dto.setUserId(StringUtils.isBlank(dto.getUserId())?null:dto.getUserId());
        dto.setPolicyId(StringUtils.isBlank(dto.getPolicyId())?null:dto.getPolicyId());
        dto.setCompanyName(StringUtils.isBlank(dto.getCompanyName())?null:dto.getCompanyName());
        dto.setProductName(StringUtils.isBlank(dto.getProductName())?null:dto.getProductName());
        dto.setProductType(StringUtils.isBlank(dto.getProductType())?null:dto.getProductType());
        dto.setOneLevelType(StringUtils.isBlank(dto.getOneLevelType())?null:dto.getOneLevelType());
        dto.setTwoLevelType(StringUtils.isBlank(dto.getTwoLevelType())?null:dto.getTwoLevelType());
        dto.setThreeLevelType(StringUtils.isBlank(dto.getThreeLevelType())?null:dto.getThreeLevelType());
        dto.setFourLevelType(StringUtils.isBlank(dto.getFourLevelType())?null:dto.getFourLevelType());
        if(Objects.nonNull(dto.getPolicyCreateTimeEnd())) {
            /**
             * 设置结束时间为23：59：:59
             */
            Calendar end = Calendar.getInstance();
            end.setTime(dto.getPolicyCreateTimeEnd());
            end.set(Calendar.HOUR, 23);
            end.set(Calendar.MINUTE, 59);
            end.set(Calendar.SECOND, 59);
            Date endTime = end.getTime();
            dto.setPolicyCreateTimeEnd(endTime);
        }
        if(Objects.nonNull(dto.getPolicyUpdateTimeEnd())) {
            /**
             * 设置结束时间为23：59：:59
             */
            Calendar end = Calendar.getInstance();
            end.setTime(dto.getPolicyUpdateTimeEnd());
            end.set(Calendar.HOUR, 23);
            end.set(Calendar.MINUTE, 59);
            end.set(Calendar.SECOND, 59);
            Date endTime = end.getTime();
            dto.setPolicyUpdateTimeEnd(endTime);
        }
        List<PolicyPageBO> list = policyBOMapper.selectByCondition(dto);
        if (CollectionUtils.isNotEmpty(list)){
            return policyConvertor.convert2DTO(list);
        }
        return Lists.newArrayList();
    }

    @Override
    public List<Policy> selectListByPolicyIds(Long[] policyIds) {
        List<PolicyBO> policyBOList = policyBOMapper.batchGetPolicyList(policyIds);
        return policyConvertor.convert2(policyBOList);
    }

    /**
     * 删除保单后，删除其关联信息
     * @param policyId
     * @return
     */
    @Override
    public int deletePolicyLinkedData(Long policyId) {
        int addtionalDeleteResult = policyBOMapper.logicDeleteAdditionalByPolicyId(policyId);
        int insurantDeleteResult = policyBOMapper.logicDeleteInsurantByPolicyId(policyId);
        int beneficiaryDeleteResult = policyBOMapper.logicDeleteBeneficiaryByPolicyId(policyId);
        int payDetailDeleteResult = policyBOMapper.logicDeletePayDetailByPolicyId(policyId);
        int attchmentDeleteResult = policyBOMapper.logicDeleteAttchmentByPolicyId(policyId);
        return addtionalDeleteResult + insurantDeleteResult + beneficiaryDeleteResult + payDetailDeleteResult + attchmentDeleteResult;
    }

    @Override
    public int updateByPolicyId(Policy policy) {
        PolicyBO policyBO = policyConvertor.convert2(policy);
        return policyBOMapper.updateByPolicyId(policyBO);
    }

    @Override
    public PageInfo<Policy> page(PolicyQueryDTO dto) {
           return policyConvertor.convert2DTO(PageHelper.startPage(dto.getPageNum(), dto.getPageSize())
                .doSelectPageInfo(() -> this.queryList(dto)));
    }

    @Override
    public List<Policy> queryPolicyByAgeBracketAndProdType(Policy policy) {
        PolicyBO policyBO = policyConvertor.convert2(policy);
        List<PolicyBO> policyBOList = policyBOMapper.queryPolicyByAgeBracketAndProdType(policyBO);
        if (CollectionUtils.isNotEmpty(policyBOList)){
            return policyConvertor.convert2(policyBOList);
        }
        return null;
    }

    @Override
    public List<Policy> queryPolicyByUserIdAndMemberId(Policy policy) {
        PolicyBO policyBO = policyConvertor.convert2(policy);
        List<PolicyBO> policyBOList = policyBOMapper.queryPolicyByUserIdAndMemberId(policyBO);
        if (CollectionUtils.isNotEmpty(policyBOList)){
            return policyConvertor.convert2(policyBOList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public List<Policy> listCompanyIdEmpty() {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria1 = example.createCriteria();
        PolicyDOExample.Criteria criteria2 = example.createCriteria();
        criteria1.andCompanyIdIsNull();
        criteria2.andCompanyIdEqualTo("");
        criteria1.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria2.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.or(criteria2);
        List<PolicyDO> policyDOList = policyBOMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(policyDOList)){
            return policyConvertor.convert(policyDOList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public List<Policy> listProductIdEmpty() {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria1 = example.createCriteria();
        PolicyDOExample.Criteria criteria2 = example.createCriteria();
        criteria1.andProductIdIsNull();
        criteria2.andProductIdEqualTo("");
        criteria1.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria2.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.or(criteria2);
        List<PolicyDO> policyDOList = policyBOMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(policyDOList)){
            return policyConvertor.convert(policyDOList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public List<Policy> listPolicyByInsurantId(PolicyInsurant policyInsurant) {
        PolicyInsurantDO policyInsurantDO = policyInsurantConvertor.convert(policyInsurant);
        policyInsurantDO.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyBO> policyBOList = policyBOMapper.listPolicyByInsurantId(policyInsurantDO);
        if (CollectionUtils.isNotEmpty(policyBOList)){
            return policyConvertor.convert2(policyBOList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public String getUserIdByPolicyId(Long policyId) {
        PolicyDOExample example = new PolicyDOExample();
        PolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria.andPolicyIdEqualTo(policyId);
        PolicyDO policyDO = policyBOMapper.selectOneByExample(example);
        if(Objects.nonNull(policyDO)){
            return policyDO.getUserId();
        }
        return null;
    }
}
