package com.ekangji.policy.infrastructure;

public class Test {
}
