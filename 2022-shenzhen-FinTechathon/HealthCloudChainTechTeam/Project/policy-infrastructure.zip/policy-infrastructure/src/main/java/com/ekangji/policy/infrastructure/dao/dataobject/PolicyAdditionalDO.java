package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-06-16 15:20:45
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicyAdditionalDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long additionalId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品类型编号
     */
    private String productType;

    /**
     * 产品类型四级编号
     */
    private String productFourType;

    /**
     * 产品类型三级编号
     */
    private String productThreeType;

    /**
     * 产品类型二级编号
     */
    private String productTwoType;

    /**
     * 产品类型一级编号
     */
    private String productTopType;

    /**
     * 保障期限
     */
    private Integer guaranteePeriod;

    /**
     * 保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)
     */
    private Integer guaranteePeriodUnit;

    /**
     * 保障结束日期
     */
    private Date guaranteeEndDate;

    /**
     * 缴费期间
     */
    private Integer payPeriod;

    /**
     * 缴费期间单位(1:月 2:半年 3:年 4:至**岁)
     */
    private Integer payPeriodUnit;

    /**
     * 单次保费
     */
    private BigDecimal singlePremium;

    /**
     * 总保费
     */
    private BigDecimal totalPremium;

    /**
     * 保额(单位:元)
     */
    private BigDecimal insuredAmount;

    /**
     * 附险状态(1:保障中,0:未在保障中)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAdditionalId() {
        return additionalId;
    }

    public void setAdditionalId(Long additionalId) {
        this.additionalId = additionalId;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId == null ? null : productId.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType == null ? null : productType.trim();
    }

    public String getProductFourType() {
        return productFourType;
    }

    public void setProductFourType(String productFourType) {
        this.productFourType = productFourType == null ? null : productFourType.trim();
    }

    public String getProductThreeType() {
        return productThreeType;
    }

    public void setProductThreeType(String productThreeType) {
        this.productThreeType = productThreeType == null ? null : productThreeType.trim();
    }

    public String getProductTwoType() {
        return productTwoType;
    }

    public void setProductTwoType(String productTwoType) {
        this.productTwoType = productTwoType == null ? null : productTwoType.trim();
    }

    public String getProductTopType() {
        return productTopType;
    }

    public void setProductTopType(String productTopType) {
        this.productTopType = productTopType == null ? null : productTopType.trim();
    }

    public Integer getGuaranteePeriod() {
        return guaranteePeriod;
    }

    public void setGuaranteePeriod(Integer guaranteePeriod) {
        this.guaranteePeriod = guaranteePeriod;
    }

    public Integer getGuaranteePeriodUnit() {
        return guaranteePeriodUnit;
    }

    public void setGuaranteePeriodUnit(Integer guaranteePeriodUnit) {
        this.guaranteePeriodUnit = guaranteePeriodUnit;
    }

    public Date getGuaranteeEndDate() {
        return guaranteeEndDate;
    }

    public void setGuaranteeEndDate(Date guaranteeEndDate) {
        this.guaranteeEndDate = guaranteeEndDate;
    }

    public Integer getPayPeriod() {
        return payPeriod;
    }

    public void setPayPeriod(Integer payPeriod) {
        this.payPeriod = payPeriod;
    }

    public Integer getPayPeriodUnit() {
        return payPeriodUnit;
    }

    public void setPayPeriodUnit(Integer payPeriodUnit) {
        this.payPeriodUnit = payPeriodUnit;
    }

    public BigDecimal getSinglePremium() {
        return singlePremium;
    }

    public void setSinglePremium(BigDecimal singlePremium) {
        this.singlePremium = singlePremium;
    }

    public BigDecimal getTotalPremium() {
        return totalPremium;
    }

    public void setTotalPremium(BigDecimal totalPremium) {
        this.totalPremium = totalPremium;
    }

    public BigDecimal getInsuredAmount() {
        return insuredAmount;
    }

    public void setInsuredAmount(BigDecimal insuredAmount) {
        this.insuredAmount = insuredAmount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", additionalId=").append(additionalId);
        sb.append(", policyId=").append(policyId);
        sb.append(", productId=").append(productId);
        sb.append(", productName=").append(productName);
        sb.append(", productType=").append(productType);
        sb.append(", productFourType=").append(productFourType);
        sb.append(", productThreeType=").append(productThreeType);
        sb.append(", productTwoType=").append(productTwoType);
        sb.append(", productTopType=").append(productTopType);
        sb.append(", guaranteePeriod=").append(guaranteePeriod);
        sb.append(", guaranteePeriodUnit=").append(guaranteePeriodUnit);
        sb.append(", guaranteeEndDate=").append(guaranteeEndDate);
        sb.append(", payPeriod=").append(payPeriod);
        sb.append(", payPeriodUnit=").append(payPeriodUnit);
        sb.append(", singlePremium=").append(singlePremium);
        sb.append(", totalPremium=").append(totalPremium);
        sb.append(", insuredAmount=").append(insuredAmount);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private PolicyAdditionalDO obj;

        public Builder() {
            this.obj = new PolicyAdditionalDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder additionalId(Long additionalId) {
            obj.additionalId = additionalId;
            return this;
        }

        public Builder policyId(Long policyId) {
            obj.policyId = policyId;
            return this;
        }

        public Builder productId(String productId) {
            obj.productId = productId;
            return this;
        }

        public Builder productName(String productName) {
            obj.productName = productName;
            return this;
        }

        public Builder productType(String productType) {
            obj.productType = productType;
            return this;
        }

        public Builder productFourType(String productFourType) {
            obj.productFourType = productFourType;
            return this;
        }

        public Builder productThreeType(String productThreeType) {
            obj.productThreeType = productThreeType;
            return this;
        }

        public Builder productTwoType(String productTwoType) {
            obj.productTwoType = productTwoType;
            return this;
        }

        public Builder productTopType(String productTopType) {
            obj.productTopType = productTopType;
            return this;
        }

        public Builder guaranteePeriod(Integer guaranteePeriod) {
            obj.guaranteePeriod = guaranteePeriod;
            return this;
        }

        public Builder guaranteePeriodUnit(Integer guaranteePeriodUnit) {
            obj.guaranteePeriodUnit = guaranteePeriodUnit;
            return this;
        }

        public Builder guaranteeEndDate(Date guaranteeEndDate) {
            obj.guaranteeEndDate = guaranteeEndDate;
            return this;
        }

        public Builder payPeriod(Integer payPeriod) {
            obj.payPeriod = payPeriod;
            return this;
        }

        public Builder payPeriodUnit(Integer payPeriodUnit) {
            obj.payPeriodUnit = payPeriodUnit;
            return this;
        }

        public Builder singlePremium(BigDecimal singlePremium) {
            obj.singlePremium = singlePremium;
            return this;
        }

        public Builder totalPremium(BigDecimal totalPremium) {
            obj.totalPremium = totalPremium;
            return this;
        }

        public Builder insuredAmount(BigDecimal insuredAmount) {
            obj.insuredAmount = insuredAmount;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public PolicyAdditionalDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        additionalId("additional_id"),
        policyId("policy_id"),
        productId("product_id"),
        productName("product_name"),
        productType("product_type"),
        productFourType("product_four_type"),
        productThreeType("product_three_type"),
        productTwoType("product_two_type"),
        productTopType("product_top_type"),
        guaranteePeriod("guarantee_period"),
        guaranteePeriodUnit("guarantee_period_unit"),
        guaranteeEndDate("guarantee_end_date"),
        payPeriod("pay_period"),
        payPeriodUnit("pay_period_unit"),
        singlePremium("single_premium"),
        totalPremium("total_premium"),
        insuredAmount("insured_amount"),
        status("status"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}