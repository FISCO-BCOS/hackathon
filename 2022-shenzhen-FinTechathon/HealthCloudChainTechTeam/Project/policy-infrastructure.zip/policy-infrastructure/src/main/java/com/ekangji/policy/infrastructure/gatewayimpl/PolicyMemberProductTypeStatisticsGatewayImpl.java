package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.PolicyMemberProductTypeStatisticsGateway;
import com.ekangji.policy.domain.policy.PolicyMemberProductTypeStatistics;
import com.ekangji.policy.infrastructure.convertor.PolicyMemberProductTypeStatisticsConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyMemberProductTypeStatisticsBOMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyMemberProductTypeStatisticsGatewayImpl implements PolicyMemberProductTypeStatisticsGateway {

    @Resource
    private PolicyMemberProductTypeStatisticsConvertor convertor;

    @Resource
    private PolicyMemberProductTypeStatisticsBOMapper boMapper;

    @Override
    public Long save(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        PolicyMemberProductTypeStatisticsBO convert = convertor.convert(policyMemberProductTypeStatistics);
        convert.setCreateTime(new Date());
        convert.setUpdateTime(new Date());
        return (long)boMapper.insertSelective(convert);
    }

    @Override
    public int delete(PolicyMemberProductTypeStatistics pmpts) {
        PolicyMemberProductTypeStatisticsBO queryBO = convertor.convert(pmpts);
        PolicyMemberProductTypeStatisticsDOExample example = new PolicyMemberProductTypeStatisticsDOExample();
        PolicyMemberProductTypeStatisticsDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(queryBO.getMemberId())){
            criteria.andMemberIdEqualTo(queryBO.getMemberId());
        }
        return boMapper.deleteByExample(example);
    }

    @Override
    public int update(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        PolicyMemberProductTypeStatisticsBO convert = convertor.convert(policyMemberProductTypeStatistics);
        convert.setUpdateTime(new Date());
        PolicyMemberProductTypeStatisticsDOExample example = new PolicyMemberProductTypeStatisticsDOExample();
        PolicyMemberProductTypeStatisticsDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(policyMemberProductTypeStatistics.getProductType())){
            criteria.andProductTypeEqualTo(policyMemberProductTypeStatistics.getProductType());
        }
        if (Objects.nonNull(policyMemberProductTypeStatistics.getMemberId())){
            criteria.andMemberIdEqualTo(policyMemberProductTypeStatistics.getMemberId());
        }
        return boMapper.updateByExampleSelective(convert,example);
    }

    @Override
    public PolicyMemberProductTypeStatistics get(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        return null;
    }

    @Override
    public List<PolicyMemberProductTypeStatistics> list(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        return null;
    }

    @Override
    public PageInfo<PolicyMemberProductTypeStatistics> page(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        return null;
    }

    @Override
    public List<PolicyMemberProductTypeStatistics> findMemberProductTopTypeInfo(PolicyMemberProductTypeStatistics pmpts) {
        PolicyMemberProductTypeStatisticsBO queryBO = convertor.convert(pmpts);
        List<PolicyMemberProductTypeStatisticsBO> rBO = boMapper.findMemberProductTopTypeInfo(queryBO);
        if (CollectionUtils.isNotEmpty(rBO)) {
            List<PolicyMemberProductTypeStatistics> pmList = convertor.convert(rBO);
            return pmList;
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public List<PolicyMemberProductTypeStatistics> findMemberProductTypeInfo(PolicyMemberProductTypeStatistics pmpts) {
        PolicyMemberProductTypeStatisticsBO queryBO = convertor.convert(pmpts);
        List<PolicyMemberProductTypeStatisticsBO> rBO = boMapper.findMemberProductTypeInfo(queryBO);
        if (CollectionUtils.isNotEmpty(rBO)) {
            List<PolicyMemberProductTypeStatistics> pmList = convertor.convert(rBO);
            return pmList;
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public int updateTotalAmountPrimary(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        PolicyMemberProductTypeStatisticsBO convert = convertor.convert(policyMemberProductTypeStatistics);
        convert.setUpdateTime(new Date());
        return boMapper.updateTotalAmountPrimary(convert);
    }

    @Override
    public int updateTotalAmountAddition(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        PolicyMemberProductTypeStatisticsBO convert = convertor.convert(policyMemberProductTypeStatistics);
        convert.setUpdateTime(new Date());
        return boMapper.updateTotalAmountAddition(convert);
    }
}
