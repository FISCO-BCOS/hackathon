package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.AgeBracketEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyInsurantGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.infrastructure.convertor.PolicyInsurantConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyInsurantBOMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyInsurantMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.UserFamilyInfoMapper;
import com.ekangji.policy.infrastructure.utils.DateUtil;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Repository
public class PolicyInsurantGatewayImpl implements PolicyInsurantGateway {

    @Resource
    private PolicyInsurantBOMapper policyInsurantBOMapper;

    @Resource
    private UserFamilyInfoMapper userFamilyInfoMapper;

    @Resource
    private PolicyInsurantConvertor policyInsurantConvertor;

    @Override
    public Long save(PolicyInsurant policyInsurant) {
        return null;
    }

    @Override
    public int delete(PolicyInsurant policyInsurant) {
        return 0;
    }

    @Override
    public int update(PolicyInsurant policyInsurant) {
        return 0;
    }

    @Override
    public PolicyInsurant get(PolicyInsurant policyInsurant) {
        PolicyInsurantDOExample example = new PolicyInsurantDOExample();
        PolicyInsurantDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyInsurant.getPolicyId());
        PolicyInsurantDO policyDO = policyInsurantBOMapper.selectOneByExample(example);
        if (Objects.nonNull(policyDO)) {
            return policyInsurantConvertor.convert(policyDO);
        }
        return null;
    }

    @Override
    public List<PolicyInsurant> list(PolicyInsurant policyInsurant) {
        PolicyInsurantDOExample example = new PolicyInsurantDOExample();
        PolicyInsurantDOExample.Criteria criteria = example.createCriteria();
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        if(Objects.nonNull(policyInsurant.getInsurantId())){
            criteria.andInsurantIdEqualTo(policyInsurant.getInsurantId());
        }
        // 根据保单ID数组查询
        if(CollectionUtils.isNotEmpty(policyInsurant.getPolicyIds())){
            criteria.andPolicyIdIn(policyInsurant.getPolicyIds());
        }
        // 根据被保人ID数组查询
        if(CollectionUtils.isNotEmpty(policyInsurant.getInsurantIds())){
            criteria.andInsurantIdIn(policyInsurant.getInsurantIds());
        }
        List<PolicyInsurantDO> policyInsurantDOS = policyInsurantBOMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(policyInsurantDOS)){
            return policyInsurantConvertor.convertT(policyInsurantDOS);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public PageInfo<PolicyInsurant> page(PolicyInsurant policyInsurant) {
        return null;
    }

    @Override
    public int batchAdd(List<PolicyInsurant> piList) {
        List<PolicyInsurantDO> piDOList = piList.parallelStream().map(i ->{
            PolicyInsurantDO policyInsurantDO = policyInsurantConvertor.convert(i);
            return policyInsurantDO;
        }).collect(Collectors.toList());
        return policyInsurantBOMapper.batchSave(piDOList);
    }

    @Override
    public int deleteByPolicy(PolicyInsurant insurant) {
        PolicyInsurantDOExample example = new PolicyInsurantDOExample();
        PolicyInsurantDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(insurant.getPolicyId());
        return policyInsurantBOMapper.deleteByExample(example);
    }

    @Override
    public List<PolicyInsurant> findByPolicy(PolicyInsurant insurant) {
        PolicyInsurantDOExample example = new PolicyInsurantDOExample();
        PolicyInsurantDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(insurant.getPolicyId());
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyInsurantDO> piDO = policyInsurantBOMapper.selectByExample(example);
        return policyInsurantConvertor.convert(piDO);
    }

    @Override
    public List<PolicyInsurant> findByInsurantId(PolicyInsurant insurant) {
        PolicyInsurantDOExample example = new PolicyInsurantDOExample();
        PolicyInsurantDOExample.Criteria criteria = example.createCriteria();
        criteria.andInsurantIdEqualTo(insurant.getInsurantId());
//        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyInsurantDO> piDO = policyInsurantBOMapper.selectByExample(example);
        return policyInsurantConvertor.convert(piDO);
    }

    @Override
    public long countByAgeBracket(int ageBracket) {
        if (StringUtils.isBlank(AgeBracketEnum.getMsgByCode(ageBracket))){
            return 0;
        }
        //根据年龄段处理出生日期
        Date begin = null;
        Date end;
        if (Objects.equals(ageBracket, AgeBracketEnum.FIVESTEP.getCode())) {
            // 年龄在50以上的
            end = DateUtil.calBirthByAge(AgeBracketEnum.FIVESTEP.getBegin());
        } else {
            // 年龄在其他段的
            begin = DateUtil.calBirthByAge(AgeBracketEnum.getEndByCode(ageBracket));
            end = DateUtil.calBirthByAge(AgeBracketEnum.getBeginByCode(ageBracket));
        }

        Map<String, Object> map = new HashMap<>(16);
        map.put("begin",begin);
        map.put("end",end);
        long count = policyInsurantBOMapper.countByAgeBracket(map);
        return count;
    }
}
