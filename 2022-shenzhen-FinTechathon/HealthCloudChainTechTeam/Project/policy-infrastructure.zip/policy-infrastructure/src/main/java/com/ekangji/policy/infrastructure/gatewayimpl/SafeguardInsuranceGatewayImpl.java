package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.SafeguardInsuranceGateway;
import com.ekangji.policy.domain.policy.SafeguardInsurance;
import com.ekangji.policy.infrastructure.convertor.SafeguardInsuranceConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardInsuranceDO;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardInsuranceDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.SafeguardInsuranceMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author xintao.li
 * @date 2021/12/2 22:04
 */
@Repository
public class SafeguardInsuranceGatewayImpl implements SafeguardInsuranceGateway {

    @Resource
    private SafeguardInsuranceConvertor safeguardInsuranceConvertor;

    @Resource
    private SafeguardInsuranceMapper safeguardInsuranceMapper;

    @Override
    public Long save(SafeguardInsurance safeguardInsurance) {
        SafeguardInsuranceDO safeguardInsuranceDO = safeguardInsuranceConvertor.convert(safeguardInsurance);
        safeguardInsuranceMapper.insertSelective(safeguardInsuranceDO);
        return safeguardInsuranceDO.getId();
    }

    @Override
    public int delete(SafeguardInsurance safeguardInsurance) {
        return safeguardInsuranceMapper.deleteByPrimaryKey(safeguardInsurance.getId());
    }

    @Override
    public int update(SafeguardInsurance safeguardInsurance) {
        SafeguardInsuranceDO safeguardInsuranceDO = safeguardInsuranceConvertor.convert(safeguardInsurance);
        SafeguardInsuranceDOExample example = new SafeguardInsuranceDOExample();
        SafeguardInsuranceDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(safeguardInsurance.getInsuranceId())){
            criteria.andInsuranceIdEqualTo(safeguardInsurance.getInsuranceId());
        }
        if (Objects.nonNull(safeguardInsurance.getAgeBracket())){
            criteria.andAgeBracketEqualTo(safeguardInsurance.getAgeBracket());
        }
        if (StringUtils.isNotBlank(safeguardInsurance.getProductTypeCode())){
            criteria.andProductTypeCodeEqualTo(safeguardInsurance.getProductTypeCode());
        }
        if (StringUtils.isNotBlank(safeguardInsurance.getParentType())){
            criteria.andParentTypeEqualTo(safeguardInsurance.getParentType());
        }
        return safeguardInsuranceMapper.updateByExampleSelective(safeguardInsuranceDO,example);
    }

    @Override
    public SafeguardInsurance get(SafeguardInsurance safeguardInsurance) {
        List<SafeguardInsuranceDO> safeguardInsuranceDOList = this.query(safeguardInsurance);
        if (CollectionUtils.isNotEmpty(safeguardInsuranceDOList)){
            return safeguardInsuranceConvertor.convert(safeguardInsuranceDOList.get(0));
        }
        return null;
    }

    @Override
    public List<SafeguardInsurance> list(SafeguardInsurance safeguardInsurance) {
        List<SafeguardInsuranceDO> safeguardInsuranceDOList = this.query(safeguardInsurance);
        if (CollectionUtils.isNotEmpty(safeguardInsuranceDOList)){
            return safeguardInsuranceConvertor.convert(safeguardInsuranceDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<SafeguardInsurance> page(SafeguardInsurance safeguardInsurance) {
        PageHelper.startPage(safeguardInsurance.getPageNum(),safeguardInsurance.getPageSize());
        List<SafeguardInsuranceDO> safeguardInsuranceDOList = query(safeguardInsurance);
        PageInfo<SafeguardInsuranceDO> pageInfo = new PageInfo<>(safeguardInsuranceDOList);
        return safeguardInsuranceConvertor.convert(pageInfo);
    }

    private List<SafeguardInsuranceDO> query(SafeguardInsurance safeguardInsurance) {
        SafeguardInsuranceDOExample example = new SafeguardInsuranceDOExample();
        SafeguardInsuranceDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(safeguardInsurance.getStatus())){
            criteria.andStatusEqualTo(safeguardInsurance.getStatus());
        }
        if (StringUtils.isNotBlank(safeguardInsurance.getInsuranceId())){
            criteria.andInsuranceIdEqualTo(safeguardInsurance.getInsuranceId());
        }
        if (Objects.nonNull(safeguardInsurance.getAgeBracket())){
            criteria.andAgeBracketEqualTo(safeguardInsurance.getAgeBracket());
        }
        if (StringUtils.isNotBlank(safeguardInsurance.getParentType())){
            criteria.andParentTypeEqualTo(safeguardInsurance.getParentType());
        }
        return safeguardInsuranceMapper.selectByExample(example);
    }

}
