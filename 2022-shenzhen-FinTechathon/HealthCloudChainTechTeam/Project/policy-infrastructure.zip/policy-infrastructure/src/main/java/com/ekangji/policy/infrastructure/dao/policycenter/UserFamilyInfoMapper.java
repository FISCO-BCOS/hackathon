package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.UserFamilyInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserFamilyInfoDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface UserFamilyInfoMapper {
    long countByExample(UserFamilyInfoDOExample example);

    int deleteByExample(UserFamilyInfoDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserFamilyInfoDO record);

    int insertSelective(UserFamilyInfoDO record);

    List<UserFamilyInfoDO> selectByExampleWithRowbounds(UserFamilyInfoDOExample example, RowBounds rowBounds);

    List<UserFamilyInfoDO> selectByExample(UserFamilyInfoDOExample example);

    UserFamilyInfoDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserFamilyInfoDO record, @Param("example") UserFamilyInfoDOExample example);

    int updateByExample(@Param("record") UserFamilyInfoDO record, @Param("example") UserFamilyInfoDOExample example);

    int updateByPrimaryKeySelective(UserFamilyInfoDO record);

    int updateByPrimaryKey(UserFamilyInfoDO record);

    int batchInsert(@Param("list") List<UserFamilyInfoDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<UserFamilyInfoDO> recordList);

    UserFamilyInfoDO selectOneByExample(UserFamilyInfoDOExample example);

    UserFamilyInfoDO selectEntityByMemberId(Long memberId);

}