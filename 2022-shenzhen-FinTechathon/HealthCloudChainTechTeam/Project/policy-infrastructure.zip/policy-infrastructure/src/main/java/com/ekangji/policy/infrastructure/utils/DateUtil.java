package com.ekangji.policy.infrastructure.utils;

import com.ekangji.policy.common.constant.Constants;
import lombok.extern.slf4j.Slf4j;

import javax.validation.ValidationException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Slf4j
public class DateUtil {

    public static String datePattern = "yyyy-MM-dd";
    public static String datePattern_yyyyMM = "yyyy.MM";
    public static String datePattern_yyyy = "yyyy";
    public static String datetimePattern = "yyyy-MM-dd HH:mm:ss";
    public static String timePattern = "HH:mm:ss";




    /**
     * 根据生日获取年龄
     * @param birthday
     * @return
     */
    public static int getAgeByBirth(Date birthday) {
        int age = 0;
        try {
            Calendar now = Calendar.getInstance();
            now.setTime(new Date());// 当前时间

            Calendar birth = Calendar.getInstance();
            birth.setTime(birthday);

            if (birth.after(now)) {//如果传入的时间，在当前时间的后面，返回0岁
                age = 0;
            } else {
                age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
                if (now.get(Calendar.DAY_OF_YEAR) > birth.get(Calendar.DAY_OF_YEAR)) {
                    age += 1;
                }
            }
            return age;
        } catch (Exception e) {//兼容性更强,异常后返回数据
            return 0;
        }
    }


    /**
     * 根据年龄倒推生日
     * @param age
     * @return
     */
    public static Date calBirthByAge(Integer age){
        LocalDate now = LocalDate.now();
        int year = now.getYear();
        int month = now.getMonthValue();
        int day = now.getDayOfMonth();

        LocalDate of = LocalDate.of(year - age, month, day);
        ZoneId zone = ZoneId.systemDefault();
        Instant instant = of.atStartOfDay().atZone(zone).toInstant();
        return Date.from(instant);
    }


    /**
     * 比较日期大小，判断是否超越参照日期
     *
     * @param src
     * @param src
     * @return boolean; true:DATE1>DATE2;
     */
    public static int compareDate(Date src, Date src1) {
        String date1 = format(src, datePattern);
        String date2 =  format(src1, datePattern);
        DateFormat df = new SimpleDateFormat(datePattern);
        try {
            Date dt1 = df.parse(date1);
            Date dt2 = df.parse(date2);
            if (dt1.getTime() > dt2.getTime()) {
                return 1;
            } else if (dt1.getTime() < dt2.getTime()) {
                return -1;
            } else {
                return 0;
            }
        } catch (Exception e) {
            log.error("error",e);
        }
        return 0;
    }

    public static int compareTime(Date src, Date src1) {
        String date1 = format(src, datetimePattern);
        String date2 =  format(src1, datetimePattern);
        DateFormat df = new SimpleDateFormat(datetimePattern);
        try {
            Date dt1 = df.parse(date1);
            Date dt2 = df.parse(date2);
            if (dt1.getTime() > dt2.getTime()) {
                return 1;
            } else if (dt1.getTime() < dt2.getTime()) {
                return -1;
            } else {
                return 0;
            }
        } catch (Exception e) {
            log.error("error",e);
        }
        return 0;
    }

    /**
     * 返回月份和天数较大的日期
     * @param startDate
     * @param endDate
     * @return
     */
    public static Date compareMonthDayDate(Date startDate, Date endDate) {
        String date1 = format(startDate, datePattern);
        String date2 =  format(endDate, datePattern);
        date1 = date2.substring(0,4)+date1.substring(4,10);
        DateFormat df = new SimpleDateFormat(datePattern);
        try {
            Date dt1 = df.parse(date1);
            Date dt2 = df.parse(date2);
            if (dt1.getTime() > dt2.getTime()) {
               return dt1;
            } else if (dt1.getTime() < dt2.getTime()) {
                return dt2;
            } else {
                return dt2;
            }
        } catch (Exception e) {
            log.error("error",e);
        }
        return endDate;
    }

    /**
     * 转换日期得到指定格式的日期字符串
     *
     * @param formatString
     *            需要把目标日期格式化什么样子的格式。例如,yyyy-MM-dd HH:mm:ss
     * @param targetDate
     *            目标日期
     * @return
     */
    public static String convertDate2String(String formatString, Date targetDate) {
        SimpleDateFormat format = null;
        String result = null;
        if (targetDate != null) {
            format = new SimpleDateFormat(formatString);
            result = format.format(targetDate);
        } else {
            return null;
        }
        return result;
    }

    /**
     * 获取当前日期 格式:XXXX-XX-XX
     *
     * @return
     */
    public static Date getCurrDate() {
        String sdate = format(System.currentTimeMillis(), datePattern);
        return parseDate(sdate, datePattern);
    }

    public static Date getCurrTime() {
        String sdate = format(System.currentTimeMillis(), datetimePattern);
        return parseDate(sdate, datetimePattern);
    }

    public static Date parseDate(String date, String pattern) {
        try {
            return new SimpleDateFormat(pattern).parse(date);
        } catch (ParseException e) {
           log.error("error",e);
        }
        return null;
    }

    public static String format(long timestamp, String pattern) {
        return format(new Date(timestamp), pattern);
    }

    /**
     * 使用参数Format格式化Date成字符串
     */
    public static String format(Date date, String pattern) {
        return date == null ? " " : new SimpleDateFormat(pattern).format(date);
    }

    /**
     * 时间加天数
     * @param date
     * @param days
     * @return
     */
    public static Date addDays(Date date, int days) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, days);
        return c.getTime();
    }

    /**
     * 时间加月份
     * @param date
     * @param months
     * @return
     */
    public static Date addMonths(Date date, int months) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MONTH, months);
        return c.getTime();
    }

    /**
     * 时间加年数
     * @param date
     * @param years
     * @return
     */
    public static Date addYears(Date date, Integer years) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.YEAR, years);
        return c.getTime();
    }

    public static long getDateDiff(String startTime, String endTime,Integer type) {
        long diff = 0;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(datePattern);    //这里可以指定接收日期的格式
            LocalDate startDate = LocalDate.parse(startTime, formatter);
            LocalDate endDate = LocalDate.parse(endTime, formatter);
            if (type == 1) { //获取两个日期间隔月
                diff = ChronoUnit.MONTHS.between(startDate, endDate);
            } else if (type == 2) { //获取两个日期间隔天
                diff = ChronoUnit.DAYS.between(startDate, endDate);
            } else if (type == 3) { //获取两个日期间隔年
                diff = ChronoUnit.YEARS.between(startDate, endDate);
            }
        } catch (Exception e) {
            log.error("getDateDiff error",e);
        }
        return diff;
    }

    /**
     * 获取两个时间段跨度时间
     * @param startDate
     * @param endDate
     * @param type
     * @param dimension
     * @return
     */
    public static List<Date> getDateList(Date startDate,Date endDate,int type,int dimension) {
        List<Date> dateList = new ArrayList<>();
        dateList.add(startDate);
        if(compareDate(startDate,endDate) == Constants.ZERO){
            return dateList;
        }

        int step = dimension;
        while (true) {
            Date tmpDate;
            if (type == 1 || type == 2) {
                tmpDate = addMonths(startDate,step);
            } else if (type == 3) {
                tmpDate = addYears(startDate,step);
            } else {
                tmpDate = addDays(startDate,step);
            }
            if (tmpDate.before(endDate)) {
                dateList.add(tmpDate);
            } else if (tmpDate.after(endDate)) {
                dateList.add(tmpDate);
                break;
            } else {
                dateList.add(tmpDate);
                break;
            }
            step = step + dimension;
        }
       return dateList;
    }

    /**
     * 获取时间的年或年月
     * @param date
     * @param type
     * @return
     */
    public static String getDateLabel(Date date,Integer type) {
        convertDate2String(datePattern_yyyyMM,date);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        if (type == 3) {
            return String.valueOf(year);
        }
        return String.valueOf(year).concat("-").concat(String.valueOf(month));
    }

    /**
     * 返回
     * @param startdate
     * @param enddate
     * @return
     * @throws ParseException
     */
    public static int daysBetween(Date startdate,Date enddate)  {
        long begin = startdate.getTime();
        long end = enddate.getTime();
        long betweendays=(end-begin)/(1000*3600*24);
        int days = Integer.parseInt(String.valueOf(betweendays));
        return days;
    }

    /**
     * 时间转化为00:00:01秒开始
     * @param date
     * @return
     */
    public static Date convertDateStartTime(Date date)  {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 00);
        calendar.set(Calendar.MINUTE, 00);
        calendar.set(Calendar.SECOND, 01);
        return calendar.getTime();
    }

    /**
     * 时间转化为23:59:59秒开始
     * @param date
     * @return
     */
    public static Date convertDateEndTime(Date date)  {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return calendar.getTime();
    }

    public static void main(String[] args) throws ParseException {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//        Date d1 = sdf.parse("2022-05-25 08:10:10");
//        Date d2 = sdf.parse("2022-05-26 07:10:10");
//        int i = daysBetween(d1, d2);
//        System.out.println(i);
//        List<Date> dateList = getDateList(d1,d2,3,1);
//        System.out.println(dateList.size());
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        Date d1 = sdf.parse("2022-05-25");
//        System.out.println(compareDate(d1,new Date()));
//        // "2022-05-20","2024-04-21" 3 1   5
//        // "2022-05-20","2024-05-20" 3 2   5
//        // "2022-05-20","2024-05-21" 3 2   6
//        // "2022-05-20","2024-11-21" 3 2   7
//        System.out.println(getDateDiff("2022-05-20","2024-05-20",1));
//        System.out.println("2022-05-25".substring(0,4));
//        System.out.println("2022-05-25".substring(4,10));
       // System.out.println(compare(d1,new Date()));

//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        Date d1 = sdf.parse("2022-05-25");
//        Date d2 = sdf.parse("2023-05-26");
//
//        List<Date> list = getDateList(d1,d2,1,1);
//        list.forEach(d ->{
//            System.out.println(convertDate2String("yyyy",d));
//            System.out.println(d);
//        });

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date d1 = sdf.parse("2020-05-02");
        Date d2 = sdf.parse("2023-07-01");
        System.out.println(DateUtil.compareDate(d1, DateUtil.getCurrDate()));
        System.out.println(addDays(d1,-1));

        System.out.println(compareMonthDayDate(d1,d2));

        Date payEndDate = DateUtil.addYears(d1,1);
        Date payMaxEndDate = DateUtil.compareMonthDayDate(d2,payEndDate);
        if (DateUtil.compareDate(d2,payMaxEndDate) == Constants.ONE) {
            System.out.println("111111");
        }

    }



}
