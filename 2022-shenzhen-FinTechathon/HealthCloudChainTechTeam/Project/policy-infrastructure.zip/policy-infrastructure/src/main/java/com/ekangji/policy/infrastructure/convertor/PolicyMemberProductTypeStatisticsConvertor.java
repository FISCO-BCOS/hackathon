package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyMemberProductTypeStatistics;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsBO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/25 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyMemberProductTypeStatisticsConvertor {

    PolicyMemberProductTypeStatisticsBO convert(PolicyMemberProductTypeStatistics param);

    PolicyMemberProductTypeStatistics convert(PolicyMemberProductTypeStatisticsBO param);

    List<PolicyMemberProductTypeStatistics> convert(List<PolicyMemberProductTypeStatisticsBO> param);

}
