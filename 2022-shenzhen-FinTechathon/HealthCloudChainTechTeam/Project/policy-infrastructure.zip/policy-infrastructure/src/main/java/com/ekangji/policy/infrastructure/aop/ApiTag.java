package com.ekangji.policy.infrastructure.aop;

import java.lang.annotation.*;

/**
 * API接口属性
 *
 * @author: zhangjun
 * @create: 2021/11/29 4:37 下午
 */
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiTag {

    /**
     * 接口编码，这里使用了@AliasFor 别名。spring提供的
     *
     * @return
     */
    String code() default "";

    /**
     * 接口描述，这里使用了@AliasFor 别名。spring提供的
     *
     * @return
     */
    String desc() default "";

    /**
     * 是否记录日志 默认 true
     *
     * @return
     */
    boolean ignore() default true;

}
