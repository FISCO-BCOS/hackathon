package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.insurance.InsuranceCompany;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author 李鑫涛
 * @date 2022/2/11 14:00
 */
@Mapper(componentModel = "spring")
public interface CompanyConvertor {

    InsuranceCompanyDO convert(InsuranceCompany param);

    InsuranceCompany convert(InsuranceCompanyDO param);

    List<InsuranceCompany> convert(List<InsuranceCompanyDO> param);

    PageInfo<InsuranceCompany> convert(PageInfo<InsuranceCompanyDO> param);

}
