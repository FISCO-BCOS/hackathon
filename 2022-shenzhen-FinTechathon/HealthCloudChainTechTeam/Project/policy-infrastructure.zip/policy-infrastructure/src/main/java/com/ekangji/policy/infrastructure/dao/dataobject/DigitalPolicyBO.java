package com.ekangji.policy.infrastructure.dao.dataobject;

import com.ekangji.policy.domain.policy.DigitalPolicy;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 18:01:14
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DigitalPolicyBO extends DigitalPolicy implements Serializable {

    /**
     * 用户集合
     */
    private List<String> userIdList;

    /**
     * 数字保单数量
     */
    private Integer digitalNum;
}