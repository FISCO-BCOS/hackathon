package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAdditionalDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAdditionalDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyAdditionalMapper {
    long countByExample(PolicyAdditionalDOExample example);

    int deleteByExample(PolicyAdditionalDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyAdditionalDO record);

    int insertSelective(PolicyAdditionalDO record);

    List<PolicyAdditionalDO> selectByExampleWithRowbounds(PolicyAdditionalDOExample example, RowBounds rowBounds);

    List<PolicyAdditionalDO> selectByExample(PolicyAdditionalDOExample example);

    PolicyAdditionalDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyAdditionalDO record, @Param("example") PolicyAdditionalDOExample example);

    int updateByExample(@Param("record") PolicyAdditionalDO record, @Param("example") PolicyAdditionalDOExample example);

    int updateByPrimaryKeySelective(PolicyAdditionalDO record);

    int updateByPrimaryKey(PolicyAdditionalDO record);

    int batchInsert(@Param("list") List<PolicyAdditionalDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyAdditionalDO> recordList);

    PolicyAdditionalDO selectOneByExample(PolicyAdditionalDOExample example);
}