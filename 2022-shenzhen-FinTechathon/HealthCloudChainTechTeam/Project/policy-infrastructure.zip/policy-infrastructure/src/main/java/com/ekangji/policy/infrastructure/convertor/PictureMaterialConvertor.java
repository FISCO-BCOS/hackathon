package com.ekangji.policy.infrastructure.convertor;


import com.ekangji.policy.domain.policy.PictureMaterial;
import com.ekangji.policy.infrastructure.dao.dataobject.PictureMaterialDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/18 14:00
 */
@Mapper(componentModel = "spring")
public interface PictureMaterialConvertor {

    PictureMaterialDO convert(PictureMaterial param);

    PictureMaterial convert(PictureMaterialDO param);

    List<PictureMaterial> convert(List<PictureMaterialDO> param);
}
