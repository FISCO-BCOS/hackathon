package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.SafeguardInsurance;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardInsuranceDO;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface SafeguardInsuranceConvertor {

    SafeguardInsuranceDO convert(SafeguardInsurance param);

    SafeguardInsurance convert(SafeguardInsuranceDO param);

    List<SafeguardInsurance> convert(List<SafeguardInsuranceDO> param);

    PageInfo<SafeguardInsurance> convert(PageInfo<SafeguardInsuranceDO> param);

}
