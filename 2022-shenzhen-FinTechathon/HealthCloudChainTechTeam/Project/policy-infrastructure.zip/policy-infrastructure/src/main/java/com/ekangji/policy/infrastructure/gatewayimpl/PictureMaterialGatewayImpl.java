package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PictureMaterialGateway;
import com.ekangji.policy.domain.policy.PictureMaterial;
import com.ekangji.policy.infrastructure.convertor.PictureMaterialConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PictureMaterialDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PictureMaterialDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAdditionalDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAdditionalDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PictureMaterialMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Repository
public class PictureMaterialGatewayImpl implements PictureMaterialGateway {

    @Resource
    private PictureMaterialMapper pictureMaterialMapper;

    @Resource
    private PictureMaterialConvertor convertor;

    @Override
    public Long save(PictureMaterial pictureMaterial) {
        PictureMaterialDO pictureMaterialDO = convertor.convert(pictureMaterial);
        pictureMaterialDO.setCreateTime(new Date());
        pictureMaterialDO.setUpdateTime(new Date());
        int insert = pictureMaterialMapper.insertSelective(pictureMaterialDO);
        return (long) insert;
    }

    @Override
    public int delete(PictureMaterial pictureMaterial) {
        return 0;
    }

    @Override
    public int update(PictureMaterial pictureMaterial) {
        PictureMaterialDO pictureMaterialDO = convertor.convert(pictureMaterial);
        PictureMaterialDOExample example = new PictureMaterialDOExample();
        PictureMaterialDOExample.Criteria criteria = example.createCriteria();
        criteria.andMaterialIdEqualTo(pictureMaterial.getMaterialId());
        return pictureMaterialMapper.updateByExampleSelective(pictureMaterialDO,example);
    }

    @Override
    public PictureMaterial get(PictureMaterial pictureMaterial) {
        PictureMaterialDOExample example = new PictureMaterialDOExample();
        PictureMaterialDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(pictureMaterial.getMaterialId())){
            criteria.andMaterialIdEqualTo(pictureMaterial.getMaterialId());
        }
        if (StringUtils.isNotBlank(pictureMaterial.getCollectionNumber())){
            criteria.andCollectionNumberEqualTo(pictureMaterial.getCollectionNumber());
        }
        PictureMaterialDO pictureMaterialDO = pictureMaterialMapper.selectOneByExample(example);
        if (Objects.nonNull(pictureMaterialDO)) {
            return convertor.convert(pictureMaterialDO);
        }
        return null;
    }

    @Override
    public List<PictureMaterial> list(PictureMaterial pictureMaterial) {
        List<PictureMaterialDO> pictureMaterialDOS = this.query(pictureMaterial);
        if (CollectionUtils.isNotEmpty(pictureMaterialDOS)) {
            return convertor.convert(pictureMaterialDOS);
        }
        return Collections.emptyList();
    }

    @Override
    public PageInfo<PictureMaterial> page(PictureMaterial pictureMaterial) {
        return null;
    }

    private List<PictureMaterialDO> query(PictureMaterial pictureMaterial) {
        PictureMaterialDOExample example = new PictureMaterialDOExample();
        PictureMaterialDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(pictureMaterial.getMaterialType())) {
            criteria.andMaterialTypeEqualTo(pictureMaterial.getMaterialType());
        }
        if (Objects.nonNull(pictureMaterial.getStatus())) {
            criteria.andStatusEqualTo(pictureMaterial.getStatus());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("id desc");
        return pictureMaterialMapper.selectByExample(example);
    }

    @Override
    public int updateById(PictureMaterial pictureMaterial) {
        PictureMaterialDO pictureMaterialDO = convertor.convert(pictureMaterial);
        return pictureMaterialMapper.updateByPrimaryKeySelective(pictureMaterialDO);
    }
}
