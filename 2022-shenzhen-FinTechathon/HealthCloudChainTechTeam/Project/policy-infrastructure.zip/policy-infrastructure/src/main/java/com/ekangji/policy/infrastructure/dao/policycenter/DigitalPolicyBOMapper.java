package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.DigitalPolicyBO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description
 * @author liuchen
 * @date 2022-07-15 11:07
 */
public interface DigitalPolicyBOMapper extends DigitalPolicyMapper{
    /**
     * 批量统计用户数字保单数量
     * @param userIdList
     * @return
     */
    List<DigitalPolicyBO> countDigitalNumByUserIds(@Param("userIdList") List<String> userIdList);
}
