package com.ekangji.policy.infrastructure.dao.primary;

import com.ekangji.policy.infrastructure.dao.dataobject.RelPolicyPeopleDO;
import com.ekangji.policy.infrastructure.dao.dataobject.RelPolicyPeopleDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface RelPolicyPeopleMapper {
    long countByExample(RelPolicyPeopleDOExample example);

    int deleteByExample(RelPolicyPeopleDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(RelPolicyPeopleDO record);

    int insertSelective(RelPolicyPeopleDO record);

    List<RelPolicyPeopleDO> selectByExampleWithRowbounds(RelPolicyPeopleDOExample example, RowBounds rowBounds);

    List<RelPolicyPeopleDO> selectByExample(RelPolicyPeopleDOExample example);

    RelPolicyPeopleDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") RelPolicyPeopleDO record, @Param("example") RelPolicyPeopleDOExample example);

    int updateByExample(@Param("record") RelPolicyPeopleDO record, @Param("example") RelPolicyPeopleDOExample example);

    int updateByPrimaryKeySelective(RelPolicyPeopleDO record);

    int updateByPrimaryKey(RelPolicyPeopleDO record);

    int batchInsert(@Param("list") List<RelPolicyPeopleDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<RelPolicyPeopleDO> recordList);

    RelPolicyPeopleDO selectOneByExample(RelPolicyPeopleDOExample example);

    long queryInsuredInLine(Long id);
}