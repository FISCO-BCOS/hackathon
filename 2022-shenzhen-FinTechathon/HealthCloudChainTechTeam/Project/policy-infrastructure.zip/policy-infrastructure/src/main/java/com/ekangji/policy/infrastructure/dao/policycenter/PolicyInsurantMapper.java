package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyInsurantDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyInsurantDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyInsurantMapper {
    long countByExample(PolicyInsurantDOExample example);

    int deleteByExample(PolicyInsurantDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyInsurantDO record);

    int insertSelective(PolicyInsurantDO record);

    List<PolicyInsurantDO> selectByExampleWithRowbounds(PolicyInsurantDOExample example, RowBounds rowBounds);

    List<PolicyInsurantDO> selectByExample(PolicyInsurantDOExample example);

    PolicyInsurantDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyInsurantDO record, @Param("example") PolicyInsurantDOExample example);

    int updateByExample(@Param("record") PolicyInsurantDO record, @Param("example") PolicyInsurantDOExample example);

    int updateByPrimaryKeySelective(PolicyInsurantDO record);

    int updateByPrimaryKey(PolicyInsurantDO record);

    int batchInsert(@Param("list") List<PolicyInsurantDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyInsurantDO> recordList);

    PolicyInsurantDO selectOneByExample(PolicyInsurantDOExample example);
}