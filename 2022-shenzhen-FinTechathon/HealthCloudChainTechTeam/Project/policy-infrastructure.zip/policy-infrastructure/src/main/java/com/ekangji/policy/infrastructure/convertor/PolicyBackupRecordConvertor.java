package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.domain.policy.PolicyBackupRecord;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupRecordDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/16 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyBackupRecordConvertor {

    PolicyBackupRecordDO convert(PolicyBackupRecord param);

    PolicyBackupRecord convert(PolicyBackupRecordDO param);

    List<PolicyBackupRecord> convertDO(List<PolicyBackupRecordDO> param);

    List<PolicyBackupRecordDO> convertBO(List<PolicyBackupRecord> param);


}
