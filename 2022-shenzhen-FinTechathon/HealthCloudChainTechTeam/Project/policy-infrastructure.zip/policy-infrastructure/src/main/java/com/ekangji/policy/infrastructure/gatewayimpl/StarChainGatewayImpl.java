package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.DictDataGateway;
import com.ekangji.policy.domain.gateway.StarChainGateway;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.infrastructure.convertor.DictDataConvertor;
import com.ekangji.policy.infrastructure.convertor.RelStarChainConvertor;
import com.ekangji.policy.infrastructure.convertor.StarChainConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDO;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDO;
import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.StarChainBOMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.StarChainMapper;
import com.ekangji.policy.infrastructure.dao.primary.DictDataMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author xintao.li
 * @date 2021/12/2 22:04
 */
@Repository
public class StarChainGatewayImpl implements StarChainGateway {


    @Resource
    private StarChainMapper starChainMapper;

    @Resource
    private StarChainBOMapper starChainBOMapper;

    @Resource
    private StarChainConvertor starChainConvertor;

    @Override
    public Long save(StarChain starChain) {
        StarChainDO starChainDO = starChainConvertor.convert(starChain);
        starChainDO.setCreateTime(new Date());
        starChainDO.setUpdateTime(new Date());
        starChainMapper.insertSelective(starChainDO);
        return starChainDO.getId();
    }

    @Override
    public int delete(StarChain starChain) {
//        return dictDataMapper.deleteByPrimaryKey(dictData.getDictCode());
        return 0;
    }

    @Override
    public int update(StarChain starChain) {
//        DictDataDO dictDataDO = dictDataConvertor.convert(dictData);
//        dictDataDO.setUpdateTime(new Date());
//        dictDataDO.setUpdateBy(ShiroUtils.getUserIdStr());
//        DictDataDOExample example = new DictDataDOExample();
//        DictDataDOExample.Criteria criteria = example.createCriteria();
//        criteria.andDictCodeEqualTo(dictData.getDictCode());
//        int delete = dictDataMapper.updateByExampleSelective(dictDataDO,example);
//        return delete;
        return 0;
    }

    @Override
    public StarChain get(StarChain starChain) {
        List<StarChainDO> starChainDOList = this.query(starChain);
        if (CollectionUtils.isNotEmpty(starChainDOList)){
            return starChainConvertor.convert(starChainDOList.get(0));
        }
        return null;
    }

    @Override
    public List<StarChain> list(StarChain starChain) {
//        List<DictDataDO> dictDataDOList = this.query(dictData);
//        if (CollectionUtils.isNotEmpty(dictDataDOList)){
//            return dictDataConvertor.convert(dictDataDOList);
//        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<StarChain> page(StarChain starChain) {
//        PageHelper.startPage(dictData.getPageNum(),dictData.getPageSize());
//        List<DictDataDO> dictDataDOList = query(dictData);
//        PageInfo<DictDataDO> pageInfo = new PageInfo<>(dictDataDOList);
//        return dictDataConvertor.convert(pageInfo);
        return null;
    }

    private List<StarChainDO> query(StarChain starChain) {
        StarChainDOExample example = new StarChainDOExample();
        StarChainDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(starChain.getUserId())){
            criteria.andUserIdEqualTo(starChain.getUserId());
        }
        if (Objects.nonNull(starChain.getStarChainId())){
            criteria.andStarChainIdEqualTo(starChain.getStarChainId());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        example.setOrderByClause("id desc");
        return starChainMapper.selectByExample(example);
    }

    @Override
    public List<StarChain> listByUserIds(List<String> userIdList) {
        StarChainDOExample example = new StarChainDOExample();
        StarChainDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdIn(userIdList);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        List<StarChainDO> starChainDOS = starChainMapper.selectByExample(example);
        return starChainConvertor.convert(starChainDOS);
    }

    @Override
    public void lengthAddOne(StarChain starChain) {
        starChain.setUpdateTime(new Date());
        StarChainDO starChainDO = starChainConvertor.convert(starChain);
        starChainBOMapper.lengthAddOne(starChainDO);
    }
}
