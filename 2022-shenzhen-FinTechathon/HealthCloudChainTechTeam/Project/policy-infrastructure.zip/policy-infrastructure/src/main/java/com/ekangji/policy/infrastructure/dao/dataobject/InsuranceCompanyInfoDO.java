package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-27 02:48:57
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceCompanyInfoDO implements Serializable {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 保险公司ID
     */
    private Long companyId;

    /**
     * 保险公司英文简称
     */
    private String companyShort;

    /**
     * 保险公司中文全称
     */
    private String companyName;

    /**
     * 保险公司英文全称
     */
    private String companyNameEn;

    /**
     * 类型 1人身险 2财产险
     */
    private Integer type;

    /**
     * 公司logo地址
     */
    private String companyLogo;

    /**
     * 数据来源URL
     */
    private String sourceUrl;

    /**
     * 状态 1正常  0停用
     */
    private Integer status;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 总页数
     */
    private Integer pageTotal;

}