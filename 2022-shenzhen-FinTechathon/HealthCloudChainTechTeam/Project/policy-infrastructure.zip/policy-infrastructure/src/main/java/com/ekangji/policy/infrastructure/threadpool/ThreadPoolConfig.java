package com.ekangji.policy.infrastructure.threadpool;

import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.PoolEnum;
import com.ekangji.policy.common.enums.ThreadPoolBizEnum;
import com.google.common.collect.Maps;
import com.google.common.primitives.Ints;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.AbortPolicy;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 这个类是业务线程池配置,核心线程和最大线程,队列长度可配置为变量进行配置化管理
 *
 * @author jun.zhang
 * @date 2020/8/23 18:25
 */
@Slf4j
@Configuration
public class ThreadPoolConfig {
    /**
     * 所有的线程池的集合
     */
    public static final Map<ThreadPoolBizEnum, ThreadPoolExecutor> POOL = Maps.newHashMap();

    /**
     * 默认队列长度
     */
    private static final int DEFAULT_QUEUE_SIZE = 1024;
    /**
     * 默认核心线程数
     */
    private static final int DEFAULT_CORE = 4;
    /**
     * 默认最大线程数
     */
    private static final int DEFAULT_MAX = 20;
    /**
     * 默认存活时间 3秒
     */
    private static final int DEFAULT_ALIVE_TIME = 3000;

    /**
     * 原子操作
     */
    private static final AtomicInteger THREAD_NUM = new AtomicInteger(Constants.ONE);

    /**
     * 线程池名称定义，根据具体的使用场景来命名
     */
    private static final String COMMON_TASK = "common-task-";

    /**
     * 同步任务线程池名称
     */
    private static final String SYNCHRONIZATION_TASK = "synchronization-task-";

    @Bean
    public ThreadPoolExecutor commonThreadPool(
            @Value("${common.thread.pool.core}") String core,
            @Value("${common.thread.pool.max}") String max,
            @Value("${common.thread.pool.alive}") String alive,
            @Value("${common.thread.pool.queue}") String queue) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                getNum(core, PoolEnum.CORE_SIZE),
                getNum(max, PoolEnum.MAX_SIZE),
                getNum(alive, PoolEnum.KEEP_ALIVE),
                TimeUnit.MICROSECONDS,
                new LinkedBlockingQueue<>(getNum(queue, PoolEnum.QUEUE_SIZE)),
                r -> new Thread(r, COMMON_TASK.concat(String.valueOf(THREAD_NUM.getAndIncrement()))),
                new AbortPolicy());
        POOL.put(ThreadPoolBizEnum.COMMON_TASK, threadPoolExecutor);
        return threadPoolExecutor;
    }

    @Bean
    public ThreadPoolExecutor synchronizationThreadPool(
            @Value("${synchronization.thread.pool.core}") String core,
            @Value("${synchronization.thread.pool.max}") String max,
            @Value("${synchronization.thread.pool.alive}") String alive,
            @Value("${synchronization.thread.pool.queue}") String queue) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                getNum(core, PoolEnum.CORE_SIZE),
                getNum(max, PoolEnum.MAX_SIZE),
                getNum(alive, PoolEnum.KEEP_ALIVE),
                TimeUnit.MICROSECONDS,
                new LinkedBlockingQueue<>(getNum(queue, PoolEnum.QUEUE_SIZE)),
                r -> new Thread(r, SYNCHRONIZATION_TASK.concat(String.valueOf(THREAD_NUM.getAndIncrement()))),
                new AbortPolicy());
        POOL.put(ThreadPoolBizEnum.SYNCHRONIZATION_TASK, threadPoolExecutor);
        return threadPoolExecutor;
    }

    /**
     * 功能描述:
     *
     * @param valueStr:
     * @param poolEnum:
     * @return : int
     */
    private int getNum(String valueStr, PoolEnum poolEnum) {
        Integer num;
        if (StringUtils.isNotBlank(valueStr) && (num = Ints.tryParse(valueStr)) != null) {
            return num;
        }
        switch (poolEnum) {
            case CORE_SIZE:
                return DEFAULT_CORE;
            case MAX_SIZE:
                return DEFAULT_MAX;
            case KEEP_ALIVE:
                return DEFAULT_ALIVE_TIME;
            case QUEUE_SIZE:
                return DEFAULT_QUEUE_SIZE;
            default:
                return Constants.ONE;
        }
    }

}
