package com.ekangji.policy.infrastructure.convertor;


import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDO;
import org.mapstruct.Mapper;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 * @author sunqihua
 * @date 2022-05-22 14:05:49
 */
@Mapper(componentModel = "spring")
public interface FamilyEnsuredInfoConvertor {

    FamilyEnsuredInfo convert(FamilyEnsuredInfoDO familyEnsuredInfoDO);

    FamilyEnsuredInfoDO convert(FamilyEnsuredInfo familyEnsuredInfoDO);

}
