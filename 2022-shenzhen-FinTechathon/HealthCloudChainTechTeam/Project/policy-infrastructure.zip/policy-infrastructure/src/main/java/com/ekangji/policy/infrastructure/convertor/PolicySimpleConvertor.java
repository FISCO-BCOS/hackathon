package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicySimple;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicySimpleDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/18 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicySimpleConvertor {

    PolicySimpleDO convert(PolicySimple param);

    PolicySimple convert(PolicySimpleDO param);

    List<PolicySimple> convert(List<PolicySimpleDO> param);

}
