package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBO;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPageBO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/18 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyConvertor {

    PolicyDO convert(Policy param);

    Policy convert(PolicyDO param);

    PolicyBO convert2(Policy param);

    Policy convert2(PolicyBO param);

    List<Policy> convert(List<PolicyDO> param);

    PageInfo<Policy> convert2DTO(PageInfo<PolicyPageBO> param);

    List<Policy> convert2DTO(List<PolicyPageBO> param);

    List<Policy> convert2(List<PolicyBO> param);

}
