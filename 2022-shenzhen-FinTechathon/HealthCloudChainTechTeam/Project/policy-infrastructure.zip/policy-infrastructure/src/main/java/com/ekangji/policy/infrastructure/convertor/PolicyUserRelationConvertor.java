package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyUserRelation;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyUserRelationDO;
import org.mapstruct.Mapper;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/17 11:00
 */
@Mapper(componentModel = "spring")
public interface PolicyUserRelationConvertor {

    PolicyUserRelationDO convert(PolicyUserRelation param);

    PolicyUserRelation convert(PolicyUserRelationDO param);

}
