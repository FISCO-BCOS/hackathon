package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.PolicyAttchmentGateway;
import com.ekangji.policy.domain.policy.PolicyAttchment;
import com.ekangji.policy.infrastructure.convertor.PolicyAttchmentConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAttchmentDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAttchmentDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyAttchmentMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyAttchmentGatewayImpl implements PolicyAttchmentGateway {

    @Resource
    private PolicyAttchmentConvertor policyAttchmentConvertor;

    @Resource
    private PolicyAttchmentMapper policyAttchmentMapper;

    @Override
    public Long save(PolicyAttchment policyAttchment) {
        return null;
    }

    @Override
    public int delete(PolicyAttchment policyAttchment) {
        return 0;
    }

    @Override
    public int update(PolicyAttchment policyAttchment) {
        return 0;
    }

    @Override
    public PolicyAttchment get(PolicyAttchment policyAttchment) {
        return null;
    }

    @Override
    public List<PolicyAttchment> list(PolicyAttchment policyAttchment) {
        List<PolicyAttchmentDO> policyAttchmentDOS = this.query(policyAttchment);
        if (CollectionUtils.isNotEmpty(policyAttchmentDOS)) {
           return policyAttchmentConvertor.convertDO(policyAttchmentDOS);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public PageInfo<PolicyAttchment> page(PolicyAttchment policyAttchment) {
        return null;
    }

    @Override
    public int batchSave(List<PolicyAttchment> attchmentList) {
        List<PolicyAttchmentDO> attchmentDOList = policyAttchmentConvertor.convert(attchmentList);
        int num = 0;
        for (PolicyAttchmentDO tmp: attchmentDOList) {
            policyAttchmentMapper.insertSelective(tmp);
            num++;
        }
        return num;
        //policyAttchmentMapper.batchInsert(attchmentDOList);
    }

    @Override
    public int deleteByPolicy(PolicyAttchment build) {
        PolicyAttchmentDOExample example = new PolicyAttchmentDOExample();
        PolicyAttchmentDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(build.getPolicyId());
        return policyAttchmentMapper.deleteByExample(example);
    }

    private List<PolicyAttchmentDO> query(PolicyAttchment policyAttchment) {
        PolicyAttchmentDOExample example = new PolicyAttchmentDOExample();
        PolicyAttchmentDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(policyAttchment.getPolicyId())) {
            criteria.andPolicyIdEqualTo(policyAttchment.getPolicyId());
        }
        if (Objects.nonNull(policyAttchment.getDelFlag())) {
            criteria.andDelFlagEqualTo(policyAttchment.getDelFlag());
        }
        return  policyAttchmentMapper.selectByExample(example);
    }
}
