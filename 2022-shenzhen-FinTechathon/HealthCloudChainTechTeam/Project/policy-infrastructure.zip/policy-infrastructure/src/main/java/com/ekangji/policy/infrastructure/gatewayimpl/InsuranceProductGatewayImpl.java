package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonIfEnum;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.InsuranceProductGateway;
import com.ekangji.policy.domain.insurance.InsuranceProduct;
import com.ekangji.policy.infrastructure.convertor.InsuranceProductConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDOExample;
import com.ekangji.policy.infrastructure.dao.productcenter.InsuranceCompanyMapper;
import com.ekangji.policy.infrastructure.dao.productcenter.InsuranceProductBusinessMapper;
import com.ekangji.policy.infrastructure.dao.productcenter.InsuranceProductMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author 李鑫涛
 * @date 2012/2/15 16:08
 */
@Repository
public class InsuranceProductGatewayImpl implements InsuranceProductGateway {

    @Resource
    private InsuranceProductMapper productMapper;

    @Resource
    private InsuranceCompanyMapper companyMapper;

    @Resource
    private InsuranceProductConvertor productConvertor;

    @Resource
    private InsuranceProductBusinessMapper insuranceProductBusinessMapper;


    @Override
    public Long save(InsuranceProduct insuranceProduct) {
        InsuranceProductDO productDO = productConvertor.convert(insuranceProduct);
        productDO.setCreateTime(new Date());
        productDO.setUpdateTime(new Date());
        productDO.setIsDismantle(0);
        productDO.setDelFlag(0);
        productDO.setCreateBy(ShiroUtils.getUserIdStr());
        productDO.setUpdateBy(ShiroUtils.getUserIdStr());
        productDO.setStatus(CommonStatusEnum.VALID.getCode());
        productMapper.insert(productDO);
        return productDO.getId();
    }

    @Override
    public int delete(InsuranceProduct insuranceProduct) {
        return 0;
    }

    @Override
    public int update(InsuranceProduct insuranceProduct) {
        InsuranceProductDO insuranceProductDO = productConvertor.convert(insuranceProduct);
        insuranceProductDO.setUpdateTime(new Date());
        insuranceProductDO.setUpdateBy(ShiroUtils.getUserIdStr());
        InsuranceProductDOExample example = new InsuranceProductDOExample();
        InsuranceProductDOExample.Criteria criteria = example.createCriteria();
        criteria.andProductIdEqualTo(insuranceProduct.getProductId());
        return productMapper.updateByExample(insuranceProductDO,example);
    }

    @Override
    public InsuranceProduct getByIdAndName(InsuranceProduct insuranceProduct) {
        InsuranceProductDOExample insuranceProductDOExample = new InsuranceProductDOExample();
        InsuranceProductDOExample.Criteria criteria = insuranceProductDOExample.createCriteria();
        criteria.andProductIdEqualTo(insuranceProduct.getProductId());
        criteria.andProductNameEqualTo(insuranceProduct.getProductName());
        return productConvertor.convert(productMapper.selectOneByExample(insuranceProductDOExample));
    }

    @Override
    public List<InsuranceProduct> listByCompanyId(InsuranceProduct insuranceProduct) {
        InsuranceProductDO insuranceProductDO = productConvertor.convert(insuranceProduct);
        insuranceProductDO.setStatus(Constants.ONE);
        insuranceProductDO.setDelFlag(Constants.ONE);
        List<InsuranceProductDO> ipDOList = insuranceProductBusinessMapper.selectProductByCompanyId(insuranceProductDO);
        if (CollectionUtils.isNotEmpty(ipDOList)) {
           return productConvertor.convert(ipDOList);
        }
        return Collections.emptyList();
    }

    @Override
    public InsuranceProduct getByProductId(InsuranceProduct insuranceProduct) {
        InsuranceProductDOExample insuranceProductDOExample = new InsuranceProductDOExample();
        InsuranceProductDOExample.Criteria criteria = insuranceProductDOExample.createCriteria();
        criteria.andProductIdEqualTo(insuranceProduct.getProductId());
        return productConvertor.convert(productMapper.selectOneByExample(insuranceProductDOExample));
    }

    @Override
    public InsuranceProduct get(InsuranceProduct insuranceProduct) {
        List<InsuranceProductDO> productDOList = this.query(insuranceProduct);
        if (CollectionUtils.isNotEmpty(productDOList)){
            InsuranceProduct product = productConvertor.convert(productDOList.get(0));
            InsuranceCompanyDOExample companyDOExample = new InsuranceCompanyDOExample();
            InsuranceCompanyDOExample.Criteria companyCriteria = companyDOExample.createCriteria();
            companyCriteria.andCompanyIdEqualTo(product.getCompanyId());
            InsuranceCompanyDO companyDO = companyMapper.selectOneByExample(companyDOExample);
            if (Objects.nonNull(companyDO)){
                product.setCompanyName(companyDO.getCompanyName());
            }
            return product;
        }
        return null;
    }

    @Override
    public InsuranceProduct getById(InsuranceProduct insuranceProduct) {
        InsuranceProductDO insuranceProductDO = productConvertor.convert(insuranceProduct);
        InsuranceProductDOExample insuranceProductDOExample = new InsuranceProductDOExample();
        InsuranceProductDOExample.Criteria criteria = insuranceProductDOExample.createCriteria();
        criteria.andProductIdEqualTo(insuranceProductDO.getProductId());
        return productConvertor.convert(productMapper.selectOneByExample(insuranceProductDOExample));
    }

    @Override
    public List<InsuranceProduct> queryByIds(InsuranceProduct product) {
        InsuranceProductDOExample example = new InsuranceProductDOExample();
        example.createCriteria().andProductIdIn(product.getProductIds());
        return productConvertor.convert(productMapper.selectByExample(example));
    }

    @Override
    public int updateDisByIds(List<String> productIds) {
        if (CollectionUtils.isEmpty(productIds)){
            return 0;
        }
        InsuranceProductDO insuranceProductDO = new InsuranceProductDO();
        insuranceProductDO.setIsDismantle(CommonIfEnum.YES.getCode());
        insuranceProductDO.setUpdateTime(new Date());
        insuranceProductDO.setUpdateBy(ShiroUtils.getUserIdStr());

        InsuranceProductDOExample example = new InsuranceProductDOExample();
        example.createCriteria().andProductIdIn(productIds);
        return productMapper.updateByExampleSelective(insuranceProductDO,example);
    }

    @Override
    public List<InsuranceProduct> list(InsuranceProduct insuranceProduct) {
        List<InsuranceProductDO> productDOList = this.query(insuranceProduct);
        if (CollectionUtils.isNotEmpty(productDOList)){
            return productConvertor.convert(productDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<InsuranceProduct> page(InsuranceProduct product) {
        return productConvertor.convert(PageHelper.startPage(product.getPageNum(), product.getPageSize())
                .doSelectPageInfo(() -> list(product)));
    }

    private List<InsuranceProductDO> query(InsuranceProduct product) {
        InsuranceProductDO insuranceProductDO = productConvertor.convert(product);
        InsuranceProductDOExample insuranceProductDOExample = new InsuranceProductDOExample();
        InsuranceProductDOExample.Criteria criteria = insuranceProductDOExample.createCriteria();
        if (StringUtils.isNotBlank(insuranceProductDO.getProductName())){
            criteria.andProductNameEqualTo(insuranceProductDO.getProductName());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        return insuranceProductBusinessMapper.listByProduct(insuranceProductDO);
    }
}
