package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/16 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyBackupMessageConvertor {

    PolicyBackupMessageDO convert(PolicyBackupMessage param);

    PolicyBackupMessage convert(PolicyBackupMessageDO param);

    PolicyBackupMessage convert(PolicyBackupMessageBO param);

    List<PolicyBackupMessage> convert(List<PolicyBackupMessageBO> param);

    List<PolicyBackupMessage> convertDO(List<PolicyBackupMessageDO> param);

    List<PolicyBackupMessageBO> convertBO(List<PolicyBackupMessage> param);


}
