package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 17:59:36
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class FamilyEnsuredInfoDO implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 用户id 对应b_user_family_info表的belong_user_id
     */
    private String userId;

    /**
     * 健康险保障分
     */
    private Integer healthScore;

    /**
     * 人寿险保障分
     */
    private Integer lifeInsuranceScore;

    /**
     * 意外险保障分
     */
    private Integer unexpectedScore;

    /**
     * 年金险保障分
     */
    private Integer renteScore;

    /**
     * 社保保障分
     */
    private Integer socialSecurityScore;

    /**
     * 家庭保障总得分
     */
    private Integer familyTotalScore;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public Integer getHealthScore() {
        return healthScore;
    }

    public void setHealthScore(Integer healthScore) {
        this.healthScore = healthScore;
    }

    public Integer getLifeInsuranceScore() {
        return lifeInsuranceScore;
    }

    public void setLifeInsuranceScore(Integer lifeInsuranceScore) {
        this.lifeInsuranceScore = lifeInsuranceScore;
    }

    public Integer getUnexpectedScore() {
        return unexpectedScore;
    }

    public void setUnexpectedScore(Integer unexpectedScore) {
        this.unexpectedScore = unexpectedScore;
    }

    public Integer getRenteScore() {
        return renteScore;
    }

    public void setRenteScore(Integer renteScore) {
        this.renteScore = renteScore;
    }

    public Integer getSocialSecurityScore() {
        return socialSecurityScore;
    }

    public void setSocialSecurityScore(Integer socialSecurityScore) {
        this.socialSecurityScore = socialSecurityScore;
    }

    public Integer getFamilyTotalScore() {
        return familyTotalScore;
    }

    public void setFamilyTotalScore(Integer familyTotalScore) {
        this.familyTotalScore = familyTotalScore;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", healthScore=").append(healthScore);
        sb.append(", lifeInsuranceScore=").append(lifeInsuranceScore);
        sb.append(", unexpectedScore=").append(unexpectedScore);
        sb.append(", renteScore=").append(renteScore);
        sb.append(", socialSecurityScore=").append(socialSecurityScore);
        sb.append(", familyTotalScore=").append(familyTotalScore);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private FamilyEnsuredInfoDO obj;

        public Builder() {
            this.obj = new FamilyEnsuredInfoDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder healthScore(Integer healthScore) {
            obj.healthScore = healthScore;
            return this;
        }

        public Builder lifeInsuranceScore(Integer lifeInsuranceScore) {
            obj.lifeInsuranceScore = lifeInsuranceScore;
            return this;
        }

        public Builder unexpectedScore(Integer unexpectedScore) {
            obj.unexpectedScore = unexpectedScore;
            return this;
        }

        public Builder renteScore(Integer renteScore) {
            obj.renteScore = renteScore;
            return this;
        }

        public Builder socialSecurityScore(Integer socialSecurityScore) {
            obj.socialSecurityScore = socialSecurityScore;
            return this;
        }

        public Builder familyTotalScore(Integer familyTotalScore) {
            obj.familyTotalScore = familyTotalScore;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public FamilyEnsuredInfoDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        userId("user_id"),
        healthScore("health_score"),
        lifeInsuranceScore("life_insurance_score"),
        unexpectedScore("unexpected_score"),
        renteScore("rente_score"),
        socialSecurityScore("social_security_score"),
        familyTotalScore("family_total_score"),
        status("status"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by"),
        delFlag("del_flag");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}