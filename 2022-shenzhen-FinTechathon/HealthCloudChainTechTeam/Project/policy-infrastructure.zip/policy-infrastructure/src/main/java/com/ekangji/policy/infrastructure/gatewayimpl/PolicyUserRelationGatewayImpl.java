package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.PolicyUserRelationGateway;
import com.ekangji.policy.domain.policy.PolicyUserRelation;
import com.ekangji.policy.infrastructure.convertor.PolicyUserRelationConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyUserRelationDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyUserRelationDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyUserRelationMapper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyUserRelationGatewayImpl implements PolicyUserRelationGateway {

    @Resource
    private PolicyUserRelationConvertor policyUserRelationConvertor;

    @Resource
    private PolicyUserRelationMapper policyUserRelationMapper;

    @Override
    public Long save(PolicyUserRelation policyUserRelation) {
        PolicyUserRelationDO purDO = policyUserRelationConvertor.convert(policyUserRelation);
        policyUserRelationMapper.insertSelective(purDO);
        return purDO.getId();
    }

    @Override
    public int delete(PolicyUserRelation policyUserRelation) {
        return 0;
    }

    @Override
    public int update(PolicyUserRelation policyUserRelation) {
        return 0;
    }

    @Override
    public PolicyUserRelation get(PolicyUserRelation policyUserRelation) {
        return null;
    }

    @Override
    public List<PolicyUserRelation> list(PolicyUserRelation policyUserRelation) {
        return null;
    }

    @Override
    public PageInfo<PolicyUserRelation> page(PolicyUserRelation policyUserRelation) {
        return null;
    }

    @Override
    public PolicyUserRelation selectByUserIdAndPolicyId(PolicyUserRelation userRelation) {
        PolicyUserRelationDO userRelationDO = policyUserRelationConvertor.convert(userRelation);
        PolicyUserRelationDOExample example = new PolicyUserRelationDOExample();
        PolicyUserRelationDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(userRelationDO.getUserId());
        criteria.andPolicyIdEqualTo(userRelationDO.getPolicyId());
        PolicyUserRelationDO purDO = policyUserRelationMapper.selectOneByExample(example);
        if (Objects.nonNull(purDO)) {
            return policyUserRelationConvertor.convert(purDO);
        }
        return null;
    }
}
