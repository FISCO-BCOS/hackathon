package com.ekangji.policy.infrastructure.dao.productcenter;

import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDictDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDictDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface InsuranceProductDictMapper {
    long countByExample(InsuranceProductDictDOExample example);

    int deleteByExample(InsuranceProductDictDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(InsuranceProductDictDO record);

    int insertSelective(InsuranceProductDictDO record);

    List<InsuranceProductDictDO> selectByExampleWithRowbounds(InsuranceProductDictDOExample example, RowBounds rowBounds);

    List<InsuranceProductDictDO> selectByExample(InsuranceProductDictDOExample example);

    InsuranceProductDictDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") InsuranceProductDictDO record, @Param("example") InsuranceProductDictDOExample example);

    int updateByExample(@Param("record") InsuranceProductDictDO record, @Param("example") InsuranceProductDictDOExample example);

    int updateByPrimaryKeySelective(InsuranceProductDictDO record);

    int updateByPrimaryKey(InsuranceProductDictDO record);

    int batchInsert(@Param("list") List<InsuranceProductDictDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<InsuranceProductDictDO> recordList);

    InsuranceProductDictDO selectOneByExample(InsuranceProductDictDOExample example);
}