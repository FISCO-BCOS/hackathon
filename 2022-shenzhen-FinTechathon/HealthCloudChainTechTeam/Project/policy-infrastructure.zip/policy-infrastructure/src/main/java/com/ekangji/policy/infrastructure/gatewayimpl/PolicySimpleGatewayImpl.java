package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.PolicySimpleGateway;
import com.ekangji.policy.domain.policy.PolicySimple;
import com.ekangji.policy.infrastructure.convertor.PolicySimpleConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicySimpleDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicySimpleDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicySimpleMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicySimpleGatewayImpl implements PolicySimpleGateway {

    @Resource
    private PolicySimpleMapper policySimpleMapper;

    @Resource
    private PolicySimpleConvertor convertor;

    @Override
    public Long save(PolicySimple policySimple) {
        PolicySimpleDO policySimpleDO = convertor.convert(policySimple);
        policySimpleMapper.insertSelective(policySimpleDO);
        return policySimpleDO.getPolicyId();
    }

    @Override
    public int delete(PolicySimple policySimple) {
        return 0;
    }

    @Override
    public int update(PolicySimple policySimple) {
        PolicySimpleDO policySimpleDO = convertor.convert(policySimple);
        return policySimpleMapper.updateByPrimaryKeySelective(policySimpleDO);
    }

    @Override
    public PolicySimple get(PolicySimple policySimple) {
        List<PolicySimpleDO> policySimpleDOS = query(policySimple);
        if (CollectionUtils.isNotEmpty(policySimpleDOS)) {
            return convertor.convert(policySimpleDOS.get(0));
        }
        return null;
    }

    @Override
    public List<PolicySimple> list(PolicySimple policySimple) {
        return null;
    }

    @Override
    public PageInfo<PolicySimple> page(PolicySimple policySimple) {
        return null;
    }

    private List<PolicySimpleDO> query(PolicySimple policySimple) {
        PolicySimpleDOExample example = new PolicySimpleDOExample();
        PolicySimpleDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotEmpty(policySimple.getUserId())) {
            criteria.andUserIdEqualTo(policySimple.getUserId());
        }

        if (Objects.nonNull(policySimple.getPolicyId())) {
            criteria.andPolicyIdEqualTo(policySimple.getPolicyId());
        }

        if (Objects.nonNull(policySimple.getDelFlag())) {
            criteria.andDelFlagEqualTo(policySimple.getDelFlag());
        }
        return policySimpleMapper.selectByExample(example);
    }
}
