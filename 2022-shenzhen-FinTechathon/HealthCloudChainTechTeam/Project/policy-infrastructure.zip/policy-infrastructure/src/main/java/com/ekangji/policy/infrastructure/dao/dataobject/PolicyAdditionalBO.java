package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.Data;
import lombok.ToString;

import java.util.Date;

/**
 *
 * @author   xintao.li
 * @date   2022-05-18 17:00:25
 */
@Data
@ToString(callSuper = true)
public class PolicyAdditionalBO extends PolicyAdditionalDO{

    /**
     * 被保人出生日期-起
     */
    private Date insurantBirthdayBegin;

    /**
     * 被保人出生日期-止
     */
    private Date insurantBirthdayEnd;

    /**
     * 所属用户
     */
    private String userId;

    /**
     * 被保人id
     */
    private Long insurantId;
}
