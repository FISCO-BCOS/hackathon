package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-06-01 12:27:06
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBackupRecordDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long backupId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 保单父ID
     */
    private Long parentPolicyId;

    /**
     * 保单所属用户ID
     */
    private String userId;

    /**
     * 保单所属用户手机号
     */
    private String userPhone;

    /**
     * 发起备份用户ID
     */
    private String backupUserId;

    /**
     * 发起备份用户手机号
     */
    private String backupUserPhone;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBackupId() {
        return backupId;
    }

    public void setBackupId(Long backupId) {
        this.backupId = backupId;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public Long getParentPolicyId() {
        return parentPolicyId;
    }

    public void setParentPolicyId(Long parentPolicyId) {
        this.parentPolicyId = parentPolicyId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone == null ? null : userPhone.trim();
    }

    public String getBackupUserId() {
        return backupUserId;
    }

    public void setBackupUserId(String backupUserId) {
        this.backupUserId = backupUserId == null ? null : backupUserId.trim();
    }

    public String getBackupUserPhone() {
        return backupUserPhone;
    }

    public void setBackupUserPhone(String backupUserPhone) {
        this.backupUserPhone = backupUserPhone == null ? null : backupUserPhone.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", backupId=").append(backupId);
        sb.append(", policyId=").append(policyId);
        sb.append(", parentPolicyId=").append(parentPolicyId);
        sb.append(", userId=").append(userId);
        sb.append(", userPhone=").append(userPhone);
        sb.append(", backupUserId=").append(backupUserId);
        sb.append(", backupUserPhone=").append(backupUserPhone);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private PolicyBackupRecordDO obj;

        public Builder() {
            this.obj = new PolicyBackupRecordDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder backupId(Long backupId) {
            obj.backupId = backupId;
            return this;
        }

        public Builder policyId(Long policyId) {
            obj.policyId = policyId;
            return this;
        }

        public Builder parentPolicyId(Long parentPolicyId) {
            obj.parentPolicyId = parentPolicyId;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder userPhone(String userPhone) {
            obj.userPhone = userPhone;
            return this;
        }

        public Builder backupUserId(String backupUserId) {
            obj.backupUserId = backupUserId;
            return this;
        }

        public Builder backupUserPhone(String backupUserPhone) {
            obj.backupUserPhone = backupUserPhone;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public PolicyBackupRecordDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        backupId("backup_id"),
        policyId("policy_id"),
        parentPolicyId("parent_policy_id"),
        userId("user_id"),
        userPhone("user_phone"),
        backupUserId("backup_user_id"),
        backupUserPhone("backup_user_phone"),
        status("status"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}