package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDO;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface SafeguardOverviewMapper {
    long countByExample(SafeguardOverviewDOExample example);

    int deleteByExample(SafeguardOverviewDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SafeguardOverviewDO record);

    int insertSelective(SafeguardOverviewDO record);

    List<SafeguardOverviewDO> selectByExampleWithRowbounds(SafeguardOverviewDOExample example, RowBounds rowBounds);

    List<SafeguardOverviewDO> selectByExample(SafeguardOverviewDOExample example);

    SafeguardOverviewDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SafeguardOverviewDO record, @Param("example") SafeguardOverviewDOExample example);

    int updateByExample(@Param("record") SafeguardOverviewDO record, @Param("example") SafeguardOverviewDOExample example);

    int updateByPrimaryKeySelective(SafeguardOverviewDO record);

    int updateByPrimaryKey(SafeguardOverviewDO record);

    int batchInsert(@Param("list") List<SafeguardOverviewDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<SafeguardOverviewDO> recordList);

    SafeguardOverviewDO selectOneByExample(SafeguardOverviewDOExample example);
}