package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.RelPolicyPeople;
import com.ekangji.policy.infrastructure.dao.dataobject.RelPolicyPeopleDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author wjx
 * @date 2021/1/17 16:00
 */
@Mapper(componentModel = "spring")
public interface RelPolicyPeopleConvertor {

    List<RelPolicyPeopleDO> convert(List<RelPolicyPeople> param);

    List<RelPolicyPeople> convertList(List<RelPolicyPeopleDO> param);

    RelPolicyPeopleDO convert(RelPolicyPeople param);

    RelPolicyPeople convert(RelPolicyPeopleDO param);


}
