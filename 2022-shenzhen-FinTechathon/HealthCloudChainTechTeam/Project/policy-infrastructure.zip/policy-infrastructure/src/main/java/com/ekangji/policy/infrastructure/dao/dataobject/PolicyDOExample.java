package com.ekangji.policy.infrastructure.dao.dataobject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class PolicyDOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public PolicyDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andPolicyIdIsNull() {
            addCriterion("policy_id is null");
            return (Criteria) this;
        }

        public Criteria andPolicyIdIsNotNull() {
            addCriterion("policy_id is not null");
            return (Criteria) this;
        }

        public Criteria andPolicyIdEqualTo(Long value) {
            addCriterion("policy_id =", value, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdNotEqualTo(Long value) {
            addCriterion("policy_id <>", value, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdGreaterThan(Long value) {
            addCriterion("policy_id >", value, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdGreaterThanOrEqualTo(Long value) {
            addCriterion("policy_id >=", value, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdLessThan(Long value) {
            addCriterion("policy_id <", value, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdLessThanOrEqualTo(Long value) {
            addCriterion("policy_id <=", value, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdIn(List<Long> values) {
            addCriterion("policy_id in", values, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdNotIn(List<Long> values) {
            addCriterion("policy_id not in", values, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdBetween(Long value1, Long value2) {
            addCriterion("policy_id between", value1, value2, "policyId");
            return (Criteria) this;
        }

        public Criteria andPolicyIdNotBetween(Long value1, Long value2) {
            addCriterion("policy_id not between", value1, value2, "policyId");
            return (Criteria) this;
        }

        public Criteria andPlatformIsNull() {
            addCriterion("platform is null");
            return (Criteria) this;
        }

        public Criteria andPlatformIsNotNull() {
            addCriterion("platform is not null");
            return (Criteria) this;
        }

        public Criteria andPlatformEqualTo(Integer value) {
            addCriterion("platform =", value, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformNotEqualTo(Integer value) {
            addCriterion("platform <>", value, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformGreaterThan(Integer value) {
            addCriterion("platform >", value, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformGreaterThanOrEqualTo(Integer value) {
            addCriterion("platform >=", value, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformLessThan(Integer value) {
            addCriterion("platform <", value, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformLessThanOrEqualTo(Integer value) {
            addCriterion("platform <=", value, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformIn(List<Integer> values) {
            addCriterion("platform in", values, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformNotIn(List<Integer> values) {
            addCriterion("platform not in", values, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformBetween(Integer value1, Integer value2) {
            addCriterion("platform between", value1, value2, "platform");
            return (Criteria) this;
        }

        public Criteria andPlatformNotBetween(Integer value1, Integer value2) {
            addCriterion("platform not between", value1, value2, "platform");
            return (Criteria) this;
        }

        public Criteria andSourceTypeIsNull() {
            addCriterion("source_type is null");
            return (Criteria) this;
        }

        public Criteria andSourceTypeIsNotNull() {
            addCriterion("source_type is not null");
            return (Criteria) this;
        }

        public Criteria andSourceTypeEqualTo(Integer value) {
            addCriterion("source_type =", value, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeNotEqualTo(Integer value) {
            addCriterion("source_type <>", value, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeGreaterThan(Integer value) {
            addCriterion("source_type >", value, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("source_type >=", value, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeLessThan(Integer value) {
            addCriterion("source_type <", value, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeLessThanOrEqualTo(Integer value) {
            addCriterion("source_type <=", value, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeIn(List<Integer> values) {
            addCriterion("source_type in", values, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeNotIn(List<Integer> values) {
            addCriterion("source_type not in", values, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeBetween(Integer value1, Integer value2) {
            addCriterion("source_type between", value1, value2, "sourceType");
            return (Criteria) this;
        }

        public Criteria andSourceTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("source_type not between", value1, value2, "sourceType");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(String value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(String value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(String value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(String value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(String value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(String value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLike(String value) {
            addCriterion("user_id like", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotLike(String value) {
            addCriterion("user_id not like", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<String> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<String> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(String value1, String value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(String value1, String value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNull() {
            addCriterion("user_phone is null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIsNotNull() {
            addCriterion("user_phone is not null");
            return (Criteria) this;
        }

        public Criteria andUserPhoneEqualTo(String value) {
            addCriterion("user_phone =", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotEqualTo(String value) {
            addCriterion("user_phone <>", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThan(String value) {
            addCriterion("user_phone >", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("user_phone >=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThan(String value) {
            addCriterion("user_phone <", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLessThanOrEqualTo(String value) {
            addCriterion("user_phone <=", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneLike(String value) {
            addCriterion("user_phone like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotLike(String value) {
            addCriterion("user_phone not like", value, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneIn(List<String> values) {
            addCriterion("user_phone in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotIn(List<String> values) {
            addCriterion("user_phone not in", values, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneBetween(String value1, String value2) {
            addCriterion("user_phone between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andUserPhoneNotBetween(String value1, String value2) {
            addCriterion("user_phone not between", value1, value2, "userPhone");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberIsNull() {
            addCriterion("policy_number is null");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberIsNotNull() {
            addCriterion("policy_number is not null");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberEqualTo(String value) {
            addCriterion("policy_number =", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberNotEqualTo(String value) {
            addCriterion("policy_number <>", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberGreaterThan(String value) {
            addCriterion("policy_number >", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberGreaterThanOrEqualTo(String value) {
            addCriterion("policy_number >=", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberLessThan(String value) {
            addCriterion("policy_number <", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberLessThanOrEqualTo(String value) {
            addCriterion("policy_number <=", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberLike(String value) {
            addCriterion("policy_number like", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberNotLike(String value) {
            addCriterion("policy_number not like", value, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberIn(List<String> values) {
            addCriterion("policy_number in", values, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberNotIn(List<String> values) {
            addCriterion("policy_number not in", values, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberBetween(String value1, String value2) {
            addCriterion("policy_number between", value1, value2, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andPolicyNumberNotBetween(String value1, String value2) {
            addCriterion("policy_number not between", value1, value2, "policyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIsNull() {
            addCriterion("company_id is null");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIsNotNull() {
            addCriterion("company_id is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyIdEqualTo(String value) {
            addCriterion("company_id =", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotEqualTo(String value) {
            addCriterion("company_id <>", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdGreaterThan(String value) {
            addCriterion("company_id >", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdGreaterThanOrEqualTo(String value) {
            addCriterion("company_id >=", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLessThan(String value) {
            addCriterion("company_id <", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLessThanOrEqualTo(String value) {
            addCriterion("company_id <=", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLike(String value) {
            addCriterion("company_id like", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotLike(String value) {
            addCriterion("company_id not like", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIn(List<String> values) {
            addCriterion("company_id in", values, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotIn(List<String> values) {
            addCriterion("company_id not in", values, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdBetween(String value1, String value2) {
            addCriterion("company_id between", value1, value2, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotBetween(String value1, String value2) {
            addCriterion("company_id not between", value1, value2, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyNameIsNull() {
            addCriterion("company_name is null");
            return (Criteria) this;
        }

        public Criteria andCompanyNameIsNotNull() {
            addCriterion("company_name is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyNameEqualTo(String value) {
            addCriterion("company_name =", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotEqualTo(String value) {
            addCriterion("company_name <>", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameGreaterThan(String value) {
            addCriterion("company_name >", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameGreaterThanOrEqualTo(String value) {
            addCriterion("company_name >=", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameLessThan(String value) {
            addCriterion("company_name <", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameLessThanOrEqualTo(String value) {
            addCriterion("company_name <=", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameLike(String value) {
            addCriterion("company_name like", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotLike(String value) {
            addCriterion("company_name not like", value, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameIn(List<String> values) {
            addCriterion("company_name in", values, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotIn(List<String> values) {
            addCriterion("company_name not in", values, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameBetween(String value1, String value2) {
            addCriterion("company_name between", value1, value2, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameNotBetween(String value1, String value2) {
            addCriterion("company_name not between", value1, value2, "companyName");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortIsNull() {
            addCriterion("company_name_short is null");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortIsNotNull() {
            addCriterion("company_name_short is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortEqualTo(String value) {
            addCriterion("company_name_short =", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortNotEqualTo(String value) {
            addCriterion("company_name_short <>", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortGreaterThan(String value) {
            addCriterion("company_name_short >", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortGreaterThanOrEqualTo(String value) {
            addCriterion("company_name_short >=", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortLessThan(String value) {
            addCriterion("company_name_short <", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortLessThanOrEqualTo(String value) {
            addCriterion("company_name_short <=", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortLike(String value) {
            addCriterion("company_name_short like", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortNotLike(String value) {
            addCriterion("company_name_short not like", value, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortIn(List<String> values) {
            addCriterion("company_name_short in", values, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortNotIn(List<String> values) {
            addCriterion("company_name_short not in", values, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortBetween(String value1, String value2) {
            addCriterion("company_name_short between", value1, value2, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andCompanyNameShortNotBetween(String value1, String value2) {
            addCriterion("company_name_short not between", value1, value2, "companyNameShort");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNull() {
            addCriterion("product_id is null");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNotNull() {
            addCriterion("product_id is not null");
            return (Criteria) this;
        }

        public Criteria andProductIdEqualTo(String value) {
            addCriterion("product_id =", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotEqualTo(String value) {
            addCriterion("product_id <>", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThan(String value) {
            addCriterion("product_id >", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThanOrEqualTo(String value) {
            addCriterion("product_id >=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThan(String value) {
            addCriterion("product_id <", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThanOrEqualTo(String value) {
            addCriterion("product_id <=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLike(String value) {
            addCriterion("product_id like", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotLike(String value) {
            addCriterion("product_id not like", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdIn(List<String> values) {
            addCriterion("product_id in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotIn(List<String> values) {
            addCriterion("product_id not in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdBetween(String value1, String value2) {
            addCriterion("product_id between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotBetween(String value1, String value2) {
            addCriterion("product_id not between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andProductNameIsNull() {
            addCriterion("product_name is null");
            return (Criteria) this;
        }

        public Criteria andProductNameIsNotNull() {
            addCriterion("product_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductNameEqualTo(String value) {
            addCriterion("product_name =", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotEqualTo(String value) {
            addCriterion("product_name <>", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameGreaterThan(String value) {
            addCriterion("product_name >", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_name >=", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLessThan(String value) {
            addCriterion("product_name <", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLessThanOrEqualTo(String value) {
            addCriterion("product_name <=", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLike(String value) {
            addCriterion("product_name like", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotLike(String value) {
            addCriterion("product_name not like", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameIn(List<String> values) {
            addCriterion("product_name in", values, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotIn(List<String> values) {
            addCriterion("product_name not in", values, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameBetween(String value1, String value2) {
            addCriterion("product_name between", value1, value2, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotBetween(String value1, String value2) {
            addCriterion("product_name not between", value1, value2, "productName");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNull() {
            addCriterion("product_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeIsNotNull() {
            addCriterion("product_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeEqualTo(String value) {
            addCriterion("product_type =", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotEqualTo(String value) {
            addCriterion("product_type <>", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThan(String value) {
            addCriterion("product_type >", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type >=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThan(String value) {
            addCriterion("product_type <", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLessThanOrEqualTo(String value) {
            addCriterion("product_type <=", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeLike(String value) {
            addCriterion("product_type like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotLike(String value) {
            addCriterion("product_type not like", value, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeIn(List<String> values) {
            addCriterion("product_type in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotIn(List<String> values) {
            addCriterion("product_type not in", values, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeBetween(String value1, String value2) {
            addCriterion("product_type between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductTypeNotBetween(String value1, String value2) {
            addCriterion("product_type not between", value1, value2, "productType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeIsNull() {
            addCriterion("product_four_type is null");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeIsNotNull() {
            addCriterion("product_four_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeEqualTo(String value) {
            addCriterion("product_four_type =", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeNotEqualTo(String value) {
            addCriterion("product_four_type <>", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeGreaterThan(String value) {
            addCriterion("product_four_type >", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_four_type >=", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeLessThan(String value) {
            addCriterion("product_four_type <", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeLessThanOrEqualTo(String value) {
            addCriterion("product_four_type <=", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeLike(String value) {
            addCriterion("product_four_type like", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeNotLike(String value) {
            addCriterion("product_four_type not like", value, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeIn(List<String> values) {
            addCriterion("product_four_type in", values, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeNotIn(List<String> values) {
            addCriterion("product_four_type not in", values, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeBetween(String value1, String value2) {
            addCriterion("product_four_type between", value1, value2, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductFourTypeNotBetween(String value1, String value2) {
            addCriterion("product_four_type not between", value1, value2, "productFourType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeIsNull() {
            addCriterion("product_three_type is null");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeIsNotNull() {
            addCriterion("product_three_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeEqualTo(String value) {
            addCriterion("product_three_type =", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeNotEqualTo(String value) {
            addCriterion("product_three_type <>", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeGreaterThan(String value) {
            addCriterion("product_three_type >", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_three_type >=", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeLessThan(String value) {
            addCriterion("product_three_type <", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeLessThanOrEqualTo(String value) {
            addCriterion("product_three_type <=", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeLike(String value) {
            addCriterion("product_three_type like", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeNotLike(String value) {
            addCriterion("product_three_type not like", value, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeIn(List<String> values) {
            addCriterion("product_three_type in", values, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeNotIn(List<String> values) {
            addCriterion("product_three_type not in", values, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeBetween(String value1, String value2) {
            addCriterion("product_three_type between", value1, value2, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductThreeTypeNotBetween(String value1, String value2) {
            addCriterion("product_three_type not between", value1, value2, "productThreeType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeIsNull() {
            addCriterion("product_two_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeIsNotNull() {
            addCriterion("product_two_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeEqualTo(String value) {
            addCriterion("product_two_type =", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeNotEqualTo(String value) {
            addCriterion("product_two_type <>", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeGreaterThan(String value) {
            addCriterion("product_two_type >", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_two_type >=", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeLessThan(String value) {
            addCriterion("product_two_type <", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeLessThanOrEqualTo(String value) {
            addCriterion("product_two_type <=", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeLike(String value) {
            addCriterion("product_two_type like", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeNotLike(String value) {
            addCriterion("product_two_type not like", value, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeIn(List<String> values) {
            addCriterion("product_two_type in", values, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeNotIn(List<String> values) {
            addCriterion("product_two_type not in", values, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeBetween(String value1, String value2) {
            addCriterion("product_two_type between", value1, value2, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTwoTypeNotBetween(String value1, String value2) {
            addCriterion("product_two_type not between", value1, value2, "productTwoType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeIsNull() {
            addCriterion("product_top_type is null");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeIsNotNull() {
            addCriterion("product_top_type is not null");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeEqualTo(String value) {
            addCriterion("product_top_type =", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeNotEqualTo(String value) {
            addCriterion("product_top_type <>", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeGreaterThan(String value) {
            addCriterion("product_top_type >", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeGreaterThanOrEqualTo(String value) {
            addCriterion("product_top_type >=", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeLessThan(String value) {
            addCriterion("product_top_type <", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeLessThanOrEqualTo(String value) {
            addCriterion("product_top_type <=", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeLike(String value) {
            addCriterion("product_top_type like", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeNotLike(String value) {
            addCriterion("product_top_type not like", value, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeIn(List<String> values) {
            addCriterion("product_top_type in", values, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeNotIn(List<String> values) {
            addCriterion("product_top_type not in", values, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeBetween(String value1, String value2) {
            addCriterion("product_top_type between", value1, value2, "productTopType");
            return (Criteria) this;
        }

        public Criteria andProductTopTypeNotBetween(String value1, String value2) {
            addCriterion("product_top_type not between", value1, value2, "productTopType");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdIsNull() {
            addCriterion("policy_holder_id is null");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdIsNotNull() {
            addCriterion("policy_holder_id is not null");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdEqualTo(Long value) {
            addCriterion("policy_holder_id =", value, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdNotEqualTo(Long value) {
            addCriterion("policy_holder_id <>", value, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdGreaterThan(Long value) {
            addCriterion("policy_holder_id >", value, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdGreaterThanOrEqualTo(Long value) {
            addCriterion("policy_holder_id >=", value, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdLessThan(Long value) {
            addCriterion("policy_holder_id <", value, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdLessThanOrEqualTo(Long value) {
            addCriterion("policy_holder_id <=", value, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdIn(List<Long> values) {
            addCriterion("policy_holder_id in", values, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdNotIn(List<Long> values) {
            addCriterion("policy_holder_id not in", values, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdBetween(Long value1, Long value2) {
            addCriterion("policy_holder_id between", value1, value2, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andPolicyHolderIdNotBetween(Long value1, Long value2) {
            addCriterion("policy_holder_id not between", value1, value2, "policyHolderId");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeIsNull() {
            addCriterion("beneficiary_type is null");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeIsNotNull() {
            addCriterion("beneficiary_type is not null");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeEqualTo(Integer value) {
            addCriterion("beneficiary_type =", value, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeNotEqualTo(Integer value) {
            addCriterion("beneficiary_type <>", value, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeGreaterThan(Integer value) {
            addCriterion("beneficiary_type >", value, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("beneficiary_type >=", value, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeLessThan(Integer value) {
            addCriterion("beneficiary_type <", value, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeLessThanOrEqualTo(Integer value) {
            addCriterion("beneficiary_type <=", value, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeIn(List<Integer> values) {
            addCriterion("beneficiary_type in", values, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeNotIn(List<Integer> values) {
            addCriterion("beneficiary_type not in", values, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeBetween(Integer value1, Integer value2) {
            addCriterion("beneficiary_type between", value1, value2, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andBeneficiaryTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("beneficiary_type not between", value1, value2, "beneficiaryType");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateIsNull() {
            addCriterion("effective_date is null");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateIsNotNull() {
            addCriterion("effective_date is not null");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateEqualTo(Date value) {
            addCriterionForJDBCDate("effective_date =", value, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("effective_date <>", value, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateGreaterThan(Date value) {
            addCriterionForJDBCDate("effective_date >", value, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("effective_date >=", value, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateLessThan(Date value) {
            addCriterionForJDBCDate("effective_date <", value, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("effective_date <=", value, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateIn(List<Date> values) {
            addCriterionForJDBCDate("effective_date in", values, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("effective_date not in", values, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("effective_date between", value1, value2, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andEffectiveDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("effective_date not between", value1, value2, "effectiveDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodIsNull() {
            addCriterion("guarantee_period is null");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodIsNotNull() {
            addCriterion("guarantee_period is not null");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodEqualTo(Integer value) {
            addCriterion("guarantee_period =", value, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodNotEqualTo(Integer value) {
            addCriterion("guarantee_period <>", value, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodGreaterThan(Integer value) {
            addCriterion("guarantee_period >", value, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodGreaterThanOrEqualTo(Integer value) {
            addCriterion("guarantee_period >=", value, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodLessThan(Integer value) {
            addCriterion("guarantee_period <", value, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodLessThanOrEqualTo(Integer value) {
            addCriterion("guarantee_period <=", value, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodIn(List<Integer> values) {
            addCriterion("guarantee_period in", values, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodNotIn(List<Integer> values) {
            addCriterion("guarantee_period not in", values, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodBetween(Integer value1, Integer value2) {
            addCriterion("guarantee_period between", value1, value2, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodNotBetween(Integer value1, Integer value2) {
            addCriterion("guarantee_period not between", value1, value2, "guaranteePeriod");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitIsNull() {
            addCriterion("guarantee_period_unit is null");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitIsNotNull() {
            addCriterion("guarantee_period_unit is not null");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitEqualTo(Integer value) {
            addCriterion("guarantee_period_unit =", value, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitNotEqualTo(Integer value) {
            addCriterion("guarantee_period_unit <>", value, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitGreaterThan(Integer value) {
            addCriterion("guarantee_period_unit >", value, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitGreaterThanOrEqualTo(Integer value) {
            addCriterion("guarantee_period_unit >=", value, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitLessThan(Integer value) {
            addCriterion("guarantee_period_unit <", value, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitLessThanOrEqualTo(Integer value) {
            addCriterion("guarantee_period_unit <=", value, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitIn(List<Integer> values) {
            addCriterion("guarantee_period_unit in", values, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitNotIn(List<Integer> values) {
            addCriterion("guarantee_period_unit not in", values, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitBetween(Integer value1, Integer value2) {
            addCriterion("guarantee_period_unit between", value1, value2, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteePeriodUnitNotBetween(Integer value1, Integer value2) {
            addCriterion("guarantee_period_unit not between", value1, value2, "guaranteePeriodUnit");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateIsNull() {
            addCriterion("guarantee_end_date is null");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateIsNotNull() {
            addCriterion("guarantee_end_date is not null");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateEqualTo(Date value) {
            addCriterionForJDBCDate("guarantee_end_date =", value, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("guarantee_end_date <>", value, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateGreaterThan(Date value) {
            addCriterionForJDBCDate("guarantee_end_date >", value, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("guarantee_end_date >=", value, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateLessThan(Date value) {
            addCriterionForJDBCDate("guarantee_end_date <", value, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("guarantee_end_date <=", value, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateIn(List<Date> values) {
            addCriterionForJDBCDate("guarantee_end_date in", values, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("guarantee_end_date not in", values, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("guarantee_end_date between", value1, value2, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andGuaranteeEndDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("guarantee_end_date not between", value1, value2, "guaranteeEndDate");
            return (Criteria) this;
        }

        public Criteria andPayCycleIsNull() {
            addCriterion("pay_cycle is null");
            return (Criteria) this;
        }

        public Criteria andPayCycleIsNotNull() {
            addCriterion("pay_cycle is not null");
            return (Criteria) this;
        }

        public Criteria andPayCycleEqualTo(Integer value) {
            addCriterion("pay_cycle =", value, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleNotEqualTo(Integer value) {
            addCriterion("pay_cycle <>", value, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleGreaterThan(Integer value) {
            addCriterion("pay_cycle >", value, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleGreaterThanOrEqualTo(Integer value) {
            addCriterion("pay_cycle >=", value, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleLessThan(Integer value) {
            addCriterion("pay_cycle <", value, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleLessThanOrEqualTo(Integer value) {
            addCriterion("pay_cycle <=", value, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleIn(List<Integer> values) {
            addCriterion("pay_cycle in", values, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleNotIn(List<Integer> values) {
            addCriterion("pay_cycle not in", values, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleBetween(Integer value1, Integer value2) {
            addCriterion("pay_cycle between", value1, value2, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayCycleNotBetween(Integer value1, Integer value2) {
            addCriterion("pay_cycle not between", value1, value2, "payCycle");
            return (Criteria) this;
        }

        public Criteria andPayPeriodIsNull() {
            addCriterion("pay_period is null");
            return (Criteria) this;
        }

        public Criteria andPayPeriodIsNotNull() {
            addCriterion("pay_period is not null");
            return (Criteria) this;
        }

        public Criteria andPayPeriodEqualTo(Integer value) {
            addCriterion("pay_period =", value, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodNotEqualTo(Integer value) {
            addCriterion("pay_period <>", value, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodGreaterThan(Integer value) {
            addCriterion("pay_period >", value, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodGreaterThanOrEqualTo(Integer value) {
            addCriterion("pay_period >=", value, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodLessThan(Integer value) {
            addCriterion("pay_period <", value, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodLessThanOrEqualTo(Integer value) {
            addCriterion("pay_period <=", value, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodIn(List<Integer> values) {
            addCriterion("pay_period in", values, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodNotIn(List<Integer> values) {
            addCriterion("pay_period not in", values, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodBetween(Integer value1, Integer value2) {
            addCriterion("pay_period between", value1, value2, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodNotBetween(Integer value1, Integer value2) {
            addCriterion("pay_period not between", value1, value2, "payPeriod");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitIsNull() {
            addCriterion("pay_period_unit is null");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitIsNotNull() {
            addCriterion("pay_period_unit is not null");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitEqualTo(Integer value) {
            addCriterion("pay_period_unit =", value, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitNotEqualTo(Integer value) {
            addCriterion("pay_period_unit <>", value, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitGreaterThan(Integer value) {
            addCriterion("pay_period_unit >", value, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitGreaterThanOrEqualTo(Integer value) {
            addCriterion("pay_period_unit >=", value, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitLessThan(Integer value) {
            addCriterion("pay_period_unit <", value, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitLessThanOrEqualTo(Integer value) {
            addCriterion("pay_period_unit <=", value, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitIn(List<Integer> values) {
            addCriterion("pay_period_unit in", values, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitNotIn(List<Integer> values) {
            addCriterion("pay_period_unit not in", values, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitBetween(Integer value1, Integer value2) {
            addCriterion("pay_period_unit between", value1, value2, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andPayPeriodUnitNotBetween(Integer value1, Integer value2) {
            addCriterion("pay_period_unit not between", value1, value2, "payPeriodUnit");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumIsNull() {
            addCriterion("single_premium is null");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumIsNotNull() {
            addCriterion("single_premium is not null");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumEqualTo(BigDecimal value) {
            addCriterion("single_premium =", value, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumNotEqualTo(BigDecimal value) {
            addCriterion("single_premium <>", value, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumGreaterThan(BigDecimal value) {
            addCriterion("single_premium >", value, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("single_premium >=", value, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumLessThan(BigDecimal value) {
            addCriterion("single_premium <", value, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumLessThanOrEqualTo(BigDecimal value) {
            addCriterion("single_premium <=", value, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumIn(List<BigDecimal> values) {
            addCriterion("single_premium in", values, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumNotIn(List<BigDecimal> values) {
            addCriterion("single_premium not in", values, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("single_premium between", value1, value2, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andSinglePremiumNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("single_premium not between", value1, value2, "singlePremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumIsNull() {
            addCriterion("total_premium is null");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumIsNotNull() {
            addCriterion("total_premium is not null");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumEqualTo(BigDecimal value) {
            addCriterion("total_premium =", value, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumNotEqualTo(BigDecimal value) {
            addCriterion("total_premium <>", value, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumGreaterThan(BigDecimal value) {
            addCriterion("total_premium >", value, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("total_premium >=", value, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumLessThan(BigDecimal value) {
            addCriterion("total_premium <", value, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumLessThanOrEqualTo(BigDecimal value) {
            addCriterion("total_premium <=", value, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumIn(List<BigDecimal> values) {
            addCriterion("total_premium in", values, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumNotIn(List<BigDecimal> values) {
            addCriterion("total_premium not in", values, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("total_premium between", value1, value2, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andTotalPremiumNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("total_premium not between", value1, value2, "totalPremium");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountIsNull() {
            addCriterion("insured_amount is null");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountIsNotNull() {
            addCriterion("insured_amount is not null");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountEqualTo(BigDecimal value) {
            addCriterion("insured_amount =", value, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountNotEqualTo(BigDecimal value) {
            addCriterion("insured_amount <>", value, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountGreaterThan(BigDecimal value) {
            addCriterion("insured_amount >", value, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("insured_amount >=", value, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountLessThan(BigDecimal value) {
            addCriterion("insured_amount <", value, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("insured_amount <=", value, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountIn(List<BigDecimal> values) {
            addCriterion("insured_amount in", values, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountNotIn(List<BigDecimal> values) {
            addCriterion("insured_amount not in", values, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("insured_amount between", value1, value2, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andInsuredAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("insured_amount not between", value1, value2, "insuredAmount");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberIsNull() {
            addCriterion("pay_card_number is null");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberIsNotNull() {
            addCriterion("pay_card_number is not null");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberEqualTo(String value) {
            addCriterion("pay_card_number =", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberNotEqualTo(String value) {
            addCriterion("pay_card_number <>", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberGreaterThan(String value) {
            addCriterion("pay_card_number >", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberGreaterThanOrEqualTo(String value) {
            addCriterion("pay_card_number >=", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberLessThan(String value) {
            addCriterion("pay_card_number <", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberLessThanOrEqualTo(String value) {
            addCriterion("pay_card_number <=", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberLike(String value) {
            addCriterion("pay_card_number like", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberNotLike(String value) {
            addCriterion("pay_card_number not like", value, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberIn(List<String> values) {
            addCriterion("pay_card_number in", values, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberNotIn(List<String> values) {
            addCriterion("pay_card_number not in", values, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberBetween(String value1, String value2) {
            addCriterion("pay_card_number between", value1, value2, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andPayCardNumberNotBetween(String value1, String value2) {
            addCriterion("pay_card_number not between", value1, value2, "payCardNumber");
            return (Criteria) this;
        }

        public Criteria andBankNameIsNull() {
            addCriterion("bank_name is null");
            return (Criteria) this;
        }

        public Criteria andBankNameIsNotNull() {
            addCriterion("bank_name is not null");
            return (Criteria) this;
        }

        public Criteria andBankNameEqualTo(String value) {
            addCriterion("bank_name =", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameNotEqualTo(String value) {
            addCriterion("bank_name <>", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameGreaterThan(String value) {
            addCriterion("bank_name >", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameGreaterThanOrEqualTo(String value) {
            addCriterion("bank_name >=", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameLessThan(String value) {
            addCriterion("bank_name <", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameLessThanOrEqualTo(String value) {
            addCriterion("bank_name <=", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameLike(String value) {
            addCriterion("bank_name like", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameNotLike(String value) {
            addCriterion("bank_name not like", value, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameIn(List<String> values) {
            addCriterion("bank_name in", values, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameNotIn(List<String> values) {
            addCriterion("bank_name not in", values, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameBetween(String value1, String value2) {
            addCriterion("bank_name between", value1, value2, "bankName");
            return (Criteria) this;
        }

        public Criteria andBankNameNotBetween(String value1, String value2) {
            addCriterion("bank_name not between", value1, value2, "bankName");
            return (Criteria) this;
        }

        public Criteria andHandlerIsNull() {
            addCriterion("`handler` is null");
            return (Criteria) this;
        }

        public Criteria andHandlerIsNotNull() {
            addCriterion("`handler` is not null");
            return (Criteria) this;
        }

        public Criteria andHandlerEqualTo(String value) {
            addCriterion("`handler` =", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerNotEqualTo(String value) {
            addCriterion("`handler` <>", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerGreaterThan(String value) {
            addCriterion("`handler` >", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerGreaterThanOrEqualTo(String value) {
            addCriterion("`handler` >=", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerLessThan(String value) {
            addCriterion("`handler` <", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerLessThanOrEqualTo(String value) {
            addCriterion("`handler` <=", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerLike(String value) {
            addCriterion("`handler` like", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerNotLike(String value) {
            addCriterion("`handler` not like", value, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerIn(List<String> values) {
            addCriterion("`handler` in", values, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerNotIn(List<String> values) {
            addCriterion("`handler` not in", values, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerBetween(String value1, String value2) {
            addCriterion("`handler` between", value1, value2, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerNotBetween(String value1, String value2) {
            addCriterion("`handler` not between", value1, value2, "handler");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneIsNull() {
            addCriterion("handler_phone is null");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneIsNotNull() {
            addCriterion("handler_phone is not null");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneEqualTo(String value) {
            addCriterion("handler_phone =", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneNotEqualTo(String value) {
            addCriterion("handler_phone <>", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneGreaterThan(String value) {
            addCriterion("handler_phone >", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("handler_phone >=", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneLessThan(String value) {
            addCriterion("handler_phone <", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneLessThanOrEqualTo(String value) {
            addCriterion("handler_phone <=", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneLike(String value) {
            addCriterion("handler_phone like", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneNotLike(String value) {
            addCriterion("handler_phone not like", value, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneIn(List<String> values) {
            addCriterion("handler_phone in", values, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneNotIn(List<String> values) {
            addCriterion("handler_phone not in", values, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneBetween(String value1, String value2) {
            addCriterion("handler_phone between", value1, value2, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andHandlerPhoneNotBetween(String value1, String value2) {
            addCriterion("handler_phone not between", value1, value2, "handlerPhone");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("`status` is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("`status` is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("`status` =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("`status` <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("`status` >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("`status` >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("`status` <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("`status` <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("`status` in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("`status` not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("`status` between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("`status` not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("del_flag is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("del_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(Integer value) {
            addCriterion("del_flag =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(Integer value) {
            addCriterion("del_flag <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(Integer value) {
            addCriterion("del_flag >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("del_flag >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(Integer value) {
            addCriterion("del_flag <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(Integer value) {
            addCriterion("del_flag <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<Integer> values) {
            addCriterion("del_flag in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<Integer> values) {
            addCriterion("del_flag not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(Integer value1, Integer value2) {
            addCriterion("del_flag between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("del_flag not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(String value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(String value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(String value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(String value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(String value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(String value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLike(String value) {
            addCriterion("create_by like", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotLike(String value) {
            addCriterion("create_by not like", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<String> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<String> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(String value1, String value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(String value1, String value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(String value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(String value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(String value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(String value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(String value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(String value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLike(String value) {
            addCriterion("update_by like", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotLike(String value) {
            addCriterion("update_by not like", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<String> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<String> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(String value1, String value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(String value1, String value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}