package com.ekangji.policy.infrastructure.dao.productcenter;

import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InsuranceProductBusinessMapper {

    List<InsuranceProductDO> listByProduct(InsuranceProductDO productDO);

    List<InsuranceProductDO> selectProductByCompanyId(InsuranceProductDO insuranceProductDO);

//    List<DismantleProductRecordDO> listDismantleTemplate(InsuranceProductDO productDO);

//    List<TemplateGroupAttrDO> listGroupWithAttrForTemplate(TemplateGroupAttrDO templateGroupAttrDO);
}