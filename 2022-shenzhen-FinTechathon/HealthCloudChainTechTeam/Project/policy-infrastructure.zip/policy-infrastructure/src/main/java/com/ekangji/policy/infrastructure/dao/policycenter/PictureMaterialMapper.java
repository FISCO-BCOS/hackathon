package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PictureMaterialDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PictureMaterialDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PictureMaterialMapper {
    long countByExample(PictureMaterialDOExample example);

    int deleteByExample(PictureMaterialDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PictureMaterialDO record);

    int insertSelective(PictureMaterialDO record);

    List<PictureMaterialDO> selectByExampleWithRowbounds(PictureMaterialDOExample example, RowBounds rowBounds);

    List<PictureMaterialDO> selectByExample(PictureMaterialDOExample example);

    PictureMaterialDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PictureMaterialDO record, @Param("example") PictureMaterialDOExample example);

    int updateByExample(@Param("record") PictureMaterialDO record, @Param("example") PictureMaterialDOExample example);

    int updateByPrimaryKeySelective(PictureMaterialDO record);

    int updateByPrimaryKey(PictureMaterialDO record);

    int batchInsert(@Param("list") List<PictureMaterialDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PictureMaterialDO> recordList);

    PictureMaterialDO selectOneByExample(PictureMaterialDOExample example);
}