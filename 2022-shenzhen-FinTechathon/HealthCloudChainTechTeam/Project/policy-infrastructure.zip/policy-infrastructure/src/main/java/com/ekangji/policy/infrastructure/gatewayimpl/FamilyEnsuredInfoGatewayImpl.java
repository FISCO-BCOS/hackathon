package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.domain.gateway.FamilyEnsuredInfoGateway;
import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.infrastructure.convertor.FamilyEnsuredInfoConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoDO;
import com.ekangji.policy.infrastructure.dao.policycenter.FamilyEnsuredInfoMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Repository
public class FamilyEnsuredInfoGatewayImpl implements FamilyEnsuredInfoGateway {
    @Resource
    private FamilyEnsuredInfoMapper familyEnsuredInfoMapper;
    @Resource
    private FamilyEnsuredInfoConvertor familyEnsuredInfoConvertor;

    @Override
    public Long save(FamilyEnsuredInfo entity) {
        FamilyEnsuredInfoDO familyEnsuredInfoDO = familyEnsuredInfoConvertor.convert(entity);
        familyEnsuredInfoDO.setCreateTime(new Date());
        familyEnsuredInfoDO.setUpdateTime(new Date());
//        familyEnsuredInfoDO.setCreateBy(ShiroUtils.getUserIdStr());
//        familyEnsuredInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        familyEnsuredInfoDO.setStatus(CommonStatusEnum.VALID.getCode());
        familyEnsuredInfoMapper.insertSelective(familyEnsuredInfoDO);
        return familyEnsuredInfoDO.getId();
    }

    @Override
    public int delete(FamilyEnsuredInfo entity) {
        return 0;
    }

    @Override
    public int update(FamilyEnsuredInfo entity) {
        FamilyEnsuredInfoDO familyEnsuredInfoDO = familyEnsuredInfoConvertor.convert(entity);
//        familyEnsuredInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        familyEnsuredInfoDO.setUpdateTime(new Date());
        FamilyEnsuredInfoDOExample example = new FamilyEnsuredInfoDOExample();
        example.createCriteria().andIdEqualTo(entity.getId());
        return familyEnsuredInfoMapper.updateByExampleSelective(familyEnsuredInfoDO,example);
    }

    @Override
    public FamilyEnsuredInfo get(FamilyEnsuredInfo entity) {
        return null;
    }

    @Override
    public List<FamilyEnsuredInfo> list(FamilyEnsuredInfo entity) {
        return null;
    }

    @Override
    public PageInfo<FamilyEnsuredInfo> page(FamilyEnsuredInfo entity) {
        return null;
    }

    @Override
    public PageInfo<FamilyEnsuredInfo> pageList(FamilyEnsuredInfo familyEnsuredInfo) {
        return null;
    }

    @Override
    public FamilyEnsuredInfo selectFamilyByUserId(String userId) {
        FamilyEnsuredInfoDO familyEnsuredInfoDO = familyEnsuredInfoMapper.selectFamilyByUserId(userId);
        return familyEnsuredInfoConvertor.convert(familyEnsuredInfoDO);
    }
}
