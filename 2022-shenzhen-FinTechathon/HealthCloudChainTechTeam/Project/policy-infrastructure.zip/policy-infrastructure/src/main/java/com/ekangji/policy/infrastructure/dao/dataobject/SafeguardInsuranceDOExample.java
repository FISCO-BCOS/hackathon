package com.ekangji.policy.infrastructure.dao.dataobject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SafeguardInsuranceDOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SafeguardInsuranceDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdIsNull() {
            addCriterion("insurance_id is null");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdIsNotNull() {
            addCriterion("insurance_id is not null");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdEqualTo(String value) {
            addCriterion("insurance_id =", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdNotEqualTo(String value) {
            addCriterion("insurance_id <>", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdGreaterThan(String value) {
            addCriterion("insurance_id >", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdGreaterThanOrEqualTo(String value) {
            addCriterion("insurance_id >=", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdLessThan(String value) {
            addCriterion("insurance_id <", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdLessThanOrEqualTo(String value) {
            addCriterion("insurance_id <=", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdLike(String value) {
            addCriterion("insurance_id like", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdNotLike(String value) {
            addCriterion("insurance_id not like", value, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdIn(List<String> values) {
            addCriterion("insurance_id in", values, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdNotIn(List<String> values) {
            addCriterion("insurance_id not in", values, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdBetween(String value1, String value2) {
            addCriterion("insurance_id between", value1, value2, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andInsuranceIdNotBetween(String value1, String value2) {
            addCriterion("insurance_id not between", value1, value2, "insuranceId");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeIsNull() {
            addCriterion("product_type_code is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeIsNotNull() {
            addCriterion("product_type_code is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeEqualTo(String value) {
            addCriterion("product_type_code =", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeNotEqualTo(String value) {
            addCriterion("product_type_code <>", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeGreaterThan(String value) {
            addCriterion("product_type_code >", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeGreaterThanOrEqualTo(String value) {
            addCriterion("product_type_code >=", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeLessThan(String value) {
            addCriterion("product_type_code <", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeLessThanOrEqualTo(String value) {
            addCriterion("product_type_code <=", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeLike(String value) {
            addCriterion("product_type_code like", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeNotLike(String value) {
            addCriterion("product_type_code not like", value, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeIn(List<String> values) {
            addCriterion("product_type_code in", values, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeNotIn(List<String> values) {
            addCriterion("product_type_code not in", values, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeBetween(String value1, String value2) {
            addCriterion("product_type_code between", value1, value2, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeCodeNotBetween(String value1, String value2) {
            addCriterion("product_type_code not between", value1, value2, "productTypeCode");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescIsNull() {
            addCriterion("product_type_desc is null");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescIsNotNull() {
            addCriterion("product_type_desc is not null");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescEqualTo(String value) {
            addCriterion("product_type_desc =", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescNotEqualTo(String value) {
            addCriterion("product_type_desc <>", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescGreaterThan(String value) {
            addCriterion("product_type_desc >", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescGreaterThanOrEqualTo(String value) {
            addCriterion("product_type_desc >=", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescLessThan(String value) {
            addCriterion("product_type_desc <", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescLessThanOrEqualTo(String value) {
            addCriterion("product_type_desc <=", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescLike(String value) {
            addCriterion("product_type_desc like", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescNotLike(String value) {
            addCriterion("product_type_desc not like", value, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescIn(List<String> values) {
            addCriterion("product_type_desc in", values, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescNotIn(List<String> values) {
            addCriterion("product_type_desc not in", values, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescBetween(String value1, String value2) {
            addCriterion("product_type_desc between", value1, value2, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andProductTypeDescNotBetween(String value1, String value2) {
            addCriterion("product_type_desc not between", value1, value2, "productTypeDesc");
            return (Criteria) this;
        }

        public Criteria andParentTypeIsNull() {
            addCriterion("parent_type is null");
            return (Criteria) this;
        }

        public Criteria andParentTypeIsNotNull() {
            addCriterion("parent_type is not null");
            return (Criteria) this;
        }

        public Criteria andParentTypeEqualTo(String value) {
            addCriterion("parent_type =", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeNotEqualTo(String value) {
            addCriterion("parent_type <>", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeGreaterThan(String value) {
            addCriterion("parent_type >", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeGreaterThanOrEqualTo(String value) {
            addCriterion("parent_type >=", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeLessThan(String value) {
            addCriterion("parent_type <", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeLessThanOrEqualTo(String value) {
            addCriterion("parent_type <=", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeLike(String value) {
            addCriterion("parent_type like", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeNotLike(String value) {
            addCriterion("parent_type not like", value, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeIn(List<String> values) {
            addCriterion("parent_type in", values, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeNotIn(List<String> values) {
            addCriterion("parent_type not in", values, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeBetween(String value1, String value2) {
            addCriterion("parent_type between", value1, value2, "parentType");
            return (Criteria) this;
        }

        public Criteria andParentTypeNotBetween(String value1, String value2) {
            addCriterion("parent_type not between", value1, value2, "parentType");
            return (Criteria) this;
        }

        public Criteria andAverValueIsNull() {
            addCriterion("aver_value is null");
            return (Criteria) this;
        }

        public Criteria andAverValueIsNotNull() {
            addCriterion("aver_value is not null");
            return (Criteria) this;
        }

        public Criteria andAverValueEqualTo(Integer value) {
            addCriterion("aver_value =", value, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueNotEqualTo(Integer value) {
            addCriterion("aver_value <>", value, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueGreaterThan(Integer value) {
            addCriterion("aver_value >", value, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueGreaterThanOrEqualTo(Integer value) {
            addCriterion("aver_value >=", value, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueLessThan(Integer value) {
            addCriterion("aver_value <", value, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueLessThanOrEqualTo(Integer value) {
            addCriterion("aver_value <=", value, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueIn(List<Integer> values) {
            addCriterion("aver_value in", values, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueNotIn(List<Integer> values) {
            addCriterion("aver_value not in", values, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueBetween(Integer value1, Integer value2) {
            addCriterion("aver_value between", value1, value2, "averValue");
            return (Criteria) this;
        }

        public Criteria andAverValueNotBetween(Integer value1, Integer value2) {
            addCriterion("aver_value not between", value1, value2, "averValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueIsNull() {
            addCriterion("median_value is null");
            return (Criteria) this;
        }

        public Criteria andMedianValueIsNotNull() {
            addCriterion("median_value is not null");
            return (Criteria) this;
        }

        public Criteria andMedianValueEqualTo(Integer value) {
            addCriterion("median_value =", value, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueNotEqualTo(Integer value) {
            addCriterion("median_value <>", value, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueGreaterThan(Integer value) {
            addCriterion("median_value >", value, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueGreaterThanOrEqualTo(Integer value) {
            addCriterion("median_value >=", value, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueLessThan(Integer value) {
            addCriterion("median_value <", value, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueLessThanOrEqualTo(Integer value) {
            addCriterion("median_value <=", value, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueIn(List<Integer> values) {
            addCriterion("median_value in", values, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueNotIn(List<Integer> values) {
            addCriterion("median_value not in", values, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueBetween(Integer value1, Integer value2) {
            addCriterion("median_value between", value1, value2, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMedianValueNotBetween(Integer value1, Integer value2) {
            addCriterion("median_value not between", value1, value2, "medianValue");
            return (Criteria) this;
        }

        public Criteria andMinValueIsNull() {
            addCriterion("min_value is null");
            return (Criteria) this;
        }

        public Criteria andMinValueIsNotNull() {
            addCriterion("min_value is not null");
            return (Criteria) this;
        }

        public Criteria andMinValueEqualTo(Integer value) {
            addCriterion("min_value =", value, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueNotEqualTo(Integer value) {
            addCriterion("min_value <>", value, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueGreaterThan(Integer value) {
            addCriterion("min_value >", value, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueGreaterThanOrEqualTo(Integer value) {
            addCriterion("min_value >=", value, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueLessThan(Integer value) {
            addCriterion("min_value <", value, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueLessThanOrEqualTo(Integer value) {
            addCriterion("min_value <=", value, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueIn(List<Integer> values) {
            addCriterion("min_value in", values, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueNotIn(List<Integer> values) {
            addCriterion("min_value not in", values, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueBetween(Integer value1, Integer value2) {
            addCriterion("min_value between", value1, value2, "minValue");
            return (Criteria) this;
        }

        public Criteria andMinValueNotBetween(Integer value1, Integer value2) {
            addCriterion("min_value not between", value1, value2, "minValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueIsNull() {
            addCriterion("max_value is null");
            return (Criteria) this;
        }

        public Criteria andMaxValueIsNotNull() {
            addCriterion("max_value is not null");
            return (Criteria) this;
        }

        public Criteria andMaxValueEqualTo(Integer value) {
            addCriterion("max_value =", value, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueNotEqualTo(Integer value) {
            addCriterion("max_value <>", value, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueGreaterThan(Integer value) {
            addCriterion("max_value >", value, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueGreaterThanOrEqualTo(Integer value) {
            addCriterion("max_value >=", value, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueLessThan(Integer value) {
            addCriterion("max_value <", value, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueLessThanOrEqualTo(Integer value) {
            addCriterion("max_value <=", value, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueIn(List<Integer> values) {
            addCriterion("max_value in", values, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueNotIn(List<Integer> values) {
            addCriterion("max_value not in", values, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueBetween(Integer value1, Integer value2) {
            addCriterion("max_value between", value1, value2, "maxValue");
            return (Criteria) this;
        }

        public Criteria andMaxValueNotBetween(Integer value1, Integer value2) {
            addCriterion("max_value not between", value1, value2, "maxValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueIsNull() {
            addCriterion("assign_value is null");
            return (Criteria) this;
        }

        public Criteria andAssignValueIsNotNull() {
            addCriterion("assign_value is not null");
            return (Criteria) this;
        }

        public Criteria andAssignValueEqualTo(Integer value) {
            addCriterion("assign_value =", value, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueNotEqualTo(Integer value) {
            addCriterion("assign_value <>", value, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueGreaterThan(Integer value) {
            addCriterion("assign_value >", value, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueGreaterThanOrEqualTo(Integer value) {
            addCriterion("assign_value >=", value, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueLessThan(Integer value) {
            addCriterion("assign_value <", value, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueLessThanOrEqualTo(Integer value) {
            addCriterion("assign_value <=", value, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueIn(List<Integer> values) {
            addCriterion("assign_value in", values, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueNotIn(List<Integer> values) {
            addCriterion("assign_value not in", values, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueBetween(Integer value1, Integer value2) {
            addCriterion("assign_value between", value1, value2, "assignValue");
            return (Criteria) this;
        }

        public Criteria andAssignValueNotBetween(Integer value1, Integer value2) {
            addCriterion("assign_value not between", value1, value2, "assignValue");
            return (Criteria) this;
        }

        public Criteria andCompareColumnIsNull() {
            addCriterion("compare_column is null");
            return (Criteria) this;
        }

        public Criteria andCompareColumnIsNotNull() {
            addCriterion("compare_column is not null");
            return (Criteria) this;
        }

        public Criteria andCompareColumnEqualTo(Integer value) {
            addCriterion("compare_column =", value, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnNotEqualTo(Integer value) {
            addCriterion("compare_column <>", value, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnGreaterThan(Integer value) {
            addCriterion("compare_column >", value, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnGreaterThanOrEqualTo(Integer value) {
            addCriterion("compare_column >=", value, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnLessThan(Integer value) {
            addCriterion("compare_column <", value, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnLessThanOrEqualTo(Integer value) {
            addCriterion("compare_column <=", value, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnIn(List<Integer> values) {
            addCriterion("compare_column in", values, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnNotIn(List<Integer> values) {
            addCriterion("compare_column not in", values, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnBetween(Integer value1, Integer value2) {
            addCriterion("compare_column between", value1, value2, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andCompareColumnNotBetween(Integer value1, Integer value2) {
            addCriterion("compare_column not between", value1, value2, "compareColumn");
            return (Criteria) this;
        }

        public Criteria andAgeBracketIsNull() {
            addCriterion("age_bracket is null");
            return (Criteria) this;
        }

        public Criteria andAgeBracketIsNotNull() {
            addCriterion("age_bracket is not null");
            return (Criteria) this;
        }

        public Criteria andAgeBracketEqualTo(Integer value) {
            addCriterion("age_bracket =", value, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketNotEqualTo(Integer value) {
            addCriterion("age_bracket <>", value, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketGreaterThan(Integer value) {
            addCriterion("age_bracket >", value, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketGreaterThanOrEqualTo(Integer value) {
            addCriterion("age_bracket >=", value, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketLessThan(Integer value) {
            addCriterion("age_bracket <", value, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketLessThanOrEqualTo(Integer value) {
            addCriterion("age_bracket <=", value, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketIn(List<Integer> values) {
            addCriterion("age_bracket in", values, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketNotIn(List<Integer> values) {
            addCriterion("age_bracket not in", values, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketBetween(Integer value1, Integer value2) {
            addCriterion("age_bracket between", value1, value2, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andAgeBracketNotBetween(Integer value1, Integer value2) {
            addCriterion("age_bracket not between", value1, value2, "ageBracket");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("`status` is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("`status` is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("`status` =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("`status` <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("`status` >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("`status` >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("`status` <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("`status` <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("`status` in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("`status` not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("`status` between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("`status` not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("del_flag is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("del_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(Integer value) {
            addCriterion("del_flag =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(Integer value) {
            addCriterion("del_flag <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(Integer value) {
            addCriterion("del_flag >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("del_flag >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(Integer value) {
            addCriterion("del_flag <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(Integer value) {
            addCriterion("del_flag <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<Integer> values) {
            addCriterion("del_flag in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<Integer> values) {
            addCriterion("del_flag not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(Integer value1, Integer value2) {
            addCriterion("del_flag between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("del_flag not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(String value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(String value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(String value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(String value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(String value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(String value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLike(String value) {
            addCriterion("create_by like", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotLike(String value) {
            addCriterion("create_by not like", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<String> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<String> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(String value1, String value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(String value1, String value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(String value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(String value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(String value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(String value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(String value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(String value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLike(String value) {
            addCriterion("update_by like", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotLike(String value) {
            addCriterion("update_by not like", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<String> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<String> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(String value1, String value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(String value1, String value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}