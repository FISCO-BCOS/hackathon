package com.ekangji.policy.infrastructure.dao.dataobject;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 18:01:14
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class MemberEnsuredInfoBO  implements Serializable {

    private Long memberId;

    private String memberName;

    private Integer channelType;

    private String userId;

    private String userPhoneNumber;

    private Integer familyScore;

    private String relation;

    private Integer policyNum;

    private Date memberCreateTime;

    private Integer memberScore;
}