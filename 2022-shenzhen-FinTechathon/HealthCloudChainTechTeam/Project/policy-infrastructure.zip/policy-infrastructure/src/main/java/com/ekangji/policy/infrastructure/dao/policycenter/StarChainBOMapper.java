package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDO;
import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface StarChainBOMapper extends StarChainMapper {

    void lengthAddOne(StarChainDO starChain);
}