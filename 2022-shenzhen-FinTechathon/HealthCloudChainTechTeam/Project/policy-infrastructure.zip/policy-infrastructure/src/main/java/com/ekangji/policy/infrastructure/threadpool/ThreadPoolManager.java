package com.ekangji.policy.infrastructure.threadpool;



import com.ekangji.policy.common.enums.BizTaskEnum;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * 这个类是管理线程池
 *
 * @author jun.zhang
 * @date 2020/8/23 18:24
 */
public class ThreadPoolManager {
    /**
     * 功能描述:根据任务类型分配线程池
     *
     * @param bizTask :
     * @return : java.util.concurrent.ThreadPoolExecutor
     */
    public static ThreadPoolExecutor getPool(BizTaskEnum bizTask) {
        if (bizTask == null) {
            return null;
        }
        return ThreadPoolConfig.POOL.get(bizTask.getPool());
    }
}
