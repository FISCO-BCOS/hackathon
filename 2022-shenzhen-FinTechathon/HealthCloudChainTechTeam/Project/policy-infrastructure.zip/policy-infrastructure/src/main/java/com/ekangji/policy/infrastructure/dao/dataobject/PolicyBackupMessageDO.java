package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-06-21 16:28:59
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBackupMessageDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long messageId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 发起人ID
     */
    private String launchUserId;

    /**
     * 接收人ID
     */
    private String receiveUserId;

    /**
     * 发起备份时间
     */
    private Date launchTime;

    /**
     * 接收人处理时间
     */
    private Date handleTime;

    /**
     * 状态(1:未处理,2:已接收,3:不接收)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 接收人手机号
     */
    private String receiveUserPhone;

    private static final long serialVersionUID = 1L;


    public enum Column {
        id("id"),
        messageId("message_id"),
        policyId("policy_id"),
        launchUserId("launch_user_id"),
        receiveUserId("receive_user_id"),
        launchTime("launch_time"),
        handleTime("handle_time"),
        status("status"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time"),
        receiveUserPhone("receive_user_phone");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}