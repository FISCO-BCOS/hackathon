package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-08-11 13:48:09
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class DigitalPolicyDO implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 数字保单ID 雪花算法生成
     */
    private Long digitalId;

    /**
     * 星球ID
     */
    private Long starId;

    /**
     * 用户id 业务主键 雪花算法生成
     */
    private String userId;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 保单产品名称
     */
    private String productName;

    /**
     * 序号id 按照产品给出的规则生成
     */
    private String sequence;

    /**
     * 链上hash地址
     */
    private String chainAddr;

    /**
     * 对应oss上的文件ID
     */
    private String fileId;

    /**
     * 链上图片url
     */
    private String pictureUrl;

    /**
     * 该数字保单上的富媒体文字
     */
    private String mediaContent;

    /**
     * 该数字保单上的富媒体图片的文件id 多张的时候 逗号分割存储
     */
    private String mediaImage;

    /**
     * 0禁用 1启用
     */
    private Integer status;

    /**
     * 推荐时间
     */
    private Date recommendTime;

    /**
     * 0不推荐 1推荐
     */
    private Integer recommendFlag;

    /**
     * 0都可见 1仅自己可见
     */
    private Integer selfFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDigitalId() {
        return digitalId;
    }

    public void setDigitalId(Long digitalId) {
        this.digitalId = digitalId;
    }

    public Long getStarId() {
        return starId;
    }

    public void setStarId(Long starId) {
        this.starId = starId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber == null ? null : phoneNumber.trim();
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence == null ? null : sequence.trim();
    }

    public String getChainAddr() {
        return chainAddr;
    }

    public void setChainAddr(String chainAddr) {
        this.chainAddr = chainAddr == null ? null : chainAddr.trim();
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId == null ? null : fileId.trim();
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl == null ? null : pictureUrl.trim();
    }

    public String getMediaContent() {
        return mediaContent;
    }

    public void setMediaContent(String mediaContent) {
        this.mediaContent = mediaContent == null ? null : mediaContent.trim();
    }

    public String getMediaImage() {
        return mediaImage;
    }

    public void setMediaImage(String mediaImage) {
        this.mediaImage = mediaImage == null ? null : mediaImage.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getRecommendTime() {
        return recommendTime;
    }

    public void setRecommendTime(Date recommendTime) {
        this.recommendTime = recommendTime;
    }

    public Integer getRecommendFlag() {
        return recommendFlag;
    }

    public void setRecommendFlag(Integer recommendFlag) {
        this.recommendFlag = recommendFlag;
    }

    public Integer getSelfFlag() {
        return selfFlag;
    }

    public void setSelfFlag(Integer selfFlag) {
        this.selfFlag = selfFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", digitalId=").append(digitalId);
        sb.append(", starId=").append(starId);
        sb.append(", userId=").append(userId);
        sb.append(", phoneNumber=").append(phoneNumber);
        sb.append(", policyId=").append(policyId);
        sb.append(", productName=").append(productName);
        sb.append(", sequence=").append(sequence);
        sb.append(", chainAddr=").append(chainAddr);
        sb.append(", fileId=").append(fileId);
        sb.append(", pictureUrl=").append(pictureUrl);
        sb.append(", mediaContent=").append(mediaContent);
        sb.append(", mediaImage=").append(mediaImage);
        sb.append(", status=").append(status);
        sb.append(", recommendTime=").append(recommendTime);
        sb.append(", recommendFlag=").append(recommendFlag);
        sb.append(", selfFlag=").append(selfFlag);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private DigitalPolicyDO obj;

        public Builder() {
            this.obj = new DigitalPolicyDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder digitalId(Long digitalId) {
            obj.digitalId = digitalId;
            return this;
        }

        public Builder starId(Long starId) {
            obj.starId = starId;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            obj.phoneNumber = phoneNumber;
            return this;
        }

        public Builder policyId(Long policyId) {
            obj.policyId = policyId;
            return this;
        }

        public Builder productName(String productName) {
            obj.productName = productName;
            return this;
        }

        public Builder sequence(String sequence) {
            obj.sequence = sequence;
            return this;
        }

        public Builder chainAddr(String chainAddr) {
            obj.chainAddr = chainAddr;
            return this;
        }

        public Builder fileId(String fileId) {
            obj.fileId = fileId;
            return this;
        }

        public Builder pictureUrl(String pictureUrl) {
            obj.pictureUrl = pictureUrl;
            return this;
        }

        public Builder mediaContent(String mediaContent) {
            obj.mediaContent = mediaContent;
            return this;
        }

        public Builder mediaImage(String mediaImage) {
            obj.mediaImage = mediaImage;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder recommendTime(Date recommendTime) {
            obj.recommendTime = recommendTime;
            return this;
        }

        public Builder recommendFlag(Integer recommendFlag) {
            obj.recommendFlag = recommendFlag;
            return this;
        }

        public Builder selfFlag(Integer selfFlag) {
            obj.selfFlag = selfFlag;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public DigitalPolicyDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        digitalId("digital_id"),
        starId("star_id"),
        userId("user_id"),
        phoneNumber("phone_number"),
        policyId("policy_id"),
        productName("product_name"),
        sequence("sequence"),
        chainAddr("chain_addr"),
        fileId("file_id"),
        pictureUrl("picture_url"),
        mediaContent("media_content"),
        mediaImage("media_image"),
        status("status"),
        recommendTime("recommend_time"),
        recommendFlag("recommend_flag"),
        selfFlag("self_flag"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by"),
        delFlag("del_flag");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}