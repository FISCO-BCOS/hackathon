package com.ekangji.policy.infrastructure.dao.productcenter;

import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InsuranceCompanyMapper {
    long countByExample(InsuranceCompanyDOExample example);

    int deleteByExample(InsuranceCompanyDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(InsuranceCompanyDO record);

    int insertSelective(InsuranceCompanyDO record);

    List<InsuranceCompanyDO> selectByExampleWithRowbounds(InsuranceCompanyDOExample example, RowBounds rowBounds);

    List<InsuranceCompanyDO> selectByExample(InsuranceCompanyDOExample example);

    InsuranceCompanyDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") InsuranceCompanyDO record, @Param("example") InsuranceCompanyDOExample example);

    int updateByExample(@Param("record") InsuranceCompanyDO record, @Param("example") InsuranceCompanyDOExample example);

    int updateByPrimaryKeySelective(InsuranceCompanyDO record);

    int updateByPrimaryKey(InsuranceCompanyDO record);

    int batchInsert(@Param("list") List<InsuranceCompanyDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<InsuranceCompanyDO> recordList);

    InsuranceCompanyDO selectOneByExample(InsuranceCompanyDOExample example);
}