package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.InsuranceInfoGateway;
import com.ekangji.policy.domain.policy.InsuranceInfo;
import com.ekangji.policy.infrastructure.convertor.InsuranceInfoConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceInfoDOExample;
import com.ekangji.policy.infrastructure.dao.primary.InsuranceInfoMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wjx
 * @date 2021/1/17 16:00
 */
@Repository
public class InsuranceInfoGatewayImpl implements InsuranceInfoGateway {

    @Resource
    private InsuranceInfoMapper insuranceInfoMapper;

    @Resource
    private InsuranceInfoConvertor insuranceInfoConvertor;


    @Override
    public Long save(InsuranceInfo entity) {
        return null;
    }

    @Override
    public int delete(InsuranceInfo entity) {
        InsuranceInfoDOExample example = new InsuranceInfoDOExample();
        InsuranceInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andQuotationNoEqualTo(entity.getQuotationNo());
        criteria.andIdNoEqualTo(entity.getIdNo());
        return insuranceInfoMapper.deleteByExample(example);
    }

    @Override
    public int update(InsuranceInfo entity) {
        InsuranceInfoDO convert = insuranceInfoConvertor.convert(entity);
        InsuranceInfoDOExample example = new InsuranceInfoDOExample();
        InsuranceInfoDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(entity.getIdNo())) {
            criteria.andIdNoEqualTo(entity.getIdNo());
        }
        if (StringUtils.isNotBlank(entity.getQuotationNo())) {
            criteria.andQuotationNoEqualTo(entity.getQuotationNo());
        }

        return insuranceInfoMapper.updateByExampleSelective(convert, example);
    }

    @Override
    public InsuranceInfo get(InsuranceInfo entity) {
        return null;
    }

    @Override
    public List<InsuranceInfo> list(InsuranceInfo entity) {
        return null;
    }

    @Override
    public PageInfo<InsuranceInfo> page(InsuranceInfo entity) {
        return null;
    }
}
