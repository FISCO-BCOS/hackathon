package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.util.Date;

/**
 *
 * @author   liuchen
 * @date   2022-05-18 17:00:25
 */
@Data
@ToString(callSuper = true)
public class PolicyBO extends PolicyDO{

    /**
     * 被保人出生日期-起
     */
    private Date insurantBirthdayBegin;

    /**
     * 被保人出生日期-止
     */
    private Date insurantBirthdayEnd;

    /**
     * 被保人id
     */
    private Long  memberId;

    /**
     * 被保人id
     */
    private Long  insurantId;
}
