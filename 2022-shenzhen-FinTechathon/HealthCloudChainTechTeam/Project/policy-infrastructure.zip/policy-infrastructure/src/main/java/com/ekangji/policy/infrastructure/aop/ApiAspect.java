package com.ekangji.policy.infrastructure.aop;

import com.ekangji.common.tool.json.JsonUtil;
import com.ekangji.common.tool.net.ip.IpUtil;
import com.ekangji.policy.infrastructure.utils.ServletUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

/**
 * 接口统一日志
 *
 * @author: zhangjun
 * @create: 2021/11/29 4:35 下午
 */
@Slf4j
@Aspect
@Component
public class ApiAspect {

    @Pointcut("execution(* com.ekangji.policy.web..*.*(..))")
    private void apiAspect() {

    }

    /**
     * 环绕
     *
     * @author jun.zhang
     * @date 2020/10/29 12:01 PM
     */
    @Around("apiAspect()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        Object result = new Object();
        StopWatch watch = new StopWatch();
        watch.start();
        ApiTag apiTag = ((MethodSignature) joinPoint.getSignature()).getMethod().getAnnotation(ApiTag.class);

        if (Objects.isNull(apiTag)){
            result = joinPoint.proceed();
            return result;
        }
        HttpServletRequest request = ServletUtil.getRequest();
        String reqJson = JsonUtil.toJson(joinPoint.getArgs());

        log.info("**************************start**************************");
        log.info("Api Code        : {}", Objects.isNull(apiTag) ? "" : apiTag.code());
        log.info("Api Desc        : {}", Objects.isNull(apiTag) ? "" : apiTag.desc());
        log.info("Request Args    : {}", reqJson);
        log.info("URL             : {}", request.getRequestURL().toString());
        log.info("HTTP Method     : {}", request.getMethod());
        log.info("Class Method    : {}.{}", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
        log.info("IP              : {}", IpUtil.getIpAddr(request));

        try {
            result = joinPoint.proceed();
        } catch (Exception e) {
            log.info("Request ERROR   : {}", e);
            throw e;
        }
        watch.stop();
        log.info("Response Args   : {}", JsonUtil.toJson(result));
        log.info("Time-Consuming  : {} ms", watch.getTotalTimeMillis());
        log.info("***************************end***************************");
        return result;
    }
}
