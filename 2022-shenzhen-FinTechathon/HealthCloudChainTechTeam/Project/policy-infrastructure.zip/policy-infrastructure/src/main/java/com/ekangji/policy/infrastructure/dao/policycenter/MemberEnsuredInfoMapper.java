package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.ekangji.policy.infrastructure.dao.dataobject.*;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface MemberEnsuredInfoMapper {
    long countByExample(MemberEnsuredInfoDOExample example);

    int deleteByExample(MemberEnsuredInfoDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(MemberEnsuredInfoDO record);

    int insertSelective(MemberEnsuredInfoDO record);

    List<MemberEnsuredInfoDO> selectByExampleWithRowbounds(MemberEnsuredInfoDOExample example, RowBounds rowBounds);

    List<MemberEnsuredInfoDO> selectByExample(MemberEnsuredInfoDOExample example);

    MemberEnsuredInfoDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") MemberEnsuredInfoDO record, @Param("example") MemberEnsuredInfoDOExample example);

    int updateByExample(@Param("record") MemberEnsuredInfoDO record, @Param("example") MemberEnsuredInfoDOExample example);

    int updateByPrimaryKeySelective(MemberEnsuredInfoDO record);

    int updateByPrimaryKey(MemberEnsuredInfoDO record);

    int batchInsert(@Param("list") List<MemberEnsuredInfoDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<MemberEnsuredInfoDO> recordList);

    MemberEnsuredInfoDO selectOneByExample(MemberEnsuredInfoDOExample example);

    MemberEnsuredInfoDO selectMemberByMemberId(Long memberId);

    /**
     * 根据条件查询
     * @param dto
     * @return
     */
    List<MemberEnsuredInfoBO> selectByCondition(MemberEnsuredDTO dto);
    /**
     * 通过状态查找
     * @param status
     * @param delFlag
     * @return
     */
    List<MemberEnsuredInfoDO> selectEntityByStatus(@Param("status") Integer status, @Param("delFlag")  Integer delFlag);

    List<MemberEnsuredInfoDO> batchGetMemberList(@Param("memberIds") Long[] memberIds);

}