package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDO;
import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao..li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface StarChainConvertor {

    StarChainDO convert(StarChain param);

    StarChain convert(StarChainDO param);

    List<StarChain> convert(List<StarChainDO> param);

}
