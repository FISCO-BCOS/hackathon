package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.UserStarDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserStarDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface UserStarMapper {
    long countByExample(UserStarDOExample example);

    int deleteByExample(UserStarDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserStarDO record);

    int insertSelective(UserStarDO record);

    List<UserStarDO> selectByExampleWithRowbounds(UserStarDOExample example, RowBounds rowBounds);

    List<UserStarDO> selectByExample(UserStarDOExample example);

    UserStarDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserStarDO record, @Param("example") UserStarDOExample example);

    int updateByExample(@Param("record") UserStarDO record, @Param("example") UserStarDOExample example);

    int updateByPrimaryKeySelective(UserStarDO record);

    int updateByPrimaryKey(UserStarDO record);

    int batchInsert(@Param("list") List<UserStarDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<UserStarDO> recordList);

    UserStarDO selectOneByExample(UserStarDOExample example);
}