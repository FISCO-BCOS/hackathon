package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.PolicyBeneficiaryGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyBeneficiary;
import com.ekangji.policy.infrastructure.convertor.PolicyBeneficiaryConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyBeneficiaryMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Repository
public class PolicyBeneficiaryGatewayImpl implements PolicyBeneficiaryGateway {

    @Resource
    private PolicyBeneficiaryMapper policyBeneficiaryMapper;

    @Resource
    private PolicyBeneficiaryConvertor policyBeneficiaryConvertor;

    @Override
    public Long save(PolicyBeneficiary policyBeneficiary) {
        return null;
    }

    @Override
    public int delete(PolicyBeneficiary policyBeneficiary) {
        PolicyBeneficiaryDOExample example = new PolicyBeneficiaryDOExample();
        PolicyBeneficiaryDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyBeneficiary.getPolicyId());
        return policyBeneficiaryMapper.deleteByExample(example);
    }

    @Override
    public int update(PolicyBeneficiary policyBeneficiary) {
        return 0;
    }

    @Override
    public PolicyBeneficiary get(PolicyBeneficiary policyBeneficiary) {
        return null;
    }

    @Override
    public List<PolicyBeneficiary> list(PolicyBeneficiary policyBeneficiary) {
        List<PolicyBeneficiaryDO> policyDO = this.query(policyBeneficiary);
        if (CollectionUtils.isNotEmpty(policyDO)) {
            return policyBeneficiaryConvertor.convert(policyDO);
        }
        return Collections.emptyList();
    }

    @Override
    public PageInfo<PolicyBeneficiary> page(PolicyBeneficiary policyBeneficiary) {
        return null;
    }

    @Override
    public int batchAdd(List<PolicyBeneficiary> beneficiaryList) {
        int num = 0;
        for (PolicyBeneficiary pb : beneficiaryList) {
            PolicyBeneficiaryDO pbdo = policyBeneficiaryConvertor.convert(pb);
            int tmp = policyBeneficiaryMapper.insertSelective(pbdo);
            num = num + tmp;
        }
        return num;
//        List<PolicyBeneficiaryDO> pbDOList = beneficiaryList.parallelStream().map(b ->{
//           return policyBeneficiaryConvertor.convert(b);
//        }).collect(Collectors.toList());
//        return policyBeneficiaryMapper.batchInsert(pbDOList);

    }

    @Override
    public PolicyBeneficiary selectEntityByMemberId(Long memberId) {
        PolicyBeneficiaryDOExample example = new PolicyBeneficiaryDOExample();
        PolicyBeneficiaryDOExample.Criteria criteria = example.createCriteria();
        criteria.andMemberIdEqualTo(memberId);
        PolicyBeneficiaryDO policyBeneficiaryDO = policyBeneficiaryMapper.selectOneByExample(example);
        if(Objects.nonNull(policyBeneficiaryDO)){
            return policyBeneficiaryConvertor.convert(policyBeneficiaryDO);
        }
        return null;
    }

    private List<PolicyBeneficiaryDO> query(PolicyBeneficiary policyBeneficiary) {
        PolicyBeneficiaryDOExample example = new PolicyBeneficiaryDOExample();
        PolicyBeneficiaryDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(policyBeneficiary.getPolicyId())) {
            criteria.andPolicyIdEqualTo(policyBeneficiary.getPolicyId());
        }
        return policyBeneficiaryMapper.selectByExample(example);
    }
}
