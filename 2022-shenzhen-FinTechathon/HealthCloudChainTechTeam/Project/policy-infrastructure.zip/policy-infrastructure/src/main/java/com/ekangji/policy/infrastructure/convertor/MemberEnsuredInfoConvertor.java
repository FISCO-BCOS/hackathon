package com.ekangji.policy.infrastructure.convertor;


import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoBO;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 * @author sunqihua
 * @date 2022-05-22 14:05:49
 */
@Mapper(componentModel = "spring")
public interface MemberEnsuredInfoConvertor {

    MemberEnsuredInfo convert(MemberEnsuredInfoDO memberEnsuredInfoDO);

    MemberEnsuredInfoDO convert(MemberEnsuredInfo memberEnsuredInfo);

    List<MemberEnsuredInfo> convert(List<MemberEnsuredInfoDO> param);

    List<MemberEnsuredInfo> convert2DTO(List<MemberEnsuredInfoBO> param);

    PageInfo<MemberEnsuredInfo> convert2DTO(PageInfo<MemberEnsuredInfoBO> param);


}
