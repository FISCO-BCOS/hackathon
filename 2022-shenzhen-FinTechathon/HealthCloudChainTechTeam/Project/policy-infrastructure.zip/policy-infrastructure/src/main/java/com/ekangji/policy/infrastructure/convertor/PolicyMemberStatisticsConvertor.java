package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/23 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyMemberStatisticsConvertor {

    PolicyMemberStatisticsBO convert(PolicyMemberStatistics param);

    PolicyMemberStatisticsDO convert2(PolicyMemberStatistics param);

    PolicyMemberStatistics convert(PolicyMemberStatisticsDO param);

    PolicyMemberStatistics convert(PolicyMemberStatisticsBO param);

    List<PolicyMemberStatistics> convert(List<PolicyMemberStatisticsBO> param);

    List<PolicyMemberStatistics> convertT(List<PolicyMemberStatisticsDO> param);

}
