package com.ekangji.policy.infrastructure.dao.primary;

import com.ekangji.policy.infrastructure.dao.dataobject.DictTypeDO;
import com.ekangji.policy.infrastructure.dao.dataobject.DictTypeDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface DictTypeMapper {
    long countByExample(DictTypeDOExample example);

    int deleteByExample(DictTypeDOExample example);

    int deleteByPrimaryKey(Long dictId);

    int insert(DictTypeDO record);

    int insertSelective(DictTypeDO record);

    List<DictTypeDO> selectByExampleWithRowbounds(DictTypeDOExample example, RowBounds rowBounds);

    List<DictTypeDO> selectByExample(DictTypeDOExample example);

    DictTypeDO selectByPrimaryKey(Long dictId);

    int updateByExampleSelective(@Param("record") DictTypeDO record, @Param("example") DictTypeDOExample example);

    int updateByExample(@Param("record") DictTypeDO record, @Param("example") DictTypeDOExample example);

    int updateByPrimaryKeySelective(DictTypeDO record);

    int updateByPrimaryKey(DictTypeDO record);
}