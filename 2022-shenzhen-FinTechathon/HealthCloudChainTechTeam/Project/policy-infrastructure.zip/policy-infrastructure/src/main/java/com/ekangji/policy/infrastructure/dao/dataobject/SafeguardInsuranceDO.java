package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-05-24 13:55:36
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class SafeguardInsuranceDO implements Serializable {
    /**
     * 自增id
     */
    private Long id;

    /**
     * 保险业务id
     */
    private String insuranceId;

    /**
     * 产品类别编码
     */
    private String productTypeCode;

    /**
     * 产品类别描述
     */
    private String productTypeDesc;

    /**
     * 父类别编码
     */
    private String parentType;

    /**
     * 用户均值
     */
    private Integer averValue;

    /**
     * 中位数值
     */
    private Integer medianValue;

    /**
     * 最小值
     */
    private Integer minValue;

    /**
     * 最大值
     */
    private Integer maxValue;

    /**
     * 指定值
     */
    private Integer assignValue;

    /**
     * 对比列 1：用户均值，2：中位数值，3:指定值
     */
    private Integer compareColumn;

    /**
     * 年龄段
     */
    private Integer ageBracket;

    /**
     * 状态  0：无效 1:有效
     */
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 更新人
     */
    private String updateBy;

    private static final long serialVersionUID = 1L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", insuranceId=").append(insuranceId);
        sb.append(", productTypeCode=").append(productTypeCode);
        sb.append(", productTypeDesc=").append(productTypeDesc);
        sb.append(", parentType=").append(parentType);
        sb.append(", averValue=").append(averValue);
        sb.append(", medianValue=").append(medianValue);
        sb.append(", minValue=").append(minValue);
        sb.append(", maxValue=").append(maxValue);
        sb.append(", assignValue=").append(assignValue);
        sb.append(", compareColumn=").append(compareColumn);
        sb.append(", ageBracket=").append(ageBracket);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private SafeguardInsuranceDO obj;

        public Builder() {
            this.obj = new SafeguardInsuranceDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder insuranceId(String insuranceId) {
            obj.insuranceId = insuranceId;
            return this;
        }

        public Builder productTypeCode(String productTypeCode) {
            obj.productTypeCode = productTypeCode;
            return this;
        }

        public Builder productTypeDesc(String productTypeDesc) {
            obj.productTypeDesc = productTypeDesc;
            return this;
        }

        public Builder parentType(String parentType) {
            obj.parentType = parentType;
            return this;
        }

        public Builder averValue(Integer averValue) {
            obj.averValue = averValue;
            return this;
        }

        public Builder medianValue(Integer medianValue) {
            obj.medianValue = medianValue;
            return this;
        }

        public Builder minValue(Integer minValue) {
            obj.minValue = minValue;
            return this;
        }

        public Builder maxValue(Integer maxValue) {
            obj.maxValue = maxValue;
            return this;
        }

        public Builder assignValue(Integer assignValue) {
            obj.assignValue = assignValue;
            return this;
        }

        public Builder compareColumn(Integer compareColumn) {
            obj.compareColumn = compareColumn;
            return this;
        }

        public Builder ageBracket(Integer ageBracket) {
            obj.ageBracket = ageBracket;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public SafeguardInsuranceDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        insuranceId("insurance_id"),
        productTypeCode("product_type_code"),
        productTypeDesc("product_type_desc"),
        parentType("parent_type"),
        averValue("aver_value"),
        medianValue("median_value"),
        minValue("min_value"),
        maxValue("max_value"),
        assignValue("assign_value"),
        compareColumn("compare_column"),
        ageBracket("age_bracket"),
        status("status"),
        delFlag("del_flag"),
        createTime("create_time"),
        updateTime("update_time"),
        createBy("create_by"),
        updateBy("update_by");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}