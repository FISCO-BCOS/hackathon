package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PolicyPayDetailBOMapper extends PolicyPayDetailMapper {

    int batchSave(@Param("list") List<PolicyPayDetailBO> list);

    /**
     * 计算保单今年保费
     * @param param
     * @return
     */
    PolicyPayDetailBO countCurrentYearPremiumByPolicy(PolicyPayDetailBO param);

    /**
     * 计算保单总保费
     * @param param
     * @return
     */
    PolicyPayDetailBO countTotalPremiumByPolicy(PolicyPayDetailBO param);
}