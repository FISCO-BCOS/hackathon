package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupRecordDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupRecordDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyBackupRecordMapper {
    long countByExample(PolicyBackupRecordDOExample example);

    int deleteByExample(PolicyBackupRecordDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyBackupRecordDO record);

    int insertSelective(PolicyBackupRecordDO record);

    List<PolicyBackupRecordDO> selectByExampleWithRowbounds(PolicyBackupRecordDOExample example, RowBounds rowBounds);

    List<PolicyBackupRecordDO> selectByExample(PolicyBackupRecordDOExample example);

    PolicyBackupRecordDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyBackupRecordDO record, @Param("example") PolicyBackupRecordDOExample example);

    int updateByExample(@Param("record") PolicyBackupRecordDO record, @Param("example") PolicyBackupRecordDOExample example);

    int updateByPrimaryKeySelective(PolicyBackupRecordDO record);

    int updateByPrimaryKey(PolicyBackupRecordDO record);

    int batchInsert(@Param("list") List<PolicyBackupRecordDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyBackupRecordDO> recordList);

    PolicyBackupRecordDO selectOneByExample(PolicyBackupRecordDOExample example);
}