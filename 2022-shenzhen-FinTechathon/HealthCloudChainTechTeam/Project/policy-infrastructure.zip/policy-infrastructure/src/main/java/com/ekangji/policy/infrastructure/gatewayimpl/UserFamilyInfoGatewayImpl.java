package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.UserFamilyInfoGateway;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.infrastructure.convertor.UserFamilyInfoConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDO;
import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.UserFamilyInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserFamilyInfoDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.UserFamilyInfoMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Repository
public class UserFamilyInfoGatewayImpl implements UserFamilyInfoGateway {
    @Resource
    private UserFamilyInfoMapper userFamilyInfoMapper;
    @Resource
    private UserFamilyInfoConvertor userFamilyInfoConvertor;

    @Override
    public UserFamilyInfo selectEntityByMemberId(Long memberId) {
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoMapper.selectEntityByMemberId(memberId);
        return userFamilyInfoConvertor.convert(userFamilyInfoDO);
    }

    @Override
    public List<UserFamilyInfo> selectListByUserId(String userId) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andBelongUserIdEqualTo(userId);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("create_time desc");
        List<UserFamilyInfoDO> userFamilyInfoDOS = userFamilyInfoMapper.selectByExample(example);
        return userFamilyInfoConvertor.convert(userFamilyInfoDOS);
    }

    @Override
    public UserFamilyInfo selectEntityByUserIdAndName(String userId, String nickName) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andBelongUserIdEqualTo(userId);
        criteria.andNickNameEqualTo(nickName);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoMapper.selectOneByExample(example);
        return userFamilyInfoConvertor.convert(userFamilyInfoDO);
    }

    @Override
    public UserFamilyInfo selectEntityByUserIdAndRelation(String userId, Integer relation) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andBelongUserIdEqualTo(userId);
        criteria.andRelationEqualTo(relation);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoMapper.selectOneByExample(example);
        return userFamilyInfoConvertor.convert(userFamilyInfoDO);
    }

    @Override
    public UserFamilyInfo selectEntityByCard(String userId, Integer identityCardType, String identityCardNumber) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andBelongUserIdEqualTo(userId);
        criteria.andIdentityCardTypeEqualTo(identityCardType);
        criteria.andIdentityCardNumberEqualTo(identityCardNumber);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoMapper.selectOneByExample(example);
        return userFamilyInfoConvertor.convert(userFamilyInfoDO);
    }

    @Override
    public Long save(UserFamilyInfo userFamilyInfo) {
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoConvertor.convert(userFamilyInfo);
        userFamilyInfoDO.setCreateTime(new Date());
        userFamilyInfoDO.setUpdateTime(new Date());
//        userFamilyInfoDO.setCreateBy(ShiroUtils.getUserIdStr());
//        userFamilyInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        userFamilyInfoDO.setStatus(CommonStatusEnum.VALID.getCode());
        userFamilyInfoMapper.insertSelective(userFamilyInfoDO);
        return userFamilyInfoDO.getMemberId();
    }

    @Override
    public int delete(UserFamilyInfo userFamilyInfo) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andMemberIdEqualTo(userFamilyInfo.getMemberId());
        return userFamilyInfoMapper.deleteByExample(example);
    }

    @Override
    public int update(UserFamilyInfo userFamilyInfo) {
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoConvertor.convert(userFamilyInfo);
        userFamilyInfoDO.setUpdateTime(new Date());
//        userFamilyInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andMemberIdEqualTo(userFamilyInfo.getMemberId());
        return userFamilyInfoMapper.updateByExampleSelective(userFamilyInfoDO, example);
    }

    @Override
    public UserFamilyInfo get(UserFamilyInfo userFamilyInfo) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andMemberIdEqualTo(userFamilyInfo.getMemberId());
        UserFamilyInfoDO userFamilyInfoDO = userFamilyInfoMapper.selectOneByExample(example);
        if (Objects.nonNull(userFamilyInfoDO)) {
            return userFamilyInfoConvertor.convert(userFamilyInfoDO);
        }
        return null;
    }

    @Override
    public List<UserFamilyInfo> list(UserFamilyInfo userFamilyInfo) {
        List<UserFamilyInfoDO> UserFamilyInfoDOList = this.query(userFamilyInfo);
        if (CollectionUtils.isNotEmpty(UserFamilyInfoDOList)){
            return userFamilyInfoConvertor.convert(UserFamilyInfoDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<UserFamilyInfo> page(UserFamilyInfo userFamilyInfo) {
        return null;
    }

    private List<UserFamilyInfoDO> query(UserFamilyInfo userFamilyInfo) {
        UserFamilyInfoDOExample example = new UserFamilyInfoDOExample();
        UserFamilyInfoDOExample.Criteria criteria = example.createCriteria();

        // 根据memberId数组查询
        if(CollectionUtils.isNotEmpty(userFamilyInfo.getMemberIds())){
            criteria.andMemberIdIn(userFamilyInfo.getMemberIds());
        }
        if(StringUtils.isNotEmpty(userFamilyInfo.getBelongUserId())) {
            criteria.andBelongUserIdEqualTo(userFamilyInfo.getBelongUserId());
        }
        if(StringUtils.isNotEmpty(userFamilyInfo.getName())) {
            criteria.andNameEqualTo(userFamilyInfo.getName());
        }
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        return userFamilyInfoMapper.selectByExample(example);
    }
}
