package com.ekangji.policy.infrastructure.utils;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.ekangji.user.center.common.constant.Constants;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;


import java.io.IOException;
import java.util.Map;
import java.util.Objects;

/**
 * @className: HttpUtil
 * @program: property-admin-old
 * @description: http请求
 * @author: sunqihua
 * @create: 2022-05-13 20:08
 */
@Slf4j
public class HttpUtil {

    public static String post(String url, String params) throws IOException {
        // 设置请求参数类型，准备好请求参数body
        MediaType type = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(type, params);

        // 创建client
        OkHttpClient client = new OkHttpClient();
        // 创建请求
        Request req = new Request.Builder().url(url).post(body).build();
        // 使用client 发送请求
        Response rsp = client.newCall(req).execute();
        System.out.println("响应码：" + rsp.code());
        System.out.println("响应头：" + rsp.headers());
        return Objects.requireNonNull(rsp.body()).string();
    }

    public static HttpResponse httpPost(String url, String param, Map<String, String> headers){
        HttpResponse response = null;
        HttpRequest httpRequest = HttpRequest.post(url);
        if(StringUtils.isNotEmpty(param)) {
            httpRequest.body(param);
        }
        if(Objects.nonNull(headers)) {
            httpRequest.addHeaders(headers);
        }
        try{
            response = httpRequest.timeout(Constants.TIME_OUT).execute();
        } catch (Exception e) {
            log.error("url:{},调用三方异常",url,e);
        }
        return response;
    }
}
