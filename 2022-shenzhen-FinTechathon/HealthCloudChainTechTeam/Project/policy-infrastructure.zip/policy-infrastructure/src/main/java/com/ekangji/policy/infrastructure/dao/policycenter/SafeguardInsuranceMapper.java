package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardInsuranceDO;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardInsuranceDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface SafeguardInsuranceMapper {
    long countByExample(SafeguardInsuranceDOExample example);

    int deleteByExample(SafeguardInsuranceDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SafeguardInsuranceDO record);

    int insertSelective(SafeguardInsuranceDO record);

    List<SafeguardInsuranceDO> selectByExampleWithRowbounds(SafeguardInsuranceDOExample example, RowBounds rowBounds);

    List<SafeguardInsuranceDO> selectByExample(SafeguardInsuranceDOExample example);

    SafeguardInsuranceDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SafeguardInsuranceDO record, @Param("example") SafeguardInsuranceDOExample example);

    int updateByExample(@Param("record") SafeguardInsuranceDO record, @Param("example") SafeguardInsuranceDOExample example);

    int updateByPrimaryKeySelective(SafeguardInsuranceDO record);

    int updateByPrimaryKey(SafeguardInsuranceDO record);

    int batchInsert(@Param("list") List<SafeguardInsuranceDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<SafeguardInsuranceDO> recordList);

    SafeguardInsuranceDO selectOneByExample(SafeguardInsuranceDOExample example);
}