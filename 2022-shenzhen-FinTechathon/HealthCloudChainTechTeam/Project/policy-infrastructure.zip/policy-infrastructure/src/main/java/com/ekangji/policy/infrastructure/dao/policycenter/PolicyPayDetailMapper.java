package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface PolicyPayDetailMapper {
    long countByExample(PolicyPayDetailDOExample example);

    int deleteByExample(PolicyPayDetailDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyPayDetailDO record);

    int insertSelective(PolicyPayDetailDO record);

    List<PolicyPayDetailDO> selectByExampleWithRowbounds(PolicyPayDetailDOExample example, RowBounds rowBounds);

    List<PolicyPayDetailDO> selectByExample(PolicyPayDetailDOExample example);

    PolicyPayDetailDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyPayDetailDO record, @Param("example") PolicyPayDetailDOExample example);

    int updateByExample(@Param("record") PolicyPayDetailDO record, @Param("example") PolicyPayDetailDOExample example);

    int updateByPrimaryKeySelective(PolicyPayDetailDO record);

    int updateByPrimaryKey(PolicyPayDetailDO record);

    int batchInsert(@Param("list") List<PolicyPayDetailDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyPayDetailDO> recordList);

    PolicyPayDetailDO selectOneByExample(PolicyPayDetailDOExample example);
}