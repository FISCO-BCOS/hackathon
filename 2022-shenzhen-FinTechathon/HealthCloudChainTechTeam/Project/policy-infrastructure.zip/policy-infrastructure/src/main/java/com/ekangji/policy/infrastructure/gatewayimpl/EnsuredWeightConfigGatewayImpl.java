package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonIfEnum;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.ProductDictEnum;
import com.ekangji.policy.common.enums.ScoreTypeEnum;
import com.ekangji.policy.domain.gateway.EnsuredWeightConfigGateway;
import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.ekangji.policy.infrastructure.convertor.EnsuredWeightConfigConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.EnsuredWeightConfigMapper;
import com.ekangji.policy.infrastructure.dao.productcenter.InsuranceProductDictMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Repository
public class EnsuredWeightConfigGatewayImpl implements EnsuredWeightConfigGateway {
    @Resource
    private EnsuredWeightConfigMapper ensuredWeightConfigMapper;
    @Resource
    private InsuranceProductDictMapper insuranceProductDictMapper;
    @Resource
    private EnsuredWeightConfigConvertor ensuredWeightConfigConvertor;

    @Override
    public Long save(EnsuredWeightConfig entity) {
        return null;
    }

    @Override
    public int delete(EnsuredWeightConfig entity) {
        return 0;
    }

    @Override
    public int update(EnsuredWeightConfig entity) {
        return 0;
    }

    @Override
    public EnsuredWeightConfig get(EnsuredWeightConfig entity) {
        return null;
    }

    @Override
    public List<EnsuredWeightConfig> list(EnsuredWeightConfig entity) {
        return null;
    }

    @Override
    public PageInfo<EnsuredWeightConfig> page(EnsuredWeightConfig entity) {
        return null;
    }

    @Override
    public PageInfo<EnsuredWeightConfig> pageList(EnsuredWeightConfig ensuredWeightConfig) {
        return null;
    }

    @Override
    public EnsuredWeightConfig selectEntityByLevelType(String programName) {
        EnsuredWeightConfigDO ensuredWeightConfigDO = ensuredWeightConfigMapper.selectEntityByLevelType(programName);
        return ensuredWeightConfigConvertor.convert(ensuredWeightConfigDO);
    }

    @Override
    public int batchUpdate(List<EnsuredWeightConfig> list) {
        List<EnsuredWeightConfigDO> ensuredWeightConfigDOS = ensuredWeightConfigConvertor.convert2DO(list);
        ensuredWeightConfigDOS.forEach(rule -> {
            rule.setCreateBy(ShiroUtils.getUserIdStr());
            rule.setUpdateBy(ShiroUtils.getUserIdStr());
            rule.setCreateTime(new Date());
            rule.setUpdateTime(new Date());
            rule.setStatus(CommonStatusEnum.VALID.getCode());
            rule.setDelFlag(CommonIfEnum.YES.getCode());
        });
        return ensuredWeightConfigMapper.batchUpdate(ensuredWeightConfigDOS);
    }

    @Override
    public int batchInsert(List<EnsuredWeightConfig> list) {
        List<EnsuredWeightConfigDO> ensuredReadConfigDOS = ensuredWeightConfigConvertor.convert2DO(list);
        ensuredReadConfigDOS.forEach(x -> {
            x.setFirstLevelName(Objects.requireNonNull(ScoreTypeEnum.getMsgByCode(x.getOneLevelType())).getMsg());
            x.setProgramName(this.getProgramName(x.getOneLevelType()));
            x.setStatus(CommonStatusEnum.VALID.getCode());
            x.setCreateTime(new Date());
            x.setUpdateTime(new Date());
            x.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        });
        return ensuredWeightConfigMapper.batchInsert(ensuredReadConfigDOS);
    }

    private String getProgramName(String dictValue) {
        InsuranceProductDictDOExample example = new InsuranceProductDictDOExample();
        // 默认查询父级
        example.setOrderByClause("sort asc");
        example.createCriteria().andDictTypeEqualTo(ProductDictEnum.PRODUCT_TYPE.getCode())
                .andDictValueEqualTo(dictValue)
                .andParentIdEqualTo(0L);
        InsuranceProductDictDO insuranceProductDictDO = insuranceProductDictMapper.selectOneByExample(example);
        if (Optional.ofNullable(insuranceProductDictDO).isPresent()) {
            return insuranceProductDictDO.getDictName();
        }
        return Objects.requireNonNull(ScoreTypeEnum.getMsgByCode(dictValue)).getMsg();
    }

    @Override
    public int batchDelete() {
        List<EnsuredWeightConfig> ensuredReadConfigs = this.selectWeightList();
        if (CollectionUtils.isNotEmpty(ensuredReadConfigs)) {
            return ensuredWeightConfigMapper.batchDelete(ensuredReadConfigs.stream().map(EnsuredWeightConfig::getId).toArray(Long[]::new));
        }
        return 0;
    }

    @Override
    public List<EnsuredWeightConfig> selectWeightList() {
        EnsuredWeightConfigDOExample example = new EnsuredWeightConfigDOExample();
        EnsuredWeightConfigDOExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        List<EnsuredWeightConfigDO> ensuredWeightConfigDOS = ensuredWeightConfigMapper.selectByExample(example);
        return ensuredWeightConfigConvertor.convert(ensuredWeightConfigDOS);

    }
}
