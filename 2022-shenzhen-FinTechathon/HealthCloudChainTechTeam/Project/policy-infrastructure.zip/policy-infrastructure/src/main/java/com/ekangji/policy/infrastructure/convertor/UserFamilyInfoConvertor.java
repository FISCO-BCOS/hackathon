package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.infrastructure.dao.dataobject.UserFamilyInfoDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 家庭数据转换
 *
 * @author: wjx
 * @create: 2021/12/14 9:20 上午
 */
@Mapper(componentModel = "spring")
public interface UserFamilyInfoConvertor {

    UserFamilyInfo convert(UserFamilyInfoDO userFamilyInfoDO);

    UserFamilyInfoDO convert(UserFamilyInfo userFamilyInfo);

    List<UserFamilyInfo> convert(List<UserFamilyInfoDO> param);



}
