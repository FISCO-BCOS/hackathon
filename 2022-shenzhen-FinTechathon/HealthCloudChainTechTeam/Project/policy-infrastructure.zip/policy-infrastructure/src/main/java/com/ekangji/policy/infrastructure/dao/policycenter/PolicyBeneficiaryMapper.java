package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBeneficiaryDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBeneficiaryDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyBeneficiaryMapper {
    long countByExample(PolicyBeneficiaryDOExample example);

    int deleteByExample(PolicyBeneficiaryDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyBeneficiaryDO record);

    int insertSelective(PolicyBeneficiaryDO record);

    List<PolicyBeneficiaryDO> selectByExampleWithRowbounds(PolicyBeneficiaryDOExample example, RowBounds rowBounds);

    List<PolicyBeneficiaryDO> selectByExample(PolicyBeneficiaryDOExample example);

    PolicyBeneficiaryDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyBeneficiaryDO record, @Param("example") PolicyBeneficiaryDOExample example);

    int updateByExample(@Param("record") PolicyBeneficiaryDO record, @Param("example") PolicyBeneficiaryDOExample example);

    int updateByPrimaryKeySelective(PolicyBeneficiaryDO record);

    int updateByPrimaryKey(PolicyBeneficiaryDO record);

    int batchInsert(@Param("list") List<PolicyBeneficiaryDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyBeneficiaryDO> recordList);

    PolicyBeneficiaryDO selectOneByExample(PolicyBeneficiaryDOExample example);
}