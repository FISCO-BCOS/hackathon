package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyMemberStatisticsMapper {
    long countByExample(PolicyMemberStatisticsDOExample example);

    int deleteByExample(PolicyMemberStatisticsDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyMemberStatisticsDO record);

    int insertSelective(PolicyMemberStatisticsDO record);

    List<PolicyMemberStatisticsDO> selectByExampleWithRowbounds(PolicyMemberStatisticsDOExample example, RowBounds rowBounds);

    List<PolicyMemberStatisticsDO> selectByExample(PolicyMemberStatisticsDOExample example);

    PolicyMemberStatisticsDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyMemberStatisticsDO record, @Param("example") PolicyMemberStatisticsDOExample example);

    int updateByExample(@Param("record") PolicyMemberStatisticsDO record, @Param("example") PolicyMemberStatisticsDOExample example);

    int updateByPrimaryKeySelective(PolicyMemberStatisticsDO record);

    int updateByPrimaryKey(PolicyMemberStatisticsDO record);

    int batchInsert(@Param("list") List<PolicyMemberStatisticsDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyMemberStatisticsDO> recordList);

    PolicyMemberStatisticsDO selectOneByExample(PolicyMemberStatisticsDOExample example);
}