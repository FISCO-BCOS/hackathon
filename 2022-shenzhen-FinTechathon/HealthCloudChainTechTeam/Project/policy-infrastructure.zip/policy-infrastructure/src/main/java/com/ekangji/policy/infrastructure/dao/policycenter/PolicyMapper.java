package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyMapper {
    long countByExample(PolicyDOExample example);

    int deleteByExample(PolicyDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyDO record);

    int insertSelective(PolicyDO record);

    List<PolicyDO> selectByExampleWithRowbounds(PolicyDOExample example, RowBounds rowBounds);

    List<PolicyDO> selectByExample(PolicyDOExample example);

    PolicyDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyDO record, @Param("example") PolicyDOExample example);

    int updateByExample(@Param("record") PolicyDO record, @Param("example") PolicyDOExample example);

    int updateByPrimaryKeySelective(PolicyDO record);

    int updateByPrimaryKey(PolicyDO record);

    int batchInsert(@Param("list") List<PolicyDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyDO> recordList);

    PolicyDO selectOneByExample(PolicyDOExample example);
}