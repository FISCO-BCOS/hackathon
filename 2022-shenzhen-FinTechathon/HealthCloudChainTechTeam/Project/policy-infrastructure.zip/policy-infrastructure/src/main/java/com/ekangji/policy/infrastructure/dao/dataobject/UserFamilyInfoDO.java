package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-05-31 11:06:20
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class UserFamilyInfoDO implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 成员id
     */
    private Long memberId;

    /**
     * 该成员所属用户id 业务主键 雪花算法生成
     */
    private String belongUserId;

    /**
     * 用户昵称
     */
    private String nickName;

    /**
     * 关系0本人 1 伴侣 2孩子 3爸爸 4妈妈 5兄弟姐妹 6祖父 7祖母 8其他
     */
    private Integer relation;

    /**
     * 渠道标识 0微信小程序 1抖音小程序
     */
    private Integer channelType;

    /**
     * 用户真实名称
     */
    private String name;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 所属用户手机号
     */
    private String userPhoneNumber;

    /**
     * 有无社保 0 无 1有
     */
    private Integer socialSecurityFlag;

    /**
     * 身份证件类型 0 身份证 1户口本 2出生证 3护照 4 军官证 5警官证 6 外国人永久居留证 7 港澳台同胞回乡证 8 外国人永久居留身份证 9港澳台居民居住证
     */
    private Integer identityCardType;

    /**
     * 证件号码
     */
    private String identityCardNumber;

    /**
     * 性别 0女 1男
     */
    private Integer sex;

    /**
     * 出生日期
     */
    private Date birthday;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    /**
     * 
     */
    private String userPhoto;

    /**
     * 是否备份过来的 0 否 1是
     */
    private Integer backFlag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public String getBelongUserId() {
        return belongUserId;
    }

    public void setBelongUserId(String belongUserId) {
        this.belongUserId = belongUserId == null ? null : belongUserId.trim();
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName == null ? null : nickName.trim();
    }

    public Integer getRelation() {
        return relation;
    }

    public void setRelation(Integer relation) {
        this.relation = relation;
    }

    public Integer getChannelType() {
        return channelType;
    }

    public void setChannelType(Integer channelType) {
        this.channelType = channelType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber == null ? null : phoneNumber.trim();
    }

    public String getUserPhoneNumber() {
        return userPhoneNumber;
    }

    public void setUserPhoneNumber(String userPhoneNumber) {
        this.userPhoneNumber = userPhoneNumber == null ? null : userPhoneNumber.trim();
    }

    public Integer getSocialSecurityFlag() {
        return socialSecurityFlag;
    }

    public void setSocialSecurityFlag(Integer socialSecurityFlag) {
        this.socialSecurityFlag = socialSecurityFlag;
    }

    public Integer getIdentityCardType() {
        return identityCardType;
    }

    public void setIdentityCardType(Integer identityCardType) {
        this.identityCardType = identityCardType;
    }

    public String getIdentityCardNumber() {
        return identityCardNumber;
    }

    public void setIdentityCardNumber(String identityCardNumber) {
        this.identityCardNumber = identityCardNumber == null ? null : identityCardNumber.trim();
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto == null ? null : userPhoto.trim();
    }

    public Integer getBackFlag() {
        return backFlag;
    }

    public void setBackFlag(Integer backFlag) {
        this.backFlag = backFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", memberId=").append(memberId);
        sb.append(", belongUserId=").append(belongUserId);
        sb.append(", nickName=").append(nickName);
        sb.append(", relation=").append(relation);
        sb.append(", channelType=").append(channelType);
        sb.append(", name=").append(name);
        sb.append(", phoneNumber=").append(phoneNumber);
        sb.append(", userPhoneNumber=").append(userPhoneNumber);
        sb.append(", socialSecurityFlag=").append(socialSecurityFlag);
        sb.append(", identityCardType=").append(identityCardType);
        sb.append(", identityCardNumber=").append(identityCardNumber);
        sb.append(", sex=").append(sex);
        sb.append(", birthday=").append(birthday);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", userPhoto=").append(userPhoto);
        sb.append(", backFlag=").append(backFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private UserFamilyInfoDO obj;

        public Builder() {
            this.obj = new UserFamilyInfoDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder memberId(Long memberId) {
            obj.memberId = memberId;
            return this;
        }

        public Builder belongUserId(String belongUserId) {
            obj.belongUserId = belongUserId;
            return this;
        }

        public Builder nickName(String nickName) {
            obj.nickName = nickName;
            return this;
        }

        public Builder relation(Integer relation) {
            obj.relation = relation;
            return this;
        }

        public Builder channelType(Integer channelType) {
            obj.channelType = channelType;
            return this;
        }

        public Builder name(String name) {
            obj.name = name;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            obj.phoneNumber = phoneNumber;
            return this;
        }

        public Builder userPhoneNumber(String userPhoneNumber) {
            obj.userPhoneNumber = userPhoneNumber;
            return this;
        }

        public Builder socialSecurityFlag(Integer socialSecurityFlag) {
            obj.socialSecurityFlag = socialSecurityFlag;
            return this;
        }

        public Builder identityCardType(Integer identityCardType) {
            obj.identityCardType = identityCardType;
            return this;
        }

        public Builder identityCardNumber(String identityCardNumber) {
            obj.identityCardNumber = identityCardNumber;
            return this;
        }

        public Builder sex(Integer sex) {
            obj.sex = sex;
            return this;
        }

        public Builder birthday(Date birthday) {
            obj.birthday = birthday;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder userPhoto(String userPhoto) {
            obj.userPhoto = userPhoto;
            return this;
        }

        public Builder backFlag(Integer backFlag) {
            obj.backFlag = backFlag;
            return this;
        }

        public UserFamilyInfoDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        memberId("member_id"),
        belongUserId("belong_user_id"),
        nickName("nick_name"),
        relation("relation"),
        channelType("channel_type"),
        name("name"),
        phoneNumber("phone_number"),
        userPhoneNumber("user_phone_number"),
        socialSecurityFlag("social_security_flag"),
        identityCardType("identity_card_type"),
        identityCardNumber("identity_card_number"),
        sex("sex"),
        birthday("birthday"),
        status("status"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by"),
        delFlag("del_flag"),
        userPhoto("user_photo"),
        backFlag("back_flag");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}