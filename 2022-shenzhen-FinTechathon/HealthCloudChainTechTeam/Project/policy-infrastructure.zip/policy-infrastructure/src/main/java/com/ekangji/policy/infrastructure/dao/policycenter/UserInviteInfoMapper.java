package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.UserInviteInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserInviteInfoDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface UserInviteInfoMapper {
    long countByExample(UserInviteInfoDOExample example);

    int deleteByExample(UserInviteInfoDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserInviteInfoDO record);

    int insertSelective(UserInviteInfoDO record);

    List<UserInviteInfoDO> selectByExampleWithRowbounds(UserInviteInfoDOExample example, RowBounds rowBounds);

    List<UserInviteInfoDO> selectByExample(UserInviteInfoDOExample example);

    UserInviteInfoDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserInviteInfoDO record, @Param("example") UserInviteInfoDOExample example);

    int updateByExample(@Param("record") UserInviteInfoDO record, @Param("example") UserInviteInfoDOExample example);

    int updateByPrimaryKeySelective(UserInviteInfoDO record);

    int updateByPrimaryKey(UserInviteInfoDO record);

    int batchInsert(@Param("list") List<UserInviteInfoDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<UserInviteInfoDO> recordList);

    UserInviteInfoDO selectOneByExample(UserInviteInfoDOExample example);
}