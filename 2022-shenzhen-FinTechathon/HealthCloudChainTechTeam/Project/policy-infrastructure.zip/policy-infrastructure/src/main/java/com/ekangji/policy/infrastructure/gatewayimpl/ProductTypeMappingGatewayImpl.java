package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.ProductTypeMappingGateway;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.infrastructure.convertor.ProductTypeMappingConvertor;
import com.ekangji.policy.infrastructure.dao.policycenter.ProductTypeMappingMapper;
import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDO;
import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDOExample;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author xintao.li
 * @date 2021/12/2 22:04
 */
@Repository
public class ProductTypeMappingGatewayImpl implements ProductTypeMappingGateway {

    @Resource
    private ProductTypeMappingConvertor productTypeMappingConvertor;

    @Resource
    private ProductTypeMappingMapper productTypeMappingMapper;

    @Override
    public Long save(ProductTypeMapping productTypeMapping) {
        ProductTypeMappingDO productTypeMappingDO = productTypeMappingConvertor.convert(productTypeMapping);
        productTypeMappingMapper.insertSelective(productTypeMappingDO);
        return productTypeMappingDO.getId();
    }

    @Override
    public int delete(ProductTypeMapping productTypeMapping) {
        return productTypeMappingMapper.deleteByPrimaryKey(productTypeMapping.getId());
    }

    @Override
    public int update(ProductTypeMapping productTypeMapping) {
        ProductTypeMappingDO productTypeMappingDO = productTypeMappingConvertor.convert(productTypeMapping);
        ProductTypeMappingDOExample example = new ProductTypeMappingDOExample();
        ProductTypeMappingDOExample.Criteria criteria = example.createCriteria();
        criteria.andMappingIdEqualTo(productTypeMappingDO.getMappingId());
        return productTypeMappingMapper.updateByExampleSelective(productTypeMappingDO,example);
    }

    @Override
    public ProductTypeMapping get(ProductTypeMapping productTypeMapping) {
        List<ProductTypeMappingDO> productTypeMappingDOList = this.query(productTypeMapping);
        if (CollectionUtils.isNotEmpty(productTypeMappingDOList)){
            return productTypeMappingConvertor.convert(productTypeMappingDOList.get(0));
        }
        return null;
    }

    @Override
    public List<ProductTypeMapping> list(ProductTypeMapping productTypeMapping) {
        List<ProductTypeMappingDO> productTypeMappingDOList = this.query(productTypeMapping);
        if (CollectionUtils.isNotEmpty(productTypeMappingDOList)){
            return productTypeMappingConvertor.convert(productTypeMappingDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<ProductTypeMapping> page(ProductTypeMapping productTypeMapping) {
        PageHelper.startPage(productTypeMapping.getPageNum(),productTypeMapping.getPageSize());
        List<ProductTypeMappingDO> productTypeMappingDOList = query(productTypeMapping);
        PageInfo<ProductTypeMappingDO> pageInfo = new PageInfo<>(productTypeMappingDOList);
        return productTypeMappingConvertor.convert(pageInfo);
    }

    private List<ProductTypeMappingDO> query(ProductTypeMapping productTypeMapping) {
        ProductTypeMappingDOExample example = new ProductTypeMappingDOExample();
        ProductTypeMappingDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(productTypeMapping.getMappingId())){
            criteria.andMappingIdEqualTo(productTypeMapping.getMappingId());
        }
        if (StringUtils.isNotBlank(productTypeMapping.getParentCode())){
            criteria.andParentCodeEqualTo(productTypeMapping.getParentCode());
        }

        // 根据code数组查询
        if(CollectionUtils.isNotEmpty(productTypeMapping.getCodeList())){
            criteria.andCodeIn(productTypeMapping.getCodeList());
        }

        if (StringUtils.isNotBlank(productTypeMapping.getMappingCode())) {
            criteria.andMappingCodeEqualTo(productTypeMapping.getMappingCode());
        }
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        return productTypeMappingMapper.selectByExample(example);
    }

    @Override
    public List<ProductTypeMapping> listOneLevel() {
        ProductTypeMappingDOExample example = new ProductTypeMappingDOExample();
        ProductTypeMappingDOExample.Criteria criteria = example.createCriteria();
        criteria.andParentCodeIsNull();
        example.setOrderByClause("sort asc");
        List<ProductTypeMappingDO> productTypeMappingDOList = productTypeMappingMapper.selectByExample(example);
        return productTypeMappingConvertor.convert(productTypeMappingDOList);
    }
}
