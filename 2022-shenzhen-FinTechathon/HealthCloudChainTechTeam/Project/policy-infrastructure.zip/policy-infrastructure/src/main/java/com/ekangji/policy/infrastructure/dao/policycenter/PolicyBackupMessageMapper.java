package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyBackupMessageMapper {
    long countByExample(PolicyBackupMessageDOExample example);

    int deleteByExample(PolicyBackupMessageDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyBackupMessageDO record);

    int insertSelective(PolicyBackupMessageDO record);

    List<PolicyBackupMessageDO> selectByExampleWithRowbounds(PolicyBackupMessageDOExample example, RowBounds rowBounds);

    List<PolicyBackupMessageDO> selectByExample(PolicyBackupMessageDOExample example);

    PolicyBackupMessageDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyBackupMessageDO record, @Param("example") PolicyBackupMessageDOExample example);

    int updateByExample(@Param("record") PolicyBackupMessageDO record, @Param("example") PolicyBackupMessageDOExample example);

    int updateByPrimaryKeySelective(PolicyBackupMessageDO record);

    int updateByPrimaryKey(PolicyBackupMessageDO record);

    int batchInsert(@Param("list") List<PolicyBackupMessageDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyBackupMessageDO> recordList);

    PolicyBackupMessageDO selectOneByExample(PolicyBackupMessageDOExample example);
}