package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.common.tool.util.SqlUtil;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.UserStarGateway;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.infrastructure.convertor.UserStarConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.UserStarMapper;
import com.ekangji.policy.infrastructure.utils.DateUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Repository
public class UserStarGatewayImpl implements UserStarGateway {

    @Resource
    private UserStarMapper userStarMapper;

    @Resource
    private UserStarConvertor convertor;

    @Override
    public Long save(UserStar userStar) {
        UserStarDO userStarDO = convertor.convert(userStar);
        userStarDO.setCreateTime(new Date());
        userStarDO.setUpdateTime(new Date());
//        familyEnsuredInfoDO.setCreateBy(ShiroUtils.getUserIdStr());
//        familyEnsuredInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        userStarDO.setStatus(CommonStatusEnum.VALID.getCode());
        userStarMapper.insertSelective(userStarDO);
        return userStarDO.getId();
    }

    @Override
    public int delete(UserStar userStar) {
        UserStarDO userStarDO = convertor.convert(userStar);
        return userStarMapper.updateByPrimaryKeySelective(userStarDO);
    }

    @Override
    public int update(UserStar userStar) {
        UserStarDO userStarDO = convertor.convert(userStar);
        userStarDO.setUpdateTime(new Date());
//        userFamilyInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        UserStarDOExample example = new UserStarDOExample();
        UserStarDOExample.Criteria criteria = example.createCriteria();
        criteria.andStarIdEqualTo(userStarDO.getStarId());
//        criteria.andNickNameEqualTo(userStarDO.getNickName());
        return userStarMapper.updateByExampleSelective(userStarDO, example);
    }

    @Override
    public UserStar get(UserStar userStar) {
        UserStarDOExample example = new UserStarDOExample();
        UserStarDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotEmpty(userStar.getUserId())) {
            criteria.andUserIdEqualTo(userStar.getUserId());
        }
        if (Objects.nonNull(userStar.getStarId())) {
            criteria.andStarIdEqualTo(userStar.getStarId());
        }
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        UserStarDO userStarDO = userStarMapper.selectOneByExample(example);
        if (Objects.nonNull(userStarDO)) {
            return convertor.convert(userStarDO);
        }
        return null;
    }

    @Override
    public List<UserStar> list(UserStar userStar) {
        List<UserStarDO> userStarDOS = this.query(userStar);
        if(CollectionUtils.isNotEmpty(userStarDOS)) {
            return convertor.convert(userStarDOS);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public PageInfo<UserStar> page(UserStar userStar) {
        return convertor.convert(PageHelper.startPage(userStar.getPageNum(), userStar.getPageSize())
                .doSelectPageInfo(() -> list(userStar)));
    }

    private List<UserStarDO> query(UserStar userStar) {
        UserStarDOExample example = new UserStarDOExample();
        UserStarDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(userStar.getStarId())) {
            criteria.andStarIdEqualTo(userStar.getStarId());
        }
        if (StringUtils.isNotEmpty(userStar.getUserId())) {
            criteria.andUserIdEqualTo(userStar.getUserId());
        }
        if (StringUtils.isNotEmpty(userStar.getUserPhone())) {
            criteria.andUserPhoneEqualTo(userStar.getUserPhone());
        }
        if (Objects.nonNull(userStar.getStartDate())) {
            criteria.andCreateTimeGreaterThanOrEqualTo(DateUtil.convertDateStartTime(userStar.getStartDate()));
        }
        if (Objects.nonNull(userStar.getEndDate())) {
            criteria.andCreateTimeLessThanOrEqualTo(DateUtil.convertDateEndTime(userStar.getEndDate()));
        }
        if (StringUtils.isNotEmpty(userStar.getNickName())) {
            criteria.andNickNameLike(SqlUtil.like(userStar.getNickName()));
        }
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("id desc");
        return userStarMapper.selectByExample(example);
    }

    @Override
    public List<UserStar> listByIds(List<Long> ids) {
        UserStarDOExample example = new UserStarDOExample();
        UserStarDOExample.Criteria criteria = example.createCriteria();
        criteria.andStarIdIn(ids);
        List<UserStarDO> userStarDOS = userStarMapper.selectByExample(example);
        return convertor.convert(userStarDOS);
    }
}
