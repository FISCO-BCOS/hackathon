package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyPayDetail;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/23 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyPayDetailConvertor {

    PolicyPayDetailDO convert(PolicyPayDetail param);

    PolicyPayDetailBO convert2(PolicyPayDetail param);

    PolicyPayDetail convert2(PolicyPayDetailBO param);

    PolicyPayDetail convert(PolicyPayDetailDO param);

    //List<PolicyPayDetailDO> convert(List<PolicyPayDetail> param);

    List<PolicyPayDetailBO> convert(List<PolicyPayDetail> param);

    List<PolicyPayDetail> convert2(List<PolicyPayDetailDO> param);

}
