package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsBO;

import java.util.List;

/**
 * @Description
 * @author liuchen
 * @date 2022-05-24 11:07
 */
public interface PolicyMemberStatisticsBOMapper extends PolicyMemberStatisticsMapper{

    /**
     * 获取家庭报告统计信息
     * @param param
     * @return
     */
    PolicyMemberStatisticsBO findFamilyReportTotalInfo(PolicyMemberStatisticsBO param);

    /**
     * 获取家庭成员(被保人)统计信息
     * @param param
     * @return
     */
    List<PolicyMemberStatisticsBO> findFamilyMemberTotalInfo(PolicyMemberStatisticsBO param);
}
