package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author   liuchen
 * @date   2022-05-24 14:01:18
 */
@Data
@ToString(callSuper = true)
public class PolicyPayDetailBO extends PolicyPayDetailDO implements Serializable {

    /**
     * 保费
     */
    private BigDecimal premium;

    /**
     * 保单id集合
     */
    private List<Long> policyIdList;

}