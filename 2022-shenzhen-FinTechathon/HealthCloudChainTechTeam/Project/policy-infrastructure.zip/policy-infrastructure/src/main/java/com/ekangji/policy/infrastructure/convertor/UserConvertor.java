package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.user.User;
import com.ekangji.policy.infrastructure.dao.dataobject.UserDO;
import com.ekangji.policy.infrastructure.user.CacheUser;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author zhangjun
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface UserConvertor {

    UserDO convert(User param);

    User convert(UserDO param);

    CacheUser convertCacheUser(User param);

    List<User> convert(List<UserDO> param);

    PageInfo<User> convert(PageInfo<UserDO> param);

}
