package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 14:46:44
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class ProductTypeMappingDO implements Serializable {
    /**
     * 自增id
     */
    private Long id;

    /**
     * 产品类型匹配id
     */
    private String mappingId;

    /**
     * 产品类型编码
     */
    private String code;

    /**
     * 产品类型名称
     */
    private String name;

    /**
     * 父产品类别编码
     */
    private String parentCode;

    /**
     * 产品库对应的产品类别编码
     */
    private String mappingCode;

    /**
     * 产品库对应的产品类别名称 
     */
    private String mappingName;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 状态  0：无效 1:有效
     */
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 更新人
     */
    private String updateBy;

    private static final long serialVersionUID = 1L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", mappingId=").append(mappingId);
        sb.append(", code=").append(code);
        sb.append(", name=").append(name);
        sb.append(", parentCode=").append(parentCode);
        sb.append(", mappingCode=").append(mappingCode);
        sb.append(", mappingName=").append(mappingName);
        sb.append(", sort=").append(sort);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private ProductTypeMappingDO obj;

        public Builder() {
            this.obj = new ProductTypeMappingDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder mappingId(String mappingId) {
            obj.mappingId = mappingId;
            return this;
        }

        public Builder code(String code) {
            obj.code = code;
            return this;
        }

        public Builder name(String name) {
            obj.name = name;
            return this;
        }

        public Builder parentCode(String parentCode) {
            obj.parentCode = parentCode;
            return this;
        }

        public Builder mappingCode(String mappingCode) {
            obj.mappingCode = mappingCode;
            return this;
        }

        public Builder mappingName(String mappingName) {
            obj.mappingName = mappingName;
            return this;
        }

        public Builder sort(Integer sort) {
            obj.sort = sort;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public ProductTypeMappingDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        mappingId("mapping_id"),
        code("code"),
        name("name"),
        parentCode("parent_code"),
        mappingCode("mapping_code"),
        mappingName("mapping_name"),
        sort("sort"),
        status("status"),
        delFlag("del_flag"),
        createTime("create_time"),
        updateTime("update_time"),
        createBy("create_by"),
        updateBy("update_by");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}