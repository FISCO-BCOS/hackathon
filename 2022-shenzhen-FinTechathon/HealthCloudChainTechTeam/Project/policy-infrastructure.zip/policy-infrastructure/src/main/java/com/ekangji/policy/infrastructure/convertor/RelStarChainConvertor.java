package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.infrastructure.dao.dataobject.RelStarChainDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface RelStarChainConvertor {

    RelStarChainDO convert(RelStarChain param);

    RelStarChain convert(RelStarChainDO param);

    List<RelStarChain> convert(List<RelStarChainDO> param);

}
