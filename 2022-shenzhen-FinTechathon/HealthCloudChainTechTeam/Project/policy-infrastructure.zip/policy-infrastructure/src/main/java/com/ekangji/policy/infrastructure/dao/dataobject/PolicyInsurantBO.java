package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   liuchen
 * @date   2022-06-01 15:50:16
 */
@Data
@ToString(callSuper = true)
public class PolicyInsurantBO extends PolicyInsurantDO implements Serializable {

}