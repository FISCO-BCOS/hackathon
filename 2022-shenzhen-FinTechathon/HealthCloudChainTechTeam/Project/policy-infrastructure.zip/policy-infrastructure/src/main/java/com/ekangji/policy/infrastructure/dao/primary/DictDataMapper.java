package com.ekangji.policy.infrastructure.dao.primary;

import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDO;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface DictDataMapper {
    long countByExample(DictDataDOExample example);

    int deleteByExample(DictDataDOExample example);

    int deleteByPrimaryKey(Long dictCode);

    int insert(DictDataDO record);

    int insertSelective(DictDataDO record);

    List<DictDataDO> selectByExampleWithRowbounds(DictDataDOExample example, RowBounds rowBounds);

    List<DictDataDO> selectByExample(DictDataDOExample example);

    DictDataDO selectByPrimaryKey(Long dictCode);

    int updateByExampleSelective(@Param("record") DictDataDO record, @Param("example") DictDataDOExample example);

    int updateByExample(@Param("record") DictDataDO record, @Param("example") DictDataDOExample example);

    int updateByPrimaryKeySelective(DictDataDO record);

    int updateByPrimaryKey(DictDataDO record);
}