package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.util.SqlUtil;
import com.ekangji.policy.domain.dict.DictType;
import com.ekangji.policy.domain.gateway.DictTypeGateway;
import com.ekangji.policy.infrastructure.convertor.DictTypeConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.DictTypeDO;
import com.ekangji.policy.infrastructure.dao.dataobject.DictTypeDOExample;
import com.ekangji.policy.infrastructure.dao.primary.DictTypeMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangjun
 * @date 2021/12/2 22:04
 */
@Repository
public class DictTypeGatewayImpl implements DictTypeGateway {

    @Resource
    private DictTypeConvertor dictTypeConvertor;

    @Resource
    private DictTypeMapper dictTypeMapper;

    @Override
    public Long save(DictType dictType) {
        DictTypeDO dictTypeDO = dictTypeConvertor.convert(dictType);
        dictTypeDO.setCreateTime(new Date());
        dictTypeDO.setUpdateTime(new Date());
        dictTypeDO.setCreateBy(ShiroUtils.getUserIdStr());
        dictTypeDO.setUpdateBy(ShiroUtils.getUserIdStr());
        dictTypeMapper.insertSelective(dictTypeDO);
        return dictTypeDO.getDictId();
    }

    @Override
    public int delete(DictType dictType) {
        return dictTypeMapper.deleteByPrimaryKey(dictType.getDictId());
    }

    @Override
    public int update(DictType dictType) {
        DictTypeDO dictTypeDO = dictTypeConvertor.convert(dictType);
        dictTypeDO.setUpdateTime(new Date());
        dictTypeDO.setUpdateBy(ShiroUtils.getUserIdStr());
        DictTypeDOExample example = new DictTypeDOExample();
        DictTypeDOExample.Criteria criteria = example.createCriteria();
        criteria.andDictIdEqualTo(dictType.getDictId());
        return dictTypeMapper.updateByExampleSelective(dictTypeDO, example);
    }

    @Override
    public DictType get(DictType dictType) {
        List<DictTypeDO> dictTypeDOList = this.query(dictType);
        if (CollectionUtils.isNotEmpty(dictTypeDOList)){
            return dictTypeConvertor.convert(dictTypeDOList.get(0));
        }
        return null;
    }

    @Override
    public List<DictType> list(DictType dictType) {
        List<DictTypeDO> dictTypeDOList = this.query(dictType);
        if (CollectionUtils.isNotEmpty(dictTypeDOList)){
            return dictTypeConvertor.convert(dictTypeDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<DictType> page(DictType dictType) {
        PageHelper.startPage(dictType.getPageNum(),dictType.getPageSize());
        List<DictTypeDO> dictTypeDOList = query(dictType);
        PageInfo<DictTypeDO> pageInfo = new PageInfo<>(dictTypeDOList);
        return dictTypeConvertor.convert(pageInfo);
    }


    private List<DictTypeDO> query(DictType dictType) {
        DictTypeDOExample example = new DictTypeDOExample();
        DictTypeDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(dictType.getStatus())){
            criteria.andStatusEqualTo(dictType.getStatus());
        }
        if (Objects.nonNull(dictType.getDictId())){
            criteria.andDictIdEqualTo(dictType.getDictId());
        }
        if (Objects.nonNull(dictType.getDictName())){
            criteria.andDictNameLike(SqlUtil.like(dictType.getDictName()));
        }
        if (StringUtils.isNotEmpty(dictType.getDictType())){
            criteria.andDictTypeEqualTo(dictType.getDictType());
        }
        return dictTypeMapper.selectByExample(example);
    }
}
