package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.ekangji.policy.infrastructure.dao.dataobject.*;

import java.util.List;

import org.apache.ibatis.annotations.Param;


/**
 * @Description
 * @author liuchen
 * @date 2022-05-18 11:07
 */
public interface PolicyBOMapper extends PolicyMapper{

    /**
     * 根据条件查询
     * @param dto
     * @return
     */
    List<PolicyPageBO> selectByCondition(PolicyQueryDTO dto);

    List<PolicyBO> queryPolicyByAgeBracketAndProdType(PolicyBO policyBO);

    /**
     * 根据用户id和成员id获取保单信息
     * @param policyBO
     * @return
     */
    List<PolicyBO> queryPolicyByUserIdAndMemberId(PolicyBO policyBO);

    /**
     * 根据被保人id获取保单信息
     * @param policyInsurantDO
     * @return
     */
    List<PolicyBO> listPolicyByInsurantId(PolicyInsurantDO policyInsurantDO);

    List<PolicyBO> batchGetPolicyList(@Param("policyIds") Long[] policyIds);

    /**
     * 根据保单ID逻辑删除附加险信息
     * @param policyId
     * @return
     */
    int logicDeleteAdditionalByPolicyId(Long policyId);
    /**
     * 根据保单ID逻辑删除被保人信息
     * @param policyId
     * @return
     */
    int logicDeleteInsurantByPolicyId(Long policyId);
    /**
     * 根据保单ID逻辑删除受益人信息
     * @param policyId
     * @return
     */
    int logicDeleteBeneficiaryByPolicyId(Long policyId);
    /**
     * 根据保单ID逻辑删除附件信息
     * @param policyId
     * @return
     */
    int logicDeleteAttchmentByPolicyId(Long policyId);
    /**
     * 根据保单ID逻辑删除主险缴费标签信息
     * @param policyId
     * @return
     */
    int logicDeletePayDetailByPolicyId(Long policyId);

    /**
     * 更新保单
     * @param policyBO
     * @return
     */
    int updateByPolicyId(PolicyBO policyBO);
}
