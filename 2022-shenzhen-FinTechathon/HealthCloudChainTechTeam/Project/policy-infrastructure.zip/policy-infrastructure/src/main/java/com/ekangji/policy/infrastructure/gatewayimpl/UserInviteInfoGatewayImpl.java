package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.UserFamilyInfoGateway;
import com.ekangji.policy.domain.gateway.UserInviteInfoGateway;
import com.ekangji.policy.domain.policy.SafeguardInsurance;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.domain.policy.UserInviteInfo;
import com.ekangji.policy.infrastructure.convertor.UserFamilyInfoConvertor;
import com.ekangji.policy.infrastructure.convertor.UserInviteInfoConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.UserFamilyInfoMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.UserInviteInfoMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Repository
public class UserInviteInfoGatewayImpl implements UserInviteInfoGateway {
    @Resource
    private UserInviteInfoMapper userInviteInfoMapper;
    @Resource
    private UserInviteInfoConvertor userInviteInfoConvertor;
    @Override
    public List<UserInviteInfo> selectListByInviterId(String userId) {
        UserInviteInfoDOExample example = new UserInviteInfoDOExample();
        UserInviteInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andInviterUserIdEqualTo(userId);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("create_time desc");
        List<UserInviteInfoDO> userInviteInfoDOS = userInviteInfoMapper.selectByExample(example);
        return userInviteInfoConvertor.convert(userInviteInfoDOS);
    }

    @Override
    public List<UserInviteInfo> selectListByInviteeId(String inviteeUserId) {
        UserInviteInfoDOExample example = new UserInviteInfoDOExample();
        UserInviteInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andInviteeUserIdEqualTo(inviteeUserId);
        criteria.andPolicyStatusEqualTo(Constants.ZERO);
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("create_time asc");
        List<UserInviteInfoDO> userInviteInfoDOS = userInviteInfoMapper.selectByExample(example);
        return userInviteInfoConvertor.convert(userInviteInfoDOS);
    }

    @Override
    public Long save(UserInviteInfo userInviteInfo) {
        UserInviteInfoDO userInviteInfoDO = userInviteInfoConvertor.convert(userInviteInfo);
        userInviteInfoDO.setCreateTime(new Date());
        userInviteInfoDO.setUpdateTime(new Date());
//        userFamilyInfoDO.setCreateBy(ShiroUtils.getUserIdStr());
//        userFamilyInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        userInviteInfoDO.setStatus(CommonStatusEnum.VALID.getCode());
        userInviteInfoMapper.insertSelective(userInviteInfoDO);
        return userInviteInfoDO.getInviteId();
    }

    @Override
    public int delete(UserInviteInfo userInviteInfo) {
        return 0;
    }

    @Override
    public int update(UserInviteInfo userInviteInfo) {
        UserInviteInfoDO userInviteInfoDO = userInviteInfoConvertor.convert(userInviteInfo);
        userInviteInfoDO.setUpdateTime(new Date());
//        userFamilyInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        UserInviteInfoDOExample example = new UserInviteInfoDOExample();
        UserInviteInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andInviteIdEqualTo(userInviteInfo.getInviteId());
        return userInviteInfoMapper.updateByExampleSelective(userInviteInfoDO, example);
    }

    @Override
    public UserInviteInfo get(UserInviteInfo userInviteInfo) {
        UserInviteInfoDOExample example = new UserInviteInfoDOExample();
        UserInviteInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andInviteeUserIdEqualTo(userInviteInfo.getInviteeUserId());
        criteria.andInviterUserIdEqualTo(userInviteInfo.getInviterUserId());
        UserInviteInfoDO userInviteInfoDO = userInviteInfoMapper.selectOneByExample(example);
        if (Objects.nonNull(userInviteInfoDO)) {
            return userInviteInfoConvertor.convert(userInviteInfoDO);
        }
        return null;
    }

    @Override
    public List<UserInviteInfo> list(UserInviteInfo userInviteInfo) {
        return null;
    }

    @Override
    public PageInfo<UserInviteInfo> page(UserInviteInfo userInviteInfo) {
        PageHelper.startPage(userInviteInfo.getPageNum(),userInviteInfo.getPageSize());
        List<UserInviteInfoDO> userDOList = this.query(userInviteInfo);
        PageInfo<UserInviteInfoDO> pageInfo = new PageInfo<>(userDOList);
        return userInviteInfoConvertor.convert(pageInfo);
    }
    private List<UserInviteInfoDO> query(UserInviteInfo userInviteInfo) {
        UserInviteInfoDOExample example = new UserInviteInfoDOExample();
        UserInviteInfoDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(userInviteInfo.getInviterUserId())){
            criteria.andInviterUserIdEqualTo(userInviteInfo.getInviterUserId());
        }
        example.setOrderByClause("create_time desc");
        return userInviteInfoMapper.selectByExample(example);
    }
}
