package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.RelStarChainDO;
import com.ekangji.policy.infrastructure.dao.dataobject.RelStarChainDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface RelStarChainMapper {
    long countByExample(RelStarChainDOExample example);

    int deleteByExample(RelStarChainDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(RelStarChainDO record);

    int insertSelective(RelStarChainDO record);

    List<RelStarChainDO> selectByExampleWithRowbounds(RelStarChainDOExample example, RowBounds rowBounds);

    List<RelStarChainDO> selectByExample(RelStarChainDOExample example);

    RelStarChainDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") RelStarChainDO record, @Param("example") RelStarChainDOExample example);

    int updateByExample(@Param("record") RelStarChainDO record, @Param("example") RelStarChainDOExample example);

    int updateByPrimaryKeySelective(RelStarChainDO record);

    int updateByPrimaryKey(RelStarChainDO record);

    int batchInsert(@Param("list") List<RelStarChainDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<RelStarChainDO> recordList);

    RelStarChainDO selectOneByExample(RelStarChainDOExample example);
}