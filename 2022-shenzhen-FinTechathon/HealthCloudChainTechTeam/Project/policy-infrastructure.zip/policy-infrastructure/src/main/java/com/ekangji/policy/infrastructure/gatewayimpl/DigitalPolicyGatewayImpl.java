package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.YESORNOEnum;
import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.domain.gateway.DigitalPolicyGateway;
import com.ekangji.policy.domain.gateway.RelStarChainGateway;
import com.ekangji.policy.domain.gateway.UserStarGateway;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.policy.pojo.DigitalPolicyDTO;
import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.infrastructure.convertor.DigitalPolicyConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.DigitalPolicyBOMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.DigitalPolicyMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Repository
public class DigitalPolicyGatewayImpl implements DigitalPolicyGateway {
    @Resource
    private DigitalPolicyMapper digitalPolicyMapper;
    @Resource
    private DigitalPolicyConvertor digitalPolicyConvertor;
    @Resource
    private DigitalPolicyBOMapper digitalPolicyBOMapper;

    @Resource
    private RelStarChainGateway relStarChainGateway;

    @Resource
    private UserStarGateway userStarGateway;

    @Override
    public Long save(DigitalPolicy digitalPolicy) {
        DigitalPolicyDO digitalPolicyDO = digitalPolicyConvertor.convert(digitalPolicy);
        digitalPolicyDO.setCreateTime(new Date());
        digitalPolicyDO.setUpdateTime(new Date());
//        familyEnsuredInfoDO.setCreateBy(ShiroUtils.getUserIdStr());
//        familyEnsuredInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        digitalPolicyDO.setStatus(CommonStatusEnum.VALID.getCode());
        digitalPolicyMapper.insertSelective(digitalPolicyDO);
        return digitalPolicyDO.getId();
    }

    @Override
    public int delete(DigitalPolicy digitalPolicy) {
        return 0;
    }

    @Override
    public int update(DigitalPolicy digitalPolicy) {
        DigitalPolicyDO digitalPolicyDO = digitalPolicyConvertor.convert(digitalPolicy);
        DigitalPolicyDOExample example = new DigitalPolicyDOExample();
        DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
        if(Objects.nonNull(digitalPolicy.getRecommendFlag())
                &&digitalPolicy.getRecommendFlag().equals(Constants.ONE)){
            digitalPolicyDO.setRecommendTime(new Date());
        }
        criteria.andDigitalIdEqualTo(digitalPolicy.getDigitalId());
        return digitalPolicyMapper.updateByExampleSelective(digitalPolicyDO,example);
    }

    @Override
    public DigitalPolicy get(DigitalPolicy digitalPolicy) {
        DigitalPolicyDOExample example = new DigitalPolicyDOExample();
        DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(digitalPolicy.getPolicyId());
        criteria.andDelFlagEqualTo(digitalPolicy.getDelFlag());
        DigitalPolicyDO digitalPolicyDO = digitalPolicyMapper.selectOneByExample(example);
        if (Objects.nonNull(digitalPolicyDO)) {
            return digitalPolicyConvertor.convert(digitalPolicyDO);
        }
        return null;
    }

    @Override
    public List<DigitalPolicy> list(DigitalPolicy digitalPolicy) {
        List<DigitalPolicyDO> digitalPolicyDOS = this.query(digitalPolicy);
        if (CollectionUtils.isNotEmpty(digitalPolicyDOS)){
            return digitalPolicyConvertor.convert(digitalPolicyDOS);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<DigitalPolicy> page(DigitalPolicy digitalPolicy) {
        return digitalPolicyConvertor.convert(PageHelper.startPage(digitalPolicy.getPageNum(), digitalPolicy.getPageSize())
                .doSelectPageInfo(() -> this.list(digitalPolicy)));
    }

    private List<DigitalPolicyDO> query(DigitalPolicy digitalPolicy) {
        DigitalPolicyDOExample example = new DigitalPolicyDOExample();
        DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
        if(StringUtils.isNotEmpty(digitalPolicy.getUserId())){
            criteria.andUserIdEqualTo(digitalPolicy.getUserId());
        }
        if (Objects.nonNull(digitalPolicy.getStatus())) {
            criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        }
        if (Objects.nonNull(digitalPolicy.getSelfFlag())) {
            criteria.andSelfFlagEqualTo(digitalPolicy.getSelfFlag());
        }

        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("id desc");
        return digitalPolicyMapper.selectByExample(example);
    }

    @Override
    public PageInfo<DigitalPolicy> page(DigitalPolicyDTO dto) {
        return digitalPolicyConvertor.convert2DTO(PageHelper.startPage(dto.getPageNum(), dto.getPageSize())
                .doSelectPageInfo(() -> this.query(dto)));
    }

    @Override
    public PageInfo<DigitalPolicy> pageCommand(Page page) {
        return digitalPolicyConvertor.convert(PageHelper.startPage(page.getPageNum(), page.getPageSize())
                .doSelectPageInfo(() -> {
                    DigitalPolicyDOExample example = new DigitalPolicyDOExample();
                    DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
                    criteria.andRecommendFlagEqualTo(YESORNOEnum.YES.getCode());
                    criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
                    criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
                    criteria.andSelfFlagEqualTo(YESORNOEnum.NO.getCode());
                    example.setOrderByClause("recommend_time desc");
                    digitalPolicyMapper.selectByExample(example);
                }));
    }


    @Override
    public List<DigitalPolicy> countDigitalNumByUserIds(List<String> userIdList) {
        List<DigitalPolicyBO> digitalPolicyBOS = digitalPolicyBOMapper.countDigitalNumByUserIds(userIdList);
        return digitalPolicyConvertor.convert2(digitalPolicyBOS);
    }

    @Override
    public List<DigitalPolicy> pageChainContent(StarChain starChain) {

        ArrayList<DigitalPolicy> digitalPolicies = new ArrayList<>();
        //获取星链id对应的所有的星球
        List<RelStarChain> starChains = relStarChainGateway.list(
                RelStarChain.builder()
                        .chainId(starChain.getStarChainId())
                        .build()
        );
        for (RelStarChain relStarChain : starChains){
            //根据星球id获取星球信息
            List<UserStar> list = userStarGateway.list(
                    UserStar.builder()
                            .starId(relStarChain.getStarId())
                            .build()
            );
            if (CollectionUtils.isEmpty(list)){
                throw new RuntimeException("不存在星球" + relStarChain.getStarId());
            }
            UserStar userStar = list.get(0);
            //根据星球对应的userId获取数字保单
            List<DigitalPolicy> digitalPolicyList = this.list(
                    DigitalPolicy.builder()
                            .userId(userStar.getUserId())
                            .status(CommonStatusEnum.VALID.getCode())
                            .selfFlag(CommonStatusEnum.INVALID.getCode())
                            .build()
            );
            //封装昵称
            digitalPolicyList.stream().forEach(
                    digitalPolicy -> {
                        digitalPolicy.setNickName(userStar.getNickName());
                        digitalPolicy.setStarFileId(userStar.getFileId());
                        digitalPolicy.setStarSequence(userStar.getSequence());
                    }
            );
            digitalPolicies.addAll(digitalPolicyList);
        }
        //按时间倒序
        List<DigitalPolicy> collect = digitalPolicies.stream()
                .sorted(Comparator.comparing(DigitalPolicy::getCreateTime).reversed())
                .collect(Collectors.toList());
        return collect;
    }

    @Override
    public DigitalPolicy getByDigitalId(Long digitalId) {
        DigitalPolicyDOExample example = new DigitalPolicyDOExample();
        DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andDigitalIdEqualTo(digitalId);
        DigitalPolicyDO digitalPolicyDO = digitalPolicyMapper.selectOneByExample(example);
        if (Objects.nonNull(digitalPolicyDO)) {
            return digitalPolicyConvertor.convert(digitalPolicyDO);
        }
        return null;
    }

    @Override
    public DigitalPolicy getByStarId(Long starId) {
        DigitalPolicyDOExample example = new DigitalPolicyDOExample();
        DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andStarIdEqualTo(starId);
        DigitalPolicyDO digitalPolicyDO = digitalPolicyMapper.selectOneByExample(example);
        if (Objects.nonNull(digitalPolicyDO)) {
            return digitalPolicyConvertor.convert(digitalPolicyDO);
        }
        return null;
    }

    @Override
    public DigitalPolicy getByHash(String chainAddr) {
        DigitalPolicyDOExample example = new DigitalPolicyDOExample();
        DigitalPolicyDOExample.Criteria criteria = example.createCriteria();
        criteria.andChainAddrEqualTo(chainAddr);
        DigitalPolicyDO digitalPolicyDO = digitalPolicyMapper.selectOneByExample(example);
        if (Objects.nonNull(digitalPolicyDO)) {
            return digitalPolicyConvertor.convert(digitalPolicyDO);
        }
        return null;
    }

    private List<DigitalPolicy> query(DigitalPolicyDTO dto) {
        dto.setProductName(StringUtils.isBlank(dto.getProductName())?null:dto.getProductName());
        dto.setUserId(StringUtils.isBlank(dto.getUserId())?null:dto.getUserId());
        dto.setPhoneNumber(StringUtils.isBlank(dto.getPhoneNumber())?null:dto.getPhoneNumber());

        if(Objects.nonNull(dto.getDigitalPolicyCreateTimeEnd())) {
            /**
             * 设置结束时间为23：59：:59
             */
            Calendar end = Calendar.getInstance();
            end.setTime(dto.getDigitalPolicyCreateTimeEnd());
            end.set(Calendar.HOUR, 23);
            end.set(Calendar.MINUTE, 59);
            end.set(Calendar.SECOND, 59);
            Date endTime = end.getTime();
            dto.setDigitalPolicyCreateTimeEnd(endTime);
        }
        List<DigitalPolicyInfoBO> list = digitalPolicyMapper.selectByCondition(dto);
        if (CollectionUtils.isNotEmpty(list)){
            return digitalPolicyConvertor.convert2DTO(list);
        }
        return Lists.newArrayList();
    }
}
