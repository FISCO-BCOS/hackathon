package com.ekangji.policy.infrastructure.dao.productcenter;

import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface InsuranceProductMapper {
    long countByExample(InsuranceProductDOExample example);

    int deleteByExample(InsuranceProductDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(InsuranceProductDO record);

    int insertSelective(InsuranceProductDO record);

    List<InsuranceProductDO> selectByExampleWithRowbounds(InsuranceProductDOExample example, RowBounds rowBounds);

    List<InsuranceProductDO> selectByExample(InsuranceProductDOExample example);

    InsuranceProductDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") InsuranceProductDO record, @Param("example") InsuranceProductDOExample example);

    int updateByExample(@Param("record") InsuranceProductDO record, @Param("example") InsuranceProductDOExample example);

    int updateByPrimaryKeySelective(InsuranceProductDO record);

    int updateByPrimaryKey(InsuranceProductDO record);

    int batchInsert(@Param("list") List<InsuranceProductDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<InsuranceProductDO> recordList);

    InsuranceProductDO selectOneByExample(InsuranceProductDOExample example);

}