package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author   zhangjun
 * @date   2022-07-22 16:32:49
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceInfoDO implements Serializable {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 投保单号
     */
    private String quotationNo;

    /**
     * 保费
     */
    private BigDecimal premium;

    /**
     * 保单渠道名称
     */
    private String channelName;

    /**
     * 是否是公域 1 是 0 否
     */
    private Integer isPublic;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 用户性别（0男 1女 2未知）
     */
    private Integer sex;

    /**
     * 被保人身份证号
     */
    private String idNo;

    /**
     * 销售渠道类型 1 保险公司 2 经纪公司 3 代理公司 4 合作公司 5 其他 6 银邮
     */
    private String saleChannelType;

    /**
     * 创建时间
     */
    private Date createTime;

    private static final long serialVersionUID = 1L;

    public enum Column {
        id("id"),
        quotationNo("quotation_no"),
        premium("premium"),
        channelName("channel_name"),
        isPublic("is_public"),
        age("age"),
        sex("sex"),
        idNo("id_no"),
        saleChannelType("sale_channel_type"),
        createTime("create_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}