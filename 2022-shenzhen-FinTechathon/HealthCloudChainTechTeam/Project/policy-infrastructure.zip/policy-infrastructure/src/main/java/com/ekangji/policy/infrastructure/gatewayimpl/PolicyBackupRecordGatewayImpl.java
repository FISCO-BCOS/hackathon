package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyBackupRecordGateway;
import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.domain.policy.PolicyBackupRecord;
import com.ekangji.policy.infrastructure.convertor.PolicyBackupRecordConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupRecordDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupRecordDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyBackupRecordMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.ekangji.policy.domain.gateway.PolicyBackupRecordGateway;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyBackupRecordGatewayImpl implements PolicyBackupRecordGateway {

    @Resource
    private PolicyBackupRecordConvertor policyBackupRecordConvertor;

    @Resource
    private PolicyBackupRecordMapper policyBackupRecordMapper;

    @Override
    public Long save(PolicyBackupRecord policyBackupRecord) {
        PolicyBackupRecordDO recordDO = policyBackupRecordConvertor.convert(policyBackupRecord);
        policyBackupRecordMapper.insertSelective(recordDO);
        return recordDO.getPolicyId();
    }

    @Override
    public int delete(PolicyBackupRecord policyBackupRecord) {
        return 0;
    }

    @Override
    public int update(PolicyBackupRecord policyBackupRecord) {
        return 0;
    }

    @Override
    public PolicyBackupRecord get(PolicyBackupRecord policyBackupRecord) {
        return null;
    }

    @Override
    public List<PolicyBackupRecord> list(PolicyBackupRecord policyBackupRecord) {
        List<PolicyBackupRecordDO> policyBackupRecordDOList = this.query(policyBackupRecord);
        if (CollectionUtils.isNotEmpty(policyBackupRecordDOList)){
            return policyBackupRecordConvertor.convertDO(policyBackupRecordDOList);
        }
        return Collections.emptyList();
    }

    @Override
    public PageInfo<PolicyBackupRecord> page(PolicyBackupRecord policyBackupRecord) {
        return null;
    }


    private List<PolicyBackupRecordDO> query(PolicyBackupRecord pbr) {
        PolicyBackupRecordDOExample example = new PolicyBackupRecordDOExample();
        PolicyBackupRecordDOExample.Criteria criteria = example.createCriteria();
        // 根据接收状态查询
        if(Objects.nonNull(pbr.getStatus())){
            criteria.andStatusEqualTo(pbr.getStatus());
        }
        // 根据保单ID数组查询
        if (CollectionUtils.isNotEmpty(pbr.getPolicyIds())){
            criteria.andPolicyIdIn(pbr.getPolicyIds());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyBackupRecordDO> policyBackupRecordDOS = policyBackupRecordMapper.selectByExample(example);
        example.setOrderByClause("status");
        return policyBackupRecordDOS;
    }
}
