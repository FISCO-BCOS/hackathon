package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyMemberStatisticsGateway;
import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.infrastructure.convertor.PolicyMemberStatisticsConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyMemberStatisticsBOMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyMemberStatisticsMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyMemberStatisticsGatewayImpl implements PolicyMemberStatisticsGateway {

    @Resource
    private PolicyMemberStatisticsMapper policyMemberStatisticsMapper;

    @Resource
    private PolicyMemberStatisticsBOMapper policyMemberStatisticsBOMapper;

    @Resource
    private PolicyMemberStatisticsConvertor policyMemberStatisticsConvertor;

    @Override
    public Long save(PolicyMemberStatistics policyMemberStatistics) {
        PolicyMemberStatisticsDO pmsDO = policyMemberStatisticsConvertor.convert2(policyMemberStatistics);
        policyMemberStatisticsMapper.insertSelective(pmsDO);
        return pmsDO.getId();
    }

    @Override
    public int delete(PolicyMemberStatistics policyMemberStatistics) {
        PolicyMemberStatisticsDOExample example = new PolicyMemberStatisticsDOExample();
        PolicyMemberStatisticsDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(policyMemberStatistics.getUserId());
        criteria.andMemberIdEqualTo(policyMemberStatistics.getMemberId());
        return policyMemberStatisticsMapper.deleteByExample(example);
    }

    @Override
    public int update(PolicyMemberStatistics policyMemberStatistics) {
        PolicyMemberStatisticsDO pmsDO = policyMemberStatisticsConvertor.convert2(policyMemberStatistics);
        PolicyMemberStatisticsDOExample example = new PolicyMemberStatisticsDOExample();
        PolicyMemberStatisticsDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(policyMemberStatistics.getUserId());
        criteria.andMemberIdEqualTo(policyMemberStatistics.getMemberId());
        return policyMemberStatisticsMapper.updateByExampleSelective(pmsDO,example);
    }

    @Override
    public PolicyMemberStatistics get(PolicyMemberStatistics policyMemberStatistics) {
        PolicyMemberStatisticsDOExample example = new PolicyMemberStatisticsDOExample();
        PolicyMemberStatisticsDOExample.Criteria criteria = example.createCriteria();
        if(Objects.nonNull(policyMemberStatistics.getMemberId())) {
            criteria.andMemberIdEqualTo(policyMemberStatistics.getMemberId());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        PolicyMemberStatisticsDO pmsDO = policyMemberStatisticsMapper.selectOneByExample(example);
        if (Objects.nonNull(pmsDO)) {
            return policyMemberStatisticsConvertor.convert(pmsDO);
        }
        return null;
    }

    @Override
    public List<PolicyMemberStatistics> list(PolicyMemberStatistics policyMemberStatistics) {
        PolicyMemberStatisticsDOExample example = new PolicyMemberStatisticsDOExample();
        PolicyMemberStatisticsDOExample.Criteria criteria = example.createCriteria();
        List<PolicyMemberStatisticsDO> policyMemberStatisticsDOS = policyMemberStatisticsBOMapper.selectByExample(example);
        return policyMemberStatisticsConvertor.convertT(policyMemberStatisticsDOS);
    }

    @Override
    public PageInfo<PolicyMemberStatistics> page(PolicyMemberStatistics policyMemberStatistics) {
        return null;
    }

    @Override
    public PolicyMemberStatistics findFamilyReportTotalInfo(PolicyMemberStatistics pms) {
        PolicyMemberStatisticsBO param = policyMemberStatisticsConvertor.convert(pms);
        PolicyMemberStatisticsBO pmsBO = policyMemberStatisticsBOMapper.findFamilyReportTotalInfo(param);
        PolicyMemberStatistics policyMemberStatistics = policyMemberStatisticsConvertor.convert(pmsBO);
        return policyMemberStatistics;
    }

    @Override
    public List<PolicyMemberStatistics> findFamilyMemberTotalInfo(PolicyMemberStatistics pms) {
        PolicyMemberStatisticsBO param = policyMemberStatisticsConvertor.convert(pms);
        List<PolicyMemberStatisticsBO> pmsBO = policyMemberStatisticsBOMapper.findFamilyMemberTotalInfo(param);

        if (CollectionUtils.isNotEmpty(pmsBO)) {
            return  policyMemberStatisticsConvertor.convert(pmsBO);
        }
        return Collections.emptyList();
    }

    @Override
    public PolicyMemberStatistics findByUserIdAndMemberId(PolicyMemberStatistics pms) {
        PolicyMemberStatisticsDOExample example = new PolicyMemberStatisticsDOExample();
        PolicyMemberStatisticsDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(pms.getUserId());
        criteria.andMemberIdEqualTo(pms.getMemberId());
        PolicyMemberStatisticsDO rbo = policyMemberStatisticsBOMapper.selectOneByExample(example);
        if (Objects.nonNull(rbo)) {
            return policyMemberStatisticsConvertor.convert(rbo);
        }
        return null;
    }
}
