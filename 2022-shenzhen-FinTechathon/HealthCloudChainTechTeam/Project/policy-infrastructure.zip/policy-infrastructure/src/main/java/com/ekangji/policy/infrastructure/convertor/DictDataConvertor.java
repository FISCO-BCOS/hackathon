package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author zhangjun
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface DictDataConvertor {

    DictDataDO convert(DictData param);

    DictData convert(DictDataDO param);

    List<DictData> convert(List<DictDataDO> param);

    PageInfo<DictData> convert(PageInfo<DictDataDO> param);

}
