package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-07-07 11:02:13
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class RelPolicyPeopleDO implements Serializable {
    /**
     * 自增ID
     */
    private Long id;

    /**
     * 投保单号
     */
    private String quotationNo;

    /**
     * 产品编码 玉惠保 GXYLYHB 惠鹤保 HNHBHHB2022
     */
    private String productCode;

    /**
     * 姓名
     */
    private String name;

    /**
     * 身份证号
     */
    private String idNo;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 性别（0男 1女 2未知）
     */
    private Integer sex;

    /**
     * 在保单中角色 1 投保人 2 被保人
     */
    private Integer roleFlag;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 最后修改者
     */
    private String updateBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 状态 0 无效 1有效
     */
    private Integer status;

    /**
     * 删除表示 1 存在 0 删除
     */
    private Integer delFlag;

    private static final long serialVersionUID = 1L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", quotationNo=").append(quotationNo);
        sb.append(", productCode=").append(productCode);
        sb.append(", name=").append(name);
        sb.append(", idNo=").append(idNo);
        sb.append(", age=").append(age);
        sb.append(", sex=").append(sex);
        sb.append(", roleFlag=").append(roleFlag);
        sb.append(", mobile=").append(mobile);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private RelPolicyPeopleDO obj;

        public Builder() {
            this.obj = new RelPolicyPeopleDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder quotationNo(String quotationNo) {
            obj.quotationNo = quotationNo;
            return this;
        }

        public Builder productCode(String productCode) {
            obj.productCode = productCode;
            return this;
        }

        public Builder name(String name) {
            obj.name = name;
            return this;
        }

        public Builder idNo(String idNo) {
            obj.idNo = idNo;
            return this;
        }

        public Builder age(Integer age) {
            obj.age = age;
            return this;
        }

        public Builder sex(Integer sex) {
            obj.sex = sex;
            return this;
        }

        public Builder roleFlag(Integer roleFlag) {
            obj.roleFlag = roleFlag;
            return this;
        }

        public Builder mobile(String mobile) {
            obj.mobile = mobile;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public RelPolicyPeopleDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        quotationNo("quotation_no"),
        productCode("product_code"),
        name("name"),
        idNo("id_no"),
        age("age"),
        sex("sex"),
        roleFlag("role_flag"),
        mobile("mobile"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time"),
        status("status"),
        delFlag("del_flag");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}