package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   xintao.li
 * @date   2022-05-23 22:32:02
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class SafeguardOverviewDO implements Serializable {
    /**
     * 自增id
     */
    private Long id;

    /**
     * 保障总图业务id
     */
    private String overviewId;

    /**
     * 一级类别编码
     */
    private String oneLevelTypeCode;

    /**
     * 一级类别描述
     */
    private String oneLevelTypeDesc;

    /**
     * 一级类别对应小程序名称
     */
    private String oneLevelTypeAlias;

    /**
     * 用户均值
     */
    private Integer averValue;

    /**
     * 中位数值
     */
    private Integer medianValue;

    /**
     * 最小值
     */
    private Integer minValue;

    /**
     * 最大值
     */
    private Integer maxValue;

    /**
     * 对比值
     */
    private Integer compareValue;

    /**
     * 前端是否显示对比值 0：不显示，1：显示
     */
    private Integer shownCompareValue;

    /**
     * 雷达图最大值
     */
    private Integer radarMapMaxValue;

    /**
     * 年龄段
     */
    private Integer ageBracket;

    /**
     * 状态  0：无效 1:有效
     */
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 更新人
     */
    private String updateBy;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOverviewId() {
        return overviewId;
    }

    public void setOverviewId(String overviewId) {
        this.overviewId = overviewId == null ? null : overviewId.trim();
    }

    public String getOneLevelTypeCode() {
        return oneLevelTypeCode;
    }

    public void setOneLevelTypeCode(String oneLevelTypeCode) {
        this.oneLevelTypeCode = oneLevelTypeCode == null ? null : oneLevelTypeCode.trim();
    }

    public String getOneLevelTypeDesc() {
        return oneLevelTypeDesc;
    }

    public void setOneLevelTypeDesc(String oneLevelTypeDesc) {
        this.oneLevelTypeDesc = oneLevelTypeDesc == null ? null : oneLevelTypeDesc.trim();
    }

    public String getOneLevelTypeAlias() {
        return oneLevelTypeAlias;
    }

    public void setOneLevelTypeAlias(String oneLevelTypeAlias) {
        this.oneLevelTypeAlias = oneLevelTypeAlias == null ? null : oneLevelTypeAlias.trim();
    }

    public Integer getAverValue() {
        return averValue;
    }

    public void setAverValue(Integer averValue) {
        this.averValue = averValue;
    }

    public Integer getMedianValue() {
        return medianValue;
    }

    public void setMedianValue(Integer medianValue) {
        this.medianValue = medianValue;
    }

    public Integer getMinValue() {
        return minValue;
    }

    public void setMinValue(Integer minValue) {
        this.minValue = minValue;
    }

    public Integer getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(Integer maxValue) {
        this.maxValue = maxValue;
    }

    public Integer getCompareValue() {
        return compareValue;
    }

    public void setCompareValue(Integer compareValue) {
        this.compareValue = compareValue;
    }

    public Integer getShownCompareValue() {
        return shownCompareValue;
    }

    public void setShownCompareValue(Integer shownCompareValue) {
        this.shownCompareValue = shownCompareValue;
    }

    public Integer getRadarMapMaxValue() {
        return radarMapMaxValue;
    }

    public void setRadarMapMaxValue(Integer radarMapMaxValue) {
        this.radarMapMaxValue = radarMapMaxValue;
    }

    public Integer getAgeBracket() {
        return ageBracket;
    }

    public void setAgeBracket(Integer ageBracket) {
        this.ageBracket = ageBracket;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", overviewId=").append(overviewId);
        sb.append(", oneLevelTypeCode=").append(oneLevelTypeCode);
        sb.append(", oneLevelTypeDesc=").append(oneLevelTypeDesc);
        sb.append(", oneLevelTypeAlias=").append(oneLevelTypeAlias);
        sb.append(", averValue=").append(averValue);
        sb.append(", medianValue=").append(medianValue);
        sb.append(", minValue=").append(minValue);
        sb.append(", maxValue=").append(maxValue);
        sb.append(", compareValue=").append(compareValue);
        sb.append(", shownCompareValue=").append(shownCompareValue);
        sb.append(", radarMapMaxValue=").append(radarMapMaxValue);
        sb.append(", ageBracket=").append(ageBracket);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private SafeguardOverviewDO obj;

        public Builder() {
            this.obj = new SafeguardOverviewDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder overviewId(String overviewId) {
            obj.overviewId = overviewId;
            return this;
        }

        public Builder oneLevelTypeCode(String oneLevelTypeCode) {
            obj.oneLevelTypeCode = oneLevelTypeCode;
            return this;
        }

        public Builder oneLevelTypeDesc(String oneLevelTypeDesc) {
            obj.oneLevelTypeDesc = oneLevelTypeDesc;
            return this;
        }

        public Builder oneLevelTypeAlias(String oneLevelTypeAlias) {
            obj.oneLevelTypeAlias = oneLevelTypeAlias;
            return this;
        }

        public Builder averValue(Integer averValue) {
            obj.averValue = averValue;
            return this;
        }

        public Builder medianValue(Integer medianValue) {
            obj.medianValue = medianValue;
            return this;
        }

        public Builder minValue(Integer minValue) {
            obj.minValue = minValue;
            return this;
        }

        public Builder maxValue(Integer maxValue) {
            obj.maxValue = maxValue;
            return this;
        }

        public Builder compareValue(Integer compareValue) {
            obj.compareValue = compareValue;
            return this;
        }

        public Builder shownCompareValue(Integer shownCompareValue) {
            obj.shownCompareValue = shownCompareValue;
            return this;
        }

        public Builder radarMapMaxValue(Integer radarMapMaxValue) {
            obj.radarMapMaxValue = radarMapMaxValue;
            return this;
        }

        public Builder ageBracket(Integer ageBracket) {
            obj.ageBracket = ageBracket;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public SafeguardOverviewDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        overviewId("overview_id"),
        oneLevelTypeCode("one_level_type_code"),
        oneLevelTypeDesc("one_level_type_desc"),
        oneLevelTypeAlias("one_level_type_alias"),
        averValue("aver_value"),
        medianValue("median_value"),
        minValue("min_value"),
        maxValue("max_value"),
        compareValue("compare_value"),
        shownCompareValue("shown_compare_value"),
        radarMapMaxValue("radar_map_max_value"),
        ageBracket("age_bracket"),
        status("status"),
        delFlag("del_flag"),
        createTime("create_time"),
        updateTime("update_time"),
        createBy("create_by"),
        updateBy("update_by");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}