package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-07-12 16:37:29
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicySimpleDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 保单ID 雪花算法生产
     */
    private Long policyId;

    /**
     * 所属平台(0:微信，1:抖音小程序)
     */
    private Integer platform;

    /**
     * 所属用户
     */
    private String userId;

    /**
     * 所属用户手机号
     */
    private String userPhone;

    /**
     * 保司ID
     */
    private String companyId;

    /**
     * 保司名称
     */
    private String companyName;

    /**
     * 保司简称
     */
    private String companyNameShort;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品类型编号
     */
    private String productType;

    /**
     * 产品四级类型标号
     */
    private String productFourType;

    /**
     * 产品三级类型标号
     */
    private String productThreeType;

    /**
     * 产品二级类型编号
     */
    private String productTwoType;

    /**
     * 产品一级类型编号
     */
    private String productTopType;

    /**
     * 被保人
     */
    private String insurantName;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public Integer getPlatform() {
        return platform;
    }

    public void setPlatform(Integer platform) {
        this.platform = platform;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone == null ? null : userPhone.trim();
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId == null ? null : companyId.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getCompanyNameShort() {
        return companyNameShort;
    }

    public void setCompanyNameShort(String companyNameShort) {
        this.companyNameShort = companyNameShort == null ? null : companyNameShort.trim();
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId == null ? null : productId.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType == null ? null : productType.trim();
    }

    public String getProductFourType() {
        return productFourType;
    }

    public void setProductFourType(String productFourType) {
        this.productFourType = productFourType == null ? null : productFourType.trim();
    }

    public String getProductThreeType() {
        return productThreeType;
    }

    public void setProductThreeType(String productThreeType) {
        this.productThreeType = productThreeType == null ? null : productThreeType.trim();
    }

    public String getProductTwoType() {
        return productTwoType;
    }

    public void setProductTwoType(String productTwoType) {
        this.productTwoType = productTwoType == null ? null : productTwoType.trim();
    }

    public String getProductTopType() {
        return productTopType;
    }

    public void setProductTopType(String productTopType) {
        this.productTopType = productTopType == null ? null : productTopType.trim();
    }

    public String getInsurantName() {
        return insurantName;
    }

    public void setInsurantName(String insurantName) {
        this.insurantName = insurantName == null ? null : insurantName.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", policyId=").append(policyId);
        sb.append(", platform=").append(platform);
        sb.append(", userId=").append(userId);
        sb.append(", userPhone=").append(userPhone);
        sb.append(", companyId=").append(companyId);
        sb.append(", companyName=").append(companyName);
        sb.append(", companyNameShort=").append(companyNameShort);
        sb.append(", productId=").append(productId);
        sb.append(", productName=").append(productName);
        sb.append(", productType=").append(productType);
        sb.append(", productFourType=").append(productFourType);
        sb.append(", productThreeType=").append(productThreeType);
        sb.append(", productTwoType=").append(productTwoType);
        sb.append(", productTopType=").append(productTopType);
        sb.append(", insurantName=").append(insurantName);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private PolicySimpleDO obj;

        public Builder() {
            this.obj = new PolicySimpleDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder policyId(Long policyId) {
            obj.policyId = policyId;
            return this;
        }

        public Builder platform(Integer platform) {
            obj.platform = platform;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder userPhone(String userPhone) {
            obj.userPhone = userPhone;
            return this;
        }

        public Builder companyId(String companyId) {
            obj.companyId = companyId;
            return this;
        }

        public Builder companyName(String companyName) {
            obj.companyName = companyName;
            return this;
        }

        public Builder companyNameShort(String companyNameShort) {
            obj.companyNameShort = companyNameShort;
            return this;
        }

        public Builder productId(String productId) {
            obj.productId = productId;
            return this;
        }

        public Builder productName(String productName) {
            obj.productName = productName;
            return this;
        }

        public Builder productType(String productType) {
            obj.productType = productType;
            return this;
        }

        public Builder productFourType(String productFourType) {
            obj.productFourType = productFourType;
            return this;
        }

        public Builder productThreeType(String productThreeType) {
            obj.productThreeType = productThreeType;
            return this;
        }

        public Builder productTwoType(String productTwoType) {
            obj.productTwoType = productTwoType;
            return this;
        }

        public Builder productTopType(String productTopType) {
            obj.productTopType = productTopType;
            return this;
        }

        public Builder insurantName(String insurantName) {
            obj.insurantName = insurantName;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public PolicySimpleDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        policyId("policy_id"),
        platform("platform"),
        userId("user_id"),
        userPhone("user_phone"),
        companyId("company_id"),
        companyName("company_name"),
        companyNameShort("company_name_short"),
        productId("product_id"),
        productName("product_name"),
        productType("product_type"),
        productFourType("product_four_type"),
        productThreeType("product_three_type"),
        productTwoType("product_two_type"),
        productTopType("product_top_type"),
        insurantName("insurant_name"),
        status("status"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}