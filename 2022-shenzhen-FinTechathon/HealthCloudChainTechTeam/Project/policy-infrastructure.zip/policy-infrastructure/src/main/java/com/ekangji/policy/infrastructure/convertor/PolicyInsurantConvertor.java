package com.ekangji.policy.infrastructure.convertor;


import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyInsurantDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberStatisticsDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/18 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyInsurantConvertor {

    PolicyInsurantDO convert(PolicyInsurant param);

    PolicyInsurant convert(PolicyInsurantDO param);

    List<PolicyInsurant> convert(List<PolicyInsurantDO> param);

    List<PolicyInsurant> convertT(List<PolicyInsurantDO> param);

}
