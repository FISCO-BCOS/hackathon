package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.gateway.PolicyPayDetailGateway;
import com.ekangji.policy.domain.policy.PolicyPayDetail;
import com.ekangji.policy.infrastructure.convertor.PolicyPayDetailConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyPayDetailDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyPayDetailBOMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyPayDetailMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyPayDetailGatewayImpl implements PolicyPayDetailGateway {

    @Resource
    private PolicyPayDetailMapper policyPayDetailMapper;

    @Resource
    private PolicyPayDetailBOMapper policyPayDetailBOMapper;

    @Resource
    private PolicyPayDetailConvertor policyPayDetailConvertor;

    @Override
    public Long save(PolicyPayDetail policyPayDetail) {
        return null;
    }

    @Override
    public int delete(PolicyPayDetail policyPayDetail) {
        PolicyPayDetailDOExample example = new PolicyPayDetailDOExample();
        PolicyPayDetailDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyPayDetail.getPolicyId());
        return policyPayDetailMapper.deleteByExample(example);
    }

    @Override
    public int update(PolicyPayDetail policyPayDetail) {
        return 0;
    }

    @Override
    public PolicyPayDetail get(PolicyPayDetail policyPayDetail) {
        PolicyPayDetailDOExample example = new PolicyPayDetailDOExample();
        PolicyPayDetailDOExample.Criteria criteria = example.createCriteria();
        criteria.andPayLabelIdEqualTo(policyPayDetail.getPayLabelId());
        PolicyPayDetailDO payDetailDO = policyPayDetailMapper.selectOneByExample(example);
        if (Objects.nonNull(payDetailDO)) {
            return policyPayDetailConvertor.convert(payDetailDO);
        }
        return null;
    }

    @Override
    public List<PolicyPayDetail> list(PolicyPayDetail policyPayDetail) {
        this.query(policyPayDetail);
        return null;
    }

    @Override
    public PageInfo<PolicyPayDetail> page(PolicyPayDetail policyPayDetail) {
        return null;
    }


    @Override
    public int batchSave(List<PolicyPayDetail> policyPayDetail) {
        List<PolicyPayDetailBO> ppdDO = policyPayDetailConvertor.convert(policyPayDetail);
        return policyPayDetailBOMapper.batchSave(ppdDO);
    }

    @Override
    public int deleteByPolicyAdditional(PolicyPayDetail payDetail) {
        PolicyPayDetailDOExample example = new PolicyPayDetailDOExample();
        PolicyPayDetailDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(payDetail.getPolicyId());
        criteria.andAdditionalIdIsNotNull();
        return policyPayDetailBOMapper.deleteByExample(example);
    }

    @Override
    public PolicyPayDetail findCurrentYearPremiumByPolicy(PolicyPayDetail policyPayDetail) {
        PolicyPayDetailBO query = policyPayDetailConvertor.convert2(policyPayDetail);
        PolicyPayDetailBO ppBO = policyPayDetailBOMapper.countCurrentYearPremiumByPolicy(query);
        PolicyPayDetail payDetail = policyPayDetailConvertor.convert2(ppBO);
        return payDetail;
    }

    @Override
    public PolicyPayDetail findTotalPremiumByPolicy(PolicyPayDetail policyPayDetail) {
        PolicyPayDetailBO query = policyPayDetailConvertor.convert2(policyPayDetail);
        PolicyPayDetailBO ppBO = policyPayDetailBOMapper.countTotalPremiumByPolicy(query);
        PolicyPayDetail payDetail = policyPayDetailConvertor.convert2(ppBO);
        return payDetail;
    }

    @Override
    public List<PolicyPayDetail> listByPolicy(PolicyPayDetail policyPayDetail) {
        PolicyPayDetailDOExample example = new PolicyPayDetailDOExample();
        PolicyPayDetailDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyPayDetail.getPolicyId());
        if (Objects.nonNull(policyPayDetail.getAdditionalId())) {
            criteria.andAdditionalIdEqualTo(policyPayDetail.getAdditionalId());
        } else {
            criteria.andAdditionalIdIsNull();
        }
        example.setOrderByClause("pay_date asc");
        List<PolicyPayDetailDO> policyPayDetailDOS = policyPayDetailMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(policyPayDetailDOS)) {
            return policyPayDetailConvertor.convert2(policyPayDetailDOS);
        }
        return Collections.emptyList();
    }

    @Override
    public int updateLabelStatus(PolicyPayDetail policyPayDetail) {
        PolicyPayDetailDOExample example = new PolicyPayDetailDOExample();
        PolicyPayDetailDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyPayDetail.getPolicyId());
        criteria.andPayLabelEqualTo(policyPayDetail.getPayLabel());
        PolicyPayDetailDO payDetailDO = new PolicyPayDetailDO();
        payDetailDO.setStatus(policyPayDetail.getStatus());
        return policyPayDetailMapper.updateByExampleSelective(payDetailDO,example);
    }

    private List<PolicyPayDetailDO> query(PolicyPayDetail policyPayDetail){
        PolicyPayDetailDOExample example = new PolicyPayDetailDOExample();
        PolicyPayDetailDOExample.Criteria criteria = example.createCriteria();

        if (Objects.nonNull(policyPayDetail.getPolicyId())) {
            criteria.andPolicyIdEqualTo(policyPayDetail.getPolicyId());
        }
        if (Objects.nonNull(policyPayDetail.getAdditionalId())) {
            criteria.andAdditionalIdEqualTo(policyPayDetail.getAdditionalId());
        } else {
            criteria.andAdditionalIdIsNull();
        }
        return policyPayDetailMapper.selectByExample(example);
    }
}
