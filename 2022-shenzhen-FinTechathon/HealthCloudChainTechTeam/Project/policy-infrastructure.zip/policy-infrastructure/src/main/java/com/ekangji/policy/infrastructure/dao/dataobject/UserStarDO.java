package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-07-12 17:53:12
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class UserStarDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 星球ID
     */
    private Long starId;

    /**
     * 星球昵称(持有者)
     */
    private String nickName;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 用户手机号
     */
    private String userPhone;

    /**
     * 唯一序号(根据产品规则生成)
     */
    private String sequence;

    /**
     * 链上HASH地址
     */
    private String chainAddr;

    /**
     * 链上图片url
     */
    private String pictureUrl;

    /**
     * oss服务fileId
     */
    private String fileId;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常,0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStarId() {
        return starId;
    }

    public void setStarId(Long starId) {
        this.starId = starId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName == null ? null : nickName.trim();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone == null ? null : userPhone.trim();
    }

    public String getSequence() {
        return sequence;
    }

    public void setSequence(String sequence) {
        this.sequence = sequence == null ? null : sequence.trim();
    }

    public String getChainAddr() {
        return chainAddr;
    }

    public void setChainAddr(String chainAddr) {
        this.chainAddr = chainAddr == null ? null : chainAddr.trim();
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl == null ? null : pictureUrl.trim();
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId == null ? null : fileId.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", starId=").append(starId);
        sb.append(", nickName=").append(nickName);
        sb.append(", userId=").append(userId);
        sb.append(", userPhone=").append(userPhone);
        sb.append(", sequence=").append(sequence);
        sb.append(", chainAddr=").append(chainAddr);
        sb.append(", pictureUrl=").append(pictureUrl);
        sb.append(", fileId=").append(fileId);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private UserStarDO obj;

        public Builder() {
            this.obj = new UserStarDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder starId(Long starId) {
            obj.starId = starId;
            return this;
        }

        public Builder nickName(String nickName) {
            obj.nickName = nickName;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder userPhone(String userPhone) {
            obj.userPhone = userPhone;
            return this;
        }

        public Builder sequence(String sequence) {
            obj.sequence = sequence;
            return this;
        }

        public Builder chainAddr(String chainAddr) {
            obj.chainAddr = chainAddr;
            return this;
        }

        public Builder pictureUrl(String pictureUrl) {
            obj.pictureUrl = pictureUrl;
            return this;
        }

        public Builder fileId(String fileId) {
            obj.fileId = fileId;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public UserStarDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        starId("star_id"),
        nickName("nick_name"),
        userId("user_id"),
        userPhone("user_phone"),
        sequence("sequence"),
        chainAddr("chain_addr"),
        pictureUrl("picture_url"),
        fileId("file_id"),
        status("status"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}