package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * @Description
 * @author liuchen
 * @date 2022-05-18 11:07
 */
public interface PolicyAdditionalBOMapper extends PolicyAdditionalMapper{


    List<PolicyAdditionalBO> queryPolicyByAgeBracketAndProdType(PolicyAdditionalBO policyAdditionalBO);

    int batchSave(@Param("list")  List<PolicyAdditionalDO> list);

    /**
     * 根据保单ID逻辑删除附加险
     * @param policyAdditionalDO
     * @return
     */
    int logicDeleteByPolicyId(PolicyAdditionalDO policyAdditionalDO);

    /**
     * 根据被保人id获取保单信息
     * @param policyInsurantDO
     * @return
     */
    List<PolicyAdditionalBO> listPolicyByInsurantId(PolicyInsurantDO policyInsurantDO);

    List<PolicyAdditionalBO> batchGetPolicyList(@Param("policyIds") Long[] policyIds);
}
