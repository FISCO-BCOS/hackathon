package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   zhangjun
 * @date   2022-02-16 10:14:32
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductCompanyDO implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 产品id
     */
    private String productId;

    /**
     * 公司id
     */
    private String companyId;

    /**
     * 公司名称
     */
    private String companyName;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 一级产品类别
     */
    private String oneLevelType;

    /**
     * 二级产品类别
     */
    private String twoLevelType;

    /**
     * 三级产品类别
     */
    private String threeLevelType;

    /**
     * 四级产品类别
     */
    private String fourLevelType;

    /**
     * 设计类型 ProdDesiCode_00 传统型产品 ProdDesiCode_01 新型产品
     */
    private String designType;

    /**
     * 产品特殊属性 00 航空意外险 01 学生平安险 02 女性专属产品 03 少儿专属产品 04 老年专属产品
     */
    private String productSpecial;

    /**
     * 保期类型 00 短期（一年及一年以下）01 长期（超过一年或含有保证续保条款）
     */
    private String timeType;

    /**
     * 条款编码
     */
    private String clauseCode;

    /**
     * 条款文件名
     */
    private String clauseFileName;

    /**
     * 条款文件
     */
    private String clauseFileId;

    /**
     * 承保方式 00 团队 01 个人
     */
    private String insuranceStyle;

    /**
     * 交费方式 00 一次性缴费 01 分起交费 02 分期交费一次性交费兼有 03灵活交费
     */
    private String payWay;

    /**
     * 停售日期
     */
    private Date stopDate;
    /**
     *
     */
    private Long id;

    /**
     * 是否拆解 0 否 1是
     */
    private Integer isDismantle;

    /**
     * 删除标志（1 代表存在 0 代表删除）
     */
    private Integer delFlag;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否有效 （0：无效 ，1：有效）
     */
    private Integer status;
    /**
     * 01 在售 02 停售 03 停用
     */
    private String saleStatus;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId == null ? null : productId.trim();
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId == null ? null : companyId.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getOneLevelType() {
        return oneLevelType;
    }

    public void setOneLevelType(String oneLevelType) {
        this.oneLevelType = oneLevelType == null ? null : oneLevelType.trim();
    }

    public String getTwoLevelType() {
        return twoLevelType;
    }

    public void setTwoLevelType(String twoLevelType) {
        this.twoLevelType = twoLevelType == null ? null : twoLevelType.trim();
    }

    public String getThreeLevelType() {
        return threeLevelType;
    }

    public void setThreeLevelType(String threeLevelType) {
        this.threeLevelType = threeLevelType == null ? null : threeLevelType.trim();
    }

    public String getFourLevelType() {
        return fourLevelType;
    }

    public void setFourLevelType(String fourLevelType) {
        this.fourLevelType = fourLevelType == null ? null : fourLevelType.trim();
    }

    public String getDesignType() {
        return designType;
    }

    public void setDesignType(String designType) {
        this.designType = designType == null ? null : designType.trim();
    }

    public String getProductSpecial() {
        return productSpecial;
    }

    public void setProductSpecial(String productSpecial) {
        this.productSpecial = productSpecial == null ? null : productSpecial.trim();
    }

    public String getTimeType() {
        return timeType;
    }

    public void setTimeType(String timeType) {
        this.timeType = timeType == null ? null : timeType.trim();
    }

    public String getClauseCode() {
        return clauseCode;
    }

    public void setClauseCode(String clauseCode) {
        this.clauseCode = clauseCode == null ? null : clauseCode.trim();
    }

    public String getClauseFileName() {
        return clauseFileName;
    }

    public void setClauseFileName(String clauseFileName) {
        this.clauseFileName = clauseFileName == null ? null : clauseFileName.trim();
    }

    public String getClauseFileId() {
        return clauseFileId;
    }

    public void setClauseFileId(String clauseFileId) {
        this.clauseFileId = clauseFileId == null ? null : clauseFileId.trim();
    }

    public String getInsuranceStyle() {
        return insuranceStyle;
    }

    public void setInsuranceStyle(String insuranceStyle) {
        this.insuranceStyle = insuranceStyle == null ? null : insuranceStyle.trim();
    }

    public String getPayWay() {
        return payWay;
    }

    public void setPayWay(String payWay) {
        this.payWay = payWay == null ? null : payWay.trim();
    }

    public Date getStopDate() {
        return stopDate;
    }

    public void setStopDate(Date stopDate) {
        this.stopDate = stopDate;
    }

    public String getSaleStatus() {
        return saleStatus;
    }

    public void setSaleStatus(String saleStatus) {
        this.saleStatus = saleStatus == null ? null : saleStatus.trim();
    }

    public Integer getIsDismantle() {
        return isDismantle;
    }

    public void setIsDismantle(Integer isDismantle) {
        this.isDismantle = isDismantle;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", productId=").append(productId);
        sb.append(", companyId=").append(companyId);
        sb.append(", productName=").append(productName);
        sb.append(", oneLevelType=").append(oneLevelType);
        sb.append(", twoLevelType=").append(twoLevelType);
        sb.append(", threeLevelType=").append(threeLevelType);
        sb.append(", fourLevelType=").append(fourLevelType);
        sb.append(", designType=").append(designType);
        sb.append(", productSpecial=").append(productSpecial);
        sb.append(", timeType=").append(timeType);
        sb.append(", clauseCode=").append(clauseCode);
        sb.append(", clauseFileName=").append(clauseFileName);
        sb.append(", clauseFileId=").append(clauseFileId);
        sb.append(", insuranceStyle=").append(insuranceStyle);
        sb.append(", payWay=").append(payWay);
        sb.append(", stopDate=").append(stopDate);
        sb.append(", saleStatus=").append(saleStatus);
        sb.append(", isDismantle=").append(isDismantle);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", status=").append(status);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public enum Column {
        id("id"),
        productId("product_id"),
        companyId("company_id"),
        productName("product_name"),
        oneLevelType("one_level_type"),
        twoLevelType("two_level_type"),
        threeLevelType("three_level_type"),
        fourLevelType("four_level_type"),
        designType("design_type"),
        productSpecial("product_special"),
        timeType("time_type"),
        clauseCode("clause_code"),
        clauseFileName("clause_file_name"),
        clauseFileId("clause_file_id"),
        insuranceStyle("insurance_style"),
        payWay("pay_way"),
        stopDate("stop_date"),
        saleStatus("sale_status"),
        isDismantle("is_ dismantle"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time"),
        status("status");

        private final String column;

        Column(String column) {
            this.column = column;
        }

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }

    public static class Builder {
        private InsuranceProductCompanyDO obj;

        public Builder() {
            this.obj = new InsuranceProductCompanyDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder productId(String productId) {
            obj.productId = productId;
            return this;
        }

        public Builder companyId(String companyId) {
            obj.companyId = companyId;
            return this;
        }

        public Builder productName(String productName) {
            obj.productName = productName;
            return this;
        }

        public Builder oneLevelType(String oneLevelType) {
            obj.oneLevelType = oneLevelType;
            return this;
        }

        public Builder twoLevelType(String twoLevelType) {
            obj.twoLevelType = twoLevelType;
            return this;
        }

        public Builder threeLevelType(String threeLevelType) {
            obj.threeLevelType = threeLevelType;
            return this;
        }

        public Builder fourLevelType(String fourLevelType) {
            obj.fourLevelType = fourLevelType;
            return this;
        }

        public Builder designType(String designType) {
            obj.designType = designType;
            return this;
        }

        public Builder productSpecial(String productSpecial) {
            obj.productSpecial = productSpecial;
            return this;
        }

        public Builder timeType(String timeType) {
            obj.timeType = timeType;
            return this;
        }

        public Builder clauseCode(String clauseCode) {
            obj.clauseCode = clauseCode;
            return this;
        }

        public Builder clauseFileName(String clauseFileName) {
            obj.clauseFileName = clauseFileName;
            return this;
        }

        public Builder clauseFileId(String clauseFileId) {
            obj.clauseFileId = clauseFileId;
            return this;
        }

        public Builder insuranceStyle(String insuranceStyle) {
            obj.insuranceStyle = insuranceStyle;
            return this;
        }

        public Builder payWay(String payWay) {
            obj.payWay = payWay;
            return this;
        }

        public Builder stopDate(Date stopDate) {
            obj.stopDate = stopDate;
            return this;
        }

        public Builder saleStatus(String saleStatus) {
            obj.saleStatus = saleStatus;
            return this;
        }

        public Builder isDismantle(Integer isDismantle) {
            obj.isDismantle = isDismantle;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public InsuranceProductCompanyDO build() {
            return this.obj;
        }
    }
}