package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyAdditionalGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.infrastructure.convertor.PolicyAdditionalConvertor;
import com.ekangji.policy.infrastructure.convertor.PolicyInsurantConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyAdditionalBOMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyAdditionalMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Repository
public class PolicyAdditionalGatewayImpl implements PolicyAdditionalGateway {

    @Resource
    private PolicyAdditionalMapper policyAdditionalMapper;
    @Resource
    private PolicyAdditionalBOMapper policyAdditionalBOMapper;
    @Resource
    private PolicyAdditionalConvertor policyAdditionalConvertor;

    @Resource
    private PolicyInsurantConvertor policyInsurantConvertor;

    @Override
    public Long save(PolicyAdditional entity) {
        PolicyAdditionalDO policyAdditionalDO = policyAdditionalConvertor.convert(entity);
        policyAdditionalMapper.insertSelective(policyAdditionalDO);
        return policyAdditionalDO.getAdditionalId();
    }

    @Override
    public int delete(PolicyAdditional entity) {
        PolicyAdditionalDOExample example = new PolicyAdditionalDOExample();
        PolicyAdditionalDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(entity.getPolicyId());
        return policyAdditionalMapper.deleteByExample(example);
    }

    @Override
    public int update(PolicyAdditional entity) {
        PolicyAdditionalDO policyDO = policyAdditionalConvertor.convert(entity);
        PolicyAdditionalDOExample example = new PolicyAdditionalDOExample();
        PolicyAdditionalDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(policyDO.getPolicyId());
        criteria.andAdditionalIdEqualTo(policyDO.getAdditionalId());
        return policyAdditionalMapper.updateByExampleSelective(policyDO,example);
    }

    @Override
    public PolicyAdditional get(PolicyAdditional entity) {
        PolicyAdditionalDOExample example = new PolicyAdditionalDOExample();
        PolicyAdditionalDOExample.Criteria criteria = example.createCriteria();
        criteria.andPolicyIdEqualTo(entity.getPolicyId());
        PolicyAdditionalDO policyDO = policyAdditionalMapper.selectOneByExample(example);
        if (Objects.nonNull(policyDO)) {
            return policyAdditionalConvertor.convert(policyDO);
        }
        return null;
    }

    @Override
    public List<PolicyAdditional> list(PolicyAdditional entity) {
        List<PolicyAdditionalDO> PolicyAdditionalDOList = this.query(entity);
        if (CollectionUtils.isNotEmpty(PolicyAdditionalDOList)){
            return policyAdditionalConvertor.convert(PolicyAdditionalDOList);
        }
        return Collections.emptyList();
    }

    @Override
    public PageInfo<PolicyAdditional> page(PolicyAdditional entity) {
        return null;
    }

    @Override
    public int batchAdd(List<PolicyAdditional> additionalList) {

        List<PolicyAdditionalDO> paDOList = additionalList.parallelStream().map(c ->{
           return policyAdditionalConvertor.convert(c);
        }).collect(Collectors.toList());
        return policyAdditionalBOMapper.batchSave(paDOList);
      //  return policyAdditionalMapper.batchInsert(paDOList);
    }

    @Override
    public int logicDeleteByPolicyId(PolicyAdditional policyAdditional) {
        return policyAdditionalBOMapper.logicDeleteByPolicyId(policyAdditionalConvertor.convert(policyAdditional));
    }

    @Override
    public List<PolicyAdditional> listByPolicy(PolicyAdditional policyAdditional) {
        List<PolicyAdditionalDO> doList = query(policyAdditional);
        if (CollectionUtils.isNotEmpty(doList)) {
            return policyAdditionalConvertor.convert(doList);
        }
        return Collections.emptyList();
    }

    private List<PolicyAdditionalDO> query(PolicyAdditional policyAdditional) {
        PolicyAdditionalDOExample example = new PolicyAdditionalDOExample();
        PolicyAdditionalDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(policyAdditional.getPolicyId())) {
            criteria.andPolicyIdEqualTo(policyAdditional.getPolicyId());
        }
        // 根据保单ID数组查询
        if(CollectionUtils.isNotEmpty(policyAdditional.getPolicyIds())){
            criteria.andPolicyIdIn(policyAdditional.getPolicyIds());
        }
        if(Objects.nonNull(policyAdditional.getDelFlag())) {
            criteria.andDelFlagEqualTo(policyAdditional.getDelFlag());
        }

        return policyAdditionalMapper.selectByExample(example);
    }

    @Override
    public List<PolicyAdditional> queryAddPolicyByAgeBracketAndProdType(PolicyAdditional policyAdditional) {
        PolicyAdditionalBO policyAdditionalBO = policyAdditionalConvertor.convert2(policyAdditional);
        List<PolicyAdditionalBO> policyBOList = policyAdditionalBOMapper.queryPolicyByAgeBracketAndProdType(policyAdditionalBO);
        if (CollectionUtils.isNotEmpty(policyBOList)){
            return policyAdditionalConvertor.convert2(policyBOList);
        }
        return null;
    }

    @Override
    public List<PolicyAdditional> listProductIdEmpty() {
        PolicyAdditionalDOExample example = new PolicyAdditionalDOExample();
        PolicyAdditionalDOExample.Criteria criteria1 = example.createCriteria();
        PolicyAdditionalDOExample.Criteria criteria2 = example.createCriteria();
        criteria1.andProductIdIsNull();
        criteria2.andProductIdEqualTo("");
        criteria1.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria2.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.or(criteria2);
        List<PolicyAdditionalDO> policyDOList = policyAdditionalBOMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(policyDOList)) {
            return policyAdditionalConvertor.convert(policyDOList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public List<PolicyAdditional> listPolicyByInsurantId(PolicyInsurant policyInsurant) {
        PolicyInsurantDO policyInsurantDO = policyInsurantConvertor.convert(policyInsurant);
        policyInsurantDO.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyAdditionalBO> policyBOList = policyAdditionalBOMapper.listPolicyByInsurantId(policyInsurantDO);
        if (CollectionUtils.isNotEmpty(policyBOList)){
            return policyAdditionalConvertor.convert2(policyBOList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public List<PolicyAdditional> selectListByPolicyIds(Long[] policyIds) {
        List<PolicyAdditionalBO> policyBOList = policyAdditionalBOMapper.batchGetPolicyList(policyIds);
        return policyAdditionalConvertor.convert2(policyBOList);
    }
}
