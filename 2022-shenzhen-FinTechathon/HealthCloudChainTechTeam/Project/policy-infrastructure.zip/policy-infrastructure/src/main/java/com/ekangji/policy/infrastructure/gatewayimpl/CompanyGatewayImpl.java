package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.SqlUtil;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.CompanyGateway;
import com.ekangji.policy.domain.insurance.InsuranceCompany;
import com.ekangji.policy.infrastructure.convertor.CompanyConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceCompanyDOExample;
import com.ekangji.policy.infrastructure.dao.productcenter.InsuranceCompanyMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * 保险公司
 * @author 李鑫涛
 * @date 2022/2/11 13:56
 */
@Repository
public class CompanyGatewayImpl implements CompanyGateway {

    @Resource
    private InsuranceCompanyMapper companyMapper;

    @Resource
    private CompanyConvertor companyConvertor;

    @Override
    public Long save(InsuranceCompany company) {
        return null;
    }

    @Override
    public int delete(InsuranceCompany company) {
        return 0;
    }

    @Override
    public int update(InsuranceCompany company) {
        InsuranceCompanyDO companyDO = companyConvertor.convert(company);
        companyDO.setUpdateTime(new Date());
        companyDO.setUpdateBy(ShiroUtils.getUserIdStr());
        InsuranceCompanyDOExample example = new InsuranceCompanyDOExample();
        InsuranceCompanyDOExample.Criteria criteria = example.createCriteria();
        criteria.andCompanyIdEqualTo(company.getCompanyId());
        return companyMapper.updateByExampleSelective(companyDO,example);
    }

    @Override
    public InsuranceCompany get(InsuranceCompany company) {
        List<InsuranceCompanyDO> companyDOList = this.query(company);
        if (CollectionUtils.isNotEmpty(companyDOList)){
            return companyConvertor.convert(companyDOList.get(0));
        }
        return null;
    }

    @Override
    public List<InsuranceCompany> list(InsuranceCompany company) {
        List<InsuranceCompanyDO> companyDOList = this.query(company);
        if (CollectionUtils.isNotEmpty(companyDOList)){
            return companyConvertor.convert(companyDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<InsuranceCompany> page(InsuranceCompany company) {
        return companyConvertor.convert(PageHelper.startPage(company.getPageNum(), company.getPageSize())
                .doSelectPageInfo(() -> list(company)));
    }

    private List<InsuranceCompanyDO> query(InsuranceCompany company) {
        InsuranceCompanyDOExample example = new InsuranceCompanyDOExample();
        InsuranceCompanyDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotEmpty(company.getCompanyType())){
            criteria.andCompanyTypeEqualTo(company.getCompanyType());
        }
        if (StringUtils.isNotEmpty(company.getCompanyName())){
            criteria.andCompanyNameLike(SqlUtil.like(company.getCompanyName()));
        }
        if (StringUtils.isNotEmpty(company.getCompanyNameShort())){
            criteria.andCompanyNameShortLike(SqlUtil.like(company.getCompanyNameShort()));
        }
        if (StringUtils.isNotEmpty(company.getProvinceCode())){
            criteria.andProvinceCodeEqualTo(company.getProvinceCode());
        }
        if (StringUtils.isNotEmpty(company.getCityCode())){
            criteria.andCityCodeEqualTo(company.getCityCode());
        }
        if (StringUtils.isNotBlank(company.getCompanyId())){
            criteria.andCompanyIdEqualTo(company.getCompanyId());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        example.setOrderByClause("ID");
        return companyMapper.selectByExample(example);
    }

}
