package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyMemberProductTypeStatisticsBOMapper extends PolicyMemberProductTypeStatisticsMapper {

    /**
     * 获取成员一级保险类别数据
     * @param queryBO
     * @return
     */
    List<PolicyMemberProductTypeStatisticsBO> findMemberProductTopTypeInfo(PolicyMemberProductTypeStatisticsBO queryBO);

    /**
     * 获取成员某一级保险子类别数据
     * @param queryBO
     * @return
     */
    List<PolicyMemberProductTypeStatisticsBO> findMemberProductTypeInfo(PolicyMemberProductTypeStatisticsBO queryBO);

    /**
     * 更新总保额-主险
     * @param convert
     * @return
     */
    int updateTotalAmountPrimary(PolicyMemberProductTypeStatisticsBO convert);

    /**
     * 更新总保额-附加险
     * @param convert
     * @return
     */
    int updateTotalAmountAddition(PolicyMemberProductTypeStatisticsBO convert);
}