package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyInsurantDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyInsurantDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface PolicyInsurantBOMapper extends PolicyInsurantMapper{

   int batchSave(@Param("list") List<PolicyInsurantDO> list);

    /**
     * 计算在保人数
     * @return
     */
    long countByAgeBracket(Map<String,Object> map);
}