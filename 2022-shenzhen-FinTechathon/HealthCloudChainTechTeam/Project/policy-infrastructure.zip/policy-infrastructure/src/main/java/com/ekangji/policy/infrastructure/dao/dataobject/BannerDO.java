package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * Banner Bean
 * @author   Yangzhiwen
 * @date   2022-02-18 10:35:24
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class BannerDO implements Serializable {
    /**
     * ID
     */
    private Long id;

    /**
     * 所属渠道 0小程序 1IOS 2安卓 3WEB 4 H5
     */
    private Integer clientChannel;

    /**
     * 展示位置 1 首页
     */
    private Integer showPostion;

    /**
     * banner标题
     */
    private String title;

    /**
     * banner图片URL
     */
    private String imgUrl;

    /**
     * banner跳转链接
     */
    private String jumpUrl;

    /**
     * 0:小知识文章 1：自定义链接 2：不跳转
     */
    private Integer jumpType;

    /**
     * 状态 0：未生效 1：生效
     */
    private Integer status;

    /**
     * 权重
     */
    private Integer weight;

    /**
     * banner点击次数
     */
    private Integer bannerNum;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人ID
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人ID
     */
    private String updateBy;

    private static final long serialVersionUID = 1L;


    public enum Column {
        id("id"),
        clientChannel("client_channel"),
        showPostion("show_postion"),
        title("title"),
        imgUrl("img_url"),
        jumpUrl("jump_url"),
        jumpType("jump_type"),
        status("status"),
        weight("weight"),
        bannerNum("banner_num"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}