package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-05-27 17:07:37
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class EnsuredReadConfigDO implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 最小保障分
     */
    private Integer minScore;

    /**
     * 最大保障分
     */
    private Integer maxScore;

    /**
     * 封面文案
     */
    private String coverTitle;

    /**
     * 解读文案
     */
    private String readContent;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getMinScore() {
        return minScore;
    }

    public void setMinScore(Integer minScore) {
        this.minScore = minScore;
    }

    public Integer getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(Integer maxScore) {
        this.maxScore = maxScore;
    }

    public String getCoverTitle() {
        return coverTitle;
    }

    public void setCoverTitle(String coverTitle) {
        this.coverTitle = coverTitle == null ? null : coverTitle.trim();
    }

    public String getReadContent() {
        return readContent;
    }

    public void setReadContent(String readContent) {
        this.readContent = readContent == null ? null : readContent.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", minScore=").append(minScore);
        sb.append(", maxScore=").append(maxScore);
        sb.append(", coverTitle=").append(coverTitle);
        sb.append(", readContent=").append(readContent);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private EnsuredReadConfigDO obj;

        public Builder() {
            this.obj = new EnsuredReadConfigDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder minScore(Integer minScore) {
            obj.minScore = minScore;
            return this;
        }

        public Builder maxScore(Integer maxScore) {
            obj.maxScore = maxScore;
            return this;
        }

        public Builder coverTitle(String coverTitle) {
            obj.coverTitle = coverTitle;
            return this;
        }

        public Builder readContent(String readContent) {
            obj.readContent = readContent;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public EnsuredReadConfigDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        minScore("min_score"),
        maxScore("max_score"),
        coverTitle("cover_title"),
        readContent("read_content"),
        status("status"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by"),
        delFlag("del_flag");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}