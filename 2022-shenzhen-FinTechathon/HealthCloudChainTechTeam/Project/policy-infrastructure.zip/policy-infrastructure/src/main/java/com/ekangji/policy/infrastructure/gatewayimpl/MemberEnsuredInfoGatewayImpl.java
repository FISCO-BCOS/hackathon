package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonIfEnum;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.MemberEnsuredInfoGateway;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.ekangji.policy.infrastructure.convertor.FamilyEnsuredInfoConvertor;
import com.ekangji.policy.infrastructure.convertor.MemberEnsuredInfoConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoBO;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.MemberEnsuredInfoDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.FamilyEnsuredInfoMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.MemberEnsuredInfoMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;
import sun.management.resources.agent;

import javax.annotation.Resource;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Repository
public class MemberEnsuredInfoGatewayImpl implements MemberEnsuredInfoGateway {
    @Resource
    private MemberEnsuredInfoMapper memberEnsuredInfoMapper;
    @Resource
    private MemberEnsuredInfoConvertor memberEnsuredInfoConvertor;
    @Override
    public Long save(MemberEnsuredInfo entity) {
        MemberEnsuredInfoDO memberEnsuredInfoDO = memberEnsuredInfoConvertor.convert(entity);
        memberEnsuredInfoDO.setCreateTime(new Date());
        memberEnsuredInfoDO.setUpdateTime(new Date());
//        memberEnsuredInfoDO.setCreateBy(ShiroUtils.getUserIdStr());
//        memberEnsuredInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        memberEnsuredInfoDO.setStatus(CommonStatusEnum.VALID.getCode());
        memberEnsuredInfoMapper.insertSelective(memberEnsuredInfoDO);
        return memberEnsuredInfoDO.getId();
    }

    @Override
    public int delete(MemberEnsuredInfo entity) {
        return 0;
    }

    @Override
    public int update(MemberEnsuredInfo entity) {
        MemberEnsuredInfoDO memberEnsuredInfoDO = memberEnsuredInfoConvertor.convert(entity);
        memberEnsuredInfoDO.setUpdateTime(new Date());
//        memberEnsuredInfoDO.setUpdateBy(ShiroUtils.getUserIdStr());
        MemberEnsuredInfoDOExample example = new MemberEnsuredInfoDOExample();
        MemberEnsuredInfoDOExample.Criteria criteria = example.createCriteria();
        criteria.andMemberIdEqualTo(entity.getMemberId());
        return memberEnsuredInfoMapper.updateByExampleSelective(memberEnsuredInfoDO,example);
    }

    @Override
    public MemberEnsuredInfo get(MemberEnsuredInfo entity) {
        return null;
    }

    @Override
    public List<MemberEnsuredInfo> list(MemberEnsuredInfo entity) {
        return null;
    }

    @Override
    public PageInfo<MemberEnsuredInfo> page(MemberEnsuredInfo entity) {
        return null;
    }

    @Override
    public PageInfo<MemberEnsuredInfo> pageList(MemberEnsuredInfo memberEnsuredInfo) {
        return null;
    }

    @Override
    public MemberEnsuredInfo selectEntityByMemberId(Long memberId) {
        MemberEnsuredInfoDO memberEnsuredInfo = memberEnsuredInfoMapper.selectMemberByMemberId(memberId);
        return memberEnsuredInfoConvertor.convert(memberEnsuredInfo);
    }

    @Override
    public List<MemberEnsuredInfo> selectEntityByStatus(Integer status, Integer delFlag) {
        List<MemberEnsuredInfoDO> memberEnsuredInfoDOS = memberEnsuredInfoMapper.selectEntityByStatus(status, delFlag);
        return memberEnsuredInfoConvertor.convert(memberEnsuredInfoDOS);
    }

    @Override
    public List<MemberEnsuredInfo> selectListByMemberIds(Long[] memberIds) {
        List<MemberEnsuredInfoDO> memberEnsuredInfoDOS = memberEnsuredInfoMapper.batchGetMemberList(memberIds);
        return memberEnsuredInfoConvertor.convert(memberEnsuredInfoDOS);
    }

    @Override
    public PageInfo<MemberEnsuredInfo> page(MemberEnsuredDTO dto) {
        return memberEnsuredInfoConvertor.convert2DTO(PageHelper.startPage(dto.getPageNum(), dto.getPageSize())
                .doSelectPageInfo(() -> this.query(dto)));
    }

    public List<MemberEnsuredInfo> query(MemberEnsuredDTO dto) {
        dto.setPhoneNumber(StringUtils.isBlank(dto.getPhoneNumber())?null:dto.getPhoneNumber());
        dto.setUserId(StringUtils.isBlank(dto.getUserId())?null:dto.getUserId());
        dto.setMemberId(StringUtils.isBlank(dto.getMemberId())?null:dto.getMemberId());

        if(Objects.nonNull(dto.getMemberCreateTimeEnd())) {
            /**
             * 设置结束时间为23：59：:59
             */
            Calendar end = Calendar.getInstance();
            end.setTime(dto.getMemberCreateTimeEnd());
            end.set(Calendar.HOUR, 23);
            end.set(Calendar.MINUTE, 59);
            end.set(Calendar.SECOND, 59);
            Date endTime = end.getTime();
            dto.setMemberCreateTimeEnd(endTime);
        }
        List<MemberEnsuredInfoBO> list = memberEnsuredInfoMapper.selectByCondition(dto);
        if (CollectionUtils.isNotEmpty(list)){
            return memberEnsuredInfoConvertor.convert2DTO(list);
        }
        return Lists.newArrayList();
    }
}
