package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;

/**
 * 
 * @author   李鑫涛
 * @date   2022-02-10 14:11:06
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductDictDO implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * id
     */
    private Long id;
    /**
     * 字典类型
     */
    private String dictType;
    /**
     * 字典值
     */
    private String dictValue;
    /**
     * 字典名
     */
    private String dictName;
    /**
     * 父ID
     */
    private Long parentId;
    /**
     * 排序
     */
    private Integer sort;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDictType() {
        return dictType;
    }

    public void setDictType(String dictType) {
        this.dictType = dictType == null ? null : dictType.trim();
    }

    public String getDictValue() {
        return dictValue;
    }

    public void setDictValue(String dictValue) {
        this.dictValue = dictValue == null ? null : dictValue.trim();
    }

    public String getDictName() {
        return dictName;
    }

    public void setDictName(String dictName) {
        this.dictName = dictName == null ? null : dictName.trim();
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", dictType=").append(dictType);
        sb.append(", dictValue=").append(dictValue);
        sb.append(", dictName=").append(dictName);
        sb.append(", parentId=").append(parentId);
        sb.append(", sort=").append(sort);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public enum Column {
        id("id"),
        dictType("dict_type"),
        dictValue("dict_value"),
        dictName("dict_name"),
        parentId("parent_id"),
        sort("sort");

        private final String column;

        Column(String column) {
            this.column = column;
        }

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }

    public static class Builder {
        private InsuranceProductDictDO obj;

        public Builder() {
            this.obj = new InsuranceProductDictDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder dictType(String dictType) {
            obj.dictType = dictType;
            return this;
        }

        public Builder dictValue(String dictValue) {
            obj.dictValue = dictValue;
            return this;
        }

        public Builder dictName(String dictName) {
            obj.dictName = dictName;
            return this;
        }

        public Builder parentId(Long parentId) {
            obj.parentId = parentId;
            return this;
        }

        public Builder sort(Integer sort) {
            obj.sort = sort;
            return this;
        }

        public InsuranceProductDictDO build() {
            return this.obj;
        }
    }
}