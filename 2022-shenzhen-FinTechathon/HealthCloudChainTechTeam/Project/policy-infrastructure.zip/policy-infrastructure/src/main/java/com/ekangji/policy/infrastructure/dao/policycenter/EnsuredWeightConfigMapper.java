package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.EnsuredWeightConfigDO;
import com.ekangji.policy.infrastructure.dao.dataobject.EnsuredWeightConfigDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface EnsuredWeightConfigMapper {
    long countByExample(EnsuredWeightConfigDOExample example);

    int deleteByExample(EnsuredWeightConfigDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(EnsuredWeightConfigDO record);

    int insertSelective(EnsuredWeightConfigDO record);

    List<EnsuredWeightConfigDO> selectByExampleWithRowbounds(EnsuredWeightConfigDOExample example, RowBounds rowBounds);

    List<EnsuredWeightConfigDO> selectByExample(EnsuredWeightConfigDOExample example);

    EnsuredWeightConfigDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") EnsuredWeightConfigDO record, @Param("example") EnsuredWeightConfigDOExample example);

    int updateByExample(@Param("record") EnsuredWeightConfigDO record, @Param("example") EnsuredWeightConfigDOExample example);

    int updateByPrimaryKeySelective(EnsuredWeightConfigDO record);

    int updateByPrimaryKey(EnsuredWeightConfigDO record);

    int batchInsert(@Param("list") List<EnsuredWeightConfigDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<EnsuredWeightConfigDO> recordList);

    EnsuredWeightConfigDO selectOneByExample(EnsuredWeightConfigDOExample example);

    EnsuredWeightConfigDO selectEntityByLevelType(String levelType);

}