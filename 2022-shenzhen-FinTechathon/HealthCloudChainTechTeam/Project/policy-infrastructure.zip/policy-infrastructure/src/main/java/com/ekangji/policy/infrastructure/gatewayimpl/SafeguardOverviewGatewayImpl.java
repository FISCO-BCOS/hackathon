package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.SafeguardOverviewGateway;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.infrastructure.convertor.SafeguardOverviewConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDO;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.SafeguardOverviewMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author xintao.li
 * @date 2021/12/2 22:04
 */
@Repository
public class SafeguardOverviewGatewayImpl implements SafeguardOverviewGateway {

    @Resource
    private SafeguardOverviewConvertor safeguardOverviewConvertor;

    @Resource
    private SafeguardOverviewMapper safeguardOverviewMapper;

    @Override
    public Long save(SafeguardOverview safeguardOverview) {
        SafeguardOverviewDO safeguardOverviewDO = safeguardOverviewConvertor.convert(safeguardOverview);
        safeguardOverviewMapper.insertSelective(safeguardOverviewDO);
        return safeguardOverviewDO.getId();
    }

    @Override
    public int delete(SafeguardOverview safeguardOverview) {
        return safeguardOverviewMapper.deleteByPrimaryKey(safeguardOverview.getId());
    }

    @Override
    public int update(SafeguardOverview safeguardOverview) {
        SafeguardOverviewDO safeguardOverviewDO = safeguardOverviewConvertor.convert(safeguardOverview);
        safeguardOverviewDO.setUpdateTime(new Date());
        SafeguardOverviewDOExample example = new SafeguardOverviewDOExample();
        SafeguardOverviewDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(safeguardOverview.getOverviewId())){
            criteria.andOverviewIdEqualTo(safeguardOverview.getOverviewId());
        }
        if (StringUtils.isNotBlank(safeguardOverview.getOneLevelTypeCode())){
            criteria.andOneLevelTypeCodeEqualTo(safeguardOverview.getOneLevelTypeCode());
        }
        if (Objects.nonNull(safeguardOverview.getAgeBracket())){
            criteria.andAgeBracketEqualTo(safeguardOverview.getAgeBracket());
        }
        return safeguardOverviewMapper.updateByExampleSelective(safeguardOverviewDO,example);
    }

    @Override
    public SafeguardOverview get(SafeguardOverview safeguardOverview) {
        List<SafeguardOverviewDO> safeguardOverviewDOList = this.query(safeguardOverview);
        if (CollectionUtils.isNotEmpty(safeguardOverviewDOList)){
            return safeguardOverviewConvertor.convert(safeguardOverviewDOList.get(0));
        }
        return null;
    }

    @Override
    public List<SafeguardOverview> list(SafeguardOverview safeguardOverview) {
        List<SafeguardOverviewDO> safeguardOverviewDOList = this.query(safeguardOverview);
        if (CollectionUtils.isNotEmpty(safeguardOverviewDOList)){
            return safeguardOverviewConvertor.convert(safeguardOverviewDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<SafeguardOverview> page(SafeguardOverview safeguardOverview) {
        PageHelper.startPage(safeguardOverview.getPageNum(),safeguardOverview.getPageSize());
        List<SafeguardOverviewDO> safeguardOverviewDOList = query(safeguardOverview);
        PageInfo<SafeguardOverviewDO> pageInfo = new PageInfo<>(safeguardOverviewDOList);
        return safeguardOverviewConvertor.convert(pageInfo);
    }

    private List<SafeguardOverviewDO> query(SafeguardOverview safeguardOverview) {
        SafeguardOverviewDOExample example = new SafeguardOverviewDOExample();
        SafeguardOverviewDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(safeguardOverview.getStatus())){
            criteria.andStatusEqualTo(safeguardOverview.getStatus());
        }
        if (StringUtils.isNotBlank(safeguardOverview.getOverviewId())){
            criteria.andOverviewIdEqualTo(safeguardOverview.getOverviewId());
        }
        if (Objects.nonNull(safeguardOverview.getAgeBracket())){
            criteria.andAgeBracketEqualTo(safeguardOverview.getAgeBracket());
        }
        if (Objects.nonNull(safeguardOverview.getOneLevelTypeCode())){
            criteria.andOneLevelTypeCodeEqualTo(safeguardOverview.getOneLevelTypeCode());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("ID ASC");
        return safeguardOverviewMapper.selectByExample(example);
    }

}
