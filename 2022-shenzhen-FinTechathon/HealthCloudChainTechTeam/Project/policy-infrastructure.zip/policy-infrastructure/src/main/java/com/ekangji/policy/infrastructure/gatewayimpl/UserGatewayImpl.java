package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.util.SqlUtil;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.UserGateway;
import com.ekangji.policy.domain.user.User;
import com.ekangji.policy.infrastructure.convertor.UserConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.UserDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserDOExample;
import com.ekangji.policy.infrastructure.dao.primary.UserMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * 用户相关
 *
 * @author: zhangjun
 * @create: 2021/11/29 6:02 下午
 */
@Repository
public class UserGatewayImpl implements UserGateway {

    @Resource
    private UserMapper userMapper;

    @Resource
    private UserConvertor userConvertor;

    @Override
    public Long save(User user) {
        UserDO userDO = userConvertor.convert(user);
        userDO.setCreateTime(new Date());
        userDO.setUpdateTime(new Date());
        userDO.setCreateBy(ShiroUtils.getUserIdStr());
        userDO.setUpdateBy(ShiroUtils.getUserIdStr());
        userMapper.insertSelective(userDO);
        return userDO.getId();
    }

    @Override
    public int delete(User user) {
        UserDOExample example = new UserDOExample();
        UserDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(user.getUserId());
        return userMapper.deleteByExample(example);
    }

    @Override
    public int update(User user) {
        UserDO userDO = userConvertor.convert(user);
        userDO.setUpdateTime(new Date());
        userDO.setUpdateBy(ShiroUtils.getUserIdStr());
        UserDOExample example = new UserDOExample();
        UserDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(user.getUserId());
        return userMapper.updateByExampleSelective(userDO, example);
    }

    @Override
    public int updatePwd(User user) {
        UserDO userDO = userConvertor.convert(user);
        userDO.setUpdateTime(new Date());
        userDO.setUpdateBy(ShiroUtils.getUserIdStr());
        userDO.setPwdUpdateDate(new Date());

        UserDOExample example = new UserDOExample();
        UserDOExample.Criteria criteria = example.createCriteria();
        criteria.andUserIdEqualTo(user.getUserId());
        return userMapper.updateByExampleSelective(userDO, example);
    }

    @Override
    public User get(User user) {
        List<UserDO> userDOList = this.query(user);
        if (CollectionUtils.isNotEmpty(userDOList)){
            UserDO userDO = userDOList.get(0);
            return userConvertor.convert(userDO);
        }
        return null;
    }

    @Override
    public List<User> list(User user) {
        List<UserDO> userDOList = this.query(user);
        if (CollectionUtils.isNotEmpty(userDOList)){
            return userConvertor.convert(userDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<User> page(User user) {
        PageHelper.startPage(user.getPageNum(),user.getPageSize());
        List<UserDO> userDOList = this.query(user);
        PageInfo<UserDO> pageInfo = new PageInfo<>(userDOList);
        return userConvertor.convert(pageInfo);
    }

    @Override
    public PageInfo<User> pageNoAdmin(User user) {
        PageHelper.startPage(user.getPageNum(),user.getPageSize());
        List<UserDO> userDOList = this.queryNoAdmin(user);
        PageInfo<UserDO> pageInfo = new PageInfo<>(userDOList);
        return userConvertor.convert(pageInfo);
    }


    private UserDO queryOne(User user) {
        UserDOExample example = new UserDOExample();
        UserDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(user.getId())){
            criteria.andIdEqualTo(user.getId());
        }
        if (Objects.nonNull(user.getUserId())){
            criteria.andUserIdEqualTo(user.getUserId());
        }
        if (CollectionUtils.isNotEmpty(user.getUserIdList())){
            criteria.andUserIdIn(user.getUserIdList());
        }
        if (CollectionUtils.isNotEmpty(user.getUserIdNotInList())){
            criteria.andUserIdNotIn(user.getUserIdNotInList());
        }
        if (Objects.nonNull(user.getStatus())){
            criteria.andStatusEqualTo(user.getStatus());
        }
        if (StringUtils.isNotEmpty(user.getUserName())){
            criteria.andUserNameLike(SqlUtil.like(user.getUserName()));
        }
        if (StringUtils.isNotEmpty(user.getPhone())){
            criteria.andPhoneEqualTo(user.getPhone());
        }
        if (StringUtils.isNotEmpty(user.getEmail())){
            criteria.andEmailEqualTo(user.getEmail());
        }
        if (StringUtils.isNotEmpty(user.getLoginName())){
            criteria.andLoginNameEqualTo(user.getLoginName());
        }
        if ((user.getDeptId()) != null){
            criteria.andDeptIdEqualTo(user.getDeptId());
        }
        example.setOrderByClause("ID DESC");
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        return userMapper.selectOneByExample(example);
    }

    private List<UserDO> query(User user) {
        UserDOExample example = new UserDOExample();
        UserDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(user.getId())){
            criteria.andIdEqualTo(user.getId());
        }
        if (Objects.nonNull(user.getUserId())){
            criteria.andUserIdEqualTo(user.getUserId());
        }
        if (CollectionUtils.isNotEmpty(user.getUserIdList())){
            criteria.andUserIdIn(user.getUserIdList());
        }
        if (CollectionUtils.isNotEmpty(user.getUserIdNotInList())){
            criteria.andUserIdNotIn(user.getUserIdNotInList());
        }
        if (Objects.nonNull(user.getStatus())){
            criteria.andStatusEqualTo(user.getStatus());
        }
        if (StringUtils.isNotEmpty(user.getUserName())){
            criteria.andUserNameLike(SqlUtil.like(user.getUserName()));
        }
        if (StringUtils.isNotEmpty(user.getPhone())){
            criteria.andPhoneEqualTo(user.getPhone());
        }
        if (StringUtils.isNotEmpty(user.getEmail())){
            criteria.andEmailEqualTo(user.getEmail());
        }
        if (StringUtils.isNotEmpty(user.getLoginName())){
            criteria.andLoginNameEqualTo(user.getLoginName());
        }
        if ((user.getDeptId()) != null){
            criteria.andDeptIdEqualTo(user.getDeptId());
        }
        example.setOrderByClause("ID DESC");
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        return userMapper.selectByExample(example);
    }

    private List<UserDO> queryNoAdmin(User user) {
        UserDOExample example = new UserDOExample();
        UserDOExample.Criteria criteria = example.createCriteria();

        if (Objects.nonNull(user.getUserId())){
            criteria.andUserIdEqualTo(user.getUserId());
        }
        if (Objects.nonNull(user.getId())){
            criteria.andIdEqualTo(user.getId());
        }
        if (StringUtils.isNotEmpty(user.getUserName())){
            criteria.andUserNameLike(SqlUtil.like(user.getUserName()));
        }
        if (CollectionUtils.isNotEmpty(user.getUserIdList())){
            criteria.andUserIdIn(user.getUserIdList());
        }
        if (CollectionUtils.isNotEmpty(user.getUserIdNotInList())){
            criteria.andUserIdNotIn(user.getUserIdNotInList());
        }
        if (StringUtils.isNotEmpty(user.getEmail())){
            criteria.andEmailEqualTo(user.getEmail());
        }
        if (StringUtils.isNotEmpty(user.getLoginName())){
            criteria.andLoginNameEqualTo(user.getLoginName());
        }
        if (Objects.nonNull(user.getStatus())){
            criteria.andStatusEqualTo(user.getStatus());
        }

        if (StringUtils.isNotEmpty(user.getPhone())){
            criteria.andPhoneEqualTo(user.getPhone());
        }
        if ((user.getDeptId()) != null){
            criteria.andDeptIdEqualTo(user.getDeptId());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        example.setOrderByClause("ID DESC");
        criteria.andUserIdNotEqualTo(1L);
        return userMapper.selectByExample(example);
    }

    @Override
    public User getByUserId(String userId) {
        if (StringUtils.isNotBlank(userId)){
            User user = this.getOne(User.builder().userId(Long.valueOf(userId)).build());
            return user;
        }
        return null;
    }

    @Override
    public User getOne(User user) {
        UserDO userDO = this.queryOne(user);
        if (Objects.nonNull(userDO)) {
            return userConvertor.convert(userDO);
        }
        return null;
    }

    @Override
    public String getUserName(String userId) {
        if (StringUtils.isNotBlank(userId)){
            User user = this.getOne(User.builder().userId(Long.valueOf(userId)).build());
            if (Objects.nonNull(user)){
                return user.getUserName();
            }
        }
        return "";
    }
}
