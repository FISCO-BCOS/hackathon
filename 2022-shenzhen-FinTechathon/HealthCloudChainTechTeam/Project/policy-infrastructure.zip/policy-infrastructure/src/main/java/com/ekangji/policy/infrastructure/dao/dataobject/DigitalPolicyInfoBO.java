package com.ekangji.policy.infrastructure.dao.dataobject;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 18:01:14
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class DigitalPolicyInfoBO implements Serializable {

    private Long digitalId;

    private Long starId;

    private Long policyId;

    private String userId;

    private String phoneNumber;

    private String productName;

    private Date recommendTime;

    private Date createTime;

    private Integer selfFlag;

    private Integer status;

    private Integer recommendFlag;

    private String fileId;
}