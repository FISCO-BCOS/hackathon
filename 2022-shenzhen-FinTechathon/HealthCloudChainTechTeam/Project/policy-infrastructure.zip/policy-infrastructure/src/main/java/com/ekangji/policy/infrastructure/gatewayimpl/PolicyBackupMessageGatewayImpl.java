package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.PolicyReceiveStatusEnum;
import com.ekangji.policy.domain.gateway.PolicyBackupMessageGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.infrastructure.convertor.PolicyBackupMessageConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.PolicyBackupMessageBOMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.common.constants.CommonConstants;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Repository
public class PolicyBackupMessageGatewayImpl implements PolicyBackupMessageGateway {

    @Resource
    private PolicyBackupMessageBOMapper policyBackupMessageBOMapper;

    @Resource
    private PolicyBackupMessageConvertor policyBackupMessageConvertor;

    @Override
    public Long save(PolicyBackupMessage entity) {
        return null;
    }

    @Override
    public int delete(PolicyBackupMessage entity) {
        return 0;
    }

    @Override
    public int update(PolicyBackupMessage entity) {
        PolicyBackupMessageDO pbmDO = policyBackupMessageConvertor.convert(entity);
        PolicyBackupMessageDOExample example = new PolicyBackupMessageDOExample();
        PolicyBackupMessageDOExample.Criteria criteria = example.createCriteria();
        criteria.andReceiveUserPhoneEqualTo(entity.getReceiveUserPhone());
        criteria.andLaunchUserIdEqualTo(entity.getLaunchUserId());
        criteria.andStatusEqualTo(PolicyReceiveStatusEnum.TORECEIVE.getCode());
        return policyBackupMessageBOMapper.updateByExampleSelective(pbmDO,example);
    }

    @Override
    public PolicyBackupMessage get(PolicyBackupMessage entity) {
        return null;
    }

    @Override
    public List<PolicyBackupMessage> list(PolicyBackupMessage entity) {
        List<PolicyBackupMessageDO> policyBackupMessageDOList = this.query(entity);
        if (CollectionUtils.isNotEmpty(policyBackupMessageDOList)){
            return policyBackupMessageConvertor.convertDO(policyBackupMessageDOList);
        }
        return Collections.emptyList();
    }

    @Override
    public PageInfo<PolicyBackupMessage> page(PolicyBackupMessage entity) {
        return null;
    }


    @Override
    public PolicyBackupMessage countToReceivePolicy(PolicyBackupMessage param) {
        PolicyBackupMessageDO pbmDO = policyBackupMessageConvertor.convert(param);
        List<PolicyBackupMessageBO> boList = policyBackupMessageBOMapper.countToReceivePolicy(pbmDO);
        if (CollectionUtils.isEmpty(boList)) {
            PolicyBackupMessage policyBackupMessage = new PolicyBackupMessage();
            policyBackupMessage.setPolicyNum(Constants.ZERO);
            return policyBackupMessage;
        }
        PolicyBackupMessage policyBackupMessage = policyBackupMessageConvertor.convert(boList.get(Constants.ZERO));
        if (boList.size() > Constants.ONE) { //后面还有待接收保单
            policyBackupMessage.setLastFlag(Constants.ONE);
        } else {
            policyBackupMessage.setLastFlag(Constants.ZERO);
        }
        return policyBackupMessage;
    }

    @Override
    public List<PolicyBackupMessage> selectToReceivePolicy(PolicyBackupMessage param) {
        PolicyBackupMessageDO pbmDO = policyBackupMessageConvertor.convert(param);
        List<PolicyBackupMessageBO> boList = policyBackupMessageBOMapper.selectToReceivePolicy(pbmDO);
        if (CollectionUtils.isNotEmpty(boList)) {
            List<PolicyBackupMessage> messageList = policyBackupMessageConvertor.convert(boList);
            return messageList;
        }
       return null;
    }

    @Override
    public int batchSave(List<PolicyBackupMessage> backupList) {
        List<PolicyBackupMessageBO> boList = policyBackupMessageConvertor.convertBO(backupList);
        int saveNum = policyBackupMessageBOMapper.batchSave(boList);
        return saveNum;
    }

    private List<PolicyBackupMessageDO> query(PolicyBackupMessage pbm) {
        PolicyBackupMessageDOExample example = new PolicyBackupMessageDOExample();
        PolicyBackupMessageDOExample.Criteria criteria = example.createCriteria();
        // 根据接收状态查询
        if(Objects.nonNull(pbm.getStatus())){
            criteria.andStatusEqualTo(pbm.getStatus());
        }
        // 根据接收人ID查询
        if (StringUtils.isNotBlank(pbm.getReceiveUserId())){
            criteria.andReceiveUserIdEqualTo(pbm.getReceiveUserId());
        }
        // 根据接收人手机号查询
        if (StringUtils.isNotBlank(pbm.getReceiveUserPhone())){
            criteria.andReceiveUserPhoneEqualTo(pbm.getReceiveUserPhone());
        }
        // 根据保单ID数组查询
        if (CollectionUtils.isNotEmpty(pbm.getPolicyIds())){
            criteria.andPolicyIdIn(pbm.getPolicyIds());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyBackupMessageDO> PolicyBackupMessageDOList = policyBackupMessageBOMapper.selectByExample(example);
        example.setOrderByClause("status");
        return PolicyBackupMessageDOList;
    }
}
