package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-06-01 15:50:16
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicyInsurantDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 附加险ID
     */
    private Long additionalId;

    /**
     * 被保人id
     */
    private Long insurantId;

    /**
     * 被保人出生日期
     */
    private Date insurantBirthday;

    /**
     * 保险类别(1:主险,0:附加险)
     */
    private Integer insuranceType;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新人
     */
    private String updateBy;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public Long getAdditionalId() {
        return additionalId;
    }

    public void setAdditionalId(Long additionalId) {
        this.additionalId = additionalId;
    }

    public Long getInsurantId() {
        return insurantId;
    }

    public void setInsurantId(Long insurantId) {
        this.insurantId = insurantId;
    }

    public Date getInsurantBirthday() {
        return insurantBirthday;
    }

    public void setInsurantBirthday(Date insurantBirthday) {
        this.insurantBirthday = insurantBirthday;
    }

    public Integer getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(Integer insuranceType) {
        this.insuranceType = insuranceType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", policyId=").append(policyId);
        sb.append(", additionalId=").append(additionalId);
        sb.append(", insurantId=").append(insurantId);
        sb.append(", insurantBirthday=").append(insurantBirthday);
        sb.append(", insuranceType=").append(insuranceType);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private PolicyInsurantDO obj;

        public Builder() {
            this.obj = new PolicyInsurantDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder policyId(Long policyId) {
            obj.policyId = policyId;
            return this;
        }

        public Builder additionalId(Long additionalId) {
            obj.additionalId = additionalId;
            return this;
        }

        public Builder insurantId(Long insurantId) {
            obj.insurantId = insurantId;
            return this;
        }

        public Builder insurantBirthday(Date insurantBirthday) {
            obj.insurantBirthday = insurantBirthday;
            return this;
        }

        public Builder insuranceType(Integer insuranceType) {
            obj.insuranceType = insuranceType;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public PolicyInsurantDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        policyId("policy_id"),
        additionalId("additional_id"),
        insurantId("insurant_id"),
        insurantBirthday("insurant_birthday"),
        insuranceType("insurance_type"),
        status("status"),
        delFlag("del_flag"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}