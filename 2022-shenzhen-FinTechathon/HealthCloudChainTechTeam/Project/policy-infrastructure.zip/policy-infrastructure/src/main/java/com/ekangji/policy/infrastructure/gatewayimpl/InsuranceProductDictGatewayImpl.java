package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.common.enums.ProductDictEnum;
import com.ekangji.policy.domain.gateway.InsuranceProductDictGateway;
import com.ekangji.policy.domain.insurance.InsuranceProductDict;
import com.ekangji.policy.infrastructure.convertor.InsuranceProductDictConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDictDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDictDOExample;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyDOExample;
import com.ekangji.policy.infrastructure.dao.productcenter.InsuranceProductDictMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Repository
public class InsuranceProductDictGatewayImpl implements InsuranceProductDictGateway {

    @Resource
    private InsuranceProductDictMapper insuranceProductDictMapper;

    @Resource
    private InsuranceProductDictConvertor insuranceProductDictConvertor;

    @Override
    public Long save(InsuranceProductDict insuranceProductDict) {
        return null;
    }

    @Override
    public int delete(InsuranceProductDict insuranceProductDict) {
        return 0;
    }

    @Override
    public int update(InsuranceProductDict insuranceProductDict) {
        return 0;
    }

    @Override
    public InsuranceProductDict get(InsuranceProductDict insuranceProductDict) {
        InsuranceProductDictDOExample example = new InsuranceProductDictDOExample();
        InsuranceProductDictDOExample.Criteria criteria = example.createCriteria();
        criteria.andDictValueEqualTo(insuranceProductDict.getDictValue());
        InsuranceProductDictDO insuranceProductDictDO = insuranceProductDictMapper.selectOneByExample(example);
        if (Objects.nonNull(insuranceProductDictDO)) {
            return insuranceProductDictConvertor.convert(insuranceProductDictDO);
        }
        return null;
    }

    @Override
    public List<InsuranceProductDict> list(InsuranceProductDict insuranceProductDict) {
        return query(insuranceProductDict);
    }

    @Override
    public List<InsuranceProductDict> queryProductType(InsuranceProductDict insuranceProductDict) {
        InsuranceProductDictDOExample example = new InsuranceProductDictDOExample();
        // 默认查询父级
        example.setOrderByClause("sort asc");
        example.createCriteria().andDictTypeEqualTo(ProductDictEnum.PRODUCT_TYPE.getCode()).andParentIdEqualTo(0L);
        if (insuranceProductDict.getParentId() != null){
            example.clear();
            example.createCriteria().andDictTypeEqualTo(ProductDictEnum.PRODUCT_TYPE.getCode()).andParentIdEqualTo(insuranceProductDict.getParentId());
        }
        return insuranceProductDictConvertor.convert(insuranceProductDictMapper.selectByExample(example));
    }

    @Override
    public PageInfo<InsuranceProductDict> page(InsuranceProductDict insuranceProductDict) {
        return null;
    }

    @Override
    public List<InsuranceProductDict> querySonByIds(List<Long> idList) {
        InsuranceProductDictDOExample example = new InsuranceProductDictDOExample();
        example.createCriteria().andParentIdIn(idList);
        return insuranceProductDictConvertor.convert(insuranceProductDictMapper.selectByExample(example));
    }

    private List<InsuranceProductDict> query(InsuranceProductDict insuranceProductDict){
        InsuranceProductDictDOExample example = new InsuranceProductDictDOExample();
        example.setOrderByClause("sort asc");
        InsuranceProductDictDOExample.Criteria criteria = example.createCriteria();
        if (StringUtils.isNotBlank(insuranceProductDict.getDictType())){
            criteria.andDictTypeEqualTo(insuranceProductDict.getDictType());
        }
        return insuranceProductDictConvertor.convert(insuranceProductDictMapper.selectByExample(example));
    }
}
