package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyBeneficiary;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBeneficiaryDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/20 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyBeneficiaryConvertor {

    PolicyBeneficiaryDO convert(PolicyBeneficiary param);

    PolicyBeneficiary convert(PolicyBeneficiaryDO param);

    List<PolicyBeneficiary> convert(List<PolicyBeneficiaryDO> param);
}
