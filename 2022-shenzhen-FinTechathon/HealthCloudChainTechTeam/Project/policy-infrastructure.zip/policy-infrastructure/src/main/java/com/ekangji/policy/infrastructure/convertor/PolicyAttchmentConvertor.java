package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.PolicyAttchment;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAttchmentDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/05/18 14:00
 */
@Mapper(componentModel = "spring")
public interface PolicyAttchmentConvertor {

    PolicyAttchmentDO convert(PolicyAttchment param);

    PolicyAttchment convert(PolicyAttchmentDO param);

    List<PolicyAttchmentDO> convert(List<PolicyAttchment> param);

    List<PolicyAttchment> convertDO(List<PolicyAttchmentDO> param);

}
