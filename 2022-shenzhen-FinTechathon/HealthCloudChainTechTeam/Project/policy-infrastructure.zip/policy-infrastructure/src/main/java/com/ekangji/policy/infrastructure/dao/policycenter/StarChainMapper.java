package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDO;
import com.ekangji.policy.infrastructure.dao.dataobject.StarChainDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface StarChainMapper {
    long countByExample(StarChainDOExample example);

    int deleteByExample(StarChainDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(StarChainDO record);

    int insertSelective(StarChainDO record);

    List<StarChainDO> selectByExampleWithRowbounds(StarChainDOExample example, RowBounds rowBounds);

    List<StarChainDO> selectByExample(StarChainDOExample example);

    StarChainDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") StarChainDO record, @Param("example") StarChainDOExample example);

    int updateByExample(@Param("record") StarChainDO record, @Param("example") StarChainDOExample example);

    int updateByPrimaryKeySelective(StarChainDO record);

    int updateByPrimaryKey(StarChainDO record);

    int batchInsert(@Param("list") List<StarChainDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<StarChainDO> recordList);

    StarChainDO selectOneByExample(StarChainDOExample example);
}