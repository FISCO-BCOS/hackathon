package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonIfEnum;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.EnsuredReadConfigGateway;
import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.infrastructure.convertor.EnsuredReadConfigConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.EnsuredReadConfigDO;
import com.ekangji.policy.infrastructure.dao.dataobject.EnsuredReadConfigDOExample;
import com.ekangji.policy.infrastructure.dao.policycenter.EnsuredReadConfigMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Repository
public class EnsuredReadConfigGatewayImpl implements EnsuredReadConfigGateway {
    @Resource
    private EnsuredReadConfigMapper ensuredReadConfigMapper;
    @Resource
    private EnsuredReadConfigConvertor ensuredReadConfigConvertor;

    @Override
    public EnsuredReadConfig selectConfigByScore(Integer score) {
        EnsuredReadConfigDOExample example = new EnsuredReadConfigDOExample();
        EnsuredReadConfigDOExample.Criteria criteria = example.createCriteria();
        score = score == null ? 0 : score;
        criteria.andMinScoreLessThanOrEqualTo(score);
        criteria.andMaxScoreGreaterThanOrEqualTo(score);
        EnsuredReadConfigDO ensuredReadConfigDOS = ensuredReadConfigMapper.selectOneByExample(example);
        return ensuredReadConfigConvertor.convert(ensuredReadConfigDOS);
    }

    @Override
    public List<EnsuredReadConfig> selectReadList() {
        EnsuredReadConfigDOExample example = new EnsuredReadConfigDOExample();
        EnsuredReadConfigDOExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        List<EnsuredReadConfigDO> ensuredWeightConfigDOS = ensuredReadConfigMapper.selectByExample(example);
        return ensuredReadConfigConvertor.convert(ensuredWeightConfigDOS);    }

    @Override
    public int batchUpdate(List<EnsuredReadConfig> list) {
        List<EnsuredReadConfigDO> ensuredReadConfigDOS = ensuredReadConfigConvertor.convert2DO(list);
        ensuredReadConfigDOS.forEach(rule->{
            rule.setCreateBy(ShiroUtils.getUserIdStr());
            rule.setUpdateBy(ShiroUtils.getUserIdStr());
            rule.setCreateTime(new Date());
            rule.setUpdateTime(new Date());
            rule.setStatus(CommonStatusEnum.VALID.getCode());
            rule.setDelFlag(CommonIfEnum.YES.getCode());
        });
        return ensuredReadConfigMapper.batchUpdate(ensuredReadConfigDOS);    }

    @Override
    public int batchDelete() {
        List<EnsuredReadConfig> ensuredReadConfigs = this.selectReadList();
        if(CollectionUtils.isNotEmpty(ensuredReadConfigs)) {
            return ensuredReadConfigMapper.batchDelete(ensuredReadConfigs.stream().map(EnsuredReadConfig::getId).toArray(Long[]::new));
        }
        return 0;
    }

    @Override
    public int batchInsert(List<EnsuredReadConfig> list) {
        List<EnsuredReadConfigDO> ensuredReadConfigDOS = ensuredReadConfigConvertor.convert2DO(list);
        ensuredReadConfigDOS.forEach(x->{
            x.setStatus(CommonStatusEnum.VALID.getCode());
            x.setCreateTime(new Date());
            x.setUpdateTime(new Date());
            x.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        });
        return ensuredReadConfigMapper.batchInsert(ensuredReadConfigDOS);
    }

    @Override
    public Long save(EnsuredReadConfig ensuredReadConfig) {
        return null;
    }

    @Override
    public int delete(EnsuredReadConfig ensuredReadConfig) {
        return 0;
    }

    @Override
    public int update(EnsuredReadConfig ensuredReadConfig) {
        return 0;
    }

    @Override
    public EnsuredReadConfig get(EnsuredReadConfig ensuredReadConfig) {
        return null;
    }

    @Override
    public List<EnsuredReadConfig> list(EnsuredReadConfig ensuredReadConfig) {
        return null;
    }

    @Override
    public PageInfo<EnsuredReadConfig> page(EnsuredReadConfig ensuredReadConfig) {
        return null;
    }
}
