package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.infrastructure.dao.dataobject.UserStarDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author liuchen
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface UserStarConvertor {

    UserStarDO convert(UserStar param);

    UserStar convert(UserStarDO param);

    List<UserStar> convert(List<UserStarDO> param);

    PageInfo<UserStar> convert(PageInfo<UserStarDO> param);

}
