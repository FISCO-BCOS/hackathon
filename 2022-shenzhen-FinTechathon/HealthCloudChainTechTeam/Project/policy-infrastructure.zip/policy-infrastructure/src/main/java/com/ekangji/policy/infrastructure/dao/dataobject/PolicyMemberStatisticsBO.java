package com.ekangji.policy.infrastructure.dao.dataobject;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;

/**
 *
 * @author   liuchen
 * @date   2022-05-23 17:00:25
 */
@Data
@ToString(callSuper = true)
public class PolicyMemberStatisticsBO extends PolicyMemberStatisticsDO{

    /**
     * 家庭总保单数（包含未在保障中的）
     */
    private Integer policyNumTotal;

    /**
     * 今年总保费
     */
    private BigDecimal premiumTotal;

}
