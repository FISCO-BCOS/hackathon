package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.domain.policy.UserInviteInfo;
import com.ekangji.policy.domain.user.User;
import com.ekangji.policy.infrastructure.dao.dataobject.UserDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserFamilyInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.UserInviteInfoDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 邀请数据转换
 *
 * @author: wjx
 * @create: 2021/12/14 9:20 上午
 */
@Mapper(componentModel = "spring")
public interface UserInviteInfoConvertor {

    UserInviteInfo convert(UserInviteInfoDO userInviteInfoDO);

    UserInviteInfoDO convert(UserInviteInfo userFamilyInfo);

    List<UserInviteInfo> convert(List<UserInviteInfoDO> param);

    PageInfo<UserInviteInfo> convert(PageInfo<UserInviteInfoDO> param);
}
