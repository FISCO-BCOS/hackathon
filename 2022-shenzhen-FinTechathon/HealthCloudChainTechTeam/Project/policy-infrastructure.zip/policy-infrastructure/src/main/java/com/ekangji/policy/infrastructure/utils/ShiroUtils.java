package com.ekangji.policy.infrastructure.utils;

import com.ekangji.policy.infrastructure.user.CacheUser;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;

import java.util.Objects;

/**
 * 获取shiro用户信息
 *
 * @author: zhangjun
 * @create: 2021/12/3 11:08 下午
 */
public class ShiroUtils {

    public static Session getSession() {
        return SecurityUtils.getSubject().getSession();
    }

    /**
     * 获取shiro的连接器
     *
     * @return
     */
    public static Subject getSubject() {
        return SecurityUtils.getSubject();
    }

    /**
     * 获取登录用户的信息
     *
     * @return
     */
    public static CacheUser getUser() {
        return (CacheUser) SecurityUtils.getSubject().getPrincipal();
    }

    /**
     * 获取登录用户的id
     *
     * @return
     */
    public static Long getUserId() {
        return getUser().getUserId();
    }

    /**
     * 获取登录用户的id
     *
     * @return
     */
    public static String getUserIdStr() {
        Long userId = getUser().getUserId();
        if (Objects.nonNull(userId)) {
            return String.valueOf(userId);
        }
        return null;
    }

    /**
     * 获取登录用户的姓名
     *
     * @return
     */
    public static String getUserName() {
        return getUser().getUserName();
    }

    /**
     * @param key
     * @param value
     */
    public static void setSessionAttribute(Object key, Object value) {
        getSession().setAttribute(key, value);
    }

    /**
     * @param key
     * @return
     */
    public static Object getSessionAttribute(Object key) {
        return getSession().getAttribute(key);
    }

    /**
     * 用于判断有没有获取登录用户的信息
     *
     * @return
     */
    public static boolean isLogin() {
        return SecurityUtils.getSubject().getPrincipal() != null;
    }

    /**
     * 注销用户
     */
    public static void logout() {
        SecurityUtils.getSubject().logout();
    }

    /**
     * 是否为管理员
     *
     * @param userId 用户ID
     * @return 结果
     */
    public static boolean isAdmin(Long userId) {
        return userId != null && 1L == userId;
    }

}
