package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.domain.policy.pojo.DigitalPolicyDTO;
import com.ekangji.policy.infrastructure.dao.dataobject.DigitalPolicyDO;
import com.ekangji.policy.infrastructure.dao.dataobject.DigitalPolicyDOExample;
import java.util.List;

import com.ekangji.policy.infrastructure.dao.dataobject.DigitalPolicyInfoBO;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface DigitalPolicyMapper {
    long countByExample(DigitalPolicyDOExample example);

    int deleteByExample(DigitalPolicyDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DigitalPolicyDO record);

    int insertSelective(DigitalPolicyDO record);

    List<DigitalPolicyDO> selectByExampleWithRowbounds(DigitalPolicyDOExample example, RowBounds rowBounds);

    List<DigitalPolicyDO> selectByExample(DigitalPolicyDOExample example);

    DigitalPolicyDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DigitalPolicyDO record, @Param("example") DigitalPolicyDOExample example);

    int updateByExample(@Param("record") DigitalPolicyDO record, @Param("example") DigitalPolicyDOExample example);

    int updateByPrimaryKeySelective(DigitalPolicyDO record);

    int updateByPrimaryKey(DigitalPolicyDO record);

    int batchInsert(@Param("list") List<DigitalPolicyDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<DigitalPolicyDO> recordList);

    DigitalPolicyDO selectOneByExample(DigitalPolicyDOExample example);
    /**
     * 根据条件查询
     * @param dto
     * @return
     */
    List<DigitalPolicyInfoBO> selectByCondition(DigitalPolicyDTO dto);
}