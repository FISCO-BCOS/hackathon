package com.ekangji.policy.infrastructure.dao.primary;

import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceInfoDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceInfoDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface InsuranceInfoMapper {

        long countByExample(InsuranceInfoDOExample example);

        int deleteByExample(InsuranceInfoDOExample example);

        int deleteByPrimaryKey(Long id);

        int insert(InsuranceInfoDO record);

        int insertSelective(InsuranceInfoDO record);

        List<InsuranceInfoDO> selectByExampleWithRowbounds(InsuranceInfoDOExample example, RowBounds rowBounds);

        List<InsuranceInfoDO> selectByExample(InsuranceInfoDOExample example);

        InsuranceInfoDO selectByPrimaryKey(Long id);

        int updateByExampleSelective(@Param("record") InsuranceInfoDO record, @Param("example") InsuranceInfoDOExample example);

        int updateByExample(@Param("record") InsuranceInfoDO record, @Param("example") InsuranceInfoDOExample example);

        int updateByPrimaryKeySelective(InsuranceInfoDO record);

        int updateByPrimaryKey(InsuranceInfoDO record);

        int batchInsert(@Param("list") List<InsuranceInfoDO> list);

        int batchDelete(@Param("ids") Long[] ids);

        int batchUpdate(@Param("recordList") List<InsuranceInfoDO> recordList);

        InsuranceInfoDO selectOneByExample(InsuranceInfoDOExample example);

}