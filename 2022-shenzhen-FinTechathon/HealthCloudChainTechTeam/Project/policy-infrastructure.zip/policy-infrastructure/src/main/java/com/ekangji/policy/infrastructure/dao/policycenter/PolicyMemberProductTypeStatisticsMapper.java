package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyMemberProductTypeStatisticsDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyMemberProductTypeStatisticsMapper {
    long countByExample(PolicyMemberProductTypeStatisticsDOExample example);

    int deleteByExample(PolicyMemberProductTypeStatisticsDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyMemberProductTypeStatisticsDO record);

    int insertSelective(PolicyMemberProductTypeStatisticsDO record);

    List<PolicyMemberProductTypeStatisticsDO> selectByExampleWithRowbounds(PolicyMemberProductTypeStatisticsDOExample example, RowBounds rowBounds);

    List<PolicyMemberProductTypeStatisticsDO> selectByExample(PolicyMemberProductTypeStatisticsDOExample example);

    PolicyMemberProductTypeStatisticsDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyMemberProductTypeStatisticsDO record, @Param("example") PolicyMemberProductTypeStatisticsDOExample example);

    int updateByExample(@Param("record") PolicyMemberProductTypeStatisticsDO record, @Param("example") PolicyMemberProductTypeStatisticsDOExample example);

    int updateByPrimaryKeySelective(PolicyMemberProductTypeStatisticsDO record);

    int updateByPrimaryKey(PolicyMemberProductTypeStatisticsDO record);

    int batchInsert(@Param("list") List<PolicyMemberProductTypeStatisticsDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyMemberProductTypeStatisticsDO> recordList);

    PolicyMemberProductTypeStatisticsDO selectOneByExample(PolicyMemberProductTypeStatisticsDOExample example);
}