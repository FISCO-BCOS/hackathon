package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.DictDataGateway;
import com.ekangji.policy.infrastructure.convertor.DictDataConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDO;
import com.ekangji.policy.infrastructure.dao.dataobject.DictDataDOExample;
import com.ekangji.policy.infrastructure.dao.primary.DictDataMapper;
import com.ekangji.policy.infrastructure.utils.ShiroUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author zhangjun
 * @date 2021/12/2 22:04
 */
@Repository
public class DictDataGatewayImpl implements DictDataGateway {

    @Resource
    private DictDataConvertor dictDataConvertor;

    @Resource
    private DictDataMapper dictDataMapper;

    @Override
    public Long save(DictData dictData) {
        DictDataDO dictDataDO = dictDataConvertor.convert(dictData);
        dictDataDO.setCreateTime(new Date());
        dictDataDO.setUpdateTime(new Date());
        dictDataDO.setCreateBy(ShiroUtils.getUserIdStr());
        dictDataDO.setUpdateBy(ShiroUtils.getUserIdStr());
        dictDataMapper.insertSelective(dictDataDO);
        return dictDataDO.getDictCode();
    }

    @Override
    public int delete(DictData dictData) {
        return dictDataMapper.deleteByPrimaryKey(dictData.getDictCode());
    }

    @Override
    public int update(DictData dictData) {
        DictDataDO dictDataDO = dictDataConvertor.convert(dictData);
        dictDataDO.setUpdateTime(new Date());
        dictDataDO.setUpdateBy(ShiroUtils.getUserIdStr());
        DictDataDOExample example = new DictDataDOExample();
        DictDataDOExample.Criteria criteria = example.createCriteria();
        criteria.andDictCodeEqualTo(dictData.getDictCode());
        int delete = dictDataMapper.updateByExampleSelective(dictDataDO,example);
        return delete;
    }

    @Override
    public DictData get(DictData dictData) {
        List<DictDataDO> dictDataDOList = this.query(dictData);
        if (CollectionUtils.isNotEmpty(dictDataDOList)){
            return dictDataConvertor.convert(dictDataDOList.get(0));
        }
        return null;
    }

    @Override
    public List<DictData> list(DictData dictData) {
        List<DictDataDO> dictDataDOList = this.query(dictData);
        if (CollectionUtils.isNotEmpty(dictDataDOList)){
            return dictDataConvertor.convert(dictDataDOList);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<DictData> page(DictData dictData) {
        PageHelper.startPage(dictData.getPageNum(),dictData.getPageSize());
        List<DictDataDO> dictDataDOList = query(dictData);
        PageInfo<DictDataDO> pageInfo = new PageInfo<>(dictDataDOList);
        return dictDataConvertor.convert(pageInfo);
    }

    private List<DictDataDO> query(DictData dictData) {
        DictDataDOExample example = new DictDataDOExample();
        DictDataDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(dictData.getStatus())){
            criteria.andStatusEqualTo(dictData.getStatus());
        }
        if (Objects.nonNull(dictData.getDictCode())){
            criteria.andDictCodeEqualTo(dictData.getDictCode());
        }
        if (StringUtils.isNotEmpty(dictData.getDictType())){
            criteria.andDictTypeEqualTo(dictData.getDictType());
        }
        if (StringUtils.isNotEmpty(dictData.getDictLabel())){
            criteria.andDictLabelEqualTo(dictData.getDictLabel());
        }
        if (StringUtils.isNotEmpty(dictData.getDictValue())){
            criteria.andDictValueEqualTo(dictData.getDictValue());
        }
        return dictDataMapper.selectByExample(example);
    }

}
