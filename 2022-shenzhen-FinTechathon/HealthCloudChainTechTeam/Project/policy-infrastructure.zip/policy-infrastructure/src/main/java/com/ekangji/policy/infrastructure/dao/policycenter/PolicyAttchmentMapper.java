package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAttchmentDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyAttchmentDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyAttchmentMapper {
    long countByExample(PolicyAttchmentDOExample example);

    int deleteByExample(PolicyAttchmentDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyAttchmentDO record);

    int insertSelective(PolicyAttchmentDO record);

    List<PolicyAttchmentDO> selectByExampleWithRowbounds(PolicyAttchmentDOExample example, RowBounds rowBounds);

    List<PolicyAttchmentDO> selectByExample(PolicyAttchmentDOExample example);

    PolicyAttchmentDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyAttchmentDO record, @Param("example") PolicyAttchmentDOExample example);

    int updateByExample(@Param("record") PolicyAttchmentDO record, @Param("example") PolicyAttchmentDOExample example);

    int updateByPrimaryKeySelective(PolicyAttchmentDO record);

    int updateByPrimaryKey(PolicyAttchmentDO record);

    int batchInsert(@Param("list") List<PolicyAttchmentDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyAttchmentDO> recordList);

    PolicyAttchmentDO selectOneByExample(PolicyAttchmentDOExample example);
}