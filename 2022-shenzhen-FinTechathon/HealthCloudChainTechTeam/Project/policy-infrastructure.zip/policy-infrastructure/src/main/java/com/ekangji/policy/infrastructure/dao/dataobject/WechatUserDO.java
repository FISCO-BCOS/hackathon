package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   zhangjun
 * @date   2022-02-19 15:58:47
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class WechatUserDO implements Serializable {
    /**
     * ID
     */
    private Long id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 微信用户openId
     */
    private String openId;

    /**
     * 用户token
     */
    private String userToken;

    /**
     * 微信名
     */
    private String wechatName;

    /**
     * 用户真实名称
     */
    private String userName;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 性别 0女 1男
     */
    private Integer sex;

    /**
     * 手机号
     */
    private String phoneNumber;

    /**
     * 头像
     */
    private String userPhoto;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 注册时间
     */
    private Date registerTime;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 地区
     */
    private String city;

    private static final long serialVersionUID = 1L;


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", openId=").append(openId);
        sb.append(", userToken=").append(userToken);
        sb.append(", wechatName=").append(wechatName);
        sb.append(", userName=").append(userName);
        sb.append(", age=").append(age);
        sb.append(", sex=").append(sex);
        sb.append(", phoneNumber=").append(phoneNumber);
        sb.append(", userPhoto=").append(userPhoto);
        sb.append(", status=").append(status);
        sb.append(", registerTime=").append(registerTime);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private WechatUserDO obj;

        public Builder() {
            this.obj = new WechatUserDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder openId(String openId) {
            obj.openId = openId;
            return this;
        }

        public Builder userToken(String userToken) {
            obj.userToken = userToken;
            return this;
        }

        public Builder wechatName(String wechatName) {
            obj.wechatName = wechatName;
            return this;
        }

        public Builder userName(String userName) {
            obj.userName = userName;
            return this;
        }

        public Builder age(Integer age) {
            obj.age = age;
            return this;
        }

        public Builder sex(Integer sex) {
            obj.sex = sex;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            obj.phoneNumber = phoneNumber;
            return this;
        }

        public Builder userPhoto(String userPhoto) {
            obj.userPhoto = userPhoto;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder registerTime(Date registerTime) {
            obj.registerTime = registerTime;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public WechatUserDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        userId("user_id"),
        openId("open_id"),
        userToken("user_token"),
        wechatName("wechat_name"),
        userName("user_name"),
        age("age"),
        sex("sex"),
        phoneNumber("phone_number"),
        userPhoto("user_photo"),
        status("status"),
        registerTime("register_time"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}