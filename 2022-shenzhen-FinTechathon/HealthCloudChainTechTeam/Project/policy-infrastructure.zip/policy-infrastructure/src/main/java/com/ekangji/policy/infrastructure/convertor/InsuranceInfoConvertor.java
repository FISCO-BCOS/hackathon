package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.policy.InsuranceInfo;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceInfoDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author wjx
 * @date 2021/1/17 16:00
 */
@Mapper(componentModel = "spring")
public interface InsuranceInfoConvertor {

    InsuranceInfoDO convert(InsuranceInfo param);

    InsuranceInfo convert(InsuranceInfoDO param);

    List<InsuranceInfo> convert(List<InsuranceInfoDO> param);

    List<InsuranceInfoDO> convertList(List<InsuranceInfo> param);

    PageInfo<InsuranceInfo> convert(PageInfo<InsuranceInfoDO> param);

}
