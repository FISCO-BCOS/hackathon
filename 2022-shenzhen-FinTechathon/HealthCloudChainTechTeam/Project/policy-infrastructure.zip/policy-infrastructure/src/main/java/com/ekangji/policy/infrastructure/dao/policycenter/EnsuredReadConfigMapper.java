package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.EnsuredReadConfigDO;
import com.ekangji.policy.infrastructure.dao.dataobject.EnsuredReadConfigDOExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

public interface EnsuredReadConfigMapper {
    long countByExample(EnsuredReadConfigDOExample example);

    int deleteByExample(EnsuredReadConfigDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(EnsuredReadConfigDO record);

    int insertSelective(EnsuredReadConfigDO record);

    List<EnsuredReadConfigDO> selectByExampleWithRowbounds(EnsuredReadConfigDOExample example, RowBounds rowBounds);

    List<EnsuredReadConfigDO> selectByExample(EnsuredReadConfigDOExample example);

    EnsuredReadConfigDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") EnsuredReadConfigDO record, @Param("example") EnsuredReadConfigDOExample example);

    int updateByExample(@Param("record") EnsuredReadConfigDO record, @Param("example") EnsuredReadConfigDOExample example);

    int updateByPrimaryKeySelective(EnsuredReadConfigDO record);

    int updateByPrimaryKey(EnsuredReadConfigDO record);

    int batchInsert(@Param("list") List<EnsuredReadConfigDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<EnsuredReadConfigDO> recordList);

    EnsuredReadConfigDO selectOneByExample(EnsuredReadConfigDOExample example);
}