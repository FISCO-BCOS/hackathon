package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.Data;
import lombok.ToString;

/**
 *
 * @author   liuchen
 * @date   2022-05-24 17:00:25
 */
@Data
@ToString(callSuper = true)
public class PolicyMemberProductTypeStatisticsBO extends PolicyMemberProductTypeStatisticsDO{
}
