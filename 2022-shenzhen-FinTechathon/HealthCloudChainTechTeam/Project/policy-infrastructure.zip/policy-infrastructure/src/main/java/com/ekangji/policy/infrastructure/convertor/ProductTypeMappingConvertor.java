package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.infrastructure.dao.dataobject.ProductTypeMappingDO;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface ProductTypeMappingConvertor {

    ProductTypeMappingDO convert(ProductTypeMapping param);

    ProductTypeMapping convert(ProductTypeMappingDO param);

    List<ProductTypeMapping> convert(List<ProductTypeMappingDO> param);

    PageInfo<ProductTypeMapping> convert(PageInfo<ProductTypeMappingDO> param);

}
