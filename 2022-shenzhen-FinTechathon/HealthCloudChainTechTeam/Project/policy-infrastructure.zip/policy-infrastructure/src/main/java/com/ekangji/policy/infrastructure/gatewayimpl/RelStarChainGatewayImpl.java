package com.ekangji.policy.infrastructure.gatewayimpl;

import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.RelStarChainGateway;
import com.ekangji.policy.domain.gateway.StarChainGateway;
import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.infrastructure.convertor.RelStarChainConvertor;
import com.ekangji.policy.infrastructure.dao.dataobject.*;
import com.ekangji.policy.infrastructure.dao.policycenter.RelStarChainMapper;
import com.ekangji.policy.infrastructure.dao.policycenter.StarChainMapper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author xintao.li
 * @date 2021/12/2 22:04
 */
@Repository
public class RelStarChainGatewayImpl implements RelStarChainGateway {


    @Resource
    private RelStarChainMapper relStarChainMapper;

    @Resource
    private RelStarChainConvertor relStarChainConvertor;

    @Override
    public Long save(RelStarChain relStarChain) {
        RelStarChainDO relStarChainDO = relStarChainConvertor.convert(relStarChain);
        relStarChainDO.setCreateTime(new Date());
        relStarChainDO.setUpdateTime(new Date());
        relStarChainMapper.insertSelective(relStarChainDO);
        return relStarChainDO.getId();

    }

    @Override
    public int delete(RelStarChain relStarChain) {
//        return dictDataMapper.deleteByPrimaryKey(dictData.getDictCode());
        return 0;
    }

    @Override
    public int update(RelStarChain relStarChain) {
//        DictDataDO dictDataDO = dictDataConvertor.convert(dictData);
//        dictDataDO.setUpdateTime(new Date());
//        dictDataDO.setUpdateBy(ShiroUtils.getUserIdStr());
//        DictDataDOExample example = new DictDataDOExample();
//        DictDataDOExample.Criteria criteria = example.createCriteria();
//        criteria.andDictCodeEqualTo(dictData.getDictCode());
//        int delete = dictDataMapper.updateByExampleSelective(dictDataDO,example);
//        return delete;
        return 0;
    }

    @Override
    public RelStarChain get(RelStarChain relStarChain) {
//        List<DictDataDO> dictDataDOList = this.query(dictData);
//        if (CollectionUtils.isNotEmpty(dictDataDOList)){
//            return dictDataConvertor.convert(dictDataDOList.get(0));
//        }
        return null;
    }

    @Override
    public List<RelStarChain> list(RelStarChain relStarChain) {
        List<RelStarChainDO> relStarChainDOS = this.query(relStarChain);
        if (CollectionUtils.isNotEmpty(relStarChainDOS)){
            return relStarChainConvertor.convert(relStarChainDOS);
        }
        return Lists.newArrayList();
    }

    @Override
    public PageInfo<RelStarChain> page(RelStarChain relStarChain) {
//        PageHelper.startPage(dictData.getPageNum(),dictData.getPageSize());
//        List<DictDataDO> dictDataDOList = query(dictData);
//        PageInfo<DictDataDO> pageInfo = new PageInfo<>(dictDataDOList);
//        return dictDataConvertor.convert(pageInfo);
        return null;
    }

    private List<RelStarChainDO> query(RelStarChain relStarChain) {
        RelStarChainDOExample example = new RelStarChainDOExample();
        RelStarChainDOExample.Criteria criteria = example.createCriteria();
        if (Objects.nonNull(relStarChain.getChainId())){
            criteria.andChainIdEqualTo(relStarChain.getChainId());
        }
        criteria.andDelFlagEqualTo(DeleteFlagEnum.NORMAL.getCode());
        criteria.andStatusEqualTo(CommonStatusEnum.VALID.getCode());
        example.setOrderByClause("id desc");
        return relStarChainMapper.selectByExample(example);
    }

}
