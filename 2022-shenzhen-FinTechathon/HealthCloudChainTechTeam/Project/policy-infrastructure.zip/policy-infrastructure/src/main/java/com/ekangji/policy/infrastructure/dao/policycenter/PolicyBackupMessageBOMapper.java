package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageBO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBackupMessageDO;

import java.util.List;

/**
 * @Description
 * @author liuchen
 * @date 2022-05-16 11:07
 */
public interface PolicyBackupMessageBOMapper extends PolicyBackupMessageMapper{

    /**
     * 统计用户待接收保单
     * @param pbmDO
     * @return
     */
    List<PolicyBackupMessageBO> countToReceivePolicy(PolicyBackupMessageDO pbmDO);

    /**
     * 获取用户待接收保单信息
     * @param pbmDO
     * @return
     */
    List<PolicyBackupMessageBO> selectToReceivePolicy(PolicyBackupMessageDO pbmDO);

    /**
     * 保存备份保单
     * @param boList
     * @return
     */
    int batchSave(List<PolicyBackupMessageBO> boList);
}
