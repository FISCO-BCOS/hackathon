package com.ekangji.policy.infrastructure.dubbo;

import com.ekangji.ability.api.CloudChainService;
import com.ekangji.file.center.client.api.FileCenterService;
import com.ekangji.marketing.client.api.*;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.api.UserInfoService;
import com.ekangji.user.center.client.api.UserThirdMappingService;
import org.apache.dubbo.config.annotation.DubboReference;
import org.springframework.context.annotation.Configuration;

/**
 * Dubbo消费者服务注册
 *
 * @author liuchen
 * @date 2022/05/16 14:22
 */
@Configuration
public class DubboConsumerConfig {

    /**
     * 用户中心 渠道用户信息
     */
    @DubboReference(version = "${user-center.service.version}",interfaceClass = UserChannelInfoService.class,timeout = 5000,check = false)
    private UserChannelInfoService userChannelInfoService;

    /**
     * 用户中心 基本用户信息
     */
    @DubboReference(version = "${user-center.service.version}",interfaceClass = UserInfoService.class,timeout = 5000,check = false)
    private UserInfoService userInfoService;


    /**
     * 文件中心
     */
    @DubboReference(version = "${file-center.service.version}",interfaceClass = FileCenterService.class,timeout = 30000,retries = 0)
    private FileCenterService fileCenterService;

    /**
     * 用户中心 用户映射信息
     */
    @DubboReference(version = "${user-center.service.version}",interfaceClass = UserThirdMappingService.class,timeout = 5000,check = false)
    private UserThirdMappingService userThirdMappingService;

    /**
     * 原子能力 云链服务
     */
    @DubboReference(version = "${ability-center.service.version}",interfaceClass = CloudChainService.class,timeout = 30000,retries = 0)
    private CloudChainService cloudChainService;

    /**
     * 营销中心-积分规则、积分明细
     */
    @DubboReference(version = "${marketing.service.version}",interfaceClass = IntegralDetailRuleService.class,timeout = 30000,retries = 0)
    private IntegralDetailRuleService integralDetailRuleService;

    /**
     * 营销中心-增加积分详情
     */
    @DubboReference(version = "${marketing.service.version}",interfaceClass = UserIntegralDetailService.class,timeout = 30000,retries = 0)
    private UserIntegralDetailService userIntegralDetailService;

    /**
     * 营销中心-增加积分
     */
    @DubboReference(version = "${marketing.service.version}",interfaceClass = UserIntegralService.class,timeout = 30000,retries = 0)
    private UserIntegralService userIntegralService;

    /**
     * 营销中心-用户抽奖信息
     */
    @DubboReference(version = "${marketing.service.version}",interfaceClass = UserDrawInfoService.class,timeout = 30000,retries = 0)
    private UserDrawInfoService userDrawInfoService;

    /**
     * 营销中心-用户抽奖规则
     */
    @DubboReference(version = "${marketing.service.version}",interfaceClass = UserDrawContentService.class,timeout = 30000,retries = 0)
    private UserDrawContentService userDrawContentService;
}
