package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicySimpleDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicySimpleDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicySimpleMapper {
    long countByExample(PolicySimpleDOExample example);

    int deleteByExample(PolicySimpleDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicySimpleDO record);

    int insertSelective(PolicySimpleDO record);

    List<PolicySimpleDO> selectByExampleWithRowbounds(PolicySimpleDOExample example, RowBounds rowBounds);

    List<PolicySimpleDO> selectByExample(PolicySimpleDOExample example);

    PolicySimpleDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicySimpleDO record, @Param("example") PolicySimpleDOExample example);

    int updateByExample(@Param("record") PolicySimpleDO record, @Param("example") PolicySimpleDOExample example);

    int updateByPrimaryKeySelective(PolicySimpleDO record);

    int updateByPrimaryKey(PolicySimpleDO record);

    int batchInsert(@Param("list") List<PolicySimpleDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicySimpleDO> recordList);

    PolicySimpleDO selectOneByExample(PolicySimpleDOExample example);
}