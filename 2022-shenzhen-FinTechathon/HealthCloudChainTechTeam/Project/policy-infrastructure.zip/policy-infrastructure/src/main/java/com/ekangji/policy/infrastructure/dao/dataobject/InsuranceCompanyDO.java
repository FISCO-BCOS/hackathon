package com.ekangji.policy.infrastructure.dao.dataobject;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   李鑫涛
 * @date   2022-02-11 16:03:14
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceCompanyDO implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     *
     */
    private Long id;
    /**
     * 公司id
     */
    private String companyId;
    /**
     * 公司名称
     */
    private String companyName;
    /**
     * 公司简称
     */
    private String companyNameShort;
    /**
     * 公司英文名
     */
    private String companyNameEn;
    /**
     * 图标
     */
    private String fileId;
    /**
     * 公司类型
     */
    private String companyType;
    /**
     * 省
     */
    private String provinceCode;
    /**
     * 市
     */
    private String cityCode;
    /**
     * 客服电话
     */
    private String phone;
    /**
     * 删除标志（1 代表存在 0 代表删除）
     */
    private Integer delFlag;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 是否有效（1：有效，0：无效）
     */
    private Integer status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId == null ? null : companyId.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getCompanyNameShort() {
        return companyNameShort;
    }

    public void setCompanyNameShort(String companyNameShort) {
        this.companyNameShort = companyNameShort == null ? null : companyNameShort.trim();
    }

    public String getCompanyNameEn() {
        return companyNameEn;
    }

    public void setCompanyNameEn(String companyNameEn) {
        this.companyNameEn = companyNameEn == null ? null : companyNameEn.trim();
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId == null ? null : fileId.trim();
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType == null ? null : companyType.trim();
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", companyId=").append(companyId);
        sb.append(", companyName=").append(companyName);
        sb.append(", companyNameShort=").append(companyNameShort);
        sb.append(", companyNameEn=").append(companyNameEn);
        sb.append(", fileId=").append(fileId);
        sb.append(", companyType=").append(companyType);
        sb.append(", provinceCode=").append(provinceCode);
        sb.append(", cityCode=").append(cityCode);
        sb.append(", phone=").append(phone);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", status=").append(status);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public enum Column {
        id("id"),
        companyId("company_id"),
        companyName("company_name"),
        companyNameShort("company_name_short"),
        companyNameEn("company_name_en"),
        fileId("file_id"),
        companyType("company_type"),
        provinceCode("province_code"),
        cityCode("city_code"),
        phone("phone"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time"),
        status("status");

        private final String column;

        Column(String column) {
            this.column = column;
        }

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }

    public static class Builder {
        private InsuranceCompanyDO obj;

        public Builder() {
            this.obj = new InsuranceCompanyDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder companyId(String companyId) {
            obj.companyId = companyId;
            return this;
        }

        public Builder companyName(String companyName) {
            obj.companyName = companyName;
            return this;
        }

        public Builder companyNameShort(String companyNameShort) {
            obj.companyNameShort = companyNameShort;
            return this;
        }

        public Builder companyNameEn(String companyNameEn) {
            obj.companyNameEn = companyNameEn;
            return this;
        }

        public Builder fileId(String fileId) {
            obj.fileId = fileId;
            return this;
        }

        public Builder companyType(String companyType) {
            obj.companyType = companyType;
            return this;
        }

        public Builder provinceCode(String provinceCode) {
            obj.provinceCode = provinceCode;
            return this;
        }

        public Builder cityCode(String cityCode) {
            obj.cityCode = cityCode;
            return this;
        }

        public Builder phone(String phone) {
            obj.phone = phone;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public InsuranceCompanyDO build() {
            return this.obj;
        }
    }
}