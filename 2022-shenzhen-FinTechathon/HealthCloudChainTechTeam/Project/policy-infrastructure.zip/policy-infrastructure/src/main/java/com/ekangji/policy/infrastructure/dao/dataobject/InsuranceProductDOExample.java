package com.ekangji.policy.infrastructure.dao.dataobject;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class InsuranceProductDOExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public InsuranceProductDOExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNull() {
            addCriterion("product_id is null");
            return (Criteria) this;
        }

        public Criteria andProductIdIsNotNull() {
            addCriterion("product_id is not null");
            return (Criteria) this;
        }

        public Criteria andProductIdEqualTo(String value) {
            addCriterion("product_id =", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotEqualTo(String value) {
            addCriterion("product_id <>", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThan(String value) {
            addCriterion("product_id >", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdGreaterThanOrEqualTo(String value) {
            addCriterion("product_id >=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThan(String value) {
            addCriterion("product_id <", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLessThanOrEqualTo(String value) {
            addCriterion("product_id <=", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdLike(String value) {
            addCriterion("product_id like", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotLike(String value) {
            addCriterion("product_id not like", value, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdIn(List<String> values) {
            addCriterion("product_id in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotIn(List<String> values) {
            addCriterion("product_id not in", values, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdBetween(String value1, String value2) {
            addCriterion("product_id between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andProductIdNotBetween(String value1, String value2) {
            addCriterion("product_id not between", value1, value2, "productId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIsNull() {
            addCriterion("company_id is null");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIsNotNull() {
            addCriterion("company_id is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyIdEqualTo(String value) {
            addCriterion("company_id =", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotEqualTo(String value) {
            addCriterion("company_id <>", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdGreaterThan(String value) {
            addCriterion("company_id >", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdGreaterThanOrEqualTo(String value) {
            addCriterion("company_id >=", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLessThan(String value) {
            addCriterion("company_id <", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLessThanOrEqualTo(String value) {
            addCriterion("company_id <=", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLike(String value) {
            addCriterion("company_id like", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotLike(String value) {
            addCriterion("company_id not like", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIn(List<String> values) {
            addCriterion("company_id in", values, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotIn(List<String> values) {
            addCriterion("company_id not in", values, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdBetween(String value1, String value2) {
            addCriterion("company_id between", value1, value2, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotBetween(String value1, String value2) {
            addCriterion("company_id not between", value1, value2, "companyId");
            return (Criteria) this;
        }

        public Criteria andProductNameIsNull() {
            addCriterion("product_name is null");
            return (Criteria) this;
        }

        public Criteria andProductNameIsNotNull() {
            addCriterion("product_name is not null");
            return (Criteria) this;
        }

        public Criteria andProductNameEqualTo(String value) {
            addCriterion("product_name =", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotEqualTo(String value) {
            addCriterion("product_name <>", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameGreaterThan(String value) {
            addCriterion("product_name >", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameGreaterThanOrEqualTo(String value) {
            addCriterion("product_name >=", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLessThan(String value) {
            addCriterion("product_name <", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLessThanOrEqualTo(String value) {
            addCriterion("product_name <=", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameLike(String value) {
            addCriterion("product_name like", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotLike(String value) {
            addCriterion("product_name not like", value, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameIn(List<String> values) {
            addCriterion("product_name in", values, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotIn(List<String> values) {
            addCriterion("product_name not in", values, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameBetween(String value1, String value2) {
            addCriterion("product_name between", value1, value2, "productName");
            return (Criteria) this;
        }

        public Criteria andProductNameNotBetween(String value1, String value2) {
            addCriterion("product_name not between", value1, value2, "productName");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeIsNull() {
            addCriterion("one_level_type is null");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeIsNotNull() {
            addCriterion("one_level_type is not null");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeEqualTo(String value) {
            addCriterion("one_level_type =", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeNotEqualTo(String value) {
            addCriterion("one_level_type <>", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeGreaterThan(String value) {
            addCriterion("one_level_type >", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeGreaterThanOrEqualTo(String value) {
            addCriterion("one_level_type >=", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeLessThan(String value) {
            addCriterion("one_level_type <", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeLessThanOrEqualTo(String value) {
            addCriterion("one_level_type <=", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeLike(String value) {
            addCriterion("one_level_type like", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeNotLike(String value) {
            addCriterion("one_level_type not like", value, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeIn(List<String> values) {
            addCriterion("one_level_type in", values, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeNotIn(List<String> values) {
            addCriterion("one_level_type not in", values, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeBetween(String value1, String value2) {
            addCriterion("one_level_type between", value1, value2, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andOneLevelTypeNotBetween(String value1, String value2) {
            addCriterion("one_level_type not between", value1, value2, "oneLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeIsNull() {
            addCriterion("two_level_type is null");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeIsNotNull() {
            addCriterion("two_level_type is not null");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeEqualTo(String value) {
            addCriterion("two_level_type =", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeNotEqualTo(String value) {
            addCriterion("two_level_type <>", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeGreaterThan(String value) {
            addCriterion("two_level_type >", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeGreaterThanOrEqualTo(String value) {
            addCriterion("two_level_type >=", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeLessThan(String value) {
            addCriterion("two_level_type <", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeLessThanOrEqualTo(String value) {
            addCriterion("two_level_type <=", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeLike(String value) {
            addCriterion("two_level_type like", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeNotLike(String value) {
            addCriterion("two_level_type not like", value, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeIn(List<String> values) {
            addCriterion("two_level_type in", values, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeNotIn(List<String> values) {
            addCriterion("two_level_type not in", values, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeBetween(String value1, String value2) {
            addCriterion("two_level_type between", value1, value2, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andTwoLevelTypeNotBetween(String value1, String value2) {
            addCriterion("two_level_type not between", value1, value2, "twoLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeIsNull() {
            addCriterion("three_level_type is null");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeIsNotNull() {
            addCriterion("three_level_type is not null");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeEqualTo(String value) {
            addCriterion("three_level_type =", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeNotEqualTo(String value) {
            addCriterion("three_level_type <>", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeGreaterThan(String value) {
            addCriterion("three_level_type >", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeGreaterThanOrEqualTo(String value) {
            addCriterion("three_level_type >=", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeLessThan(String value) {
            addCriterion("three_level_type <", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeLessThanOrEqualTo(String value) {
            addCriterion("three_level_type <=", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeLike(String value) {
            addCriterion("three_level_type like", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeNotLike(String value) {
            addCriterion("three_level_type not like", value, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeIn(List<String> values) {
            addCriterion("three_level_type in", values, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeNotIn(List<String> values) {
            addCriterion("three_level_type not in", values, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeBetween(String value1, String value2) {
            addCriterion("three_level_type between", value1, value2, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andThreeLevelTypeNotBetween(String value1, String value2) {
            addCriterion("three_level_type not between", value1, value2, "threeLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeIsNull() {
            addCriterion("four_level_type is null");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeIsNotNull() {
            addCriterion("four_level_type is not null");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeEqualTo(String value) {
            addCriterion("four_level_type =", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeNotEqualTo(String value) {
            addCriterion("four_level_type <>", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeGreaterThan(String value) {
            addCriterion("four_level_type >", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeGreaterThanOrEqualTo(String value) {
            addCriterion("four_level_type >=", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeLessThan(String value) {
            addCriterion("four_level_type <", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeLessThanOrEqualTo(String value) {
            addCriterion("four_level_type <=", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeLike(String value) {
            addCriterion("four_level_type like", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeNotLike(String value) {
            addCriterion("four_level_type not like", value, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeIn(List<String> values) {
            addCriterion("four_level_type in", values, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeNotIn(List<String> values) {
            addCriterion("four_level_type not in", values, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeBetween(String value1, String value2) {
            addCriterion("four_level_type between", value1, value2, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andFourLevelTypeNotBetween(String value1, String value2) {
            addCriterion("four_level_type not between", value1, value2, "fourLevelType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeIsNull() {
            addCriterion("design_type is null");
            return (Criteria) this;
        }

        public Criteria andDesignTypeIsNotNull() {
            addCriterion("design_type is not null");
            return (Criteria) this;
        }

        public Criteria andDesignTypeEqualTo(String value) {
            addCriterion("design_type =", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeNotEqualTo(String value) {
            addCriterion("design_type <>", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeGreaterThan(String value) {
            addCriterion("design_type >", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeGreaterThanOrEqualTo(String value) {
            addCriterion("design_type >=", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeLessThan(String value) {
            addCriterion("design_type <", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeLessThanOrEqualTo(String value) {
            addCriterion("design_type <=", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeLike(String value) {
            addCriterion("design_type like", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeNotLike(String value) {
            addCriterion("design_type not like", value, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeIn(List<String> values) {
            addCriterion("design_type in", values, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeNotIn(List<String> values) {
            addCriterion("design_type not in", values, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeBetween(String value1, String value2) {
            addCriterion("design_type between", value1, value2, "designType");
            return (Criteria) this;
        }

        public Criteria andDesignTypeNotBetween(String value1, String value2) {
            addCriterion("design_type not between", value1, value2, "designType");
            return (Criteria) this;
        }

        public Criteria andProductSpecialIsNull() {
            addCriterion("product_special is null");
            return (Criteria) this;
        }

        public Criteria andProductSpecialIsNotNull() {
            addCriterion("product_special is not null");
            return (Criteria) this;
        }

        public Criteria andProductSpecialEqualTo(String value) {
            addCriterion("product_special =", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialNotEqualTo(String value) {
            addCriterion("product_special <>", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialGreaterThan(String value) {
            addCriterion("product_special >", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialGreaterThanOrEqualTo(String value) {
            addCriterion("product_special >=", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialLessThan(String value) {
            addCriterion("product_special <", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialLessThanOrEqualTo(String value) {
            addCriterion("product_special <=", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialLike(String value) {
            addCriterion("product_special like", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialNotLike(String value) {
            addCriterion("product_special not like", value, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialIn(List<String> values) {
            addCriterion("product_special in", values, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialNotIn(List<String> values) {
            addCriterion("product_special not in", values, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialBetween(String value1, String value2) {
            addCriterion("product_special between", value1, value2, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andProductSpecialNotBetween(String value1, String value2) {
            addCriterion("product_special not between", value1, value2, "productSpecial");
            return (Criteria) this;
        }

        public Criteria andTimeTypeIsNull() {
            addCriterion("time_type is null");
            return (Criteria) this;
        }

        public Criteria andTimeTypeIsNotNull() {
            addCriterion("time_type is not null");
            return (Criteria) this;
        }

        public Criteria andTimeTypeEqualTo(String value) {
            addCriterion("time_type =", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeNotEqualTo(String value) {
            addCriterion("time_type <>", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeGreaterThan(String value) {
            addCriterion("time_type >", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeGreaterThanOrEqualTo(String value) {
            addCriterion("time_type >=", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeLessThan(String value) {
            addCriterion("time_type <", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeLessThanOrEqualTo(String value) {
            addCriterion("time_type <=", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeLike(String value) {
            addCriterion("time_type like", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeNotLike(String value) {
            addCriterion("time_type not like", value, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeIn(List<String> values) {
            addCriterion("time_type in", values, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeNotIn(List<String> values) {
            addCriterion("time_type not in", values, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeBetween(String value1, String value2) {
            addCriterion("time_type between", value1, value2, "timeType");
            return (Criteria) this;
        }

        public Criteria andTimeTypeNotBetween(String value1, String value2) {
            addCriterion("time_type not between", value1, value2, "timeType");
            return (Criteria) this;
        }

        public Criteria andClauseCodeIsNull() {
            addCriterion("clause_code is null");
            return (Criteria) this;
        }

        public Criteria andClauseCodeIsNotNull() {
            addCriterion("clause_code is not null");
            return (Criteria) this;
        }

        public Criteria andClauseCodeEqualTo(String value) {
            addCriterion("clause_code =", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeNotEqualTo(String value) {
            addCriterion("clause_code <>", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeGreaterThan(String value) {
            addCriterion("clause_code >", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeGreaterThanOrEqualTo(String value) {
            addCriterion("clause_code >=", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeLessThan(String value) {
            addCriterion("clause_code <", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeLessThanOrEqualTo(String value) {
            addCriterion("clause_code <=", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeLike(String value) {
            addCriterion("clause_code like", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeNotLike(String value) {
            addCriterion("clause_code not like", value, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeIn(List<String> values) {
            addCriterion("clause_code in", values, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeNotIn(List<String> values) {
            addCriterion("clause_code not in", values, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeBetween(String value1, String value2) {
            addCriterion("clause_code between", value1, value2, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseCodeNotBetween(String value1, String value2) {
            addCriterion("clause_code not between", value1, value2, "clauseCode");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameIsNull() {
            addCriterion("clause_file_name is null");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameIsNotNull() {
            addCriterion("clause_file_name is not null");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameEqualTo(String value) {
            addCriterion("clause_file_name =", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameNotEqualTo(String value) {
            addCriterion("clause_file_name <>", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameGreaterThan(String value) {
            addCriterion("clause_file_name >", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameGreaterThanOrEqualTo(String value) {
            addCriterion("clause_file_name >=", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameLessThan(String value) {
            addCriterion("clause_file_name <", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameLessThanOrEqualTo(String value) {
            addCriterion("clause_file_name <=", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameLike(String value) {
            addCriterion("clause_file_name like", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameNotLike(String value) {
            addCriterion("clause_file_name not like", value, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameIn(List<String> values) {
            addCriterion("clause_file_name in", values, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameNotIn(List<String> values) {
            addCriterion("clause_file_name not in", values, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameBetween(String value1, String value2) {
            addCriterion("clause_file_name between", value1, value2, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileNameNotBetween(String value1, String value2) {
            addCriterion("clause_file_name not between", value1, value2, "clauseFileName");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdIsNull() {
            addCriterion("clause_file_id is null");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdIsNotNull() {
            addCriterion("clause_file_id is not null");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdEqualTo(String value) {
            addCriterion("clause_file_id =", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdNotEqualTo(String value) {
            addCriterion("clause_file_id <>", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdGreaterThan(String value) {
            addCriterion("clause_file_id >", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdGreaterThanOrEqualTo(String value) {
            addCriterion("clause_file_id >=", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdLessThan(String value) {
            addCriterion("clause_file_id <", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdLessThanOrEqualTo(String value) {
            addCriterion("clause_file_id <=", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdLike(String value) {
            addCriterion("clause_file_id like", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdNotLike(String value) {
            addCriterion("clause_file_id not like", value, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdIn(List<String> values) {
            addCriterion("clause_file_id in", values, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdNotIn(List<String> values) {
            addCriterion("clause_file_id not in", values, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdBetween(String value1, String value2) {
            addCriterion("clause_file_id between", value1, value2, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andClauseFileIdNotBetween(String value1, String value2) {
            addCriterion("clause_file_id not between", value1, value2, "clauseFileId");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleIsNull() {
            addCriterion("insurance_style is null");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleIsNotNull() {
            addCriterion("insurance_style is not null");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleEqualTo(String value) {
            addCriterion("insurance_style =", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleNotEqualTo(String value) {
            addCriterion("insurance_style <>", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleGreaterThan(String value) {
            addCriterion("insurance_style >", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleGreaterThanOrEqualTo(String value) {
            addCriterion("insurance_style >=", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleLessThan(String value) {
            addCriterion("insurance_style <", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleLessThanOrEqualTo(String value) {
            addCriterion("insurance_style <=", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleLike(String value) {
            addCriterion("insurance_style like", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleNotLike(String value) {
            addCriterion("insurance_style not like", value, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleIn(List<String> values) {
            addCriterion("insurance_style in", values, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleNotIn(List<String> values) {
            addCriterion("insurance_style not in", values, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleBetween(String value1, String value2) {
            addCriterion("insurance_style between", value1, value2, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andInsuranceStyleNotBetween(String value1, String value2) {
            addCriterion("insurance_style not between", value1, value2, "insuranceStyle");
            return (Criteria) this;
        }

        public Criteria andPayWayIsNull() {
            addCriterion("pay_way is null");
            return (Criteria) this;
        }

        public Criteria andPayWayIsNotNull() {
            addCriterion("pay_way is not null");
            return (Criteria) this;
        }

        public Criteria andPayWayEqualTo(String value) {
            addCriterion("pay_way =", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayNotEqualTo(String value) {
            addCriterion("pay_way <>", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayGreaterThan(String value) {
            addCriterion("pay_way >", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayGreaterThanOrEqualTo(String value) {
            addCriterion("pay_way >=", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayLessThan(String value) {
            addCriterion("pay_way <", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayLessThanOrEqualTo(String value) {
            addCriterion("pay_way <=", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayLike(String value) {
            addCriterion("pay_way like", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayNotLike(String value) {
            addCriterion("pay_way not like", value, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayIn(List<String> values) {
            addCriterion("pay_way in", values, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayNotIn(List<String> values) {
            addCriterion("pay_way not in", values, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayBetween(String value1, String value2) {
            addCriterion("pay_way between", value1, value2, "payWay");
            return (Criteria) this;
        }

        public Criteria andPayWayNotBetween(String value1, String value2) {
            addCriterion("pay_way not between", value1, value2, "payWay");
            return (Criteria) this;
        }

        public Criteria andStopDateIsNull() {
            addCriterion("stop_date is null");
            return (Criteria) this;
        }

        public Criteria andStopDateIsNotNull() {
            addCriterion("stop_date is not null");
            return (Criteria) this;
        }

        public Criteria andStopDateEqualTo(Date value) {
            addCriterionForJDBCDate("stop_date =", value, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateNotEqualTo(Date value) {
            addCriterionForJDBCDate("stop_date <>", value, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateGreaterThan(Date value) {
            addCriterionForJDBCDate("stop_date >", value, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("stop_date >=", value, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateLessThan(Date value) {
            addCriterionForJDBCDate("stop_date <", value, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("stop_date <=", value, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateIn(List<Date> values) {
            addCriterionForJDBCDate("stop_date in", values, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateNotIn(List<Date> values) {
            addCriterionForJDBCDate("stop_date not in", values, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("stop_date between", value1, value2, "stopDate");
            return (Criteria) this;
        }

        public Criteria andStopDateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("stop_date not between", value1, value2, "stopDate");
            return (Criteria) this;
        }

        public Criteria andSaleStatusIsNull() {
            addCriterion("sale_status is null");
            return (Criteria) this;
        }

        public Criteria andSaleStatusIsNotNull() {
            addCriterion("sale_status is not null");
            return (Criteria) this;
        }

        public Criteria andSaleStatusEqualTo(String value) {
            addCriterion("sale_status =", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusNotEqualTo(String value) {
            addCriterion("sale_status <>", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusGreaterThan(String value) {
            addCriterion("sale_status >", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusGreaterThanOrEqualTo(String value) {
            addCriterion("sale_status >=", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusLessThan(String value) {
            addCriterion("sale_status <", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusLessThanOrEqualTo(String value) {
            addCriterion("sale_status <=", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusLike(String value) {
            addCriterion("sale_status like", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusNotLike(String value) {
            addCriterion("sale_status not like", value, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusIn(List<String> values) {
            addCriterion("sale_status in", values, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusNotIn(List<String> values) {
            addCriterion("sale_status not in", values, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusBetween(String value1, String value2) {
            addCriterion("sale_status between", value1, value2, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andSaleStatusNotBetween(String value1, String value2) {
            addCriterion("sale_status not between", value1, value2, "saleStatus");
            return (Criteria) this;
        }

        public Criteria andIsDismantleIsNull() {
            addCriterion("`is_ dismantle` is null");
            return (Criteria) this;
        }

        public Criteria andIsDismantleIsNotNull() {
            addCriterion("`is_ dismantle` is not null");
            return (Criteria) this;
        }

        public Criteria andIsDismantleEqualTo(Integer value) {
            addCriterion("`is_ dismantle` =", value, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleNotEqualTo(Integer value) {
            addCriterion("`is_ dismantle` <>", value, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleGreaterThan(Integer value) {
            addCriterion("`is_ dismantle` >", value, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleGreaterThanOrEqualTo(Integer value) {
            addCriterion("`is_ dismantle` >=", value, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleLessThan(Integer value) {
            addCriterion("`is_ dismantle` <", value, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleLessThanOrEqualTo(Integer value) {
            addCriterion("`is_ dismantle` <=", value, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleIn(List<Integer> values) {
            addCriterion("`is_ dismantle` in", values, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleNotIn(List<Integer> values) {
            addCriterion("`is_ dismantle` not in", values, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleBetween(Integer value1, Integer value2) {
            addCriterion("`is_ dismantle` between", value1, value2, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andIsDismantleNotBetween(Integer value1, Integer value2) {
            addCriterion("`is_ dismantle` not between", value1, value2, "isDismantle");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNull() {
            addCriterion("del_flag is null");
            return (Criteria) this;
        }

        public Criteria andDelFlagIsNotNull() {
            addCriterion("del_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(Integer value) {
            addCriterion("del_flag =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotEqualTo(Integer value) {
            addCriterion("del_flag <>", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThan(Integer value) {
            addCriterion("del_flag >", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagGreaterThanOrEqualTo(Integer value) {
            addCriterion("del_flag >=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThan(Integer value) {
            addCriterion("del_flag <", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagLessThanOrEqualTo(Integer value) {
            addCriterion("del_flag <=", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagIn(List<Integer> values) {
            addCriterion("del_flag in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotIn(List<Integer> values) {
            addCriterion("del_flag not in", values, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagBetween(Integer value1, Integer value2) {
            addCriterion("del_flag between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andDelFlagNotBetween(Integer value1, Integer value2) {
            addCriterion("del_flag not between", value1, value2, "delFlag");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNull() {
            addCriterion("create_by is null");
            return (Criteria) this;
        }

        public Criteria andCreateByIsNotNull() {
            addCriterion("create_by is not null");
            return (Criteria) this;
        }

        public Criteria andCreateByEqualTo(String value) {
            addCriterion("create_by =", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotEqualTo(String value) {
            addCriterion("create_by <>", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThan(String value) {
            addCriterion("create_by >", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByGreaterThanOrEqualTo(String value) {
            addCriterion("create_by >=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThan(String value) {
            addCriterion("create_by <", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLessThanOrEqualTo(String value) {
            addCriterion("create_by <=", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByLike(String value) {
            addCriterion("create_by like", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotLike(String value) {
            addCriterion("create_by not like", value, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByIn(List<String> values) {
            addCriterion("create_by in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotIn(List<String> values) {
            addCriterion("create_by not in", values, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByBetween(String value1, String value2) {
            addCriterion("create_by between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateByNotBetween(String value1, String value2) {
            addCriterion("create_by not between", value1, value2, "createBy");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNull() {
            addCriterion("update_by is null");
            return (Criteria) this;
        }

        public Criteria andUpdateByIsNotNull() {
            addCriterion("update_by is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateByEqualTo(String value) {
            addCriterion("update_by =", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotEqualTo(String value) {
            addCriterion("update_by <>", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThan(String value) {
            addCriterion("update_by >", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByGreaterThanOrEqualTo(String value) {
            addCriterion("update_by >=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThan(String value) {
            addCriterion("update_by <", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLessThanOrEqualTo(String value) {
            addCriterion("update_by <=", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByLike(String value) {
            addCriterion("update_by like", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotLike(String value) {
            addCriterion("update_by not like", value, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByIn(List<String> values) {
            addCriterion("update_by in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotIn(List<String> values) {
            addCriterion("update_by not in", values, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByBetween(String value1, String value2) {
            addCriterion("update_by between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateByNotBetween(String value1, String value2) {
            addCriterion("update_by not between", value1, value2, "updateBy");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("`status` is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("`status` is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("`status` =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("`status` <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("`status` >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("`status` >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("`status` <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("`status` <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("`status` in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("`status` not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("`status` between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("`status` not between", value1, value2, "status");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}