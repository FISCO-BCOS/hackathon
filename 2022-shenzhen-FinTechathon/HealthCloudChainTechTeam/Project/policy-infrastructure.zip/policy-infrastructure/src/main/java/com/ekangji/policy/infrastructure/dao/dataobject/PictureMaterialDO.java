package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   wjx
 * @date   2022-07-22 10:58:22
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PictureMaterialDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long materialId;

    /**
     * 藏品编号
     */
    private String collectionNumber;

    /**
     * 藏品总量
     */
    private Integer totalNum;

    /**
     * 藏品已用量
     */
    private Integer usedNum;

    /**
     * 图片地址ID
     */
    private String fileId;

    /**
     * 图片名称
     */
    private String pictureName;

    /**
     * 素材类型(1:星球图片,2:保单图片)
     */
    private Integer materialType;

    /**
     * 状态(1:启用,0:禁用)
     */
    private Integer status;

    /**
     * 是否启用过，0未启用过，1启用过
     */
    private Integer hasUsed;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public String getCollectionNumber() {
        return collectionNumber;
    }

    public void setCollectionNumber(String collectionNumber) {
        this.collectionNumber = collectionNumber == null ? null : collectionNumber.trim();
    }

    public Integer getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(Integer totalNum) {
        this.totalNum = totalNum;
    }

    public Integer getUsedNum() {
        return usedNum;
    }

    public void setUsedNum(Integer usedNum) {
        this.usedNum = usedNum;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId == null ? null : fileId.trim();
    }

    public String getPictureName() {
        return pictureName;
    }

    public void setPictureName(String pictureName) {
        this.pictureName = pictureName == null ? null : pictureName.trim();
    }

    public Integer getMaterialType() {
        return materialType;
    }

    public void setMaterialType(Integer materialType) {
        this.materialType = materialType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getHasUsed() {
        return hasUsed;
    }

    public void setHasUsed(Integer hasUsed) {
        this.hasUsed = hasUsed;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", materialId=").append(materialId);
        sb.append(", collectionNumber=").append(collectionNumber);
        sb.append(", totalNum=").append(totalNum);
        sb.append(", usedNum=").append(usedNum);
        sb.append(", fileId=").append(fileId);
        sb.append(", pictureName=").append(pictureName);
        sb.append(", materialType=").append(materialType);
        sb.append(", status=").append(status);
        sb.append(", hasUsed=").append(hasUsed);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private PictureMaterialDO obj;

        public Builder() {
            this.obj = new PictureMaterialDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder materialId(Long materialId) {
            obj.materialId = materialId;
            return this;
        }

        public Builder collectionNumber(String collectionNumber) {
            obj.collectionNumber = collectionNumber;
            return this;
        }

        public Builder totalNum(Integer totalNum) {
            obj.totalNum = totalNum;
            return this;
        }

        public Builder usedNum(Integer usedNum) {
            obj.usedNum = usedNum;
            return this;
        }

        public Builder fileId(String fileId) {
            obj.fileId = fileId;
            return this;
        }

        public Builder pictureName(String pictureName) {
            obj.pictureName = pictureName;
            return this;
        }

        public Builder materialType(Integer materialType) {
            obj.materialType = materialType;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder hasUsed(Integer hasUsed) {
            obj.hasUsed = hasUsed;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public PictureMaterialDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        materialId("material_id"),
        collectionNumber("collection_number"),
        totalNum("total_num"),
        usedNum("used_num"),
        fileId("file_id"),
        pictureName("picture_name"),
        materialType("material_type"),
        status("status"),
        hasUsed("has_used"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}