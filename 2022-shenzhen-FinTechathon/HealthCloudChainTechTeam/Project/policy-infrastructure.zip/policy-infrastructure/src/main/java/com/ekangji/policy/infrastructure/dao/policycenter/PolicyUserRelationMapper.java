package com.ekangji.policy.infrastructure.dao.policycenter;

import com.ekangji.policy.infrastructure.dao.dataobject.PolicyUserRelationDO;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyUserRelationDOExample;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;

public interface PolicyUserRelationMapper {
    long countByExample(PolicyUserRelationDOExample example);

    int deleteByExample(PolicyUserRelationDOExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PolicyUserRelationDO record);

    int insertSelective(PolicyUserRelationDO record);

    List<PolicyUserRelationDO> selectByExampleWithRowbounds(PolicyUserRelationDOExample example, RowBounds rowBounds);

    List<PolicyUserRelationDO> selectByExample(PolicyUserRelationDOExample example);

    PolicyUserRelationDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PolicyUserRelationDO record, @Param("example") PolicyUserRelationDOExample example);

    int updateByExample(@Param("record") PolicyUserRelationDO record, @Param("example") PolicyUserRelationDOExample example);

    int updateByPrimaryKeySelective(PolicyUserRelationDO record);

    int updateByPrimaryKey(PolicyUserRelationDO record);

    int batchInsert(@Param("list") List<PolicyUserRelationDO> list);

    int batchDelete(@Param("ids") Long[] ids);

    int batchUpdate(@Param("recordList") List<PolicyUserRelationDO> recordList);

    PolicyUserRelationDO selectOneByExample(PolicyUserRelationDOExample example);
}