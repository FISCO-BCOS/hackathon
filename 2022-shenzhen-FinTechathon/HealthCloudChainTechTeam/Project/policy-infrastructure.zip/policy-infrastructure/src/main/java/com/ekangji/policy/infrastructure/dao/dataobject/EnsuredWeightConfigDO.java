package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-05-18 17:03:06
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class EnsuredWeightConfigDO implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 一级产品类别
     */
    private String oneLevelType;

    /**
     * 一级产品类别名称
     */
    private String firstLevelName;

    /**
     * 一级类别对应的小程序名字
     */
    private String programName;

    /**
     * 0-18岁权重值
     */
    private BigDecimal firstStage;

    /**
     * 18-25岁权重值
     */
    private BigDecimal secondStage;

    /**
     * 25-35岁权重值
     */
    private BigDecimal thirdStage;

    /**
     * 35-50岁权重值
     */
    private BigDecimal fourthStage;

    /**
     * 50岁以上权重值
     */
    private BigDecimal fifthStage;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOneLevelType() {
        return oneLevelType;
    }

    public void setOneLevelType(String oneLevelType) {
        this.oneLevelType = oneLevelType == null ? null : oneLevelType.trim();
    }

    public String getFirstLevelName() {
        return firstLevelName;
    }

    public void setFirstLevelName(String firstLevelName) {
        this.firstLevelName = firstLevelName == null ? null : firstLevelName.trim();
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName == null ? null : programName.trim();
    }

    public BigDecimal getFirstStage() {
        return firstStage;
    }

    public void setFirstStage(BigDecimal firstStage) {
        this.firstStage = firstStage;
    }

    public BigDecimal getSecondStage() {
        return secondStage;
    }

    public void setSecondStage(BigDecimal secondStage) {
        this.secondStage = secondStage;
    }

    public BigDecimal getThirdStage() {
        return thirdStage;
    }

    public void setThirdStage(BigDecimal thirdStage) {
        this.thirdStage = thirdStage;
    }

    public BigDecimal getFourthStage() {
        return fourthStage;
    }

    public void setFourthStage(BigDecimal fourthStage) {
        this.fourthStage = fourthStage;
    }

    public BigDecimal getFifthStage() {
        return fifthStage;
    }

    public void setFifthStage(BigDecimal fifthStage) {
        this.fifthStage = fifthStage;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", oneLevelType=").append(oneLevelType);
        sb.append(", firstLevelName=").append(firstLevelName);
        sb.append(", programName=").append(programName);
        sb.append(", firstStage=").append(firstStage);
        sb.append(", secondStage=").append(secondStage);
        sb.append(", thirdStage=").append(thirdStage);
        sb.append(", fourthStage=").append(fourthStage);
        sb.append(", fifthStage=").append(fifthStage);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private EnsuredWeightConfigDO obj;

        public Builder() {
            this.obj = new EnsuredWeightConfigDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder oneLevelType(String oneLevelType) {
            obj.oneLevelType = oneLevelType;
            return this;
        }

        public Builder firstLevelName(String firstLevelName) {
            obj.firstLevelName = firstLevelName;
            return this;
        }

        public Builder programName(String programName) {
            obj.programName = programName;
            return this;
        }

        public Builder firstStage(BigDecimal firstStage) {
            obj.firstStage = firstStage;
            return this;
        }

        public Builder secondStage(BigDecimal secondStage) {
            obj.secondStage = secondStage;
            return this;
        }

        public Builder thirdStage(BigDecimal thirdStage) {
            obj.thirdStage = thirdStage;
            return this;
        }

        public Builder fourthStage(BigDecimal fourthStage) {
            obj.fourthStage = fourthStage;
            return this;
        }

        public Builder fifthStage(BigDecimal fifthStage) {
            obj.fifthStage = fifthStage;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public EnsuredWeightConfigDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        oneLevelType("one_level_type"),
        firstLevelName("first_level_name"),
        programName("program_name"),
        firstStage("first_stage"),
        secondStage("second_stage"),
        thirdStage("third_stage"),
        fourthStage("fourth_stage"),
        fifthStage("fifth_stage"),
        status("status"),
        createTime("create_time"),
        createBy("create_by"),
        updateTime("update_time"),
        updateBy("update_by"),
        delFlag("del_flag");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}