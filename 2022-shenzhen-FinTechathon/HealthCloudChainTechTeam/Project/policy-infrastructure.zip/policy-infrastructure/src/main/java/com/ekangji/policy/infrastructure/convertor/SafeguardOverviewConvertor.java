package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.infrastructure.dao.dataobject.SafeguardOverviewDO;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface SafeguardOverviewConvertor {

    SafeguardOverviewDO convert(SafeguardOverview param);

    SafeguardOverview convert(SafeguardOverviewDO param);

    List<SafeguardOverview> convert(List<SafeguardOverviewDO> param);

    PageInfo<SafeguardOverview> convert(PageInfo<SafeguardOverviewDO> param);

}
