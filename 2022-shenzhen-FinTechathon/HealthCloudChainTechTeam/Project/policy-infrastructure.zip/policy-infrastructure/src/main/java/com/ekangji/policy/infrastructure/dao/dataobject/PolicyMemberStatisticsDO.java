package com.ekangji.policy.infrastructure.dao.dataobject;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author   liuchen
 * @date   2022-06-08 09:06:11
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class PolicyMemberStatisticsDO implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 所属用户ID
     */
    private String userId;

    /**
     * 家庭成员ID
     */
    private Long memberId;

    /**
     * 保单总数
     */
    private Integer policyNum;

    /**
     * 有效保单数
     */
    private Integer effectivePolicyNum;

    /**
     * 今年保费
     */
    private BigDecimal premium;

    /**
     * 状态（1:有效,0:无效）
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Integer getPolicyNum() {
        return policyNum;
    }

    public void setPolicyNum(Integer policyNum) {
        this.policyNum = policyNum;
    }

    public Integer getEffectivePolicyNum() {
        return effectivePolicyNum;
    }

    public void setEffectivePolicyNum(Integer effectivePolicyNum) {
        this.effectivePolicyNum = effectivePolicyNum;
    }

    public BigDecimal getPremium() {
        return premium;
    }

    public void setPremium(BigDecimal premium) {
        this.premium = premium;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy == null ? null : createBy.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy == null ? null : updateBy.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", memberId=").append(memberId);
        sb.append(", policyNum=").append(policyNum);
        sb.append(", effectivePolicyNum=").append(effectivePolicyNum);
        sb.append(", premium=").append(premium);
        sb.append(", status=").append(status);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public static class Builder {
        private PolicyMemberStatisticsDO obj;

        public Builder() {
            this.obj = new PolicyMemberStatisticsDO();
        }

        public Builder id(Long id) {
            obj.id = id;
            return this;
        }

        public Builder userId(String userId) {
            obj.userId = userId;
            return this;
        }

        public Builder memberId(Long memberId) {
            obj.memberId = memberId;
            return this;
        }

        public Builder policyNum(Integer policyNum) {
            obj.policyNum = policyNum;
            return this;
        }

        public Builder effectivePolicyNum(Integer effectivePolicyNum) {
            obj.effectivePolicyNum = effectivePolicyNum;
            return this;
        }

        public Builder premium(BigDecimal premium) {
            obj.premium = premium;
            return this;
        }

        public Builder status(Integer status) {
            obj.status = status;
            return this;
        }

        public Builder delFlag(Integer delFlag) {
            obj.delFlag = delFlag;
            return this;
        }

        public Builder createBy(String createBy) {
            obj.createBy = createBy;
            return this;
        }

        public Builder createTime(Date createTime) {
            obj.createTime = createTime;
            return this;
        }

        public Builder updateBy(String updateBy) {
            obj.updateBy = updateBy;
            return this;
        }

        public Builder updateTime(Date updateTime) {
            obj.updateTime = updateTime;
            return this;
        }

        public PolicyMemberStatisticsDO build() {
            return this.obj;
        }
    }

    public enum Column {
        id("id"),
        userId("user_id"),
        memberId("member_id"),
        policyNum("policy_num"),
        effectivePolicyNum("effective_policy_num"),
        premium("premium"),
        status("status"),
        delFlag("del_flag"),
        createBy("create_by"),
        createTime("create_time"),
        updateBy("update_by"),
        updateTime("update_time");

        private final String column;

        public String value() {
            return this.column;
        }

        public String getValue() {
            return this.column;
        }

        Column(String column) {
            this.column = column;
        }

        public String desc() {
            return this.column + " DESC";
        }

        public String asc() {
            return this.column + " ASC";
        }
    }
}