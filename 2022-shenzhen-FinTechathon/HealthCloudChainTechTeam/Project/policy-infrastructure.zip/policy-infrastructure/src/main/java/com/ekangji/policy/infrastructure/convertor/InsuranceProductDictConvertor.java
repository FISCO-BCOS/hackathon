package com.ekangji.policy.infrastructure.convertor;

import com.ekangji.policy.domain.insurance.InsuranceProduct;
import com.ekangji.policy.domain.insurance.InsuranceProductDict;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDO;
import com.ekangji.policy.infrastructure.dao.dataobject.InsuranceProductDictDO;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author wjx
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface InsuranceProductDictConvertor {

    List<InsuranceProductDict> convert(List<InsuranceProductDictDO> param);

    InsuranceProductDict convert(InsuranceProductDictDO param);
}
