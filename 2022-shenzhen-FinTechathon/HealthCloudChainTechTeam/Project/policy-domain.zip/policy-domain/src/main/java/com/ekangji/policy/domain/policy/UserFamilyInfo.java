package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author   wjx
 * @date   2022-05-16 12:24:30
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class UserFamilyInfo implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 成员id
     */
    private Long memberId;

    /**
     * 该成员所属用户id 业务主键 雪花算法生成
     */
    private String belongUserId;

    /**
     * 用户昵称
     */
    private String nickName;

    /**
     * 关系0本人 1 伴侣 2孩子 3爸爸 4妈妈 5兄弟姐妹 6祖父 7祖母 8其他
     */
    private Integer relation;

    /**
     * 渠道标识 0微信小程序 1抖音小程序
     */
    private Integer channelType;

    /**
     * 用户真实名称
     */
    private String name;

    /**
     * 手机号
     */
    private String phoneNumber;


    /**
     * 用户手机号
     */
    private String userPhoneNumber;

    /**
     * 有无社保 0 无 1有
     */
    private Integer socialSecurityFlag;

    /**
     * 身份证件类型 0 身份证 1户口本 2出生证 3护照 4 军官证 5警官证 6 外国人永久居留证 7 港澳台同胞回乡证 8 外国人永久居留身份证 9港澳台居民居住证
     */
    private Integer identityCardType;

    /**
     * 是否是备份 1 是 0否
     */
    private Integer backFlag;

    /**
     * 证件号码
     */
    private String identityCardNumber;

    /**
     * 性别 0女 1男
     */
    private Integer sex;

    /**
     * 出生日期
     */
    private Date birthday;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    /**
     * 照片url
     */
    private String userPhoto;
    /**
     *
     */
    private List<Long> memberIds;

}