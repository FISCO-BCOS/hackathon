package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicySimple implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 保单ID 雪花算法生产
     */
    private Long policyId;

    /**
     * 所属平台(0:微信，1:抖音小程序)
     */
    private Integer platform;

    /**
     * 所属用户
     */
    private String userId;

    /**
     * 所属用户手机号
     */
    private String userPhone;

    /**
     * 保司ID
     */
    private String companyId;

    /**
     * 保司名称
     */
    private String companyName;

    /**
     * 保司简称
     */
    private String companyNameShort;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品类型编号
     */
    private String productType;

    /**
     * 产品四级类型标号
     */
    private String productFourType;

    /**
     * 产品三级类型标号
     */
    private String productThreeType;

    /**
     * 产品二级类型编号
     */
    private String productTwoType;

    /**
     * 产品一级类型编号
     */
    private String productTopType;

    /**
     * 被保人姓名
     */
    private String insurantName;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
}
