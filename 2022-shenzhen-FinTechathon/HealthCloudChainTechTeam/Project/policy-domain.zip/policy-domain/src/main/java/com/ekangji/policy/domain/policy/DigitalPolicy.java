package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.PageParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalPolicy extends PageParam implements Serializable {


    /**
     * id
     */
    private Long id;

    /**
     * 数字保单id
     */
    private Long digitalId;

    /**
     * 用户id
     */
    private String userId;

    /**
     * 封面文案
     */
    private String phoneNumber;
    /**
     * 保单ID
     */
    private Long policyId;
    /**
     * 星球id
     */
    private Long starId;

    /**
     * 保单产品名称
     */
    private String productName;

    /**
     * 序号id 按照产品给出的规则生成
     */
    private String sequence;

    /**
     * 链上hash地址
     */
    private String chainAddr;

    /**
     * 对应oss上的文件ID
     */
    private String fileId;

    /**
     * 链上的图片的url
     */
    private String pictureUrl;

    /**
     * 该数字保单上的富媒体文字
     */
    private String mediaContent;

    /**
     * 该数字保单上的富媒体图片的文件id 多张的时候 逗号分割存储
     */
    private String mediaImage;

    /**
     * 0禁用 1启用
     */
    private Integer status;

    /**
     * 推荐时间
     */
    private Date recommendTime;

    /**
     * 0不推荐 1推荐
     */
    private Integer recommendFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    /**
     * 0都可见 1仅自己可见
     */
    private Integer selfFlag;

    /**
     * 星球昵称(持有者)
     */
    private String nickName;

    /**
     * 链上图片url
     */
    private String starPictureUrl;

    /**
     * oss服务fileId
     */
    private String starFileId;

    /**
     * 星球唯一序号(根据产品规则生成)
     */
    private String starSequence;

    /**
     * 数字保单数量
     */
    private Integer digitalNum;

}
