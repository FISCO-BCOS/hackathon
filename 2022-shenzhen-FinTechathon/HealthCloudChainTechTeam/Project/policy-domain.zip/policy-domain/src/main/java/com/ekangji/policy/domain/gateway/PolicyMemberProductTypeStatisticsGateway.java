package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyMemberProductTypeStatistics;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public interface PolicyMemberProductTypeStatisticsGateway extends CommonGateway<PolicyMemberProductTypeStatistics> {

    List<PolicyMemberProductTypeStatistics> findMemberProductTopTypeInfo(PolicyMemberProductTypeStatistics pmpts);

    List<PolicyMemberProductTypeStatistics> findMemberProductTypeInfo(PolicyMemberProductTypeStatistics pmpts);

    int updateTotalAmountPrimary(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics);

    int updateTotalAmountAddition(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics);
}
