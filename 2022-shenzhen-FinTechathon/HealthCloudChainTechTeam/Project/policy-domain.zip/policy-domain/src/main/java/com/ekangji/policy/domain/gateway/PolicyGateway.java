package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface PolicyGateway extends CommonGateway<Policy> {
    /**
     * 通过被保人id查询保单对象
     * @return
     */
    Policy selectEntityByInsurantId(Long memberId);

    /**
     * 通过投保人id查询保单对象
     * @return
     */
    Policy selectEntityByPolicyHolderId(Long memberId);


    /**
     * 保单查询列表
     * @param dto
     * @return
     */
    PageInfo<Policy> page(PolicyQueryDTO dto);

    /**
     * 通过年龄段和产品类别查询保单（不包含备份保单）
     * @param policy
     * @return
     */
    List<Policy> queryPolicyByAgeBracketAndProdType(Policy policy);

    /**
     * 通过用户ID和被保人ID获取保险信息
     * @param policy
     * @return
     */
    List<Policy> queryPolicyByUserIdAndMemberId(Policy policy);

    /**
     * 查询公司id为空的记录
     * @return
     */
    List<Policy> listCompanyIdEmpty();

    /**
     * 查询产品id为空的记录
     * @return
     */
    List<Policy> listProductIdEmpty();

    /**
     * 通过被保人ID获取保单信息
     * @param policyInsurant
     * @return
     */
    List<Policy> listPolicyByInsurantId(PolicyInsurant policyInsurant);

    /**
     * 根据保单id查用户id
     * @param policyId
     * @return
     */
    String getUserIdByPolicyId(Long policyId);

    List<Policy> queryList(PolicyQueryDTO dto) ;


    /**
     * 批量获取保单列表
     * @return
     */
    List<Policy> selectListByPolicyIds(Long[] policyIds);

    /**
     * 删除保单关联的数据
     * @param policyId
     * @return
     */
    int deletePolicyLinkedData(Long policyId);

    /**
     * 更新保单
     * @param policy
     * @return
     */
    int updateByPolicyId(Policy policy);
}
