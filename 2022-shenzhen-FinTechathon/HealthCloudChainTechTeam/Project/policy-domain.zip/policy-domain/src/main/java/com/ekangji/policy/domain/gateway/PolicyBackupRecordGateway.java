package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyBackupRecord;
import org.springframework.stereotype.Component;

@Component
public interface PolicyBackupRecordGateway extends CommonGateway<PolicyBackupRecord> {
}
