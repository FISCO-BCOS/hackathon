package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyBeneficiary;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface PolicyBeneficiaryGateway extends CommonGateway<PolicyBeneficiary> {

    /**
     * 批量添加保单受益人
     * @param beneficiaryList
     */
    int batchAdd(List<PolicyBeneficiary> beneficiaryList);

    /**
     * 通过受益人id查询保单对象
     * @return
     */
    PolicyBeneficiary selectEntityByMemberId(Long memberId);

}
