package com.ekangji.policy.domain.starchain;

import com.ekangji.policy.common.page.Page;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   xintao.li
 * @date   2022-07-11 14:54:28
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class StarChain extends Page implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long id;

    /**
     * 星链ID
     */
    private Long starChainId;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 星链长度
     */
    private Integer length;

    /**
     * 星链名称
     */
    private String name;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

}