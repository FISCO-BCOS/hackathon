package com.ekangji.policy.domain.insurance;

import com.ekangji.policy.common.page.Page;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author liuchen
 * @date   2022-2-10 17:24:50
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProduct extends Page implements Serializable {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * 产品id
     */
    private String productId;

    /**
     * 产品ids
     */
    private List<String> productIds;

    /**
     * 公司id
     */
    private String companyId;

    /**
     * 公司名字
     */
    private String companyName;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 一级产品类别
     */
    private String oneLevelType;

    /**
     * 二级产品类别
     */
    private String twoLevelType;

    /**
     * 三级产品类别
     */
    private String threeLevelType;

    /**
     * 四级产品类别
     */
    private String fourLevelType;

    /**
     * 设计类型 ProdDesiCode_00 传统型产品 ProdDesiCode_01 新型产品
     */
    private String designType;

    /**
     * 产品特殊属性 00 航空意外险 01 学生平安险 02 女性专属产品 03 少儿专属产品 04 老年专属产品
     */
    private String productSpecial;

    /**
     * 保期类型 00 短期（一年及一年以下）01 长期（超过一年或含有保证续保条款）
     */
    private String timeType;

    /**
     * 条款编码
     */
    private String clauseCode;

    /**
     * 条款文件名
     */
    private String clauseFileName;

    /**
     * 条款文件
     */
    private String clauseFileId;

    /**
     * 承保方式 00 团队 01 个人
     */
    private String insuranceStyle;

    /**
     * 交费方式 00 一次性缴费 01 分起交费 02 分期交费一次性交费兼有 03灵活交费
     */
    private String payWay;

    /**
     * 交费方式 00 一次性缴费 01 分起交费 02 分期交费一次性交费兼有 03灵活交费
     */
    private List<String> payWays;

    /**
     * 停售日期
     */
    private Date stopDate;

    /**
     * 01 在售 02 停售 03 停用
     */
    private String saleStatus;

    /**
     * 是否拆解 0 否 1是
     */
    private Integer isDismantle;

    /**
     * 删除标志（1 代表存在 0 代表删除）
     */
    private Integer delFlag;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否有效 （0：无效 ，1：有效）
     */
    private Integer status;

    /**
     * 是否和条款关联 （0：未关联 ，1：已关联）
     */
    private Integer associated;

    /**
     * 模板ID
     */
    private String templateId;

}