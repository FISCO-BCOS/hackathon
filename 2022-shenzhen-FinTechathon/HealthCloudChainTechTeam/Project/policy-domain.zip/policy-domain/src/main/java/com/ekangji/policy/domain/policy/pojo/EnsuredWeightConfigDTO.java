package com.ekangji.policy.domain.policy.pojo;

import com.ekangji.policy.common.page.PageParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnsuredWeightConfigDTO extends PageParam implements Serializable {


    /**
     * id
     */
    private Long id;

    /**
     * '一级产品类别名称'
     */
    private String firstLevelName;
    /**
     * '一级类别对应的小程序名字'
     */
    private String programName;

    /**
     * '0-18岁权重值'
     */
    private BigDecimal firstStage;
    /**
     * '18-25岁权重值'
     */
    private BigDecimal secondStage;
    /**
     * '25-35岁权重值'
     */
    private BigDecimal thirdStage;
    /**
     * '35-50岁权重值'
     */
    private BigDecimal fourthStage;
    /**
     * ''50岁以上权重值''
     */
    private BigDecimal fifthStage;

    /**
     * 状态 0无效 1有效
     */
    private Integer status;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;


}
