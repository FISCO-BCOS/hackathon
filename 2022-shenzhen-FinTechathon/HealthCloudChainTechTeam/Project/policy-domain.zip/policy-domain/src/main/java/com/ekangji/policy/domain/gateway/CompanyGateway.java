package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.insurance.InsuranceCompany;
import org.springframework.stereotype.Component;

/**
 * 保险公司网关
 *
 * @author 李鑫涛
 * @date 2022/2/11 11:11
 */
@Component
public interface CompanyGateway extends CommonGateway<InsuranceCompany> {

}
