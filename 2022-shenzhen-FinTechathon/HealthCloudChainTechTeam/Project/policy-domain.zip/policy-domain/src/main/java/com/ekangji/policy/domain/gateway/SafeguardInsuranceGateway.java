package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.SafeguardInsurance;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import org.springframework.stereotype.Component;

/**
 * 网关
 *
 * @author xintao.li
 * @date 2021/11/27 11:11
 */
@Component
public interface SafeguardInsuranceGateway extends CommonGateway<SafeguardInsurance> {



}
