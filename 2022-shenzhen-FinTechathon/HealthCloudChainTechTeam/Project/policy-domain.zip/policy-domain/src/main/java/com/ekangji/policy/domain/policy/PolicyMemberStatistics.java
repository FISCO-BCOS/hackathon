package com.ekangji.policy.domain.policy;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * @Author: liuchen
 * @Date: 2022/05/23 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyMemberStatistics implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 所属用户ID
     */
    private String userId;

    /**
     * 家庭成员ID
     */
    private Long memberId;

    /**
     * 保单总数
     */
    private Integer policyNum;

    /**
     * 有效保单数
     */
    private Integer effectivePolicyNum;

    /**
     * 今年保费
     */
    private BigDecimal premium;

    /**
     * 状态（1:有效,0:无效）
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 家庭总保单数（包含未在保障中的）
     */
    private Integer policyNumTotal;

    /**
     * 今年总保费(返回使用)
     */
    private BigDecimal premiumTotal;
}
