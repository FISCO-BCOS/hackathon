package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public interface PolicyBackupMessageGateway extends CommonGateway<PolicyBackupMessage> {

    /**
     * 获取用户待接收保单统计信息
     * @param param
     * @return
     */
    PolicyBackupMessage countToReceivePolicy(PolicyBackupMessage param);

    /**
     * 获取用户待接收保单信息
     * @param param
     * @return
     */
    List<PolicyBackupMessage> selectToReceivePolicy(PolicyBackupMessage param);

    /**
     * 保存用户发起备份保单消息
     * @param backupList
     * @return
     */
    int batchSave(List<PolicyBackupMessage> backupList);
}
