package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface PolicyMemberStatisticsGateway extends CommonGateway<PolicyMemberStatistics> {

    /**
     * 获取家庭保单总计信息
     * @param pms
     * @return
     */
    PolicyMemberStatistics findFamilyReportTotalInfo(PolicyMemberStatistics pms);

    /**
     * 获取家庭成员(被保人)统计计信息
     * @param pms
     * @return
     */
    List<PolicyMemberStatistics> findFamilyMemberTotalInfo(PolicyMemberStatistics pms);

    /**
     * 根据当前用户和家庭成员获取成员保单统计
     * @param pms
     * @return
     */
    PolicyMemberStatistics findByUserIdAndMemberId(PolicyMemberStatistics pms);
}
