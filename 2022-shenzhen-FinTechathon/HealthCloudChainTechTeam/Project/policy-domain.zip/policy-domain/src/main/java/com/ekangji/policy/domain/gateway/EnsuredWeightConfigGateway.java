package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface EnsuredWeightConfigGateway extends CommonGateway<EnsuredWeightConfig> {
    /**
     * 保障分权重配置分页页查询
     * @param ensuredWeightConfig
     * @return
     */
    PageInfo<EnsuredWeightConfig> pageList(EnsuredWeightConfig ensuredWeightConfig);

    /**
     * 通过产品类别查询对象
     * @return
     */
    EnsuredWeightConfig selectEntityByLevelType(String programName);
    /**
     * 批量更新权重
     * @return
     */
    int batchUpdate(List<EnsuredWeightConfig> list);

    /**
     * 批量新增
     * @return
     */
    int batchInsert(List<EnsuredWeightConfig> list);
    /**
     * 批量删除
     * @return
     */
    int batchDelete();
    /**
     * 获取所有配置
     * @return
     */
    List<EnsuredWeightConfig> selectWeightList();
}
