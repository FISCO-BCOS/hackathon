package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.domain.policy.UserInviteInfo;
import com.ekangji.policy.domain.policy.pojo.DigitalPolicyDTO;
import com.ekangji.policy.domain.starchain.StarChain;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserInviteInfoGateway extends CommonGateway<UserInviteInfo> {

    /**
     * 通过邀请人ID查询用户邀请信息列表
     * @return
     */
    List<UserInviteInfo> selectListByInviterId(String inviterUserId);
    /**
     * 通过被邀请人ID查询用户邀请信息列表
     * @return
     */
    List<UserInviteInfo> selectListByInviteeId(String inviteeUserId);
}
