package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface MemberEnsuredInfoGateway extends CommonGateway<MemberEnsuredInfo> {
    /**
     * 保障分查询分页
     * @param memberEnsuredInfo
     * @return
     */
    PageInfo<MemberEnsuredInfo> pageList(MemberEnsuredInfo memberEnsuredInfo);
    /**
     * 通过用户ID查询家庭保障分对象
     * @return
     */
    MemberEnsuredInfo selectEntityByMemberId(Long memberId);
    /**
     * 通过用户ID查询家庭保障分对象
     * @return
     */
   List<MemberEnsuredInfo> selectEntityByStatus(Integer status,Integer delFlag);
    /**
     * 批量获取家庭成员保障分列表
     * @return
     */
    List<MemberEnsuredInfo> selectListByMemberIds(Long[] memberIds);

    /**
     * 保障分查询列表
     * @param dto
     * @return
     */
    PageInfo<MemberEnsuredInfo> page(MemberEnsuredDTO dto);

    List<MemberEnsuredInfo> query(MemberEnsuredDTO dto);
}
