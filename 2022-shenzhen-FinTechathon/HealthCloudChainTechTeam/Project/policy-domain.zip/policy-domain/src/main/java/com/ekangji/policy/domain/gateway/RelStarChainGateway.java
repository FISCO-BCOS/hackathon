package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.domain.starchain.StarChain;
import org.springframework.stereotype.Component;

/**
 * 网关
 *
 * @author zhangjun
 * @date 2021/11/27 11:11
 */
@Component
public interface RelStarChainGateway extends CommonGateway<RelStarChain> {



}
