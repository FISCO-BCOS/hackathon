package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserFamilyInfoGateway extends CommonGateway<UserFamilyInfo> {
    /**
     * 通过成员ID查询用户家庭对象
     * @return
     */
    UserFamilyInfo selectEntityByMemberId(Long memberId);
    /**
     * 通过用户ID查询用户家庭对象列表
     * @return
     */
    List<UserFamilyInfo> selectListByUserId(String userId);
    /**
     * 通过用户id和昵称查询用户家庭对象
     * @return
     */
    UserFamilyInfo selectEntityByUserIdAndName(String userId,String nickName);
    /**
     * 通过用户id和关系查询用户家庭对象
     * @return
     */
    UserFamilyInfo selectEntityByUserIdAndRelation(String userId,Integer relation);
    /**
     * 通过用户id和证件信息查询用户家庭对象
     * @return
     */
    UserFamilyInfo selectEntityByCard(String userId, Integer identityCardType,String identityCardNumber);
}
