package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.PageParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/05/18 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Policy  extends PageParam implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 保单ID 雪花算法生产
     */
    private Long policyId;

    /**
     * 所属平台(0:微信，1:抖音小程序)
     */
    private Integer platform;

    /**
     * 来源类型(1:OCR 2:快速录入 3:邮箱识别 4:备份)
     */
    private Integer sourceType;

    /**
     * 用户手机号
     */
    private String phoneNumber;
    /**
     * 所属用户
     */
    private String userId;

    /**
     * 所属用户手机号
     */
    private String userPhone;

    /**
     * 保单号
     */
    private String policyNumber;

    /**
     * 保司ID
     */
    private String companyId;

    /**
     * 保司名称
     */
    private String companyName;

    /**
     * 保司简称
     */
    private String companyNameShort;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 产品类型编号
     */
    private String productType;

    /**
     * 产品类型四级编号
     */
    private String productFourType;

    /**
     * 产品类型三级编号
     */
    private String productThreeType;

    /**
     * 产品类型二级编号
     */
    private String productTwoType;

    /**
     * 产品一级类型编号
     */
    private String productTopType;

    /**
     * 投保人ID
     */
    private Long policyHolderId;

    /**
     * 受益人类型(1:法定收益人,2:指定收益人)
     */
    private Integer beneficiaryType;

    /**
     * 保单生效日期
     */
    private Date effectiveDate;

    /**
     * 保障期限
     */
    private Integer guaranteePeriod;

    /**
     * 保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)
     */
    private Integer guaranteePeriodUnit;

    /**
     * 保障结束日期
     */
    private Date guaranteeEndDate;

    /**
     * 缴费周期(1:月缴,2:半年缴,3:年缴,4:一次性交清)
     */
    private Integer payCycle;

    /**
     * 缴费期间
     */
    private Integer payPeriod;

    /**
     * 缴费期间单位(1:月缴 2:半年缴 3:年缴 4:至**岁)
     */
    private Integer payPeriodUnit;

    /**
     * 单次保费
     */
    private BigDecimal singlePremium;

    /**
     * 总保费
     */
    private BigDecimal totalPremium;

    /**
     * 保额(单位:元)
     */
    private BigDecimal insuredAmount;

    /**
     * 缴费卡号
     */
    private String payCardNumber;

    /**
     * 开户行
     */
    private String bankName;

    /**
     * 经办人
     */
    private String handler;

    /**
     * 经办人手机号
     */
    private String handlerPhone;

    /**
     * 备注
     */
    private String remark;

    /**
     * 所属渠道平台
     */
    private Integer channelType;
    /**
     * 状态（1:保障中,0:未在保障中）
     */
    private Integer status;

    /**
     * 状态（1:保障中,0:未在保障中）
     */
    private Integer policyStatus;
    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 被保人出生日期-起
     */
    private Date insurantBirthdayBegin;

    /**
     * 被保人出生日期-止
     */
    private Date insurantBirthdayEnd;

    /**
     * 被保险人
     */
    private List<PolicyInsurant> insurant;

    /**
     * 家庭成员id
     */
    private Long memberId;

    /**
     * 保单ID数组
     */
    private List<Long> policyIds;

    /**
     * 被保人id
     */
    private Long insurantId;
    /**
     * 受益人id列表 逗号分割
     */
    private String beneficiaryIds;

    /**
     * 被保险人生日yyyy-MM-dd
     */
    private Date birthDay;
}
