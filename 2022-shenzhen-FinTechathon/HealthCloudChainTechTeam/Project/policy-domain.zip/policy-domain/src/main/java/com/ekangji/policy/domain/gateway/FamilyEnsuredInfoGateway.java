package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

@Component
public interface FamilyEnsuredInfoGateway extends CommonGateway<FamilyEnsuredInfo> {
    /**
     * 家庭保障分查询分页
     * @param familyEnsuredInfo
     * @return
     */
    PageInfo<FamilyEnsuredInfo> pageList(FamilyEnsuredInfo familyEnsuredInfo);

    /**
     * 通过用户ID查询家庭保障分对象
     * @return
     */
    FamilyEnsuredInfo selectFamilyByUserId(String userId);
}
