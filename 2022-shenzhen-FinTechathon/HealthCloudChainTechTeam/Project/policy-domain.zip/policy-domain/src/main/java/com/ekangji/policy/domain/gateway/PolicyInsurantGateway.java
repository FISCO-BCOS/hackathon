package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface PolicyInsurantGateway extends CommonGateway<PolicyInsurant> {

    /**
     * 批量添加保单被保人
     * @param piList
     */
    int batchAdd(List<PolicyInsurant> piList);

    /**
     * 根据年龄段计算被保人数量
     * @param ageBracket
     * @return
     */
    long countByAgeBracket(int ageBracket);

    /**
     * 根据保单删除被保人
     * @param insurant
     * @return
     */
    int deleteByPolicy(PolicyInsurant insurant);

    /**
     * 获取主险被保人
     * @param insurant
     * @return
     */
    List<PolicyInsurant> findByPolicy(PolicyInsurant insurant);

    /**
     * 获取主险被保人
     * @param insurant
     * @return
     */
    List<PolicyInsurant> findByInsurantId(PolicyInsurant insurant);
}
