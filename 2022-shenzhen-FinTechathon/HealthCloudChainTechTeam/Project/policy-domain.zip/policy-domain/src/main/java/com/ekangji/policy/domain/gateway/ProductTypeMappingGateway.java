package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 网关
 *
 * @author xintao.li
 * @date 2021/11/27 11:11
 */
@Component
public interface ProductTypeMappingGateway extends CommonGateway<ProductTypeMapping> {


    List<ProductTypeMapping> listOneLevel();

}
