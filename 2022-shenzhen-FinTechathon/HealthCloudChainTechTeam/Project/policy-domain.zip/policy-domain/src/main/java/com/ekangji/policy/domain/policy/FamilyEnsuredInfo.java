package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.PageParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FamilyEnsuredInfo extends PageParam implements Serializable {


    /**
     * id
     */
    private Long id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * '健康险保障分'
     */
    private Integer healthScore;

    /**
     * '人寿险保障分'
     */
    private Integer lifeInsuranceScore;

    /**
     * ''意外险保障分''
     */
    private Integer unexpectedScore;

    /**
     * ''年金险保障分''
     */
    private Integer renteScore;

    /**
     * ''社保保障分''
     */
    private Integer socialSecurityScore;

    /**
     * '家庭保障总得分'
     */
    private Integer familyTotalScore;


    /**
     * 状态 0无效 1有效
     */
    private Integer status;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;


}
