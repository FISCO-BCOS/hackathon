package com.ekangji.policy.domain.policy;

import com.alibaba.excel.annotation.ExcelProperty;
import com.ekangji.policy.common.page.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberEnsuredInfo  extends PageParam implements Serializable {


    /**
     * id
     */
    private Long id;

    /**
     * 成员ID
     */
    private Long memberId;

    /**
     * '健康险保障分'
     */
    private Integer healthScore;

    /**
     * '人寿险保障分'
     */
    private Integer lifeInsuranceScore;

    /**
     * ''意外险保障分''
     */
    private Integer unexpectedScore;

    /**
     * ''年金险保障分''
     */
    private Integer renteScore;

    /**
     * ''社保保障分''
     */
    private Integer socialSecurityScore;

    /**
     * '个人保障总得分'
     */
    private Integer personalTotalScore;


    /**
     * 状态 0无效 1有效
     */
    private Integer status;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    private String memberName;

    private Integer channelType;

    private String userId;

    private String userPhoneNumber;

    private Integer familyScore;

    private Integer relation;

    private Integer policyNum;

    private Date memberCreateTime;

    private Integer memberScore;

    private String channelName;

    private String userNickName;

}
