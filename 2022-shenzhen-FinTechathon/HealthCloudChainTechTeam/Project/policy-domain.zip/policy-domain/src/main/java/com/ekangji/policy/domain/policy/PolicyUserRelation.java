package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: liuchen
 * @Date: 2022/05/16 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyUserRelation implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long relationId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 保单所属用户ID
     */
    private String userId;

    /**
     * 保单所属用户手机号
     */
    private String userPhone;

    /**
     * 投保人ID
     */
    private Long policyHolderId;

    /**
     * 被保人ID
     */
    private Long insurantId;

    /**
     * 来源类型1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    private Integer sourceType;

    /**
     * 发起备份用户ID
     */
    private String backupUserId;

    /**
     * 发起备份用户手机号
     */
    private String backupUserPhone;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
}
