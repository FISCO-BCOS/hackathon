package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface PolicyAdditionalGateway extends CommonGateway<PolicyAdditional> {

    /**
     * 批量添加附加险
     * @param additionalList
     * @return
     */
    int batchAdd(List<PolicyAdditional> additionalList);

    /**
     * 根据保单ID逻辑删除附加险
     * @param policyAdditional
     * @return
     */
    int logicDeleteByPolicyId(PolicyAdditional policyAdditional);

    /**
     * 获取保单附加险
     * @param policyAdditional
     * @return
     */
    List<PolicyAdditional> listByPolicy(PolicyAdditional policyAdditional);

    /**
     * 通过年龄段和产品类别查询保单（不包含备份保单）
     * @param policyAdditional
     * @return
     */
    List<PolicyAdditional> queryAddPolicyByAgeBracketAndProdType(PolicyAdditional policyAdditional);

    /**
     * 查询产品id为空的记录
     * @return
     */
    List<PolicyAdditional> listProductIdEmpty();

    /**
     * 通过被保人ID获取保单信息
     * @param policyInsurant
     * @return
     */
    List<PolicyAdditional> listPolicyByInsurantId(PolicyInsurant policyInsurant);


    /**
     * 批量获取保单附加险列表
     * @return
     */
    List<PolicyAdditional> selectListByPolicyIds(Long[] policyIds);
}
