package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyPayDetail;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
public interface PolicyPayDetailGateway extends CommonGateway<PolicyPayDetail> {

    /**
     * 批量保存缴费标签
     * @param policyPayDetail
     * @return
     */
    int batchSave(List<PolicyPayDetail> policyPayDetail);

    /**
     * 删除附加险缴费标签
     * @param payDetail
     * @return
     */
    int deleteByPolicyAdditional(PolicyPayDetail payDetail);

    /**
     * 查询保单当年保费
     * @param policyPayDetail
     * @return
     */
    PolicyPayDetail findCurrentYearPremiumByPolicy(PolicyPayDetail policyPayDetail);

    /**
     * 查询保单总保费
     * @param policyPayDetail
     * @return
     */
    PolicyPayDetail findTotalPremiumByPolicy(PolicyPayDetail policyPayDetail);

    /**
     * 获取主险缴费标签
     * @param policyPayDetail
     */
    List<PolicyPayDetail> listByPolicy(PolicyPayDetail policyPayDetail);

    /**
     * 更新标签缴费状态
     * @param policyPayDetail
     */
    int updateLabelStatus(PolicyPayDetail policyPayDetail);
}
