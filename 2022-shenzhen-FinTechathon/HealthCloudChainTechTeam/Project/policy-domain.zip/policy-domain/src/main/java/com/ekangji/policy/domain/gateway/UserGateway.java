package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.user.User;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

/**
 * 网关
 *
 * @author zhangjun
 * @date 2021/11/27 11:11
 */
@Component
public interface UserGateway extends CommonGateway<User> {

    /**
     * 根据用户ID查询
     * @param userId
     * @return
     */
    User getByUserId(String userId);

    /**
     * 查一个用户
     * @param user
     * @return
     */
    User getOne(User user);

    /**
     *
     * @param userId
     * @return
     */
    String getUserName(String userId);

    /**
     * 分页：没有管理员
     * @param user
     * @return
     */
    PageInfo<User> pageNoAdmin(User user);

    /**
     * 修改密码
     * @param user
     * @return
     */
    int updatePwd(User user);

}
