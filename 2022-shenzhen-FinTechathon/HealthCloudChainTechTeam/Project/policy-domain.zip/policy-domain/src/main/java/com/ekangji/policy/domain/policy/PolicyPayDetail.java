package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/05/23 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyPayDetail implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long payLabelId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 附加险ID
     */
    private Long additionalId;

    /**
     * 缴费标签
     */
    private String payLabel;

    /**
     * 单次保费
     */
    private BigDecimal singlePremium;

    /**
     * 缴费日期
     */
    private Date payDate;

    /**
     * 缴费状态(1:已缴费，0:未缴费)
     */
    private Integer status;

    /**
     * 删除标志(1:正常,0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 今年保费或总保费
     */
    private BigDecimal premium;

    /**
     * 保单id集合
     */
    private List<Long> policyIdList;
}
