package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyAttchment;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface PolicyAttchmentGateway extends CommonGateway<PolicyAttchment> {

    int batchSave(List<PolicyAttchment> attchmentList);

    int deleteByPolicy(PolicyAttchment build);
}
