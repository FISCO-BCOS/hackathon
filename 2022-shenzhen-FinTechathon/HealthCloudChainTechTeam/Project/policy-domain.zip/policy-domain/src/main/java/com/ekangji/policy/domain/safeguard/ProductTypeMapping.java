package com.ekangji.policy.domain.safeguard;

import com.ekangji.policy.common.page.Page;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author   xintao.li
 * @date   2022-05-16 14:46:44
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
public class ProductTypeMapping extends Page implements Serializable {
    /**
     * 自增id
     */
    private Long id;

    /**
     * 产品类型匹配id
     */
    private String mappingId;

    /**
     * 产品类型编码
     */
    private String code;

    /**
     * 产品类型名称
     */
    private String name;

    /**
     * 父产品类别编码
     */
    private String parentCode;

    /**
     * 产品库对应的产品类别编码
     */
    private String mappingCode;

    /**
     * 产品库对应的产品类别名称 
     */
    private String mappingName;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 状态  0：无效 1:有效
     */
    private Integer status;

    /**
     * 逻辑删除 0：已删除 1：未删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 产品类型编码数组 查询用
     */
    private List<String> codeList;

    private static final long serialVersionUID = 1L;

}