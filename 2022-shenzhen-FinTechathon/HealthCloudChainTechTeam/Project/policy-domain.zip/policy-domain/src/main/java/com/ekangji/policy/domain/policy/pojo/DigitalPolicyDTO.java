package com.ekangji.policy.domain.policy.pojo;

import com.ekangji.policy.common.page.PageParam;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalPolicyDTO extends PageParam implements Serializable {

    /**
     * 数字保单产品名称
     */
    private String productName;

    /**
     *数字保单创建时间开始时间
     */
    private Date digitalPolicyCreateTimeStart;

    /**
     *数字保单创建时间结束时间
     */

    private Date digitalPolicyCreateTimeEnd;

    /**
     * 是否推荐
     */
    private Integer recommendFlag;
    /**
     * 用户id
     */
    private String userId;


    /**
     * 用户手机号
     */
    private String phoneNumber;

}
