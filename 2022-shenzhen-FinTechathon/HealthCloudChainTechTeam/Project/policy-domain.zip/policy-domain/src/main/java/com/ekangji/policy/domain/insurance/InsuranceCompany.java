package com.ekangji.policy.domain.insurance;

import com.ekangji.policy.common.page.Page;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 李鑫涛
 * @date 2/10/22 4:58 PM
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceCompany extends Page implements Serializable {

    /**
     *
     */
    private Long id;

    /**
     * 公司id
     */
    private String companyId;

    /**
     * 公司名称
     */
    private String companyName;

    /**
     * 公司简称
     */
    private String companyNameShort;

    /**
     * 公司英文名
     */
    private String companyNameEn;

    /**
     * 图标
     */
    private String fileId;

    /**
     * 公司类型
     */
    private String companyType;

    /**
     * 省
     */
    private String provinceCode;

    /**
     * 市
     */
    private String cityCode;

    /**
     * 客服电话
     */
    private String phone;

    /**
     * 删除标志（1 代表存在 0 代表删除）
     */
    private Integer delFlag;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否有效（1：有效，0：无效）
     */
    private Integer status;
}
