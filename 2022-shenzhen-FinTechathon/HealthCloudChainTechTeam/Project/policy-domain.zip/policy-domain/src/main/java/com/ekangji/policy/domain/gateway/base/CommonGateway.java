package com.ekangji.policy.domain.gateway.base;

import com.github.pagehelper.PageInfo;

import java.util.List;

/**
 * 基础资源网关
 *
 * @author zhangjun
 * @date 2021/11/27 11:15
 */
public interface CommonGateway<T> {

    /**
     * 保存
     *
     * @param t
     * @return 返回自增ID
     */
    Long save(T t);

    /**
     * 删除
     *
     * @param t
     * @return
     */
    int delete(T t);

    /**
     * 更新
     *
     * @param t
     * @return
     */
    int update(T t);

    /**
     * 查询单个
     *
     * @param t
     * @return
     */
    T get(T t);

    /**
     * 查询集合
     *
     * @param t
     * @return
     */
    List<T> list(T t);

    /**
     * 分页查询
     *
     * @param t
     * @return
     */
    PageInfo<T> page(T t);

}
