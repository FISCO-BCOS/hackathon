package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicyUserRelation;
import org.springframework.stereotype.Component;

@Component
public interface PolicyUserRelationGateway extends CommonGateway<PolicyUserRelation> {

    PolicyUserRelation selectByUserIdAndPolicyId(PolicyUserRelation userRelation);
}
