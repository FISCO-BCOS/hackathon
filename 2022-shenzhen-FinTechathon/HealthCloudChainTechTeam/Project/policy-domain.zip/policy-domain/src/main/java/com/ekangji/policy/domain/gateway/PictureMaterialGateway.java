package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PictureMaterial;
import org.springframework.stereotype.Component;

@Component
public interface PictureMaterialGateway extends CommonGateway<PictureMaterial> {
     int updateById(PictureMaterial pictureMaterial) ;
}
