package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface EnsuredReadConfigGateway extends CommonGateway<EnsuredReadConfig> {


    /**
     * 通过家庭保障分查询相关配置
     * @return
     */
    EnsuredReadConfig selectConfigByScore(Integer score);


    /**
     * 获取所有配置
     * @return
     */
    List<EnsuredReadConfig> selectReadList();

    /**
     * 批量更新解读
     * @return
     */
    int batchUpdate(List<EnsuredReadConfig> list);
    /**
     * 批量删除
     * @return
     */
    int batchDelete();

    /**
     * 批量新增
     * @return
     */
    int batchInsert(List<EnsuredReadConfig> list);

}
