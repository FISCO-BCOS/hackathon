package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/06/01 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyInsurant implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 附加险ID
     */
    private Long additionalId;

    /**
     * 被保人id
     */
    private Long insurantId;

    /**
     * 被保人出生日期
     */
    private Date insurantBirthday;

    /**
     * 保险类别(1:主险,0:附加险)
     */
    private Integer insuranceType;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 保单ID数组 查询用
     */
    private List<Long> policyIds;
    /**
     * 被保人ID数组 查询用
     */
    private List<Long> insurantIds;
}
