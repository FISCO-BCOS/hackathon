package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.common.page.PageParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserInviteInfo  extends Page implements Serializable {


    /**
     * id
     */
    private Long id;

    /**
     * 邀请ID
     */
    private Long inviteId;

    /**
     * 邀请人用户id
     */
    private String inviterUserId;
    /**
     * 被邀请人用户id
     */
    private String inviteeUserId;

    /**
     * 生成数字保单状态 0未生成 1已生成
     */
    private Integer policyStatus;

    /**
     * 0禁用 1启用
     */
    private Integer status;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;




}
