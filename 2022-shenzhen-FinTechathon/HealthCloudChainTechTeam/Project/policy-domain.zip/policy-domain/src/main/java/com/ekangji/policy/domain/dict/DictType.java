package com.ekangji.policy.domain.dict;

import com.ekangji.policy.common.page.Page;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   zhangjun
 * @date   2021-12-01 10:35:47
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DictType extends Page implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 字典主键
     */
    private Long dictId;

    /**
     * 字典名称
     */
    private String dictName;

    /**
     * 字典类型
     */
    private String dictType;

    /**
     * 状态（1正常 0停用）
     */
    private Integer status;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 备注
     */
    private String remark;
}