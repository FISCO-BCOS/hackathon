package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: liuchen
 * @Date: 2022/05/25 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyMemberProductTypeStatistics implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 所属用户ID
     */
    private String userId;

    /**
     * 成员ID
     */
    private Long memberId;

    /**
     * 产品一级类别（健康险，人寿险，意外险，年金险）
     */
    private String productTopType;

    /**
     * 产品子类别
     */
    private String productType;

    /**
     * 总保额
     */
    private BigDecimal insuredAmountTotal;

    /**
     * 主险保额
     */
    private BigDecimal insuredAmount;

    /**
     * 附加险保额
     */
    private BigDecimal additionalInsuredAmount;

    /**
     * 状态（1:有效,0:无效）
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
}
