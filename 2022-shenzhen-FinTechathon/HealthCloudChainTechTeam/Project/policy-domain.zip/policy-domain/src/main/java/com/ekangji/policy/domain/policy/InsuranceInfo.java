package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.PageParam;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @author   wjx
 * @date   2022-01-17 15:45:46
 */
@Data
public class InsuranceInfo extends PageParam implements Serializable {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 投保单号
     */
    private String quotationNo;

    /**
     * 保费
     */
    private BigDecimal premium;

    /**
     * 保单渠道名称
     */
    private String channelName;

    /**
     * 是否是公域 1 是 0 否
     */
    private Integer isPublic;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 用户性别（0男 1女 2未知）
     */
    private Integer sex;

    /**
     * 被保人身份证号
     */
    private String idNo;

    /**
     * 销售渠道类型 1 保险公司 2 经纪公司 3 代理公司 4 合作公司 5 其他 6 银邮
     */
    private String saleChannelType;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;


    private static final long serialVersionUID = 1L;



}