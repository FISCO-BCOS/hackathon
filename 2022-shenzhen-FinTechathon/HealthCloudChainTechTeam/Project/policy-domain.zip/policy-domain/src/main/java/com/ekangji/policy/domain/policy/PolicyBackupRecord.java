package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/06/01 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBackupRecord implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long backupId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 保单父ID
     */
    private Long parentPolicyId;

    /**
     * 保单所属用户ID
     */
    private String userId;

    /**
     * 保单所属用户手机号
     */
    private String userPhone;

    /**
     * 发起备份用户ID
     */
    private String backupUserId;

    /**
     * 发起备份用户手机号
     */
    private String backupUserPhone;

    /**
     * 状态(1:有效,0:无效)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 保单ID集合 查询用
     */
    private List<Long> policyIds;
}
