package com.ekangji.policy.domain.gateway;


import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.insurance.InsuranceProductDict;

import java.util.List;

/**
 * 网关
 * @author wjx
 * @date 2021/11/28 19:41
 */
public interface InsuranceProductDictGateway extends CommonGateway<InsuranceProductDict> {


    /**
     * 根据ID查询子集
     * @param idList
     * @return
     */
    List<InsuranceProductDict> querySonByIds(List<Long> idList);

    /**
     * 查询产品类型
     * @param insuranceProductDict
     * @return
     */
    List<InsuranceProductDict> queryProductType(InsuranceProductDict insuranceProductDict);
}
