package com.ekangji.policy.domain.user;

import com.ekangji.policy.common.page.Page;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 用户信息领域对象
 *
 * @author zhangjun
 * @date 2021/11/27 11:17
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder(toBuilder=true)
public class User extends Page implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增ID
     */
    private Long id;

    /**
     * 用户ID
     */
    private Long userId;

    /**
     * 部门ID
     */
    private Long deptId;

    /**
     * 登录账号
     */
    private String loginName;

    /**
     * 用户昵称
     */
    private String userName;

    /**
     * 用户邮箱
     */
    private String email;

    /**
     * 手机号码
     */
    private String phone;

    /**
     * 用户性别（0男 1女 2未知）
     */
    private Integer sex;

    /**
     * 头像路径
     */
    private String avatar;

    /**
     * 密码
     */
    private String password;

    /**
     * 盐加密
     */
    private String salt;

    /**
     * 帐号状态（1 正常 0 停用）
     */
    private Integer status;

    /**
     * 删除标志（1 代表存在 0 代表删除）
     */
    private Integer delFlag;

    /**
     * 最后登录IP
     */
    private String loginIp;

    /**
     * 最后登录时间
     */
    private Date loginDate;

    /**
     * 密码最后更新时间
     */
    private Date pwdUpdateDate;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新者
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 用户ID
     */
    private List<Long> userIdList;

    /**
     * 用户ID
     */
    private List<Long> userIdNotInList;

}