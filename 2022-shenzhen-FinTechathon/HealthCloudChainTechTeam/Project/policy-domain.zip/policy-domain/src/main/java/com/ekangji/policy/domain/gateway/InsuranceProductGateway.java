package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.insurance.InsuranceProduct;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * 网关
 *
 * @author 李鑫涛
 * @date 2022/2/15 16:11
 */
@Component
public interface InsuranceProductGateway extends CommonGateway<InsuranceProduct> {

    InsuranceProduct getById(InsuranceProduct product);

    List<InsuranceProduct> queryByIds(InsuranceProduct product);

    int updateDisByIds(List<String> productIds);

    InsuranceProduct getByIdAndName(InsuranceProduct insuranceProduct);

    List<InsuranceProduct> listByCompanyId(InsuranceProduct insuranceProduct);

    InsuranceProduct getByProductId(InsuranceProduct insuranceProduct);
}
