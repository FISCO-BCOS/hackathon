package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.starchain.StarChain;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserStarGateway extends CommonGateway<UserStar> {
    /**
     * 通过星球ID获取星球信息
     * @param ids
     * @return
     */
    List<UserStar> listByIds(List<Long> ids);
}
