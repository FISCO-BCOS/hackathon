package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.PolicySimple;
import org.springframework.stereotype.Component;

@Component
public interface PolicySimpleGateway extends CommonGateway<PolicySimple> {
}
