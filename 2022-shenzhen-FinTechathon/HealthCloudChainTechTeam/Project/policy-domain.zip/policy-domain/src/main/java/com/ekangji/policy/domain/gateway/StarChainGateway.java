package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.starchain.StarChain;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 网关
 *
 * @author xintao.li
 * @date 2021/11/27 11:11
 */
@Component
public interface StarChainGateway extends CommonGateway<StarChain> {


    List<StarChain> listByUserIds(List<String> userIdList);

    void lengthAddOne(StarChain starChain);
}
