package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.InsuranceInfo;
import org.springframework.stereotype.Component;

/**
 * 保险信息资源网关
 *
 * @author wjx
 * @date 2021/1/17 15:58
 */
@Component
public interface InsuranceInfoGateway extends CommonGateway<InsuranceInfo> {


}
