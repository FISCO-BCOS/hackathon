package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PictureMaterial implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long materialId;

    /**
     * 藏品编号
     */
    private String collectionNumber;

    /**
     * 藏品总量
     */
    private Integer totalNum;

    /**
     * 藏品已用量
     */
    private Integer usedNum;

    /**
     * 图片地址ID
     */
    private String fileId;

    /**
     * 图片名称
     */
    private String pictureName;

    /**
     * 素材类型(1:星球图片,2:保单图片)
     */
    private Integer materialType;

    /**
     * 状态(1:启用,0:禁用)
     */
    private Integer status;

    /**
     * 是否启用过，0未启用过，1启用过
     */
    private Integer hasUsed;


    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;
}
