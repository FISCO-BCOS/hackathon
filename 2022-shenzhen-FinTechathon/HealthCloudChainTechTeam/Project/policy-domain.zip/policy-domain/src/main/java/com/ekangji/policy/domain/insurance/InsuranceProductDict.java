package com.ekangji.policy.domain.insurance;

import com.ekangji.policy.common.page.Page;
import lombok.*;

import java.io.Serializable;

/**
 *
 *  @author   李鑫涛
 *  @date   2022-2-10 17:24:50
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class InsuranceProductDict extends Page implements Serializable {
    /**
     * id
     */
    private Long id;

    /**
     * 字典类型
     */
    private String dictType;

    /**
     * 字典值
     */
    private String dictValue;

    /**
     * 字典名
     */
    private String dictName;

    /**
     * 父ID
     */
    private Long parentId;

    /**
     * 排序
     */
    private Integer sort;
}