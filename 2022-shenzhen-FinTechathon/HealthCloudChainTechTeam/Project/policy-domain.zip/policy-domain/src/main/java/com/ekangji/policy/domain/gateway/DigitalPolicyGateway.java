package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.domain.gateway.base.CommonGateway;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.domain.policy.pojo.DigitalPolicyDTO;
import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.ekangji.policy.domain.starchain.StarChain;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface DigitalPolicyGateway extends CommonGateway<DigitalPolicy> {

    /**
     * 数字保单查询列表
     * @param dto
     * @return
     */
    PageInfo<DigitalPolicy> page(DigitalPolicyDTO dto);

    /**
     * 查询推荐保单
     * @param page
     * @return
     */
    PageInfo<DigitalPolicy> pageCommand(Page page);

    /**
     * 统计用户数字保单数量
     * @param userIdList
     * @return
     */
    List<DigitalPolicy> countDigitalNumByUserIds(List<String> userIdList);

    /**
     * 星链内容
     * @param starChain
     * @return
     */
    List<DigitalPolicy> pageChainContent(StarChain starChain);

    DigitalPolicy getByDigitalId(Long digitalId);

    DigitalPolicy getByStarId(Long starId);

    DigitalPolicy getByHash(String chainAddr);
}
