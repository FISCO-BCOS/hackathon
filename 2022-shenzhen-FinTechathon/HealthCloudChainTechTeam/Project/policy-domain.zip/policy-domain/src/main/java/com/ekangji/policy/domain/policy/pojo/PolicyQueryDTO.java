package com.ekangji.policy.domain.policy.pojo;

import com.ekangji.policy.common.page.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyQueryDTO extends PageParam implements Serializable {

    /**
     * 用户手机号
     */
    private String phoneNumber;


    /**
     * 用户id
     */
    private String userId;

    /**
     * 保单id
     */
    private String policyId;

    /**
     * 保险公司
     */
    private String companyName;
    /**
     * 产品名称
     */
    private String productName;
    /**
     * 产品类别
     */
    private String productType;
    /**
     * 所属渠道平台
     */
    private Integer channelType;

    /**
     * 创建方式 1:ocr,2:快速录入,3:邮箱识别,4:备份
     */
    private Integer sourceType;


    /**
     *保单创建时间开始时间
     */
    private Date policyCreateTimeStart;

    /**
     *保单创建时间结束时间
     */
    private Date policyCreateTimeEnd;

    /**
     *保单更新时间开始时间
     */
    private Date policyUpdateTimeStart;

    /**
     *保单更新时间结束时间
     */
    private Date policyUpdateTimeEnd;


    /**
     * 一级类别
     */
    private String oneLevelType;

    /**
     * 二级类别
     */
    private String twoLevelType;

    /**
     * 三级类别
     */
    private String threeLevelType;

    /**
     * 四级类别
     */
    private String fourLevelType;
}
