package com.ekangji.policy.domain.gateway;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.base.CommonGateway;
import org.springframework.stereotype.Component;

/**
 * 网关
 *
 * @author zhangjun
 * @date 2021/11/27 11:11
 */
@Component
public interface DictDataGateway extends CommonGateway<DictData> {



}
