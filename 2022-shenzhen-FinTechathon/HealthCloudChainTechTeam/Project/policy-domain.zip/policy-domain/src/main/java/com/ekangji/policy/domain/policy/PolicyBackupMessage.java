package com.ekangji.policy.domain.policy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/05/16 13:48
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PolicyBackupMessage implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 雪花ID
     */
    private Long messageId;

    /**
     * 保单ID
     */
    private Long policyId;

    /**
     * 发起人ID
     */
    private String launchUserId;

    /**
     * 接收人ID
     */
    private String receiveUserId;

    /**
     * 接收人手机号
     */
    private String receiveUserPhone;

    /**
     * 发起备份时间
     */
    private Date launchTime;

    /**
     * 接收人处理时间
     */
    private Date handleTime;

    /**
     * 状态(0:未处理,1:已接收,2:不接收)
     */
    private Integer status;

    /**
     * 删除标识(1:正常 0:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新人
     */
    private String updateBy;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 发起备份用户手机号
     */
    private String userPhone;

    /**
     * 待接收保单数量
     */
    private Integer policyNum;

    /**
     * 是否是最后一条标识(1:是,0:否)
     */
    private Integer lastFlag;

    /**
     * 保单ID数组
     */
    private List<Long> policyIds;

}
