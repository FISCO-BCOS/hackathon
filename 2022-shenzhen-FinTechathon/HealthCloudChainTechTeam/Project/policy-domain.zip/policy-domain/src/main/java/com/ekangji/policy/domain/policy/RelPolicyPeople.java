package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.Page;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @author   wjx
 * @date   2022-01-17 15:45:46
 */
@Data
@Builder(toBuilder=true)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RelPolicyPeople extends Page implements Serializable {
    /**
     * 自增ID
     */
    private Long id;

    /**
     * 投保单号
     */
    private String quotationNo;

    /**
     * 产品编码 玉惠保 GXYLYHB 惠鹤保 HNHBHHB2022
     */
    private String productCode;

    /**
     * 姓名
     */
    private String name;

    /**
     * 身份证号
     */
    private String idNo;

    /**
     * 年龄
     */
    private Integer age;

    /**
     * 性别（0男 1女 2未知）
     */
    private Integer sex;

    /**
     * 在保单中角色 0 投保人 1 被保人
     */
    private Integer roleFlag;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 最后修改者
     */
    private String updateBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 状态 0 无效 1有效
     */
    private Integer status;

    /**
     * 删除表示 1 存在 0 删除
     */
    private Integer delFlag;

    private static final long serialVersionUID = 1L;

}