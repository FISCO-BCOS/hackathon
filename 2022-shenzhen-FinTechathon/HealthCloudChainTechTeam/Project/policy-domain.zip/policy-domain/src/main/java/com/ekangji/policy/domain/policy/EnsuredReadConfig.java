package com.ekangji.policy.domain.policy;

import com.ekangji.policy.common.page.PageParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EnsuredReadConfig extends PageParam implements Serializable {


    /**
     * id
     */
    private Long id;

    /**
     * 最小保障分
     */
    private Integer minScore;

    /**
     * 最大保障分
     */
    private Integer maxScore;

    /**
     * 封面文案
     */
    private String coverTitle;

    /**
     * 解读文案
     */
    private String readContent;

    /**
     * 0无效 1有效
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 删除标识 1正常 0已删除
     */
    private Integer delFlag;

}
