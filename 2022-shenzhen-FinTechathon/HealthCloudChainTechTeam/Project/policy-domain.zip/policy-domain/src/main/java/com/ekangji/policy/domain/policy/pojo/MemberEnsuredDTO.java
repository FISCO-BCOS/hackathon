package com.ekangji.policy.domain.policy.pojo;

import com.ekangji.policy.common.page.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberEnsuredDTO extends PageParam implements Serializable {
    /**
     * 用户手机号
     */
    private String phoneNumber;


    /**
     * 用户id
     */
    private String userId;
    /**
     * 成员id
     */
    private String memberId;

    /**
     * 所属渠道平台
     */
    private Integer channelType;

    /**
     *家庭保障分最小值
     */
    private Integer familyMinScore;

    /**
     *家庭保障分最大值
     */
    private Integer familyMaxScore;

    /**
     *成员保障分最小值
     */
    private Integer memberMinScore;

    /**
     *成员保障分最大值
     */
    private Integer memberMaxScore;


    /**
     *成员创建时间开始时间
     */
    private Date memberCreateTimeStart;

    /**
     *成员创建时间结束时间
     */
    private Date memberCreateTimeEnd;


}
