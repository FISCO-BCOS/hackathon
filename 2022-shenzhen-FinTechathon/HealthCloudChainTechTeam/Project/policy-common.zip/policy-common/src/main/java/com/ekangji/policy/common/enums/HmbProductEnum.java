package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * 惠民保产品信息枚举
 *
 * @author liuchen
 * @date 2022-08-12 16:00
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum HmbProductEnum {

    YHB("GXYLYHB" , "玉惠保",1,3,"1","2000000","2022-07-25 00:00:00","2022-09-09 23:59:59","2022-09-10","2023-09-09",4),
    YHB2("GXYLYHB" , "玉惠保",1,3,"2","2000000","2022-09-16 00:00:00","2022-10-15 23:59:59","2022-10-16","2023-10-15",4);

    private String code;

    private String name;

    private Integer guaranteePeriod;

    private Integer guaranteePeriodUnit;

    private String orderType;

    private String insuredAmount;

    private String insureBeginDate;

    private String insureEndDate;

    private String effectiveDate;

    private String guaranteeEndDate;

    private Integer payCycle;

    public static HmbProductEnum getHmbProductEnumByCode(String code) {
        for (HmbProductEnum entry : HmbProductEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }

    public static HmbProductEnum getHmbProductEnumByCodeAndType(String code, String orderType) {
        for (HmbProductEnum entry : HmbProductEnum.values()) {
            if (Objects.equals(entry.getCode(), code) && Objects.equals(entry.getOrderType(), orderType)) {
                return entry;
            }
        }
        return null;
    }
}
