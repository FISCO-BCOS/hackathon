package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;


@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum BeneficiaryTypeEnum {

    OFFICIAL(1, "法定收益人"),
    APPOINT(2, "指定收益人");

    private Integer code;

    private String msg;

    public static String getMsgByCode(Integer code) {
        for (BeneficiaryTypeEnum entry : BeneficiaryTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
