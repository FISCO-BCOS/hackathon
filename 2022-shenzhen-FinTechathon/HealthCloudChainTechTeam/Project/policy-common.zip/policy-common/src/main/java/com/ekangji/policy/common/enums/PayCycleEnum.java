package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 缴费周期
 *
 * @author liuchen
 * @date 2022-05-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PayCycleEnum {

    MONTHLYPAYMENT(1, "月缴","12"),
    SEMIANNUALPAYMENT(2, "半年缴","2"),
    ANNUALPAYMENT(3, "年缴","1"),
    LUMPSUMPAYMENT(4, "一次性交清","1");

    private Integer code;
    private String msg;
    private String countCycle;

    public static String getMsgByCode(Integer code) {
        for (PayCycleEnum entry : PayCycleEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

    public static PayCycleEnum getEnumByCode(Integer code) {
        for (PayCycleEnum entry : PayCycleEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }
}
