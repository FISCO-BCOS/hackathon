package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保单来源类型枚举
 *
 * @author liuchen
 * @date 2022-05-17 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum SourceTypeEnum {

    OCR(1, "OCR识别"),
    QUICKENTER(2, "快速录入"),
    EMAIL(3, "邮箱识别"),
    BACKUP(4, "备份"),
    GRANT(5, "授权");


    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (SourceTypeEnum entry : SourceTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
