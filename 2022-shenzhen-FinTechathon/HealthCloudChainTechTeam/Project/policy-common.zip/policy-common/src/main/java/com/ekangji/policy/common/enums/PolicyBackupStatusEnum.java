package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保单备份状态枚举
 *
 * @author liuchen
 * @date 2022-05-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PolicyBackupStatusEnum {

    WAIT(1, "待接收"),
    RECEIVED(2, "已接收"),
    REJECTED(3, "已拒绝")
    ;

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (PolicyBackupStatusEnum entry : PolicyBackupStatusEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
