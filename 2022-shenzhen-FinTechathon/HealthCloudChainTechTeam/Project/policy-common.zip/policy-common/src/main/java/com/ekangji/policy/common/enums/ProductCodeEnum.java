package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 产品编码（数据大屏相关专用）
 *
 * @author wjx
 * @date 2021/11/28 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum ProductCodeEnum {

    YHB("GXYLYHB" , "玉惠保"),
    HHB("HNHBHHB2022" , "惠鹤保");

    private String code;

    private String msg;

    public static String getMsgByCode(String code) {
        for (ProductCodeEnum entry : ProductCodeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
