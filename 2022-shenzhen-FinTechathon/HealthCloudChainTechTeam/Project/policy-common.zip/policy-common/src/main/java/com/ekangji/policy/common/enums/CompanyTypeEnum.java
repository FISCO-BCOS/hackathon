package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 通用状态枚举
 *
 * @author xintao.li
 * @date 2022/3/22 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum CompanyTypeEnum {

    COMPANY_TYPE_0("0" , "人身险"),
    COMPANY_TYPE_1("1", "财产险")
    ;

    private String code;

    private String msg;

    public static String getMsgByCode(String code) {
        for (CompanyTypeEnum entry : CompanyTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
