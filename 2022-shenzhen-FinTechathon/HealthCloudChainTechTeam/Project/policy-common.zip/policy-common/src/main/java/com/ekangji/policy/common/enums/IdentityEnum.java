package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;


@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum IdentityEnum {

    IDENTITYCARD(0, "身份证"),
    RESIDENCE(1, "户口本"),
    BIRTH(2 , "出生证"),
    PASSPORT(3 , "护照"),
    OFFICER(4 , "军官证"),
    POLICE(5 , "警官证"),
    FOREIGNERONE(6 , "外国人永久居留证"),
    KONGONE(7 , "港澳台同胞回乡证"),
    FOREIGNERTWO(8 , "港澳台居民居住证"),
    KONGTWO(9, "外国人在华居住证");

    private Integer code;

    private String msg;

    public static String getMsgByCode(Integer code) {
        for (IdentityEnum entry : IdentityEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
