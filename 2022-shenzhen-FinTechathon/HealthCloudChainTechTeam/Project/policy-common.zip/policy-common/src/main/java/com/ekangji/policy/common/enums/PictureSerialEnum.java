package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;


@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PictureSerialEnum {

    DIGITAL("BLI", "数字保单"),
    STAR("BLS", "星球");

    private String code;

    private String msg;

    public static String getMsgByCode(String code) {
        for (PictureSerialEnum entry : PictureSerialEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
