package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 统计值
 *
 * @author xintao.li
 * @date 2022-05-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum StatisticsValueEnum {

    AVER(1,"均值"),
    MEDIAN(2, "中位数值"),
    MAX(3, "最大值"),
    MIN(4, "最小值"),
    ASSIGN(5, "指定值");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (PolicyReceiveStatusEnum entry : PolicyReceiveStatusEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
