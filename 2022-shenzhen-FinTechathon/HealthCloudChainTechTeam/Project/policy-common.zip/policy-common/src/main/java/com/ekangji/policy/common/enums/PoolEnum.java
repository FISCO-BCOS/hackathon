package com.ekangji.policy.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author jun.zhang
 * @className PoolEnum
 * @date 2020/8/23 18:26
 */
@Getter
@AllArgsConstructor
public enum PoolEnum {
    /**
     * 核心线程
     */
    CORE_SIZE,
    /**
     * 最大线程
     */
    MAX_SIZE,
    /**
     * 线程存活时间
     */
    KEEP_ALIVE,
    /**
     * 队列大小
     */
    QUEUE_SIZE

}
