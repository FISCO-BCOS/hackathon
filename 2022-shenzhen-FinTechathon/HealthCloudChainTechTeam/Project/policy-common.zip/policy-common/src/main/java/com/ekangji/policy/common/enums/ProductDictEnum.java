package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保险协字典类型枚举
 *
 * @author wjx
 * @date 2021/1/17 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum ProductDictEnum {
    PRODUCT_TYPE("product_type" , "产品类型"),
    PRODUCT_SPECIAL_TYPE("product_special_type" , "产品特殊属性"),
    INSURANCE_TIME_TYPE("insurance_time_type" , "保险期间类型"),
    INSURANCE_STYLE("insurance_style" , "承保方式"),
    PAY_WAY("pay_way" , "交费方式"),
    SALE_STATUS("sale_status" , "销售状态"),
    DESIGN_TYPE("design_type" , "设计类型"),
    ;

    private String code;

    private String msg;

    public static String getMsgByCode(String code) {
        for (ProductDictEnum entry : ProductDictEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
