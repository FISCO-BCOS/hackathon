package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 缴费期间
 *
 * @author liuchen
 * @date 2022-05-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PayPeriodUnitEnum {

    MONTH(1, "月"),
    HALFYEAR(2, "半年"),
    YEAR(3, "年"),
    ENDAGE(4, "至**岁");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (PayPeriodUnitEnum entry : PayPeriodUnitEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
    public static PayPeriodUnitEnum getEnumByCode(Integer code) {
        for (PayPeriodUnitEnum entry : PayPeriodUnitEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }
}
