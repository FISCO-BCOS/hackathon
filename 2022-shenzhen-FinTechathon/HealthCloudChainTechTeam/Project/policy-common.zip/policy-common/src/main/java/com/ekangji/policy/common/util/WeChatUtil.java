package com.ekangji.policy.common.util;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;



public class WeChatUtil {

    /**
     * 根据appId和secret，获取Access token
     * 目前access_token的有效期通过返回的expire_in来传达，目前是7200秒之内的值。中控服务器需要根据这个有效时间提前去刷新新access_token。
     * 在刷新过程中，中控服务器可对外继续输出的老access_token，此时公众平台后台会保证在5分钟内，新老access_token都可用，这保证了第三方业务的平滑过渡
     * @param appId
     * @param secret
     * @return
     */
    public static String getAccessToken( String appId,String secret) {
        if (StringUtils.isNotBlank(appId) && StringUtils.isNotBlank(secret)){
            //设置变量 url与返回值其中url使用拼接带入参数appId， secret
            String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="
                    + appId+ "&secret=" + secret;
            String message = HttpClientUtil.httpGetRequest(url);
            //转化成json对象然后返回accessToken属性的值
            JSONObject demoJson =JSONObject.parseObject(message);
            String accessToken = demoJson.getString("access_token");
            return accessToken;
        }
        return null;
    }

    /**
     * 根据accessToken获取Jsapi Ticket
     * @param accessToken
     * @return
     */
    public static String getJsapiTicket(String accessToken){

        if(StringUtils.isNotBlank(accessToken)){
            String requestUrl = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?";
            String params = "access_token=" + accessToken + "&type=jsapi";
            String result = HttpClientUtil.httpGetRequest(requestUrl+params);
            return JSONObject.parseObject(result).getString("ticket");
        }
        return null;
    }

    /**
     * 生成noncestr
     * @return
     */
    public static String getNonceStr() {
        return UUID.randomUUID().toString(true);
    }

    /**
     * 生成时间戳（精确到到秒）
     * @return
     */
    public static String getTimeStamp() {
        return String.valueOf(System.currentTimeMillis()/1000);

    }

    /**
     * 生成签名Signature
     * @param jsapiTicket
     * @param noncestr
     * @param timestamp
     * @param url
     * @return
     */
    public static String getSignature(String jsapiTicket,String noncestr,String timestamp,String url)  {
        String sign = "jsapi_ticket=" + jsapiTicket + "&noncestr=" + noncestr + "&timestamp=" + timestamp + "&url=" + url;
        String signature = Sha1Util.getSha1(sign.getBytes());
        return signature;
    }

    public static void main(String[] args) {
        String appId = "wx453a4678cf5b30e8";
        String secret = "b6bdaf1c2ff67d8aa371b77152ee2ab2";
        String url = "http://admin-ui-test.ekangji.com/bbc/index.html";

        String accessToken = getAccessToken(appId, secret);
        String jsapiTicket = getJsapiTicket(accessToken);
        String nonceStr = getNonceStr();
        String timeStamp = getTimeStamp();
        String signature = getSignature(jsapiTicket, nonceStr, timeStamp, url);
        System.out.println(jsapiTicket);
        System.out.println(nonceStr);
        System.out.println(timeStamp);
        System.out.println(signature);
    }
}

