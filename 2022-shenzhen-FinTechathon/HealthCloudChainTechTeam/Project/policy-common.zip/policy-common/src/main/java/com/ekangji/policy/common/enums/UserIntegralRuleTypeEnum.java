package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * @Author: yangzhiwen
 * @Date: 2022/3/19 11:38
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum UserIntegralRuleTypeEnum {
    LOGIN_DAT(0,"每天首次登录"),
    UPLOAD_PHONE_NUMBER(1,"授权手机号"),
    UPLOAD_PHOTO(2,"首次授权头像"),
    COLLECTION_PROGRAM(3,"收藏小程序"),
    PROGRAM_SHARE(4,"小程序分享"),
    READING_ARTICLES(5,"阅读文章"),
    SEND_QUESTIONS(6,"发去提问"),
    UPLOAD_INSURANCE_POLICY(7,"生成数字保单"),
    GET_STAR(8,"领取星球"),
    INVITE_INTO_STAR(9,"邀请好友加入星链"),
    CHAIN_LENGTH_ADD(10,"用户星链长度每加10")
    ;

    private Integer code;

    private String msg;


    public static String getMsgByCode(Integer code) {
        for (UserIntegralRuleTypeEnum entry : UserIntegralRuleTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }


}
