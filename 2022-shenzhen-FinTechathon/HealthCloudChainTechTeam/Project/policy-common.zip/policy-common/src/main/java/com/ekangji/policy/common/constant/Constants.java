package com.ekangji.policy.common.constant;

/**
 * @author 李鑫涛
 * @date 5/16/22 10:02 AM
 */
public class Constants {

    /**
     * 固定盐APP_SECRET
     */
    public static final String APP_SECRET = "ef4aa317897a4e6f9cdc2ce78569165d";
    /**
     * 默认页码
     */
    public static final Integer PAGE_NUM = 1;
    /**
     * 默认每页行数
     */
    public static final Integer PAGE_SIZE = 20;
    /**
     * 每次请求允许查询的最大行数 因为要加在注解属性里 不能用Integer类型 否则会报错
     */
    public static final int MAX_PAGE_SIZE = 100;
    /**
     * redis分布式锁过期时间
     */
    public static final int LOCK_TIME = 7;
    /**
     * 停留时长达标时间 单位秒
     */
    public static final int ENOUGH_STAY_TIME = 3600;

    /**
     * 停留时长达标时间 单位秒
     */
    public static final int INTEGRAL_ENOUGH_STAY_TIME = 30;

    /**
     * 英文冒号
     */
    public static final String COLON = ":";

    /**
     * 官方回答用户昵称
     */
    public static final String OFFICIAL_ANSWER_USER_NICKNAME = "保啦啦";

    /**
     * 全部TAB文本
     */
    public static final String ALL_TAB_STR = "全部";

    /**
     * 0值
     */
    public static final int ZERO = 0;

    /**
     * 1值
     */
    public static final int ONE = 1;

    /**
     * 2值
     */
    public static final int TWO = 2;

    /**
     * 3值
     */
    public static final int THREE = 3;

    /**
     * 4值
     */
    public static final int FOUR = 4;

    /**
     * 100值
     */
    public static final int HUNDRED = 100;


    /**
     * 最大等待时间
     */
    public static final int DEFAULT_WAIT_LIMIT = 500;


    /**
     * 计算单项保障分的分母系数
     */
    public static final int CALC_POLICY_AMOUNT = 100;

    /**
     * 分割符
     */
    public static final String SEPARATOR = "-";

    /**
     * 默认分数
     */
    public static final int DEFAULT_SCORE = 100;

    /**
     * -1值
     */
    public static final int NEGATIVE_ONE = -1;

    /**
     * 全部保障名称
     */
    public static final String PROD_TYPE_ALL_NAME = "全部保障";

    /**
     * 全部保障编号
     */
    public static final String PROD_TYPE_ALL_CODE = "ProdTypeCode_all";

    /**
     * 邀请一位新好友获取的保豆数量
     */
    public static final String  INVITE_ONE ="inviteOne";

    /**
     * 星链长度每增加10获得的保豆数
     */
    public static final String ADD_NUM ="addNum";

    /**
     * 星链长度
     */
    public static final String LENGTH ="length";

    /**
     * 已获得保豆数
     */
    public static final String  OBTAINED_NUM ="obtainedNum";

    /**
     * 微信ACCESS_TOKEN
     */
    public final static String ACCESS_TOKEN = "ekangji:wechat:star:access_token_key";

    /**
     * ACCESS_TICKET过期时间
     */
    public final static Long ACCESS_TICKET_TIMEOUT = 7000L;

}
