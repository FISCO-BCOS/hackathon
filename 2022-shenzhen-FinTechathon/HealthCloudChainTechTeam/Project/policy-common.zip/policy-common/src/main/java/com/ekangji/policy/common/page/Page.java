package com.ekangji.policy.common.page;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import static com.ekangji.policy.common.constant.Constants.PAGE_NUM;
import static com.ekangji.policy.common.constant.Constants.PAGE_SIZE;


/**
 * 分页基类
 *
 * @author: zhangjun
 * @create: 2021/11/29 3:56 下午
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Page implements Serializable {

    /**
     * 页码
     */
    @ApiModelProperty("页码")
    private Integer pageNum = PAGE_NUM;

    /**
     * 每页数据长度
     */
    @ApiModelProperty("每页数据长度")
    private Integer pageSize = PAGE_SIZE;

}
