package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;


@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum ScoreTypeEnum {

    HEALTH("ProdTypeCode_02" , "健康险"),
    LIFEINSURANCE("ProdTypeCode_00", "人寿险"),
    UNEXPECTED("ProdTypeCode_03" , "意外险"),
    RENTE("ProdTypeCode_01" , "年金险"),
    SOCIALSECURITY("SocialSecurity", "社保");

    private String code;

    private String msg;

    public static ScoreTypeEnum getMsgByCode(String code) {
        for (ScoreTypeEnum entry : ScoreTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }
}
