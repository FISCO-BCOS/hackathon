package com.ekangji.policy.common.constant;

/**
 * @Author: Yangzhiwen
 * @Date: 2022/2/24 13:27
 */
public class RedisKeys {
    /**
     * 玉惠保数据大屏数据
     */
    public static final String YHB_DATA_VIEW_INFO_KEY = "ekangji:yhb:data:view:info";

    /**
     * 领取星球用户数
     */
    public static final String STAR_DRAW_USER_NUM = "ekangji:star:draw:user:num";
}
