package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保单保障期限单位
 *
 * @author liuchen
 * @date 2022-05-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum GuaranteePeriodUnitEnum {

    DAY(1, "天"),
    MONTH(2, "月"),
    YEAR(3, "年"),
    ENDAGE(4, "至**岁"),
    LIFELONG(5, "终身"),
    OTHER(6, "其他");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (GuaranteePeriodUnitEnum entry : GuaranteePeriodUnitEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

    public static GuaranteePeriodUnitEnum getEnumByCode(Integer code) {
        for (GuaranteePeriodUnitEnum entry : GuaranteePeriodUnitEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }
}
