package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保单来源类型枚举
 *
 * @author liuchen
 * @date 2022-05-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PlatformEnum {

    WECHAT(0, "微信小程序"),
    TIKTOK(1, "抖音小程序");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (PlatformEnum entry : PlatformEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
