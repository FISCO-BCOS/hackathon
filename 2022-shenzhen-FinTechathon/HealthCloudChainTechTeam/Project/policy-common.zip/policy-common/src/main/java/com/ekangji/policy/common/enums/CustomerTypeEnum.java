package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 被保人受益人枚举
 *
 * @author wjx
 * @date 2021/1/17 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum CustomerTypeEnum {
    POLICY_HOLDER("1" , "投保人"),
    INSURED("2" , "被保人"),
    BENEFICIARY("3", "受益人");

    private String code;

    private String msg;

    public static String getMsgByCode(String code) {
        for (CustomerTypeEnum entry : CustomerTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
