package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 逻辑删除状态枚举
 *
 * @author heshuai
 * @date 2022-02-19 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum DeleteFlagEnum {

    NORMAL(1 , "正常"),
    DELETED(0, "已删除");

    private Integer code;

    private String msg;

    public static String getMsgByCode(Integer code) {
        for (DeleteFlagEnum entry : DeleteFlagEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
