package com.ekangji.policy.common.page;

import com.ekangji.policy.common.constant.Constants;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 分页参数
 *
 * @author: zhangjun
 * @create: 2021/12/14 4:35 下午
 */
@Data
public class PageParam implements Serializable {

    /**
     * 页码
     */
    @ApiModelProperty("页码")
    private Integer pageNum = Constants.PAGE_NUM;

    /**
     * 每页数据长度
     */
    @ApiModelProperty("每页数据长度")
    private Integer pageSize = Constants.PAGE_SIZE;

    /**
     * 排序
     */
    @ApiModelProperty("排序")
    private String orderBy;

}
