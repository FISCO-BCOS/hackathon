package com.ekangji.policy.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * 任务场景枚举
 * @author jun.zhang
 * @date 2020/8/23 18:32
 */
@Getter
@AllArgsConstructor
public enum BizTaskEnum {

    COMMON_TASK("commonTask", "普通任务", ThreadPoolBizEnum.COMMON_TASK),
    SYNCHRONIZATION_TASK("synchronizationTask", "同步任务", ThreadPoolBizEnum.SYNCHRONIZATION_TASK),
    DATA_RESOLVE_TASK("dataResolveTask", "大屏数据解析", ThreadPoolBizEnum.DATA_RESOLVE_TASK)
    ;
    private String taskKey;
    private String desc;
    private ThreadPoolBizEnum pool;

    public static BizTaskEnum getByKey(String taskKey) {
        if (StringUtils.isBlank(taskKey)) {
            return null;
        }
        for (BizTaskEnum taskEnum : BizTaskEnum.values()) {
            if (taskEnum.taskKey.equals(taskKey)) {
                return taskEnum;
            }
        }
        return null;
    }
}
