package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 用户来源渠道
 * @Author: yangzhiwen
 * @Date: 2022/5/11 14:35
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum UserChannelEnum {

    //0:微信,1:抖音2:快手,3:百度,4:支付宝,5:App
    WECHAT(0,"微信"),
    TIKTOK(1,"抖音"),
    KWAI(2,"快手"),
    BAIDU(3,"百度"),
    ALI_PAY(0,"支付宝"),
    APP(0,"App"),

    ;

    private Integer code;

    private String msg;


    public static String getMsgByCode(Integer code) {
        for (UserChannelEnum entry : UserChannelEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }



    public static UserChannelEnum getEnumByChannelCode(Integer code) {
        for (UserChannelEnum entry : UserChannelEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }

}
