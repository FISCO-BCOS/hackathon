package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;


@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum RelationEnum {

    MYSELF(0, "本人"),
    PARTNER(1, "伴侣"),
    CHILDREN(2 , "孩子"),
    FATHER(3 , "爸爸"),
    MOTHER(4 , "妈妈"),
    BROTHER(5 , "兄弟姐妹"),
    GRANDFATHER(6 , "祖父"),
    GRANDMOTHER(7 , "祖母"),
    OTHER(8, "其他");

    private Integer code;

    private String msg;

    public static String getMsgByCode(Integer code) {
        for (RelationEnum entry : RelationEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
