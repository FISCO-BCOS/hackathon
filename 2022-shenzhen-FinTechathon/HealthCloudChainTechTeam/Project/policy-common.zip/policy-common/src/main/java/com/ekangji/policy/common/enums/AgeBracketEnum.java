package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 年龄段枚举
 *
 * @author xintao.li
 * @date 2022/3/22 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum AgeBracketEnum {

    ONESTEP(1 , 0,18,"0-18岁（不含）"),
    TWOSTEP(2 , 18,25,"18-25岁（不含）"),
    THREESTEP(3 , 25,35,"25-35岁（不含）"),
    FOURSTEP(4 , 35,50,"35-50岁（不含）"),
    FIVESTEP(5 , 50,-1,"50岁及以上");

    private Integer code;

    private Integer begin;

    private Integer end;

    private String msg;

    public static String getMsgByCode(Integer code) {
        for (AgeBracketEnum entry : AgeBracketEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

    public static Integer getBeginByCode(Integer code) {
        for (AgeBracketEnum entry : AgeBracketEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getBegin();
            }
        }
        return null;
    }

    public static Integer getEndByCode(Integer code) {
        for (AgeBracketEnum entry : AgeBracketEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getEnd();
            }
        }
        return null;
    }

}
