package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 素材枚举
 *
 * @author liuchen
 * @date 2022-07-12 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum EnableOrDisableEnum {

    ENABLE(1, "启用"),
    DISABLE(0, "禁用");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (EnableOrDisableEnum entry : EnableOrDisableEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
