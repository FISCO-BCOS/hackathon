package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保单接收状态枚举
 *
 * @author liuchen
 * @date 2022-05-16 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PolicyStatusEnum {
    IN_INSURED(1, "保障中"),
    OUT_INSURED(0, "未在保障中");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (PolicyStatusEnum entry : PolicyStatusEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
