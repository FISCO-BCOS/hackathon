package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 对比列枚举
 *
 * @author xintao.li
 * @date 2022/3/22 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum CompareColumnEnum {

    AVER(1 ,"用户均值"),
    MEDIAN(2 , "用户中位数值"),
    ASSIGN(3 , "指定值");

    private Integer code;

    private String msg;

    public static CompareColumnEnum getEnumByCode(Integer code){
        for (CompareColumnEnum entry : CompareColumnEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry;
            }
        }
        return null;
    }

    public static String getMsgByCode(Integer code) {
        for (CompareColumnEnum entry : CompareColumnEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
