package com.ekangji.policy.common.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 任务枚举
 * @author jun.zhang
 * @date 2020/8/23 18:29
 */
@AllArgsConstructor
@Getter
public enum ThreadPoolBizEnum {
    /**
     * 普通任务
     */
    COMMON_TASK("common_task", "普通任务"),
    /**
     * 同步任务
     */
    SYNCHRONIZATION_TASK("synchronization_task", "同步任务"),
    DATA_RESOLVE_TASK("dataResolveTask", "大屏数据解析")
    ;

    private String key;
    private String desc;
}
