package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;
/**
 * 素材枚举
 *
 * @author liuchen
 * @date 2022-07-12 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum MaterialTypeEnum {

    STAR_PIC(1, "星球图片"),
    POLICY_PIC(2, "保单图片");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (MaterialTypeEnum entry : MaterialTypeEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
