package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 通用状态枚举
 *
 * @author xintao.li
 * @date 2022/3/22 19:45
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum YESORNOEnum {

    YES(1 , "是"),
    NO(0, "否")
    ;

    private Integer code;

    private String msg;

    public static String getMsgByCode(Integer code) {
        for (YESORNOEnum entry : YESORNOEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }

}
