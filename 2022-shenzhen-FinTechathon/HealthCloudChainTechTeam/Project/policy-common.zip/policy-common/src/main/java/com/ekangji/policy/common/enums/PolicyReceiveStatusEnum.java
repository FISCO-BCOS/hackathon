package com.ekangji.policy.common.enums;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

/**
 * 保单接收状态枚举
 *
 * @author liuchen
 * @date 2022-05-16 13:47:42
 */
@Getter
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public enum PolicyReceiveStatusEnum {
    TORECEIVE(1, "未处理"),
    RECEIVED(2, "接收"),
    REFUSE(3, "不接收");

    private Integer code;
    private String msg;

    public static String getMsgByCode(Integer code) {
        for (PolicyReceiveStatusEnum entry : PolicyReceiveStatusEnum.values()) {
            if (Objects.equals(entry.getCode(), code)) {
                return entry.getMsg();
            }
        }
        return "";
    }
}
