package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.*;
import com.ekangji.policy.dto.clientobject.policy.*;
import com.ekangji.policy.dto.command.member.EnsuredReadConfigBatchEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigBatchEditCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredQry;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.policy.dto.command.policy.family.MemberEnsureScorePageQry;
import com.ekangji.policy.dto.command.policy.family.UserFamilyDeleteCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyMemberEditCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Slf4j
@Api(tags = "用户家庭成员相关接口")
@RestController
@RequestMapping("/family")
public class UserFamilyInfoController {

    @Resource
    private IMemberEnsuredInfoService memberEnsuredInfoService;
    @Resource
    private UserFamilyInfoService userFamilyInfoService;
    @Resource
    private IEnsuredWeightConfigService ensuredWeightConfigService;
    @Resource
    private IEnsuredReadConfigService ensuredReadConfigService;
    @Resource
    private IFamilyEnsuredInfoService familyEnsuredInfoService;
    @Resource
    private DigitalPolicyService digitalPolicyService;

    @Resource
    private PolicyService policyService;
    @ApiTag(code = "MEMBER_ENSURED_BY_CONDITION", desc = "运营后台保障分查询接口")
    @ApiOperation(value = "运营后台保障分查询接口", notes = "运营后台保障分查询接口")
    @RequestMapping(value = "queryPageByCondition", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<MemberEnsureScoreVO>> queryPageByCondition(@RequestBody MemberEnsureScorePageQry qry) {
        return memberEnsuredInfoService.queryPageByCondition(qry);
    }
    @ApiTag(code = "POLICY_BY_CONDITION", desc = "运营台保单查询接口")
    @ApiOperation(value = "运营台保单查询接口", notes = "运营台保单查询接口")
    @RequestMapping(value = "queryPolicyPageByCondition", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<PolicyVO>> queryPolicyPageByCondition(@RequestBody PolicyPageQry qry) {
        return policyService.queryPolicyPageByCondition(qry);
    }
    @ApiTag(code = "POLICY_DETAIL", desc = "运营台保单详情")
    @ApiOperation(value = "运营台保单详情", notes = "运营台保单详情")
    @RequestMapping(value = "queryPolicyDetail", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PolicyDetailVO> queryPolicyDetail(@RequestBody PolicyQry qry) {
        return policyService.policyDetail(qry);
    }
    /**
     * 新增或修改家庭成员
     *
     * @param cmd
     * @return
     */
    @ApiTag(code = "FAMILY_MEMBER_EDIT",desc = "新增或修改家庭成员")
    @ApiOperation(value = "新增或修改家庭成员", notes = "新增或修改家庭成员")
    @RequestMapping(value = "maintainFamilyMember", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Long> maintainFamilyMember(@RequestBody @Validated UserFamilyMemberEditCmd cmd) {
        return userFamilyInfoService.maintainFamilyMember(cmd);
    }
    /**
     * 删除家庭成员
     *
     * @param cmd
     * @return
     */
    @ApiTag(code = "FAMILY_MEMBER_DELETE",desc = "删除家庭成员")
    @ApiOperation(value = "删除家庭成员", notes = "删除家庭成员")
    @RequestMapping(value = "deleteFamilyMember", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Integer> deleteFamilyMember(@RequestBody @Validated UserFamilyDeleteCmd cmd) {
        return userFamilyInfoService.deleteFamilyMember(cmd);
    }
    /**
     * 用户关系字典
     *
     * @param
     * @return
     */
    @ApiTag(code = "FAMILY_MEMBER_EDIT",desc = "用户关系字典")
    @ApiOperation(value = "用户关系字典", notes = "用户关系字典")
    @RequestMapping(value = "relationList", method = RequestMethod.GET)
    @ResponseBody
    public ApiResult<List<UserMemberRelationVO>> relationList() {
        return userFamilyInfoService.relationList();
    }
    /**
     * 根据用户id获取家庭成员清单
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "FAMILY_USER_GET",desc = "根据用户id获取家庭成员清单")
    @ApiOperation(value = "根据用户id获取家庭成员清单", notes = "根据用户id获取家庭成员清单")
    @RequestMapping(value = "findFamilyListByUserId", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<UserFamilyMemberVO>> findFamilyListByUserId(@RequestBody @Validated  UserFamilyQry qry) {
        return userFamilyInfoService.findFamilyListByUserId(qry);
    }
    /**
     * 根据成员id获取家庭对象
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "FAMILY_MEMBER_GET",desc = "根据成员id获取家庭对象")
    @ApiOperation(value = "根据成员id获取家庭对象", notes = "根据成员id获取家庭对象")
    @RequestMapping(value = "findFamilyByMemberId", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<UserFamilyMemberDetailVO> findFamilyByMemberId(@RequestBody @Validated  UserFamilyQry qry) {
        return userFamilyInfoService.findFamilyByMemberId(qry);
    }
    /**
     * 保障卡详情
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "FAMILY_ENSURED_DETAIL",desc = "保障卡详情")
    @ApiOperation(value = "保障卡详情", notes = "保障卡详情")
    @RequestMapping(value = "myFamilyEnsureDetail", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<FamilyEnsureVO>  myFamilyEnsureDetail(@RequestBody @Validated  MemberEnsuredQry qry) {
        return familyEnsuredInfoService.myFamilyEnsureDetail(qry);
    }
    /**
     * 保障分权重配置列表
     *
     * @param
     * @return
     */
    @ApiTag(code = "ENSURED_WEIGHT_DETAIL",desc = "保障分权重配置列表")
    @ApiOperation(value = "保障分权重配置列表", notes = "保障分权重配置列表")
    @RequestMapping(value = "findEnsuredWeightList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<EnsuredWeightConfigVO>> findEnsuredWeightList() {
        return ensuredWeightConfigService.findEnsuredWeightList();
    }
    /**
     * 保障分权重设置
     *
     * @param
     * @return
     */
    @ApiTag(code = "ENSURED_WEIGHT_SET",desc = "保障分权重设置")
    @ApiOperation(value = "保障分权重设置", notes = "保障分权重设置")
    @RequestMapping(value = "ensuredWeightSet", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Integer> ensuredWeightSet(@RequestBody @Validated  EnsuredWeightConfigBatchEditCmd ensuredWeightConfigBatchEditCmd) {
        return ensuredWeightConfigService.ensuredWeightSet(ensuredWeightConfigBatchEditCmd);
    }

    /**
     * 保障分解读配置列表
     *
     * @param
     * @return
     */
    @ApiTag(code = "ENSURED_READ_DETAIL",desc = "保障分解读配置列表")
    @ApiOperation(value = "保障分解读配置列表", notes = "保障分解读配置列表")
    @RequestMapping(value = "findEnsuredReadList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<EnsuredReadConfigVO>> findEnsuredReadList() {
        return ensuredReadConfigService.findEnsuredReadList();
    }

    /**
     * 保障分解读设置
     *
     * @param
     * @return
     */
    @ApiTag(code = "ENSURED_READ_SET",desc = "保障分解读设置")
    @ApiOperation(value = "保障分解读设置", notes = "保障分解读设置")
    @RequestMapping(value = "ensuredReadSet", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Integer> ensuredReadSet(@RequestBody @Validated EnsuredReadConfigBatchEditCmd ensuredReadConfigBatchEditCmd) {
        return ensuredReadConfigService.ensuredReadSet(ensuredReadConfigBatchEditCmd);
    }

    /**
     * 保障分计算  ocr识别和快速录入后 提交时 调用
     *
     * @param
     * @return
     */
    @ApiTag(code = "ENSURED_CALC_ENSURE",desc = "保障分计算")
    @ApiOperation(value = "保障分计算", notes = "保障分计算")
    @RequestMapping(value = "calculateEnsuredScore", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Long> calculateEnsuredScore(@RequestBody @Validated MemberEnsuredCalcCmd memberEnsuredCalcCmd) {
        return memberEnsuredInfoService.calculateEnsuredScore(memberEnsuredCalcCmd);
    }

    /**
     * 保障分导出Excel
     *
     * @param qry
     */
    @ApiTag(code = "ENSURED_EXCEL_EXPORT",desc = " 保障分导出Excel")
    @ApiOperation(value = "保障分导出Excel", notes = "保障分导出Excel")
    @RequestMapping(value = "member/export/excel", method = RequestMethod.GET)
    @ResponseBody
    public List<MemberEnsureScoreExportVO> memberExport(MemberEnsureScoreExportQry qry) {
       return memberEnsuredInfoService.exportExcel(qry);
    }


    /**
     * 保单导出Excel
     *
     * @param qry
     */
    @ApiTag(code = "POLICY_EXCEL_EXPORT",desc = "保单导出Excel")
    @ApiOperation(value = "保单导出Excel", notes = "保单导出Excel")
    @RequestMapping(value = "policy/export/excel", method = RequestMethod.GET)
    @ResponseBody
    public List<PolicyExcelExportVO>  policyExport(PolicyPageExportQry qry) {
       return policyService.exportExcel(qry);
    }

//    /**
//     * 生成nft保单
//     *
//     * @param
//     * @return
//     */
//    @ApiTag(code = "GENERATE_NFT_POLICY",desc = "生成nft保单")
//    @ApiOperation(value = "生成nft保单", notes = "生成nft保单")
//    @RequestMapping(value = "generateNftPolicy", method = RequestMethod.POST)
//    @ResponseBody
//    public ApiResult<String> generateNftPolicy(@RequestBody UserFamilyMemberEditCmd userFamilyMemberEditCmd) {
//        return userFamilyInfoService.generateNftPolicy(userFamilyMemberEditCmd);
//    }

    /**
     * 生成数字保单
     *
     * @param
     * @return
     */
    @ApiTag(code = "GENERATE_NFT_POLICY",desc = "生成数字保单")
    @ApiOperation(value = "生成数字保单", notes = "生成数字保单")
    @RequestMapping(value = "buildDigitalPolicy", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<DigitalPolicyVO> buildDigitalPolicy(@RequestBody DigitalPolicyCmd digitalPolicyCmd) {
        return digitalPolicyService.buildDigitalPolicy(digitalPolicyCmd);
    }

    /**
     * 编辑数字保单富媒体
     *
     * @param
     * @return
     */
    @ApiTag(code = "EDIT_NFT_POLICY",desc = "编辑数字保单")
    @ApiOperation(value = "编辑数字保单", notes = "编辑数字保单")
    @RequestMapping(value = "editDigitalPolicy", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Integer> editDigitalPolicy(@RequestBody DigitalPolicyEditCmd digitalPolicyCmd) {
        return digitalPolicyService.editDigitalPolicy(digitalPolicyCmd);
    }

}
