package com.ekangji.policy.web.scheduler;

import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.SafeguardInsuranceService;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
@Slf4j
public class UpdateInsuranceAmountScheduler extends JavaProcessor {

    @Resource
    private PolicyService policyService;

    @Resource
    private PolicyAdditionalService policyAdditionalService;
    /**
     *  定时任务：更新家庭成员各类保险有效保额
     *
     * @return
     */
    @Override
    public ProcessResult process(JobContext context) throws Exception {
        try {
            policyService.updateInsuranceAmount();
            policyAdditionalService.updateInsuranceAmount();
        }catch (Exception e){
            log.info(e.getMessage());
        }
        return new ProcessResult(true);
    }

}
