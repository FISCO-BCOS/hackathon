package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.SafeguardInsuranceService;
import com.ekangji.policy.common.enums.ScoreTypeEnum;
import com.ekangji.policy.dto.clientobject.safeguardinsurance.SafeguardInsuranceVO;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardinsurance.SafeguardInsuranceEditCompareValueCmd;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;


@Slf4j
@Api(tags = "保障图配置：四种险保障图")
@Controller
@RequestMapping("/policySteward/safeguardInsurance/")
public class SafeguardInsuranceController {

    @Resource
    private PolicyService policyService;

    @Resource
    private SafeguardInsuranceService safeguardInsuranceService;

    /**
     *  查询列表
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "查询列表")
    @ApiOperation(value = "查询列表", notes = "查询列表")
    @RequestMapping(value = "queryList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<SafeguardInsuranceVO>> queryList(@RequestBody InsuranceCommonQry qry) {
        return safeguardInsuranceService.queryList(qry);
    }

    /**
     *  获取某一级类别下的所有子类别的用户同龄保额的对比值
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "查询列表")
    @ApiOperation(value = "获取某一级类别下的所有子类别的用户同龄保额的对比值", notes = "获取某一级类别下的所有子类别的用户同龄保额的对比值")
    @RequestMapping(value = "listChildrenCompareValue", method = RequestMethod.POST)
    @ResponseBody
    public Map<String,Integer> listChildrenCompareValue(@RequestBody InsuranceCommonQry qry) {
        return safeguardInsuranceService.listChildrenCompareValue(qry);
    }

    /**
     *  更新对比列-健康险
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新对比列-健康险")
    @ApiOperation(value = "更新对比列-健康险", notes = "更新对比列-健康险")
    @RequestMapping(value = "updateHealthCompareValue", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateHealthCompareValue(@RequestBody @Validated SafeguardInsuranceEditCompareValueCmd cmd) {
        cmd.setParentType(ScoreTypeEnum.HEALTH.getCode());
        return safeguardInsuranceService.updateCompareValue(cmd);
    }

    /**
     *  更新对比列-人寿险
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新对比列-人寿险")
    @ApiOperation(value = "更新对比列-人寿险", notes = "更新对比列-人寿险")
    @RequestMapping(value = "updateLifeCompareValue", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateLifeCompareValue(@RequestBody @Validated SafeguardInsuranceEditCompareValueCmd cmd) {
        cmd.setParentType(ScoreTypeEnum.LIFEINSURANCE.getCode());
        return safeguardInsuranceService.updateCompareValue(cmd);
    }

    /**
     *  更新对比列-意外险
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新对比列-意外险")
    @ApiOperation(value = "更新对比列-意外险", notes = "更新对比列-意外险")
    @RequestMapping(value = "updateUnexpectedCompareValue", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateUnexpectedCompareValue(@RequestBody @Validated SafeguardInsuranceEditCompareValueCmd cmd) {
        cmd.setParentType(ScoreTypeEnum.UNEXPECTED.getCode());
        return safeguardInsuranceService.updateCompareValue(cmd);
    }

    /**
     *  更新对比列-年金险
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新对比列-年金险")
    @ApiOperation(value = "更新对比列-年金险", notes = "更新对比列-年金险")
    @RequestMapping(value = "updateRenteCompareValue", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateRenteCompareValue(@RequestBody @Validated SafeguardInsuranceEditCompareValueCmd cmd) {
        cmd.setParentType(ScoreTypeEnum.RENTE.getCode());
        return safeguardInsuranceService.updateCompareValue(cmd);
    }

    /**
     *  更新数据-健康险-定时任务
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新数据-健康险-定时任务")
    @ApiOperation(value = "更新数据-健康险-定时任务", notes = "更新数据-健康险-定时任务")
    @RequestMapping(value = "updateHealth", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateHealth() {
        return safeguardInsuranceService.updateHealth();
    }

    /**
     *  更新数据-人寿险-定时任务
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新数据-人寿险-定时任务")
    @ApiOperation(value = "更新数据-人寿险-定时任务", notes = "更新数据-人寿险-定时任务")
    @RequestMapping(value = "updateLifeInsurance", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateLifeInsurance() {
        return safeguardInsuranceService.updateLifeInsurance();
    }

    /**
     *  更新数据-意外险-定时任务
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新数据-意外险-定时任务")
    @ApiOperation(value = "更新数据-意外险-定时任务", notes = "更新数据-意外险-定时任务")
    @RequestMapping(value = "updateUnexpected", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateUnexpected() {
        return safeguardInsuranceService.updateUnexpected();
    }

    /**
     *  更新数据-年金险-定时任务
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新数据-年金险-定时任务")
    @ApiOperation(value = "更新数据-年金险-定时任务", notes = "更新数据-年金险-定时任务")
    @RequestMapping(value = "updateAnnuity", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateAnnuity() {
        return safeguardInsuranceService.updateAnnuity();
    }

}
