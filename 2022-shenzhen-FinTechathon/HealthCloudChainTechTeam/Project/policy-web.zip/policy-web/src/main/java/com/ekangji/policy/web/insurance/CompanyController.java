package com.ekangji.policy.web.insurance;


import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.ICompanyService;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyEditCmd;
import com.ekangji.policy.dto.command.insurance.company.CompanyPageQry;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.ekangji.user.center.common.annotation.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

/**
 * 保险公司相关接口

 */
@Slf4j
@Api(tags = "保险公司相关接口")
@Controller
@RequestMapping("/insurance/company")
public class CompanyController {

    @Resource
    private ICompanyService companyService;

    /**
     * 列表查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_COMPANY_LIST",desc = "保险公司下拉列表查询")
    @ApiOperation(value = "queryList", notes = "保险公司下拉列表查询")
    @RequestMapping(value = "queryList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<InsuranceCompanyDropListVO>> queryList(@RequestBody CompanyQry qry) {
        return companyService.queryList(qry);
    }

    /**
     * 分页查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_COMPANY_PAGE",desc = "分页查询")
    @ApiOperation(value = "queryPage", notes = "分页查询")
    @RequestMapping(value = "queryPage", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<InsuranceCompanyVO>> queryPage(@RequestBody CompanyPageQry qry) {
        return companyService.queryPage(qry);
    }

    /**
     * 编辑补充信息
     *
     * @param cmd
     * @return
     */
    @ApiTag(code = "INSURANCE_COMPANY_EDIT",desc = "编辑补充信息")
    @ApiOperation(value = "edit", notes = "编辑补充信息")
    @RequestMapping(value = "edit", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult edit(@RequestBody @Validated CompanyEditCmd cmd) {
        return companyService.edit(cmd);
    }

}
