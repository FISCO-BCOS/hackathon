package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PictureMaterialService;
import com.ekangji.policy.api.StarChainService;
import com.ekangji.policy.api.UserInviteInfoService;
import com.ekangji.policy.api.UserStarService;
import com.ekangji.policy.dto.clientobject.material.PictureMaterialVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteDetailVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteVO;
import com.ekangji.policy.dto.clientobject.star.StarStatisticsVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.ekangji.policy.dto.command.material.PictureMaterialQry;
import com.ekangji.policy.dto.command.policy.InviteAddCmd;
import com.ekangji.policy.dto.command.policy.UserInviteQry;
import com.ekangji.policy.dto.command.policy.UserStarAddCmd;
import com.ekangji.policy.dto.command.policy.UserStarEditCmd;
import com.ekangji.policy.dto.command.star.UserStarPageQry;
import com.ekangji.policy.dto.command.star.UserStarQry;
import com.ekangji.policy.dto.command.starchain.StarChainQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@Slf4j
@Api(tags = "星球相关接口")
@RestController
@RequestMapping("/star")
public class UserStarController {

    @Resource
    private UserStarService userStarService;

    @Resource
    private PictureMaterialService pictureMaterialService;

    @Resource
    private StarChainService starChainService;
    @Resource
    private UserInviteInfoService userInviteInfoService;
    /**
     * 检查用户是否领取过星球
     * @param qry
     * @return
     */
    @ApiTag(code = "CHECK_USER_START",desc = "检查用户是否领取过星球")
    @ApiOperation(value = "检查用户是否领取过星球", notes = "检查用户是否领取过星球")
    @RequestMapping(value = "checkUserHaveStar", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult checkUserHaveStar(@RequestBody @Validated LoginUserInfo qry) {
        return userStarService.checkUserHaveStar(qry);
    }

    /**
     * 获取星球素材
     * @param qry
     * @return
     */
    @ApiTag(code = "QUERY_STAR_MATERIAL",desc = "获取星球或数字保单素材")
    @ApiOperation(value = "获取星球或数字保单素材", notes = "获取星球或数字保单素材")
    @RequestMapping(value = "queryStarMaterial", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<PictureMaterialVO>> queryStarMaterial(@RequestBody @Validated PictureMaterialQry qry) {
        return pictureMaterialService.queryMaterialList(qry);
    }

    /**
     * 获取用户星球信息
     * @param qry
     * @return
     */
    @ApiTag(code = "QUERY_USER_STAR",desc = "获取用户星球信息")
    @ApiOperation(value = "获取用户星球信息", notes = "获取用户星球信息")
    @RequestMapping(value = "queryUserStar", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<StarVO> queryUserStar(@RequestBody @Validated UserStarQry qry) {
        return userStarService.queryUserStar(qry);
    }

    /**
     * 生成保拉星球
     * @param cmd
     * @return
     */
    @ApiTag(code = "GENERATE_STAR",desc = "生成保拉星球")
    @ApiOperation(value = "生成保拉星球", notes = "生成保拉星球")
    @RequestMapping(value = "buildUserStar", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult buildUserStar(@RequestBody UserStarAddCmd cmd) {
        return userStarService.buildUserStar(cmd);
    }

    /**
     * 修改保啦星球昵称
     * @param userStarEditCmd
     * @return
     */
    @ApiTag(code = "MODIFY_USER_START",desc = "修改保啦星球昵称")
    @ApiOperation(value = "修改保啦星球昵称", notes = "修改保啦星球昵称")
    @RequestMapping(value = "editUserStar", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult editUserStar(@RequestBody UserStarEditCmd userStarEditCmd) {
        return userStarService.editUserStar(userStarEditCmd);
    }

    /**
     * 运营后台获取用户星球列表
     * @param qry
     * @return
     */
    @ApiTag(code = "QUERY_STAR_PAGE",desc = "运营后台获取用户星球列表")
    @ApiOperation(value = "运营后台获取用户星球列表", notes = "运营后台获取用户星球列表")
    @RequestMapping(value = "queryStarPage", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<StarStatisticsVO>> queryStarPage(@RequestBody @Validated UserStarPageQry qry) {
        return userStarService.queryUserStarPage(qry);
    }

    /**
     * 运营后台获取用户星链星球
     * @param qry
     * @return
     */
    @ApiTag(code = "QUERY_CHAIN_STAR_LIST",desc = "运营后台获取用户星链星球")
    @ApiOperation(value = "运营后台获取用户星链星球", notes = "运营后台获取用户星链星球")
    @RequestMapping(value = "queryChainStarList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<StarVO>> queryChainStarList(@RequestBody @Validated StarChainQry qry) {
        return starChainService.queryChainStarList(qry);
    }


    /**
     * c端获取邀请人列表
     * @param qry
     * @return
     */
    @ApiTag(code = "QUERY_INVITE_LIST",desc = "c端获取邀请人列表")
    @ApiOperation(value = "c端获取邀请人列表", notes = "c端获取邀请人列表")
    @RequestMapping(value = "queryInviteList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<UserInviteDetailVO>> queryInviteList(@RequestBody @Validated UserInviteQry qry) {
        return userInviteInfoService.queryInviteList(qry);
    }

    /**
     * c端建立邀请人关系
     * @param cmd
     * @return
     */
    @ApiTag(code = "QUERY_INVITE_ADD",desc = "c端建立邀请人关系")
    @ApiOperation(value = "c端建立邀请人关系", notes = "c端建立邀请人关系")
    @RequestMapping(value = "AddInviteRelation", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<Long> AddInviteRelation(@RequestBody @Validated InviteAddCmd cmd) {
        return userInviteInfoService.AddInviteRelation(cmd);
    }
}
