package com.ekangji.policy.web.policy;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.ResultCodeEnum;
import com.ekangji.policy.api.PolicyBackupMessageService;
import com.ekangji.policy.dto.clientobject.policy.ToReceivePolicyVO;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageAddCmd;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.backup.ToBeBackupPolicyQry;
import com.ekangji.policy.dto.command.policy.backup.ToReceivePolicyQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;


@Slf4j
@Api(tags = "保单备份")
@Controller
@RequestMapping("/policy/backup/")
public class PolicyBackupMessageController {

    @Resource
    private PolicyBackupMessageService policyBackupMessageService;

    /**
     * 保单前置校验
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_BACKUP_VALIDATION",desc = "备份前置校验")
    @ApiOperation(value = "备份前置校验", notes = "备份前置校验")
    @RequestMapping(value = "/validation", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult messageAdd(@RequestBody @Validated ToBeBackupPolicyQry qry) {
        return policyBackupMessageService.validateBeforeBackup(qry);
    }

    /**
     * 保单发起备份
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_BACKUP_ADD",desc = "保单发起备份")
    @ApiOperation(value = "保单发起备份", notes = "保单发起备份")
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult messageAdd(@RequestBody @Validated PolicyBackupMessageAddCmd cmd) {
        return policyBackupMessageService.launchBackupPolicy(cmd);
    }

    /**
     * 获取用户待接收保单
     * @param qry
     * @return
     */
    @ApiOperation(value = "获取用户待接收保单")
    @RequestMapping(value = "query", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<ToReceivePolicyVO> getToReceivePolicyByUserId(@RequestBody @Validated ToReceivePolicyQry qry) {
        ApiResult<ToReceivePolicyVO> apiResult = policyBackupMessageService.getToReceivePolicyByUserId(qry);
        return apiResult;
    }

    /**
     * 保单处理(接收或不接收)
     * @param cmd
     * @return
     */
    @ApiOperation(value = "接收或不接收备份的保单")
    @PostMapping("/status/update")
    public ApiResult policyBackupHandling(@RequestBody @Validated PolicyBackupMessageEditCmd cmd) {
        ApiResult apiResult = policyBackupMessageService.policyBackupHandling(cmd);
        return apiResult;
    }
}
