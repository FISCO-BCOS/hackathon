package com.ekangji.policy.web;

import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
@Slf4j
@Controller
@RequestMapping("/wx")
public class WxgzhCodeController {

    String appId ="wx453a4678cf5b30e8";

    /**
     * 前端向服务器获取code
     * @param response
     * @return
     * @throws IOException
     */
    @ApiTag(code = "getWxgzh",desc = "前端向服务器获取code")
    @ApiOperation(value = "getWxgzh", notes = "前端向服务器获取code")
    @RequestMapping(value = "/getWxgzh", method = RequestMethod.POST)
    @ResponseBody
    public void getWxgzh(HttpServletResponse response)throws IOException {
        // 第一步：用户同意授权，获取code
        String url ="https://open.weixin.qq.com/connect/oauth2/authorize?appid="+appId
                + "&redirect_uri="+ URLEncoder.encode("http://policy-dev.baohaola.com/wx/getWxgzhUser")
                + "&response_type=code"
                + "&scope=snsapi_userinfo"
                + "&state=STATE&connect_redirect=1#wechat_redirect";
        log.info("url:{}",url);
        response.sendRedirect(url);
        log.info("重定向完毕:aaaaaaaaaaaa");
        return;//必须重定向，否则不能成功
    }

    /**
     * 获取code的重定向方法
     * @param request
     * @return
     */
    @ApiTag(code = "getWxgzhUser",desc = "前端向服务器获取code重定向")
    @ApiOperation(value = "getWxgzhUser", notes = "前端向服务器获取code重定向")
    @RequestMapping(value = "/getWxgzhUser", method = RequestMethod.GET)
    @ResponseBody
    public void getWxgzhApi(HttpServletRequest request){
        String code=request.getParameter("code");
        String errcode=request.getParameter("errcode");
        String state= request.getParameter("state");
        System.out.println("来了来了s="+code+",errcode"+errcode+"state="+state);
        log.info("code==============="+code);

        Map<String,Object> openidMap = new HashMap<>();

    }
}
