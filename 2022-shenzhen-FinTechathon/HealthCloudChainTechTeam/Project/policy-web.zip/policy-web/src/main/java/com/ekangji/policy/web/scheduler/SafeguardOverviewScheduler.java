package com.ekangji.policy.web.scheduler;

import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.ekangji.policy.api.SafeguardOverviewService;
import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;


@Component
public class SafeguardOverviewScheduler extends JavaProcessor {

    @Resource
    private SafeguardOverviewService safeguardOverviewService;

    /**
     *  更新保障总图数据
     *
     * @return
     */
    @Override
    public ProcessResult process(JobContext context) throws Exception {
        safeguardOverviewService.updateOverview();
        return new ProcessResult(true);
    }


}
