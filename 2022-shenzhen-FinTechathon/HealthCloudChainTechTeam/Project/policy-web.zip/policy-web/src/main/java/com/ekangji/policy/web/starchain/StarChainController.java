package com.ekangji.policy.web.starchain;

import com.alibaba.fastjson.JSONObject;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.api.StarChainService;
import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.starchain.ChainDetailVO;
import com.ekangji.policy.dto.clientobject.starchain.CommandContentVO;
import com.ekangji.policy.dto.command.dict.DictDataQry;
import com.ekangji.policy.dto.command.starchain.StarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.StarChainAddOneLengthCmd;
import com.ekangji.policy.dto.command.starchain.StarChainContentPageQry;
import com.ekangji.policy.dto.command.starchain.StarChainQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 星链
 *
 * @author: xintao.li
 * @create: 2022/05/17 16:40
 */
@Slf4j
@Api(tags = "星链接口")
@Controller
@RequestMapping("/star/chain/")
public class StarChainController {

    @Resource
    private StarChainService starChainService;

    /**
     * 星链详情
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "星链详情")
    @ApiOperation(value = "星链详情", notes = "星链详情")
    @PostMapping(value = "queryDetail")
    @ResponseBody
    public ApiResult<ChainDetailVO> queryDetail(@RequestBody StarChainQry qry) {
        return starChainService.queryDetail(qry);
    }

    /**
     * 创建星链
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "创建星链")
    @ApiOperation(value = "创建星链", notes = "创建星链")
    @PostMapping(value = "add")
    @ResponseBody
    public ApiResult add(@RequestBody StarChainAddCmd qry) {
        return starChainService.add(qry);
    }

    /**
     * 推荐内容
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "推荐内容")
    @ApiOperation(value = "推荐内容", notes = "推荐内容")
    @PostMapping(value = "commandContent")
    @ResponseBody
    public ApiResult<PageInfo<DigitalPolicyVO>> commandContent(@RequestBody Page qry) {
        return starChainService.commandContent(qry);
    }

    /**
     * 星链内容
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "星链内容")
    @ApiOperation(value = "星链内容", notes = "星链内容")
    @PostMapping(value = "chainContent")
    @ResponseBody
    public ApiResult<PageInfo<DigitalPolicyVO>> chainContent(@RequestBody StarChainContentPageQry qry) {
        return starChainService.chainContent(qry);
    }


    /**
     * 创建小程序二维码
     *
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "创建小程序二维码")
    @ApiOperation(value = "创建小程序二维码", notes = "创建小程序二维码")
    @GetMapping(value = "createQrCode")
    @ResponseBody
    public ApiResult createQrCode(String scene,String page,Boolean checkPath,String envVersion,Integer width){
        return starChainService.createIntoChainQrCode(scene, page, checkPath, envVersion, width);
    }

    /**
     * 星链长度加一
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "星链长度加一")
    @ApiOperation(value = "星链长度加一", notes = "星链长度加一")
    @PostMapping(value = "lengthAddOne")
    @ResponseBody
    public ApiResult lengthAddOne(@RequestBody StarChainAddOneLengthCmd qry) {
        return starChainService.lengthAddOne(qry);
    }

    /**
     * 加入星链
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "加入星链")
    @ApiOperation(value = "加入星链", notes = "加入星链")
    @PostMapping(value = "addBaoDouAndLength")
    @ResponseBody
    public ApiResult addBaoDouAndLength(@RequestBody StarChainAddOneLengthCmd qry) {
        return starChainService.addBaoDouAndLength(qry);
    }

}
