package com.ekangji.policy.web.insurance;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.IInsuranceProductService;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductTypeVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductVO;
import com.ekangji.policy.dto.command.insurance.product.*;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

/**
 * 保险产品相关接口

 */
@Slf4j
@Api(tags = "保险产品相关接口")
@Controller
@RequestMapping("/insurance/product")
public class ProductController {

    @Resource
    private IInsuranceProductService productService;


    /**
     * 根据保司ID-产品下拉列表查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_PRODUCT_DROP_LIST",desc = "保司产品下拉列表查询")
    @ApiOperation(value = "queryDropList", notes = "保司产品下拉列表查询")
    @RequestMapping(value = "queryDropList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<InsuranceProductDropListVO>> queryDropList(@RequestBody @Validated InsuranceProductByCompanyIdQry qry) {
        return productService.queryDropList(qry);
    }

    /**
     * 根据保险产品获取保险产品类型
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_PRODUCT_TYPE",desc = "保险产品类型查询")
    @ApiOperation(value = "queryProductType", notes = "保险产品类型查询")
    @RequestMapping(value = "queryProductType", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<InsuranceProductTypeVO> queryProductType(@RequestBody @Validated InsuranceProductTypeByProductIdQry qry) {
        return productService.queryProductType(qry);
    }

    /**
     * 产品列表查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_PRODUCT_QUERY_LIST",desc = "产品列表查询")
    @ApiOperation(value = "queryList", notes = "产品列表查询")
    @RequestMapping(value = "queryList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<InsuranceProductVO>> queryList(@RequestBody InsuranceProductQry qry) {
        return productService.queryList(qry);
    }

    /**
     * 产品分页查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_PRODUCT_QUERY_PAGE",desc = "产品分页查询")
    @ApiOperation(value = "queryPage", notes = "产品分页查询")
    @RequestMapping(value = "queryPage", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<InsuranceProductVO>> queryPage(@RequestBody InsuranceProductPageQry qry) {
        return productService.queryPage(qry);
    }

    /**
     * 通过产品名称查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_PRODUCT_QUERY_BY_PRODUCT_NAME",desc = "通过产品名称查询")
    @ApiOperation(value = "queryByProductName", notes = "通过产品名称查询")
    @RequestMapping(value = "queryByProductName", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<InsuranceProductVO> queryByProductName(@RequestBody @Validated InsuranceProductQry qry) {
        return ApiResult.of(productService.queryByProductName(qry));
    }

    /**
     * 通过id查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "INSURANCE_PRODUCT_QUERY_BY_ID",desc = "通过id查询")
    @ApiOperation(value = "queryById", notes = "通过id查询")
    @RequestMapping(value = "queryById", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<InsuranceProductVO> queryById(@RequestBody @Validated InsuranceProductByIdQry qry) {
        return productService.queryById(qry);
    }

//    /**
//     * 获取产品模板
//     *
//     * @param qry
//     * @return
//     */
//    @ApiTag(code = "OPERATION_INSURANCE_PRODUCT_DISMANTLE_TEMPLATE_LIST",desc = "获取产品模板")
//    @ApiOperation(value = "queryDismantleTemplate", notes = "获取产品模板")
//    @RequestMapping(value = "queryDismantleTemplate", method = RequestMethod.POST)
//    @ResponseBody
//    public ApiResult<ProductDismantleTemplateVO> queryDismantleTemplate(@RequestBody DismantleTempalteQry qry) {
//        return productService.queryDismantleTemplate(qry);
//    }

}

