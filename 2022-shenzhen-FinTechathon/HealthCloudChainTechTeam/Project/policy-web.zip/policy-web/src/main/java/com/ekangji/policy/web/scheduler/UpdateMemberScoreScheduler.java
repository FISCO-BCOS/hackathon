package com.ekangji.policy.web.scheduler;

import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.ekangji.policy.api.IMemberEnsuredInfoService;
import com.ekangji.policy.api.PolicyService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
public class UpdateMemberScoreScheduler extends JavaProcessor {

    @Resource
    private IMemberEnsuredInfoService memberEnsuredInfoService;

    /**
     *  更新成员个人保障分和家庭保障分  每五分钟执行一次
     *
     * @return
     */
    @Override
    public ProcessResult process(JobContext context) throws Exception {
        memberEnsuredInfoService.calculateTotalScore();
        return new ProcessResult(true);
    }

}
