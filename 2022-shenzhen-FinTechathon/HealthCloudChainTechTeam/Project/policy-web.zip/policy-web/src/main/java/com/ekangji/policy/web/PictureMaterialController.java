package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PictureMaterialService;
import com.ekangji.policy.dto.command.material.PictureMaterialQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@Slf4j
@Api(tags = "图片素材相关接口")
@RestController
@RequestMapping("/picture/material")
public class PictureMaterialController {

    @Resource
    private PictureMaterialService pictureMaterialService;

    /**
     * 获取星球或数字保单素材
     * @param qry
     * @return
     */
    @ApiTag(code = "PICTURE_MATERIAL_LIST",desc = "获取星球或数字保单素材")
    @ApiOperation(value = "获取星球或数字保单素材", notes = "获取星球或数字保单素材")
    @RequestMapping(value = "list", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult queryStarMaterial(@RequestBody @Validated PictureMaterialQry qry) {
        return pictureMaterialService.queryMaterialList(qry);
    }

}

