package com.ekangji.policy.web.picturematerial;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.file.center.client.api.FileCenterService;
import com.ekangji.policy.api.PictureMaterialService;
import com.ekangji.policy.api.StarChainService;
import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.dto.clientobject.material.PictureMaterialVO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.clientobject.starchain.ChainDetailVO;
import com.ekangji.policy.dto.command.material.*;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;
import com.ekangji.policy.dto.command.starchain.StarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.StarChainContentPageQry;
import com.ekangji.policy.dto.command.starchain.StarChainQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

/**
 * 图片素材接口
 */
@Slf4j
@Api(tags = "图片素材接口")
@Controller
@RequestMapping("/picture/material/")
public class PicMaterialController {

    @Resource
    private PictureMaterialService pictureMaterialService;

    @Resource
    private FileCenterService fileCenterService;

    /**
     *  查询列表
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "查询列表")
    @ApiOperation(value = "查询列表", notes = "查询列表")
    @RequestMapping(value = "queryList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<PictureMaterialVO>> queryList(@RequestBody @Validated PictureMaterialQry qry) {
        return pictureMaterialService.queryList(qry);
    }

    /**
     *  启用、禁用
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "启用、禁用")
    @ApiOperation(value = "启用、禁用", notes = "启用、禁用")
    @RequestMapping(value = "enableOrDisable", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult enableOrDisable(@RequestBody @Validated PictureMaterialEnableCmd qry) {
        return pictureMaterialService.enableOrDisable(qry);
    }

    /**
     *  预览
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "预览")
    @ApiOperation(value = "预览", notes = "预览")
    @RequestMapping(value = "preview", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult preview(String fileId) {
        return fileCenterService.preview(fileId);
    }

    /**
     * 添加
     *
     * @param cmd
     * @return
     */
    @ApiTag(code = "OPERATION_BLACKLIST_ADD",desc = "添加")
    @ApiOperation(value = "添加", notes = "添加")
    @RequestMapping(value = "add", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult add(@RequestBody @Validated PictureMaterialAddCmd cmd) {
        return pictureMaterialService.add(cmd);
    }

    /**
     *  编辑
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "编辑")
    @ApiOperation(value = "编辑", notes = "编辑")
    @RequestMapping(value = "edit", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult edit(@RequestBody @Validated PictureMaterialEditCmd qry) {
        return pictureMaterialService.edit(qry);
    }

    /**
     * 删除
     *
     * @param cmd
     * @return
     */
    @ApiTag(code = "OPERATION_AGENT_DELETE",desc = "删除")
    @ApiOperation(value = "删除", notes = "删除")
    @RequestMapping(value = "delete", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult delete(@RequestBody @Validated PictureMaterialDeleteCmd cmd) {
        return pictureMaterialService.delete(cmd);
    }

}
