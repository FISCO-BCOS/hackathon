package com.ekangji.policy.web.policy;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.app.service.PolicyPayDetailService;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyCDetailVO;
import com.ekangji.policy.dto.command.policy.PolicyPayLabelEditCmd;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;


@Slf4j
@Api(tags = "保单缴费详情")
@Controller
@RequestMapping("/policy/pay")
public class PolicyPayDetailController {

    @Resource
    private PolicyPayDetailService policyPayDetailService;

    /**
     * 保单缴费标签状态调整
     * @param cmd
     * @return
     */
    @ApiTag(code = "/label/update",desc = "更新缴费标签状态")
    @ApiOperation(value = "更新缴费标签状态", notes = "更新缴费标签状态")
    @RequestMapping(value = "/label/update", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updatePayLabelStatus(@RequestBody @Validated PolicyPayLabelEditCmd cmd) {
        return policyPayDetailService.updatePayLabelStatus(cmd);
    }


}
