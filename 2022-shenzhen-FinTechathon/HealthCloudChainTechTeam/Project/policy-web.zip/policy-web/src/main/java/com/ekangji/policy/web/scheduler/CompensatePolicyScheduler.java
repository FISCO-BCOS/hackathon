package com.ekangji.policy.web.scheduler;

import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.SafeguardInsuranceService;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
public class CompensatePolicyScheduler extends JavaProcessor {

    @Resource
    private PolicyService policyService;

    @Resource
    private PolicyAdditionalService policyAdditionalService;

    /**
     *  定时任务：每天定时补偿没有保司ID，产品ID，产品类别的保单数据
     *
     * @return
     */
    @Override
    public ProcessResult process(JobContext context) throws Exception {
        policyService.compensatePolicy();
        policyAdditionalService.compensateAdditionalPolicy();
        return new ProcessResult(true);
    }

}
