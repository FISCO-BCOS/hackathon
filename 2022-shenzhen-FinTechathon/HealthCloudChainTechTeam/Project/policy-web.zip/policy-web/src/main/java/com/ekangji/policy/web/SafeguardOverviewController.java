package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.ProductTypeMappingService;
import com.ekangji.policy.api.SafeguardOverviewService;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditCompareCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditRadarCmd;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;


@Slf4j
@Api(tags = "保障图配置：保障总图")
@Controller
@RequestMapping("/policySteward/safeguardOverview/")
public class SafeguardOverviewController {

    @Resource
    private PolicyService policyService;

    @Resource
    private SafeguardOverviewService safeguardOverviewService;

    /**
     *  查询指定年龄段、指定险种的用户数量
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "查询指定年龄段、指定险种的用户数量")
    @ApiOperation(value = "查询指定年龄段、指定险种的用户数量", notes = "查询指定年龄段、指定险种的用户数量")
    @RequestMapping(value = "countUserWithGuarantee", method = RequestMethod.POST)
    @ResponseBody
    public Integer countUserWithGuarantee(@RequestBody OverviewCommonQry qry) {
        return policyService.countUserWithGuarantee(qry);
    }

    /**
     *  根据年龄段和险种查询保单记录
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "根据年龄段和险种查询保单记录")
    @ApiOperation(value = "根据年龄段和险种查询保单记录", notes = "根据年龄段和险种查询保单记录")
    @RequestMapping(value = "queryPolicyByAgeBracketAndProdType", method = RequestMethod.POST)
    @ResponseBody
    public List<PolicyVO> queryPolicyByAgeBracketAndProdType(@RequestBody OverviewCommonQry qry) {
        return policyService.queryPolicyByAgeBracketAndProdType(qry);
    }

    /**
     *  更新保障总图数据
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新保障总图数据")
    @ApiOperation(value = "更新保障总图数据", notes = "更新保障总图数据")
    @RequestMapping(value = "updateOverview", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateOverview() {
        return safeguardOverviewService.updateOverview();
    }

    /**
     *  更新雷达图最大值
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新雷达图最大值")
    @ApiOperation(value = "更新雷达图最大值", notes = "更新雷达图最大值")
    @RequestMapping(value = "updateRadarValue", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateRadarValue(@RequestBody @Validated List<SafeguardOverviewEditRadarCmd> cmd) {

        try {
            safeguardOverviewService.updateRadarValue(cmd);
        } catch (Exception e) {
            return ApiResult.buildFailure(e.getMessage());
        }
        return ApiResult.buildSuccess();
    }

    /**
     *  更新是否显示对比列
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "更新是否显示对比列")
    @ApiOperation(value = "更新是否显示对比列", notes = "更新是否显示对比列")
    @RequestMapping(value = "updateCompareColumn", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateCompareColumn(@RequestBody @Validated SafeguardOverviewEditCompareCmd cmd) {
        return safeguardOverviewService.updateCompareColumn(cmd);
    }

    /**
     *  查询列表
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "查询列表")
    @ApiOperation(value = "查询列表", notes = "查询列表")
    @RequestMapping(value = "queryByAgeBracket", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<SafeguardOverviewVO>> queryByAgeBracket(@RequestBody @Validated OverviewQry qry) {
        return safeguardOverviewService.queryList(qry);
    }

}
