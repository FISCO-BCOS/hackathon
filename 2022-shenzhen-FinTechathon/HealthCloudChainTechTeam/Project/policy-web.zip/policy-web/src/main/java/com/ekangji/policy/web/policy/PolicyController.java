package com.ekangji.policy.web.policy;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.DigitalPolicyService;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.policy.PolicySimpleVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyTipsVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyCDetailVO;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyQry;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrAddCmd;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrPrefectCmd;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


@Slf4j
@Api(tags = "保单")
@Controller
@RequestMapping("/policy")
public class PolicyController {

    @Resource
    private PolicyService policyService;

    @Resource
    private PolicyAdditionalService policyAdditionalService;

    @Resource
    private DigitalPolicyService digitalPolicyService;

    /**
     * 简单上传
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_SIMPLE_ADD",desc = "保单简单上传")
    @ApiOperation(value = "保单简单上传", notes = "保单简单上传")
    @RequestMapping(value = "/simple/add", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult simpleAdd(@RequestBody @Validated PolicySimpleAddCmd cmd) {
        return policyService.simpleAdd(cmd);
    }

    /**
     * 保单快速录入
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_QUICK_ADD",desc = "保单信息快速录入")
    @ApiOperation(value = "保单信息快速录入", notes = "保单信息快速录入")
    @RequestMapping(value = "/quick/add", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult quickAdd(@RequestBody @Validated PolicyAddCmd cmd) {
        return policyService.add(cmd);
    }

    /**
     * 保单ocr识别录入
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_OCR_ADD",desc = "保单ocr识别录入")
    @ApiOperation(value = "保单ocr识别录入", notes = "保单ocr识别录入")
    @RequestMapping(value = "/ocr/add", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult ocrAdd(@RequestBody @Validated PolicyOcrAddCmd cmd) throws Exception {
        return policyService.ocrAdd(cmd);
    }

    /**
     * 保单编辑
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_EDIT",desc = "保单编辑")
    @ApiOperation(value = "保单编辑", notes = "保单编辑")
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult edit(@RequestBody @Validated PolicyEditCmd cmd) throws Exception {
        return policyService.edit(cmd);
    }

    /**
     * 保单详情
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DETAIL",desc = "保单详情")
    @ApiOperation(value = "保单详情", notes = "保单详情")
    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PolicyCDetailVO> detail(@RequestBody @Validated PolicyQry qry) {
        return policyService.policyCDetail(qry);
    }

    /**
     * 定时任务：每天定时补偿没有保司ID，产品ID，产品类别的保单数据
     * @param
     * @return
     */
    @ApiTag(code = "/quick/detail",desc = "定时任务：每天定时补偿没有保司ID，产品ID，产品类别的保单数据")
    @ApiOperation(value = "定时任务：每天定时补偿没有保司ID，产品ID，产品类别的保单数据", notes = "定时任务：每天定时补偿没有保司ID，产品ID，产品类别的保单数据")
    @RequestMapping(value = "/compensatePolicy", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult compensatePolicy() {
        policyService.compensatePolicy();
        policyAdditionalService.compensateAdditionalPolicy();
        return ApiResult.buildSuccess();
    }

    /**
     * 定时任务：更新家庭成员各类保险有效保额
     * @param
     * @return
     */
    @ApiTag(code = "/quick/detail",desc = "定时任务：更新家庭成员各类保险有效保额")
    @ApiOperation(value = "定时任务：更新家庭成员各类保险有效保额", notes = "定时任务：更新家庭成员各类保险有效保额")
    @RequestMapping(value = "/updateInsuranceAmount", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateInsuranceAmount() {
        try {
            policyService.updateInsuranceAmount();
            policyAdditionalService.updateInsuranceAmount();
        }catch (Exception e){
            return ApiResult.buildFailure(e.getMessage());
        }
        return ApiResult.buildSuccess();
    }

    /**
     * 统计保单家庭成员信息
     * @param qry
     * @return
     */
    @ApiTag(code = "/staMemberInfo",desc = "保单家庭成员信息")
    @ApiOperation(value = "保单详情", notes = "保单详情")
    @RequestMapping(value = "/staMemberInfo", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult staMemberInfo(@RequestBody @Validated PolicyQry qry) {
         //policyService.statisticsMemberInfo(qry.getPolicyId());
         return ApiResult.buildSuccess();
    }

    /**
     * 更新单个被保人的有效保额
     * @param
     * @return
     */
    @ApiTag(code = "/quick/detail",desc = "更新单个被保人的有效保额")
    @ApiOperation(value = "更新单个被保人的有效保额", notes = "更新单个被保人的有效保额")
    @RequestMapping(value = "/updateSingleInsuranceAmount", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult updateSingleInsuranceAmount(Long insurantId) {
        policyService.updateSingleInsuranceAmount(insurantId);
        policyAdditionalService.updateSingleInsuranceAmount(insurantId);
        return ApiResult.buildSuccess();
    }

    /**
     * 保单处理(接收或不接收)
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_BACKUP_HANDLING",desc = "备份保单处理")
    @ApiOperation(value = "接收或不接收备份的保单", notes = "接收或不接收备份的保单")
    @RequestMapping(value = "/backup/handling", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult policyBackupHandling(@RequestBody @Validated PolicyBackupMessageEditCmd cmd) {
        return policyService.policyBackupHandling(cmd);
    }


    /**
     * 根据家庭成员ID查询保单列表
     * @param qry
     * @return
     */
    @ApiOperation(value = "根据家庭成员ID查询保单列表")
    @RequestMapping(value = "/queryPolicyListByMemberId", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<PolicySimpleVO>> queryPolicyListByMemberId(@RequestBody @Validated FamilyMemberPolicyQry qry) {
        return policyService.queryFamilyMemberPolicyList(qry);
    }

    /**
     * 统计单个家庭成员ID保单数量及今年保费(b_policy_member_statistics)
     * @param qry
     * @return
     */
    @ApiTag(code = "STATISTICS_MEMBER_INFO",desc = "统计单个家庭成员ID保单数量及今年保费")
    @ApiOperation(value = "统计家庭成员保单数量及今年保费")
    @RequestMapping(value = "/statisticsMemberInfo", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult statisticsMemberInfo(@RequestBody @Validated UserFamilyQry qry) {
        try {
            policyService.statisticsMemberInfo(qry.getUserId(),qry.getMemberId());
        } catch (Exception e){
            log.info("statisticsMemberInfo 统计失败,userId:{},memberId:{}",qry.getUserId(),qry.getMemberId());
            log.error("statisticsMemberInfo error",e);
            return ApiResult.buildFailure("手动调用统计失败");
        }
        return ApiResult.buildSuccess();
    }

    @ApiTag(code = "DELETE_POLICY",desc = "统计单个家庭成员ID保单数量及今年保费")
    @ApiOperation(value = "删除保单")
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult logicDelete(@RequestBody @Validated PolicyDeleteCmd cmd) {
        try {
            policyService.logicDelete(cmd);
        } catch (Exception e){
          e.printStackTrace();
        }
        return ApiResult.buildSuccess();
    }

    /**
     * C端数字保单列表
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_LIST",desc = "C端数字保单列表")
    @ApiOperation(value = "C端数字保单列表", notes = "C端数字保单列表")
    @RequestMapping(value = "/digital/list", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<DigitalPolicyVO>> digitalList(@RequestBody @Validated DigitalPolicyQry qry) {
        return digitalPolicyService.queryDigitalPolicyListNew(qry);
    }

    /**
     * C端数字保单分页列表
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_PAGE_LIST",desc = "C端数字保单分页列表")
    @ApiOperation(value = "C端数字保单分页列表", notes = "C端数字保单分页列表")
    @RequestMapping(value = "/digital/page/list", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<DigitalPolicyVO>> queryDigitalPolicyPage(@RequestBody @Validated DigitalPolicyPageQry qry) {
        return digitalPolicyService.queryDigitalPolicyPage(qry);
    }

    /**
     * 运营后台数字保单列表
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_PAGE",desc = "后台数字保单列表")
    @ApiOperation(value = "后台数字保单列表", notes = "后台数字保单列表")
    @RequestMapping(value = "/digital/page", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<DigitalPolicyVO>> queryDigitalPolicyPageByCondition(@RequestBody @Validated DigitalPolicyPageQry qry) {
        return digitalPolicyService.queryDigitalPolicyPageByCondition(qry);
    }
    /**
     * 查询数字保单信息
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_INFO",desc = "查询数字保单信息")
    @ApiOperation(value = "查询数字保单信息", notes = "查询数字保单信息")
    @RequestMapping(value = "/digital/info", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<DigitalPolicyVO> queryDigitalPolicy(@RequestBody @Validated DigitalPolicyQry qry) {
        return digitalPolicyService.queryDigitalPolicy(qry);
    }
    /**
     * 根据星球id查询数字保单信息
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_INFO_STAR",desc = "根据星球id查询数字保单信息")
    @ApiOperation(value = "根据星球id查询数字保单信息", notes = "根据星球id查询数字保单信息")
    @RequestMapping(value = "/digital/star/info", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<DigitalPolicyVO> queryDigitalPolicyInfo(@RequestBody @Validated DigitalPolicyQry qry) {
        return digitalPolicyService.queryManagerDigitalPolicyList(qry);
    }
    /**
     * 简单保单详情
     * @param qry
     * @return
     */
    @ApiTag(code = "SIMPLE_POLICY_DETAIL",desc = "简单保单详情")
    @ApiOperation(value = "简单保单详情", notes = "简单保单详情")
    @RequestMapping(value = "/simple/detail", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PolicyCDetailVO> simpleDetail(@RequestBody @Validated PolicyQry qry) {
        return policyService.policyCSimpleDetail(qry);
    }

    /**
     * 简单保单快速录入完善信息
     * @param cmd
     * @return
     */
    @ApiTag(code = "SIMPLE_POLICY_PREFECT",desc = "简单保单完善信息")
    @ApiOperation(value = "简单保单完善信息", notes = "简单保单完善信息")
    @RequestMapping(value = "/simple/prefect", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult simplePrefect(@RequestBody @Validated PolicyPrefectCmd cmd) {
        return policyService.simplePrefect(cmd);
    }

    /**
     * 简单保单ocr完善信息
     * @param cmd
     * @return
     */
    @ApiTag(code = "SIMPLE_POLICY_OCR_PREFECT",desc = "简单保单ocr完善信息")
    @ApiOperation(value = "简单保单ocr完善信息", notes = "简单保单ocr完善信息")
    @RequestMapping(value = "/simple/ocr/prefect", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult simpleOcrPrefect(@RequestBody @Validated PolicyOcrPrefectCmd cmd) {
        return policyService.simpleOcrPrefect(cmd);
    }

    /**
     * 数字保单是否存在
     * @param qry
     * @return
     */
    @ApiTag(code = "DIGITAL_POLICY_IS_EXIST",desc = "数字保单是否存在")
    @ApiOperation(value = "数字保单是否存在", notes = "数字保单是否存在")
    @RequestMapping(value = "/digital/exist", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult digitalIsExist(@RequestBody @Validated PolicyQry qry) {
        return digitalPolicyService.digitalPolicyIsExist(qry);
    }

    /**
     * 运营后台数字保单列表
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_LIST1",desc = "运营后台数字保单列表")
    @ApiOperation(value = "运营后台数字保单列表", notes = "运营后台数字保单列表")
    @RequestMapping(value = "/digitalList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<DigitalPolicyVO>> digitalMangerList(@RequestBody @Validated DigitalPolicyManagerQry qry) {
        DigitalPolicyQry digitalPolicyQry=new DigitalPolicyQry();
        digitalPolicyQry.setUserId(qry.getUserId());
        return digitalPolicyService.queryDigitalPolicyList(digitalPolicyQry);
    }

    /**
     * 提示文案
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_TIPS",desc = "惠民保提示文案")
    @ApiOperation(value = "运营后台数字保单列表", notes = "惠民保提示文案")
    @RequestMapping(value = "/tips", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PolicyTipsVO> policyTips(@RequestBody @Validated PolicyHmbDetailQry qry) {
        return policyService.hmbTips(qry);
    }


    /**
     * 根据hash查询链上信息
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_DIGITAL_HASH",desc = "根据hash查询链上信息")
    @ApiOperation(value = "根据hash查询链上信息", notes = "根据hash查询链上信息")
    @RequestMapping(value = "/queryChainByHash", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<DigitalPolicyVO> queryChainByHash(@RequestBody @Validated DigitalPolicyQry qry) {
        return digitalPolicyService.queryChainByHash(qry);
    }

    /**
     * C端选择保单分页列表
     * @param qry
     * @return
     */
    @ApiTag(code = "POLICY_CHOICE_PAGE_LIST",desc = "C端选择保单分页列表")
    @ApiOperation(value = "C端数字保单分页列表", notes = "C端选择保单分页列表")
    @RequestMapping(value = "/choice/page", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<PolicyVO>> queryChoicePolicyPage(@RequestBody @Validated PolicyPageQry qry) {
        return policyService.queryChoicePolicyPage(qry);
    }

    /**
     * 保单批量导入
     * @param cmd
     * @return
     */
    @ApiTag(code = "POLICY_IMPORT_HMB",desc = "惠民保保单批量导入")
    @ApiOperation(value = "惠民保保单批量导入", notes = "惠民保保单批量导入")
    @RequestMapping(value = "/import", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<PageInfo<PolicyVO>> policyImport(@RequestBody @Validated PolicyImportAddCmd cmd) {
        return policyService.policyImport(cmd);
    }
}
