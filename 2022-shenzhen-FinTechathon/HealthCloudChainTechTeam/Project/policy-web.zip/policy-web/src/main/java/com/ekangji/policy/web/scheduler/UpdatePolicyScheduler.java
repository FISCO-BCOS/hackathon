package com.ekangji.policy.web.scheduler;

import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.SafeguardInsuranceService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
public class UpdatePolicyScheduler extends JavaProcessor {

    @Resource
    private PolicyService policyService;

    /**
     *  更新保单的保单状态以及保费-定时任务  每五分钟执行一次
     *
     * @return
     */
    @Override
    public ProcessResult process(JobContext context) throws Exception {
        policyService.updatePolicyStatus();
        policyService.updatePolicyNumAndAmount();
        return new ProcessResult(true);
    }

}
