package com.ekangji.policy.web.scheduler;

import com.alibaba.schedulerx.worker.domain.JobContext;
import com.alibaba.schedulerx.worker.processor.JavaProcessor;
import com.alibaba.schedulerx.worker.processor.ProcessResult;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.SafeguardInsuranceService;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.ApiOperation;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;


@Component
public class UpdateUnexpectedScheduler extends JavaProcessor {

    @Resource
    private SafeguardInsuranceService safeguardInsuranceService;

    /**
     *  更新数据-意外险-定时任务
     *
     * @return
     */
    @Override
    public ProcessResult process(JobContext context) throws Exception {
        safeguardInsuranceService.updateUnexpected();
        return new ProcessResult(true);
    }

}
