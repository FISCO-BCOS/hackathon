package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.command.dict.DictDataQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

/**
 * 数据字典
 */
@Slf4j
@Api(tags = "数据字典")
@Controller
@RequestMapping("/dict/data/")
public class DictDataController {

    @Resource
    private IDictDataService dictDataService;

    /**
     * 列表查询
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "DICT_DATA_QUERY_LIST",desc = "列表查询")
    @ApiOperation(value = "queryList", notes = "列表查询")
    @RequestMapping(value = "queryList", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<DictDataVO>> queryList(@RequestBody DictDataQry qry) {
        return dictDataService.queryList(qry);
    }
}
