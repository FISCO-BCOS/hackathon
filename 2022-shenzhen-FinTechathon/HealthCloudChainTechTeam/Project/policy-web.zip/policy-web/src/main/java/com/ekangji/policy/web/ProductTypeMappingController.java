package com.ekangji.policy.web;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.ProductTypeMappingService;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;


@Slf4j
@Api(tags = "保障图配置：产品类型映射")
@Controller
@RequestMapping("/policySteward/typeMapping/")
public class ProductTypeMappingController {

    @Resource
    private ProductTypeMappingService productTypeMappingService;

    /**
     * 查询所有一级类别
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "查询所有一级类别")
    @ApiOperation(value = "查询所有一级类别", notes = "查询所有一级类别")
    @RequestMapping(value = "listOneLevel", method = RequestMethod.POST)
    @ResponseBody
    public List<ProductTypeMappingVO> listOneLevel() {
        return productTypeMappingService.listOneLevel();
    }

    /**
     * 根据父类编码查询所有字类记录
     *
     * @return
     */
    @ApiTag(code = "OPERATION_LIST_ONE_LEVEL",desc = "根据父类编码查询所有字类记录")
    @ApiOperation(value = "根据父类编码查询所有字类记录", notes = "根据父类编码查询所有字类记录")
    @RequestMapping(value = "listChildrenByParentCode", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<List<ProductTypeMappingVO>> listChildrenByParentCode(@RequestBody ParentCodeQry qry) {
        return productTypeMappingService.listChildrenByParentCode(qry);
    }

}
