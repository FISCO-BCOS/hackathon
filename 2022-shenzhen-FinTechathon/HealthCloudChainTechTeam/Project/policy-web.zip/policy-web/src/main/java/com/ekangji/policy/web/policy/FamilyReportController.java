package com.ekangji.policy.web.policy;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.FamilyReportService;
import com.ekangji.policy.dto.clientobject.policy.familyreport.FamilyMemberTotalInfoVO;
import com.ekangji.policy.dto.clientobject.policy.familyreport.FamilyReportTotalInfoVO;
import com.ekangji.policy.dto.clientobject.policy.familyreport.InsuranceProductTypeAmountVO;
import com.ekangji.policy.dto.command.policy.familyreport.MemberProductTypeAmountQry;
import com.ekangji.policy.dto.command.policy.familyreport.MemberTotalInfoQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.ekangji.policy.infrastructure.aop.ApiTag;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;


@Slf4j
@Api(tags = "家庭报告")
@Controller
@RequestMapping("/family/report/")
public class FamilyReportController {

    @Resource
    private FamilyReportService familyReportService;

    /**
     * 家庭报告总计信息
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "queryTotalInfo",desc = "家庭报告总计信息")
    @ApiOperation(value = "queryTotalInfo", notes = "家庭报告总计信息")
    @RequestMapping(value = "queryTotalInfo", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<FamilyReportTotalInfoVO> queryTotalInfo(@RequestBody @Validated LoginUserInfo qry) {
        return familyReportService.findFamilyReportTotalInfo(qry);
    }

    /**
     * 家庭报告成员（被保险人）统计计信息及全部保障
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "queryMemberTotalInfo",desc = "家庭报告成员（被保险人）统计计信息及全部保障")
    @ApiOperation(value = "queryMemberTotalInfo", notes = "家庭报告成员（被保险人）统计计信息及全部保障")
    @RequestMapping(value = "queryMemberTotalInfo", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<FamilyMemberTotalInfoVO> queryMemberTotalInfo(@RequestBody @Validated MemberTotalInfoQry qry) {
        return familyReportService.findFamilyMemberTotalInfo(qry);
    }

    /**
     * 家庭报告成员（被保险人）统计计信息（某一一级类别）
     *
     * @param qry
     * @return
     */
    @ApiTag(code = "queryMemberProductTypeAmountInfo",desc = "家庭成员（被保险人）统计计信息（某一一级类别）")
    @ApiOperation(value = "queryMemberProductTypeAmountInfo", notes = "家庭成员（被保险人）统计计信息（某一一级类别）")
    @RequestMapping(value = "queryMemberProductTypeAmountInfo", method = RequestMethod.POST)
    @ResponseBody
    public ApiResult<InsuranceProductTypeAmountVO> queryMemberProductTypeAmountInfo(@RequestBody @Validated MemberProductTypeAmountQry qry) {
        return familyReportService.findMemberProductTypeAmountInfo(qry);
    }
}
