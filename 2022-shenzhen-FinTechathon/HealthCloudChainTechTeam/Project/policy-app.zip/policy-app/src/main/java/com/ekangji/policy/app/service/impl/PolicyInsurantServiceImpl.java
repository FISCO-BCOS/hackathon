package com.ekangji.policy.app.service.impl;

import com.ekangji.policy.app.convertor.PolicyInsurantCmdConvertor;
import com.ekangji.policy.app.service.PolicyInsurantService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.domain.gateway.PolicyInsurantGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.dto.command.policy.PolicyInsurantAddCmd;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PolicyInsurantServiceImpl implements PolicyInsurantService {

    @Resource
    private PolicyInsurantGateway policyInsurantGateway;

    @Resource
    private PolicyInsurantCmdConvertor policyInsurantConvertor;

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void add(Long policyId, List<PolicyInsurantAddCmd> cmdList) {
        if (CollectionUtils.isEmpty(cmdList)) {
            return;
        }
        log.info("policyId:{},被保险人保存开始...",policyId);
        List<PolicyInsurant> piList = convertData(policyId,cmdList);

        int insertNum = policyInsurantGateway.batchAdd(piList);
        log.info("policyId:{},PolicyInsurant add num:{}",policyId,insertNum);
        log.info("policyId:{},被保险人保存结束...",policyId);
    }

    @Override
    public void edit(Long policyId, List<PolicyInsurantAddCmd> cmdList) {
        log.info("被保险人编辑保存开始...policyId:{}",policyId);
        int num = policyInsurantGateway.deleteByPolicy(PolicyInsurant.builder().policyId(policyId).build());
        log.info("policy edit delete num={}",num);

        List<PolicyInsurant> piList = convertData(policyId,cmdList);

        int insertNum = policyInsurantGateway.batchAdd(piList);
        log.info("PolicyInsurant add num:{}",insertNum);
        log.info("被保险人编辑保存结束...policyId:{}",policyId);
    }

    @Override
    public List<PolicyInsurant> findByPolicy(Policy policy) {
        PolicyInsurant pi = PolicyInsurant.builder().policyId(policy.getPolicyId()).build();
        return policyInsurantGateway.findByPolicy(pi);
    }

    @Override
    public List<PolicyInsurant> queryList(PolicyInsurant policyInsurant) {
        List<PolicyInsurant> policyInsurantList = policyInsurantGateway.list(policyInsurant);
        return policyInsurantList;
    }

    private List<PolicyInsurant> convertData(Long policyId,List<PolicyInsurantAddCmd> cmdList){
        List<PolicyInsurant> piList = cmdList.stream().map(c ->{
            PolicyInsurant pi =  policyInsurantConvertor.convert(c);
            pi.setPolicyId(policyId);
            return pi;
        }).collect(Collectors.toList());
        return piList;
    }

    @Override
    public long countByAgeBracket(int ageBracket) {
        return policyInsurantGateway.countByAgeBracket(ageBracket);
    }

}
