package com.ekangji.policy.app.service.impl;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.schedulerx.shade.scala.annotation.meta.param;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.marketing.client.api.IntegralDetailRuleService;
import com.ekangji.marketing.client.api.UserIntegralDetailService;
import com.ekangji.marketing.client.api.UserIntegralService;
import com.ekangji.marketing.client.dto.clientobject.IntegralDetailRuleVO;
import com.ekangji.marketing.client.dto.clientobject.UserIntegralDetailVO;
import com.ekangji.marketing.client.dto.command.userIntegral.UserIntegralDetailInsertCmd;
import com.ekangji.marketing.client.dto.command.userIntegral.UserIntegralInsertCmd;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.api.StarChainService;
import com.ekangji.policy.app.convertor.DictDataCmdConvertor;
import com.ekangji.policy.app.convertor.DigitalPolicyCmdConvertor;
import com.ekangji.policy.app.convertor.StarChainCmdConvertor;
import com.ekangji.policy.app.convertor.StarCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.UserIntegralRuleTypeEnum;
import com.ekangji.policy.common.page.Page;
import com.ekangji.policy.common.util.HttpClientUtil;
import com.ekangji.policy.common.util.WeChatUtil;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.*;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.ekangji.policy.dto.clientobject.starchain.ChainDetailVO;
import com.ekangji.policy.dto.clientobject.starchain.CommandContentVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.starchain.*;
import com.ekangji.policy.infrastructure.convertor.UserStarConvertor;
import com.ekangji.policy.infrastructure.utils.RedisUtil;
import com.ekangji.policy.infrastructure.utils.StrUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.http.protocol.HTTP;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import springfox.documentation.spring.web.json.Json;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.ekangji.policy.common.constant.Constants.*;

/**
 * 星链
 *
 * @author xintao.li
 * @date 2021/11/28 14:05
 */
@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = StarChainService.class)
public class StarChainServiceImpl implements StarChainService {

    @Resource
    private StarChainCmdConvertor starChainCmdConvertor;

    @Resource
    private StarChainGateway starChainGateway;

    @Resource
    private UserStarGateway userStarGateway;

    @Resource
    private RelStarChainGateway relStarChainGateway;

    @Resource
    private DigitalPolicyGateway digitalPolicyGateway;

    @Resource
    private StarCmdConvertor starCmdConvertor;

    @Resource
    private DigitalPolicyCmdConvertor digitalPolicyCmdConvertor;

    @Resource
    private IntegralDetailRuleService integralDetailRuleService;

    @Resource
    private UserIntegralDetailService userIntegralDetailService;

    @Resource
    private UserIntegralService userIntegralService;

    @Resource
    private RedisUtil redisUtil;

    @Value("${wx.appid}")
    private String appId;

    @Value("${wx.appsecret}")
    private String secret;

    @Override
    public ApiResult<Long> add(StarChainAddCmd cmd) {
        StarChain starChain = starChainCmdConvertor.convert(cmd);
        StarChain oldChain = starChainGateway.get(
                StarChain.builder()
                        .userId(starChain.getUserId())
                        .build()
        );
        if (Objects.nonNull(oldChain)){
            return ApiResult.buildFailure("该用户已经存在星链");
        }
        starChain.setStarChainId(IdUtil.getSnowflakeNextId());
        Long save = starChainGateway.save(starChain);
        return ApiResult.of(starChain.getStarChainId());
    }

    @Override
    public ApiResult<ChainDetailVO> queryDetail(StarChainQry qry) {
        ChainDetailVO chainDetailVO = new ChainDetailVO();
        //查询星链的星球列表
        StarChain build = StarChain.builder()
                .userId(qry.getUserId())
                .build();
        StarChain starChain = starChainGateway.get(build);
        if (Objects.isNull(starChain)){
            log.error("用户{}未配置星链",qry.getUserId());
            return ApiResult.buildFailure("该用户未配置星链");
        }
        //查询星链下的星球列表
        RelStarChain relChain = RelStarChain.builder()
                .chainId(starChain.getStarChainId())
                .build();
        List<RelStarChain> relStarChainList = relStarChainGateway.list(relChain);
        if (CollectionUtils.isEmpty(relStarChainList)){
            log.error("用户{}的星链没有任何星球",qry.getUserId());
            return ApiResult.buildFailure("该用户的星链没有任何星球");
        }

        //计算星链长度
        int length = relStarChainList.size();

        //====文案设置=======
        Map<String, Integer> integralMap = dealIntegral(qry.getUserId());
        log.info("用户{}积分详情：{}",qry.getUserId(),integralMap);
        HashMap<String, Integer> map = new HashMap<>(16);
        //邀请一位新好友获取的保豆数量
        map.put(INVITE_ONE,integralMap.get(INVITE_ONE));
        //星链长度每增加10获得的保豆数
        map.put(ADD_NUM,integralMap.get(ADD_NUM));
        //星链长度
        map.put(LENGTH,length);
        //已获得保豆数
        map.put(OBTAINED_NUM,integralMap.get(OBTAINED_NUM));
        chainDetailVO.setContent(map);

        //====星球列表设置=======
        ArrayList<StarVO> starList = delStarList(relStarChainList);
        chainDetailVO.setStarList(starList);
        chainDetailVO.setStarChainId(starChain.getStarChainId());
        return ApiResult.of(chainDetailVO);
    }

    @Override
    public ApiResult<PageInfo<DigitalPolicyVO>> commandContent(Page page) {
        PageInfo<DigitalPolicy> pageInfo = digitalPolicyGateway.pageCommand(page);
        List<DigitalPolicy> pageInfoList = pageInfo.getList();
        if (CollectionUtils.isEmpty(pageInfoList)){
            return ApiResult.buildFailure("没有推荐内容");
        }

        for (DigitalPolicy digitalPolicy : pageInfoList){
            UserStar userStar = userStarGateway.get(
                    UserStar.builder()
                            .userId(digitalPolicy.getUserId())
                            .build()
            );
            if (Objects.isNull(userStar)){
                return ApiResult.buildFailure("脏数据：用户" + digitalPolicy.getUserId() + "保单没有星球！");
            }
            digitalPolicy.setNickName(userStar.getNickName());
            digitalPolicy.setStarFileId(userStar.getFileId());
            digitalPolicy.setStarPictureUrl(userStar.getPictureUrl());
            digitalPolicy.setStarSequence(userStar.getSequence());
        }
        PageInfo<DigitalPolicyVO> convert = digitalPolicyCmdConvertor.convert(pageInfo);
        return ApiResult.of(convert);
    }

    @Override
    public ApiResult<List<StarVO>> queryChainStarList(StarChainQry qry) {
        StarChain starChain = starChainGateway.get(StarChain.builder().userId(qry.getUserId()).build());
        if (Objects.isNull(starChain)) {
            return ApiResult.buildFailure("用户星链不存在");
        }
        List<RelStarChain> relStarChainList = relStarChainGateway.list(RelStarChain.builder()
                .chainId(starChain.getStarChainId()).build());
        List<Long> starIds = relStarChainList.stream().filter(r ->Objects.nonNull(r.getStarId())).map(RelStarChain::getStarId).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(starIds)) {
            return ApiResult.of(Collections.EMPTY_LIST);
        }
        Map<Long,Date> joinDateMap = relStarChainList.stream().collect(Collectors.toMap(RelStarChain::getStarId,RelStarChain::getCreateTime,(v1,v2)->v2));
        List<UserStar> starList = userStarGateway.listByIds(starIds);
        List<StarVO> starVOList = starCmdConvertor.convert2VO(starList);
        starVOList.forEach(starVO -> {
            starVO.setJoinTime(joinDateMap.get(starVO.getStarId()));
            starVO.setUserPhone(StrUtils.phoneDesensitization(starVO.getUserPhone()));
        });
        //先按倒叙排
        List<StarVO> sortedStarVO = starVOList.stream().sorted(Comparator.comparing(StarVO::getJoinTime,Comparator.reverseOrder())).collect(Collectors.toList());
        List<StarVO> resultStarVOList = new ArrayList<>();
        StarVO firstStarVO = sortedStarVO.get(sortedStarVO.size()- ONE);
        resultStarVOList.add(firstStarVO);
        if (starVOList.size() > ONE) {
            List<StarVO> otherStarVO = sortedStarVO.subList(ZERO,sortedStarVO.size()-ONE);
            resultStarVOList.addAll(otherStarVO);
        }
        return ApiResult.of(resultStarVOList);
    }

    /**
     * 星球表中查星链中包含的所有星球
     */
    private HashMap<Long,StarVO> listStar(List<Long> ids){
        HashMap<Long, StarVO> starMap = new HashMap<>(16);
        List<UserStar> starList = userStarGateway.listByIds(ids);
        List<StarVO> starVOList = starCmdConvertor.convert2VO(starList);
        if (CollectionUtils.isEmpty(starVOList)){
            return starMap;
        }
        for (StarVO userStar : starVOList){
            starMap.put(userStar.getStarId(),userStar);
        }
        return starMap;
    }

    /**
     * 星球列表
     * @param relStarChainList
     * @return
     */
    private ArrayList<StarVO> delStarList(List<RelStarChain> relStarChainList){
        //构建加入时间map
        HashMap<Long, Date> joinMap = new HashMap<>();
        relStarChainList.stream()
                .forEach(
                        relStarChain -> joinMap.put(relStarChain.getStarId(),relStarChain.getCreateTime())
                );
        ArrayList<StarVO> list = new ArrayList<>();
        List<Long> collect = relStarChainList
                .stream()
                .map(RelStarChain::getStarId)
                .collect(Collectors.toList());
        HashMap<Long, StarVO> userStarHashMap = listStar(collect);
        if (Objects.equals(relStarChainList.size(), Constants.ONE)){
            //星链中只有自己
            StarVO starVO = userStarHashMap.get(collect.get(0));
            starVO.setJoinTime(joinMap.get(starVO.getStarId()));
            list.add(starVO);
        }else {
            //取出最后一个星球（自己），放在第一位
            StarVO starVO1 = userStarHashMap.get(collect.get(relStarChainList.size() - 1));
            starVO1.setJoinTime(joinMap.get(starVO1.getStarId()));
            list.add(starVO1);
            //取出其余的依次排到list
            collect.stream()
                    .limit(relStarChainList.size()-1)
                    .forEach(
                            starId -> {
                                StarVO starVO = userStarHashMap.get(starId);
                                starVO.setJoinTime(joinMap.get(starVO.getStarId()));
                                list.add(starVO);
                            }
                    );
        }
        return list;
    }

    /**
     * 查询用户积分
     * @param userId
     * @return
     */
    private Map<String,Integer> dealIntegral(String userId){
        Map<String, Integer> map = new HashMap<>(16);
        List<IntegralDetailRuleVO> integralDetailRules = integralDetailRuleService.queryCurList();
        for (IntegralDetailRuleVO integralDetailRuleVO : integralDetailRules){
            //邀请加入星球
            if (Objects.equals(integralDetailRuleVO.getName(), UserIntegralRuleTypeEnum.INVITE_INTO_STAR.getMsg())){
                map.put(INVITE_ONE,integralDetailRuleVO.getAmount());
            }
            //星链长度每+10
            if (Objects.equals(integralDetailRuleVO.getName(), UserIntegralRuleTypeEnum.CHAIN_LENGTH_ADD.getMsg())){
                map.put(ADD_NUM,integralDetailRuleVO.getAmount());
            }
        }

        //查询用户的（星链长度每+10）积分流水
        Integer baodouNumadd10 = 0;
        List<UserIntegralDetailVO> userIntegralDetails = integralDetailRuleService.queryListByCondition(userId, UserIntegralRuleTypeEnum.CHAIN_LENGTH_ADD.getMsg(), ONE);
        if (CollectionUtils.isNotEmpty(userIntegralDetails)){
            Integer collect = userIntegralDetails.stream()
                    .mapToInt(UserIntegralDetailVO::getAmount)
                    .sum();
            baodouNumadd10 = collect;
        }

        //查询邀请好友加入星链获取的保豆
        Integer baodouNumInvite = 0;
        List<UserIntegralDetailVO> userIntegralDetails2 = integralDetailRuleService.queryListByCondition(userId, UserIntegralRuleTypeEnum.INVITE_INTO_STAR.getMsg(), ONE);
        if (CollectionUtils.isEmpty(userIntegralDetails2)){
            baodouNumInvite = 0;
        }else {
            Integer collect = userIntegralDetails2.stream()
                    .mapToInt(UserIntegralDetailVO::getAmount)
                    .sum();
            baodouNumInvite = collect;
        }
        map.put(OBTAINED_NUM,baodouNumInvite + baodouNumadd10);
        return map;
    }

    @Override
    public ApiResult<PageInfo<DigitalPolicyVO>> chainContent(StarChainContentPageQry qry) {
        StarChain starChain = starChainCmdConvertor.convert(qry);

        //创建Page类
        com.github.pagehelper.Page page = new com.github.pagehelper.Page(starChain.getPageNum(), starChain.getPageSize());
        List<DigitalPolicy> digitalPolicies = digitalPolicyGateway.pageChainContent(starChain);
        //为Page类中的total属性赋值
        int total = digitalPolicies.size();
        page.setTotal(total);
        //计算当前需要显示的数据下标起始值
        int startIndex = (starChain.getPageNum() - 1) * starChain.getPageSize();
        int endIndex = Math.min(startIndex + starChain.getPageSize(),total);
        //从链表中截取需要显示的子链表，并加入到Page
        page.addAll(digitalPolicies.subList(startIndex,endIndex));
        //以Page创建PageInfo
        PageInfo pageInfo = new PageInfo<>(page);

        PageInfo<DigitalPolicyVO> convert = digitalPolicyCmdConvertor.convert(pageInfo);
        return ApiResult.of(convert);
    }

    @Override
    public Integer getReceiveStarJf() {
        List<IntegralDetailRuleVO> integralDetailRules = integralDetailRuleService.queryCurList();
        for (IntegralDetailRuleVO integralDetailRuleVO : integralDetailRules){
            //邀请加入星球
            if (Objects.equals(integralDetailRuleVO.getName(), UserIntegralRuleTypeEnum.INVITE_INTO_STAR.getMsg())){
                return integralDetailRuleVO.getAmount();
            }
        }
        return null;
    }


    /**
     *
     * @param scene 携带参数，比如：starChainId=101&userId=202
     * @param page  页面 page，例如 pages/index/index，根路径前不要填加 /，不能携带参数（参数请放在 scene 字段里），如果不填写这个字段，默认跳主页面
     * @param checkPath 检查 page 是否存在，为 true 时 page 必须是已经发布的小程序存在的页面（否则报错）；为 false 时允许小程序未发布或者 page 不存在， 但 page 有数量上限（60000个）请勿滥用
     * @param envVersion 要打开的小程序版本。正式版为 release，体验版为 trial，开发版为 develop
     * @param width 二维码的宽度，单位 px，最小 280px，最大 1280px
     * @return
     */
    @Override
    public ApiResult createIntoChainQrCode(String scene,String page,Boolean checkPath,String envVersion,Integer width) {

        //获取ACCESS_TOKEN
        String accessToken = getAccessToken();

        //生成二维码
        String url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token="+ accessToken;
        Map<String,Object> params = new HashMap<>(16);
        params.put("page",page);
        params.put("scene",scene);
        params.put("check_path",checkPath);
        params.put("env_version",envVersion);
        params.put("width",width);

        //参数必须是Json格式
        String param = JSON.toJSONString(params);

        HttpResponse httpResponse = HttpRequest.post(url)
                .header(HTTP.CONTENT_TYPE, "application/json")
                .body(param)
                .execute();
        String body = httpResponse.body();
        //一定要返回字节数组，返回string会解析有误
        byte[] qrCode;
        //获取成功，微信返回的是buffer；获取失败，微信返回的是json。
        try {
            //解析json成功，说明微信方返回失败。
            JSONObject jsonObject = JSONObject.parseObject(body);

            if (Objects.equals(jsonObject.get("errcode"),40001)){
                //如果errcode是40001，说明access_token失效，重新获取
                redisUtil.delete(ACCESS_TOKEN);
                //获取ACCESS_TOKEN
                String newAccessToken = getAccessToken();

                //生成二维码
                String newUrl = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token="+ newAccessToken;
                Map<String,Object> newParams = new HashMap<>(16);
                newParams.put("page",page);
                newParams.put("scene",scene);
                newParams.put("check_path",checkPath);
                newParams.put("env_version",envVersion);
                newParams.put("width",width);

                //参数必须是Json格式
                String newParam = JSON.toJSONString(newParams);

                byte[] bodyBytes = HttpRequest.post(newUrl)
                        .header(HTTP.CONTENT_TYPE, "application/json")
                        .body(newParam)
                        .execute()
                        .bodyBytes();
                String encodeToString = Base64.getEncoder().encodeToString(bodyBytes);
                return ApiResult.of("data:image/jpeg;base64," + encodeToString);
            }else {
                //其他错误，直接返回
                return ApiResult.buildFailure(body);
            }
        }catch (Exception e){
            //解析json失败，说明微信方返回成功。
            qrCode = httpResponse.bodyBytes();
        }
        String encodeToString = Base64.getEncoder().encodeToString(qrCode);
        return ApiResult.of("data:image/jpeg;base64," + encodeToString);
    }

    /**
     * 获取ACCESS_TOKEN
     * @return
     */
    private String getAccessToken(){
        Object accessToken = redisUtil.get(Constants.ACCESS_TOKEN);
        if (Objects.isNull(accessToken)){
            accessToken = WeChatUtil.getAccessToken(appId, secret);
            redisUtil.setEx(ACCESS_TOKEN,accessToken.toString(),ACCESS_TICKET_TIMEOUT, TimeUnit.SECONDS);
        }
        return String.valueOf(accessToken);
    }

    private String getNewAccessToken(){
        redisUtil.delete(ACCESS_TOKEN);
        Object accessToken = WeChatUtil.getAccessToken(appId, secret);
        redisUtil.setEx(ACCESS_TOKEN,accessToken.toString(),ACCESS_TICKET_TIMEOUT, TimeUnit.SECONDS);
        return String.valueOf(accessToken);
    }
    @Override
    public ApiResult<Map<String, Object>> getPostFileIdAndJf(StarChainInvaiteCmd cmd) {

        HashMap<String, Object> map = new HashMap<>(16);
        //获取保豆规则
        Integer starJf = getReceiveStarJf();
        map.put("receiveStarJf",Objects.nonNull(starJf)?starJf:0);

        //星球图片地址
        UserStar userStar = userStarGateway.get(UserStar.builder().userId(cmd.getUserId()).build());
        map.put("fileId",userStar.getFileId());

        return ApiResult.of(map);
    }

    @Override
    public ApiResult lengthAddOne(StarChainAddOneLengthCmd qry) {
        StarChain starChain = starChainCmdConvertor.convert(qry);
        starChainGateway.lengthAddOne(starChain);
        return ApiResult.buildSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public ApiResult addBaoDouAndLength(StarChainAddOneLengthCmd qry) {
        log.info("加入星链入参：{}",JSON.toJSONString(qry));
        //将星球加入到星链关联表中
        try {
            relStarChainGateway.save(
                    RelStarChain.builder()
                            .relId(IdUtil.getSnowflakeNextId())
                            .chainId(qry.getChainId())
                            .starId(qry.getStarId())
                            .build()
            );
        }catch (Exception e){
            return ApiResult.buildFailure("加入星链失败");
        }


        //获取星链的当前长度
        StarChain starChain1 = StarChain.builder()
                .starChainId(qry.getChainId())
                .build();
        StarChain chain = starChainGateway.get(starChain1);
        log.info("当前星链信息：{}",JSON.toJSONString(chain));

        if (Objects.isNull(chain)){
            log.info("星链不存在");
            return ApiResult.buildFailure("星链不存在");
        }
        //查询出星链长度每加10，增加的保豆数量
        Integer baoDouNumadd10 = 0;
        //查询出邀请好友加入星链，增加的保豆数量
        Integer baoDouNumInviteFri = 0;
        List<IntegralDetailRuleVO> integralDetailRules = integralDetailRuleService.queryCurList();
        for (IntegralDetailRuleVO integralDetailRuleVO : integralDetailRules){
            //星链长度每+10
            if (Objects.equals(integralDetailRuleVO.getName(), UserIntegralRuleTypeEnum.CHAIN_LENGTH_ADD.getMsg())){
                baoDouNumadd10 = integralDetailRuleVO.getAmount();
                continue;
            }

            //邀请好友加入星链
            if (Objects.equals(integralDetailRuleVO.getName(), UserIntegralRuleTypeEnum.INVITE_INTO_STAR.getMsg())){
                baoDouNumInviteFri = integralDetailRuleVO.getAmount();
                continue;
            }
        }
        log.info("星链长度每加10，增加的保豆{}",baoDouNumadd10);
        log.info("邀请好友加入星链，增加的保豆{}",baoDouNumInviteFri);

        //积分流水详情增加：邀请好友加入星链
        UserIntegralDetailInsertCmd build = UserIntegralDetailInsertCmd.builder()
                .userId(chain.getUserId())
                .amount(baoDouNumInviteFri)
                .type(ONE)
                .source(UserIntegralRuleTypeEnum.INVITE_INTO_STAR.getMsg())
                .integralDetailId(0)
                .build();
        userIntegralDetailService.addUserIntegralDetailDmc(build);
        log.info("积分流水详情增加：邀请好友加入星链，增加的保豆信息{}",JSON.toJSONString(build));
        //积分增加
        UserIntegralInsertCmd integralInsertCmd = UserIntegralInsertCmd.builder()
                .userId(chain.getUserId())
                .amount(baoDouNumInviteFri)
                .build();
        userIntegralService.insertUserIntegralByUserId(integralInsertCmd);
        log.info("积分增加：邀请好友加入星链，增加的保豆信息{}",JSON.toJSONString(integralInsertCmd));

        Integer length = chain.getLength();
        //如果当前长度对10取余为9，则加保豆
        if (Objects.equals(length%10,9)){
            //积分流水详情增加：星链长度加10
            UserIntegralDetailInsertCmd detail = UserIntegralDetailInsertCmd.builder()
                    .userId(chain.getUserId())
                    .amount(baoDouNumadd10)
                    .type(ONE)
                    .source(UserIntegralRuleTypeEnum.CHAIN_LENGTH_ADD.getMsg())
                    .integralDetailId(0)
                    .build();
            userIntegralDetailService.addUserIntegralDetailDmc(detail);
            //积分增加：星链长度加10
            UserIntegralInsertCmd integralInsert = UserIntegralInsertCmd.builder()
                    .userId(chain.getUserId())
                    .amount(baoDouNumadd10)
                    .build();
            userIntegralService.insertUserIntegralByUserId(integralInsert);
        }

        //星链长度加一
        starChainGateway.lengthAddOne(chain);
        return ApiResult.buildSuccess();
    }

}
