package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.util.BigDecimalUtil;
import com.ekangji.common.tool.util.NumberUtil;
import com.ekangji.policy.api.UserFamilyInfoService;
import com.ekangji.policy.app.service.PolicyMemberProductTypeStatisticsService;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyMemberProductTypeStatisticsGateway;
import com.ekangji.policy.domain.gateway.UserFamilyInfoGateway;
import com.ekangji.policy.domain.policy.PolicyMemberProductTypeStatistics;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.dto.clientobject.policy.familyreport.InsuranceProductTypeDataVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.infrastructure.utils.CollectorsUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;


@Slf4j
@Service
public class PolicyMemberProductTypeStatisticsServiceImpl implements PolicyMemberProductTypeStatisticsService {

    @Resource
    private PolicyMemberProductTypeStatisticsGateway policyMemberProductTypeStatisticsGateway;

    @Resource
    private UserFamilyInfoGateway userFamilyInfoGateway;

    @Override
    public List<InsuranceProductTypeDataVO> findMemberProductTopTypeInfo(String userId, Long memberId, List<ProductTypeMappingVO> productType) {
        PolicyMemberProductTypeStatistics pmpts = PolicyMemberProductTypeStatistics.builder()
                .userId(userId).memberId(memberId).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();

        List<PolicyMemberProductTypeStatistics> boList = policyMemberProductTypeStatisticsGateway.findMemberProductTopTypeInfo(pmpts);
        ConcurrentMap<String, BigDecimal> map = boList.parallelStream().collect(Collectors.toConcurrentMap(
                PolicyMemberProductTypeStatistics::getProductTopType,PolicyMemberProductTypeStatistics::getInsuredAmountTotal));

        //全部保障下获取得一级类别保额数据值
        List<InsuranceProductTypeDataVO> dataList = productType.parallelStream().map(p ->{
            InsuranceProductTypeDataVO productTypeDataVO = new InsuranceProductTypeDataVO();
            productTypeDataVO.setProductTypeCode(p.getCode());
            productTypeDataVO.setProductTypeName(p.getName());
            BigDecimal insuredAmountTotal = map.get(p.getCode())==null?new BigDecimal(0):map.get(p.getCode());
            BigDecimal basicAmount = NumberUtil.div(insuredAmountTotal, new BigDecimal("10000")).setScale(2,BigDecimal.ROUND_DOWN);
            productTypeDataVO.setInsuredAmount(basicAmount.stripTrailingZeros());
            return productTypeDataVO;
        }).collect(Collectors.toList());
        return dataList;
    }

    public static void main(String[] args) {
        BigDecimal bigDecimal = NumberUtil.div(new BigDecimal(1.10), new BigDecimal("1"), 2);
        System.out.println(bigDecimal.stripTrailingZeros());
    }
    @Override
    public List<InsuranceProductTypeDataVO> findMemberProductTypeInfo(String userId, Long memberId,
                                                                      String productTopType, List<ProductTypeMappingVO> productType) {
        PolicyMemberProductTypeStatistics pmpts = new PolicyMemberProductTypeStatistics();
        pmpts.setMemberId(memberId);
        pmpts.setUserId(userId);
        pmpts.setProductTopType(productTopType);
        pmpts.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        List<PolicyMemberProductTypeStatistics> boList = policyMemberProductTypeStatisticsGateway.findMemberProductTypeInfo(pmpts);
        ConcurrentMap<String, BigDecimal> map = boList.stream().collect(Collectors.toConcurrentMap(
                PolicyMemberProductTypeStatistics::getProductType,PolicyMemberProductTypeStatistics::getInsuredAmountTotal));

        List<InsuranceProductTypeDataVO> dataList = productType.stream().map(p ->{
            InsuranceProductTypeDataVO categoryData = new InsuranceProductTypeDataVO();
            categoryData.setProductTypeCode(p.getCode());
            categoryData.setProductTypeName(p.getName());
            BigDecimal insuredAmountTotal = map.get(p.getMappingCode())==null?new BigDecimal(0):map.get(p.getMappingCode());
            BigDecimal basicAmount = NumberUtil.div(insuredAmountTotal, new BigDecimal("10000"));
            categoryData.setInsuredAmount(basicAmount);
            //categoryData.setInsuredAmount(insuredAmountTotal);
            return categoryData;
        }).collect(Collectors.toList());

        //分组求和
        Map<String,BigDecimal> productTypeGroupSum = dataList.stream().collect(Collectors.groupingBy(InsuranceProductTypeDataVO::getProductTypeCode,
                CollectorsUtils.summingBigDecimal1(InsuranceProductTypeDataVO::getInsuredAmount)));
        //类型去重
        List<ProductTypeMappingVO> disProductType = productType.stream().collect(
                collectingAndThen(toCollection(() -> new TreeSet<>(Comparator.comparing(ProductTypeMappingVO::getCode))),ArrayList::new)
        );
        //组装数据
        List<InsuranceProductTypeDataVO> lastRetData = disProductType.stream().map(dpt ->{
            InsuranceProductTypeDataVO categoryData = new InsuranceProductTypeDataVO();
            categoryData.setProductTypeCode(dpt.getCode());
            categoryData.setProductTypeName(dpt.getName());
            BigDecimal tmpInsuredAmount = productTypeGroupSum.get(dpt.getCode());
            BigDecimal insuredAmountTotal = Objects.isNull(tmpInsuredAmount)?new BigDecimal(0):tmpInsuredAmount;
            categoryData.setInsuredAmount(insuredAmountTotal.setScale(2,BigDecimal.ROUND_DOWN).stripTrailingZeros());
            return categoryData;
        }).collect(Collectors.toList());

        return lastRetData;
    }

    @Override
    public int updateTotalAmountPrimary(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        return policyMemberProductTypeStatisticsGateway.updateTotalAmountPrimary(policyMemberProductTypeStatistics);
    }

    @Override
    public int updateTotalAmountAddition(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        return policyMemberProductTypeStatisticsGateway.updateTotalAmountAddition(policyMemberProductTypeStatistics);
    }

    @Override
    public int add(PolicyMemberProductTypeStatistics statistics) {
//        if (Objects.nonNull(statistics.getInsuredAmount())){
//            statistics.setInsuredAmountTotal(statistics.getInsuredAmount());
//        }
//        if (Objects.nonNull(statistics.getAdditionalInsuredAmount())){
//            statistics.setInsuredAmountTotal(statistics.getAdditionalInsuredAmount());
//        }
        return Integer.valueOf(policyMemberProductTypeStatisticsGateway.save(statistics).toString());
    }

    @Override
    public int delete(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics) {
        return policyMemberProductTypeStatisticsGateway.delete(policyMemberProductTypeStatistics);
    }

    @Override
    public void update(PolicyMemberProductTypeStatistics build1) {
        policyMemberProductTypeStatisticsGateway.update(build1);
    }
}
