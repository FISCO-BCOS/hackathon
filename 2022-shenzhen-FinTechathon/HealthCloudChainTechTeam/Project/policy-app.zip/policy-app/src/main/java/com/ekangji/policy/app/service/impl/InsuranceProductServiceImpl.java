package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.bean.BeanUtil;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.api.ICompanyService;
import com.ekangji.policy.api.IInsuranceProductService;
import com.ekangji.policy.app.convertor.InsuranceProductCmdConvertor;
import com.ekangji.policy.app.service.IInsuranceProductDictService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.ProductDictEnum;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.CompanyGateway;
import com.ekangji.policy.domain.gateway.DictDataGateway;
import com.ekangji.policy.domain.gateway.InsuranceProductGateway;
import com.ekangji.policy.domain.gateway.UserGateway;
import com.ekangji.policy.domain.insurance.InsuranceCompany;
import com.ekangji.policy.domain.insurance.InsuranceProduct;
import com.ekangji.policy.dto.clientobject.insurance.product.*;
import com.ekangji.policy.dto.command.insurance.product.*;
import com.ekangji.policy.infrastructure.utils.StrUtils;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 人身险实现
 *
 * @author: 李鑫涛
 * @create: 2022/2/15 16:29
 */
@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IInsuranceProductService.class)
public class InsuranceProductServiceImpl implements IInsuranceProductService {

    @Resource
    private InsuranceProductCmdConvertor productCmdConvertor;

    @Resource
    private InsuranceProductGateway productGateway;

    @Resource
    private CompanyGateway companyGateway;

    @Resource
    private UserGateway userGateway;

    @Resource
    private IInsuranceProductDictService insuranceProductDictService;

    /**
     * 处理产品类别
     */
    private ArrayList<String> dealProductType(InsuranceProduct product) {
        ArrayList<String> prodLevels = new ArrayList<>();
        if (StringUtils.isNotBlank(product.getOneLevelType())) {
            prodLevels.add(product.getOneLevelType());
        }
        if (StringUtils.isNotBlank(product.getTwoLevelType())) {
            prodLevels.add(product.getTwoLevelType());
        }
        if (StringUtils.isNotBlank(product.getThreeLevelType())) {
            prodLevels.add(product.getThreeLevelType());
        }
        if (StringUtils.isNotBlank(product.getFourLevelType())) {
            prodLevels.add(product.getFourLevelType());
        }
        return prodLevels;
    }


    @Override
    public ApiResult<List<InsuranceProductVO>> queryList(InsuranceProductQry qry) {
        InsuranceProduct product = productCmdConvertor.convert(qry);
        List<InsuranceProduct> productList = productGateway.list(product);
        List<InsuranceProductVO> productVOList = productCmdConvertor.convert(productList);
        productVOList.stream().forEach(vo -> {
            buildVO(vo);
        });

        return ApiResult.of(productVOList);
    }

    @Override
    public ApiResult<PageInfo<InsuranceProductVO>> queryPage(InsuranceProductPageQry qry) {
        InsuranceProduct product = productCmdConvertor.convert(qry);
        PageInfo<InsuranceProduct> pageInfo = productGateway.page(product);
        PageInfo<InsuranceProductVO> voPageInfo = productCmdConvertor.convert(pageInfo);
        List<InsuranceProductVO> list = voPageInfo.getList();
        if (CollectionUtils.isEmpty(list)){
            return ApiResult.of(voPageInfo);
        }

        // 查询产品类型字典信息
        Map<String, String> productTypeMap = insuranceProductDictService.queryByType(ProductDictEnum.PRODUCT_TYPE.getCode());
        Map<String, String> insuranceStyleMap = insuranceProductDictService.queryByType(ProductDictEnum.INSURANCE_STYLE.getCode());
        Map<String, String> designTypeMap = insuranceProductDictService.queryByType(ProductDictEnum.DESIGN_TYPE.getCode());
        Map<String, String> specialMap = insuranceProductDictService.queryByType(ProductDictEnum.PRODUCT_SPECIAL_TYPE.getCode());
        Map<String, String> payWayMap = insuranceProductDictService.queryByType(ProductDictEnum.PAY_WAY.getCode());
        Map<String, String> saleTypeMap = insuranceProductDictService.queryByType(ProductDictEnum.SALE_STATUS.getCode());
        Map<String, String> timeTypeMap = insuranceProductDictService.queryByType(ProductDictEnum.INSURANCE_TIME_TYPE.getCode());


        for (InsuranceProductVO vo : list) {
            vo.setStatusDesc(CommonStatusEnum.getMsgByCode(vo.getStatus()));
            vo.setCreateName(userGateway.getUserName(vo.getCreateBy()));
            vo.setUpdateName(userGateway.getUserName(vo.getUpdateBy()));
            ArrayList<String> category = new ArrayList<>();
            StringBuilder sb = new StringBuilder();

            if (StringUtils.isNotEmpty(vo.getOneLevelType())){
                category.add(vo.getOneLevelType());
                sb.append("-");
                sb.append(productTypeMap.getOrDefault(vo.getOneLevelType(), ""));
            }
            if (StringUtils.isNotEmpty(vo.getTwoLevelType())){
                category.add(vo.getTwoLevelType());
                sb.append(productTypeMap.getOrDefault(vo.getTwoLevelType(), ""));
            }
            if (StringUtils.isNotEmpty(vo.getThreeLevelType())){
                category.add(vo.getThreeLevelType());
                sb.append(productTypeMap.getOrDefault(vo.getThreeLevelType(), ""));
            }
            if (StringUtils.isNotEmpty(vo.getFourLevelType())){
                category.add(vo.getFourLevelType());
                sb.append(productTypeMap.getOrDefault(vo.getFourLevelType(), ""));
            }
            vo.setCategory(category);
            if (sb.length() > 1){
                vo.setProductTypeDesc(sb.substring(1));
            }else {
                vo.setProductTypeDesc("");
            }
            //vo.setIsDismantleDesc(vo.getIsDismantle() == 0 ? IsDismantleEnum.NO_DISMANTLED.getMsg() : IsDismantleEnum.DISMANTLED.getMsg());
            vo.setInsuranceStyleDesc(insuranceStyleMap.getOrDefault(vo.getInsuranceStyle(), ""));
            vo.setDesignTypeDesc(designTypeMap.getOrDefault(vo.getDesignType(),""));
            vo.setProductSpecialDesc(specialMap.getOrDefault(vo.getProductSpecial(), ""));
            vo.setPayWayDesc(payWayMap.getOrDefault(vo.getPayWay(), ""));
            vo.setSaleStatusDesc(saleTypeMap.getOrDefault(vo.getSaleStatus(),""));
            vo.setTimeTypeDesc(timeTypeMap.getOrDefault(vo.getTimeType(), ""));
        }
        return ApiResult.of(voPageInfo);
    }

    @Override
    public ApiResult<InsuranceProductVO> queryById(InsuranceProductByIdQry qry) {
        InsuranceProduct product = productCmdConvertor.convert(qry);
        InsuranceProductVO vo = productCmdConvertor.convert(productGateway.getById(product));
        InsuranceCompany company = null;
        if (Objects.nonNull(vo) && StringUtils.isNotBlank(vo.getCompanyId())){
            company = companyGateway.get(InsuranceCompany.builder().companyId(vo.getCompanyId()).build());
        }
        ArrayList<String> category = new ArrayList<>();
        if (Objects.nonNull(vo)){
            if (Objects.nonNull(company)){
                vo.setCompanyName(company.getCompanyName());
            }
            if (StringUtils.isNotEmpty(vo.getOneLevelType())){
                category.add(vo.getOneLevelType());
            }
            if (StringUtils.isNotEmpty(vo.getTwoLevelType())){
                category.add(vo.getTwoLevelType());
            }
            if (StringUtils.isNotEmpty(vo.getThreeLevelType())){
                category.add(vo.getThreeLevelType());
            }
            if (StringUtils.isNotEmpty(vo.getFourLevelType())){
                category.add(vo.getFourLevelType());
            }
            vo.setStatusDesc(CommonStatusEnum.getMsgByCode(vo.getStatus()));
            vo.setCreateName(userGateway.getUserName(vo.getCreateBy()));
            vo.setUpdateName(userGateway.getUserName(vo.getUpdateBy()));
            vo.setCategory(category);
        }
        return ApiResult.of(vo);
    }

    @Override
    public ApiResult<List<InsuranceProductDropListVO>> queryDropList(InsuranceProductByCompanyIdQry qry) {
        InsuranceProduct insuranceProduct = productCmdConvertor.convert(qry);
        List<InsuranceProduct> productList = productGateway.listByCompanyId(insuranceProduct);
        List<InsuranceProductDropListVO> dropList = productList.parallelStream().map(product ->{
            InsuranceProductDropListVO dropVO = new InsuranceProductDropListVO();
            BeanUtil.copyProperties(product,dropVO);
            return dropVO;
        }).collect(Collectors.toList());
        return ApiResult.of(dropList);
    }

    @Override
    public ApiResult<InsuranceProductTypeVO> queryProductType(InsuranceProductTypeByProductIdQry qry) {
        InsuranceProduct insuranceProduct = productCmdConvertor.convert(qry);
        InsuranceProduct product = productGateway.getByProductId(insuranceProduct);
        InsuranceProductTypeVO typeVO = new InsuranceProductTypeVO();
        if (Objects.isNull(product)) {
            return ApiResult.of(typeVO);
        }

        // 查询产品类型字典信息
        Map<String, String> productTypeMap = insuranceProductDictService.queryByType(ProductDictEnum.PRODUCT_TYPE.getCode());

        List<String> typeList = new ArrayList<>();
        List<String> typeDescList = new ArrayList<>();
        String defaultValue = "";
        if (StringUtils.isNotEmpty(product.getOneLevelType())){
            typeList.add(product.getOneLevelType());
            typeDescList.add(productTypeMap.getOrDefault(product.getOneLevelType(), defaultValue));
        }
        if (StringUtils.isNotEmpty(product.getTwoLevelType())){
            typeList.add(product.getTwoLevelType());
            typeDescList.add(productTypeMap.getOrDefault(product.getTwoLevelType(), defaultValue));

        }
        if (StringUtils.isNotEmpty(product.getThreeLevelType())){
            typeList.add(product.getThreeLevelType());
            typeDescList.add(productTypeMap.getOrDefault(product.getThreeLevelType(), defaultValue));
        }
        if (StringUtils.isNotEmpty(product.getFourLevelType())){
            typeList.add(product.getFourLevelType());
            typeDescList.add(productTypeMap.getOrDefault(product.getFourLevelType(), defaultValue));
        }
        typeVO.setLevelTypeList(typeList);
        typeVO.setProductTypeDesc(StrUtils.listToString(typeDescList,Constants.SEPARATOR));
        return ApiResult.of(typeVO);
    }

    @Override
    public List<InsuranceProductVO> listByProductName(InsuranceProductQry qry) {
        InsuranceProduct insuranceProduct = productCmdConvertor.convert(qry);
        List<InsuranceProduct> insuranceProductList = productGateway.list(insuranceProduct);
        if (CollectionUtils.isNotEmpty(insuranceProductList)){
            return productCmdConvertor.convert(insuranceProductList);
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public InsuranceProductVO queryByProductName(InsuranceProductQry qry) {
        InsuranceProduct insuranceProduct = productCmdConvertor.convert(qry);
        List<InsuranceProduct> insuranceProductList = productGateway.list(insuranceProduct);

        if (CollectionUtils.isEmpty(insuranceProductList)){
          return null;
        }

        InsuranceProductVO vo = productCmdConvertor.convert(insuranceProductList.get(0));
        InsuranceCompany company = companyGateway.get(InsuranceCompany.builder().companyId(vo.getCompanyId()).build());
        // 查询产品类型字典信息
        Map<String, String> productTypeMap = insuranceProductDictService.queryByType(ProductDictEnum.PRODUCT_TYPE.getCode());

        ArrayList<String> category = new ArrayList<>();
        if (Objects.nonNull(company)) {
            vo.setCompanyName(company.getCompanyName());
            vo.setCompanyId(company.getCompanyId());
        }
        if (StringUtils.isNotEmpty(vo.getOneLevelType())) {
            category.add(vo.getOneLevelType());
            vo.setProductTypeDesc(productTypeMap.getOrDefault(vo.getOneLevelType(),""));
        }
        if (StringUtils.isNotEmpty(vo.getTwoLevelType())) {
            category.add(vo.getTwoLevelType());
        }
        if (StringUtils.isNotEmpty(vo.getThreeLevelType())) {
            category.add(vo.getThreeLevelType());
        }
        if (StringUtils.isNotEmpty(vo.getFourLevelType())) {
            category.add(vo.getFourLevelType());
        }
        vo.setCategory(category);
        return vo;
    }

    private void buildVO(InsuranceProductVO vo) {
        vo.setStatusDesc(CommonStatusEnum.getMsgByCode(vo.getStatus()));
        vo.setCreateName(userGateway.getUserName(vo.getCreateBy()));
        vo.setUpdateName(userGateway.getUserName(vo.getUpdateBy()));
        ArrayList<String> category = new ArrayList<>();
        if (StringUtils.isNotEmpty(vo.getOneLevelType())){
            category.add(vo.getOneLevelType());
        }
        if (StringUtils.isNotEmpty(vo.getTwoLevelType())){
            category.add(vo.getTwoLevelType());
        }
        if (StringUtils.isNotEmpty(vo.getThreeLevelType())){
            category.add(vo.getThreeLevelType());
        }
        if (StringUtils.isNotEmpty(vo.getFourLevelType())){
            category.add(vo.getFourLevelType());
        }

        vo.setCategory(category);
    }
}
