package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.IFamilyEnsuredInfoService;
import com.ekangji.policy.app.convertor.FamilyEnsuredInfoCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.domain.gateway.EnsuredReadConfigGateway;
import com.ekangji.policy.domain.gateway.FamilyEnsuredInfoGateway;
import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.dto.clientobject.policy.FamilyEnsureVO;
import com.ekangji.policy.dto.command.member.FamilyEnsuredCalcCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredQry;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Objects;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IFamilyEnsuredInfoService.class)
public class FamilyEnsuredInfoServiceImpl implements IFamilyEnsuredInfoService {
    @Resource
    private FamilyEnsuredInfoGateway familyEnsuredInfoGateway;
    @Resource
    private FamilyEnsuredInfoCmdConvertor familyEnsuredInfoCmdConvertor;
    @Resource
    private EnsuredReadConfigGateway ensuredReadConfigGateway;

    @Override
    public ApiResult<Long> calculateEnsuredScore(FamilyEnsuredCalcCmd familyEnsuredCalcCmd) {
        Long save = 0L;
        int update = 0;
        FamilyEnsuredInfo familyEnsuredInfo = familyEnsuredInfoGateway.selectFamilyByUserId(familyEnsuredCalcCmd.getUserId());
        if (Objects.isNull(familyEnsuredInfo)) {
            familyEnsuredInfo = familyEnsuredInfoCmdConvertor.convert(familyEnsuredCalcCmd);
            save =familyEnsuredInfoGateway.save(familyEnsuredInfo);
        } else {
            familyEnsuredInfo = familyEnsuredInfoCmdConvertor.convert(familyEnsuredCalcCmd);
            update =familyEnsuredInfoGateway.update(familyEnsuredInfo);
        }
        return ApiResult.of(save+update);
    }

    @Override
    public ApiResult<FamilyEnsureVO> myFamilyEnsureDetail(MemberEnsuredQry memberEnsuredQry) {
        FamilyEnsuredInfo familyEnsuredInfo = familyEnsuredInfoGateway.selectFamilyByUserId(memberEnsuredQry.getUserId());
        if (Objects.isNull(familyEnsuredInfo)) {
            return ApiResult.buildFailure("该用户没有保障分记录");
        }
        EnsuredReadConfig ensuredReadConfig = ensuredReadConfigGateway.selectConfigByScore(familyEnsuredInfo.getFamilyTotalScore());
        if (Objects.isNull(ensuredReadConfig)) {
            ensuredReadConfig = ensuredReadConfigGateway.selectConfigByScore(Constants.DEFAULT_SCORE);
        }
        FamilyEnsureVO familyEnsureVO = FamilyEnsureVO.builder()
                .familyEnsureScore(familyEnsuredInfo.getFamilyTotalScore())
                .lifeInsuranceScore(familyEnsuredInfo.getLifeInsuranceScore())
                .healthScore(familyEnsuredInfo.getHealthScore())
                .renteScore(familyEnsuredInfo.getRenteScore())
                .unexpectedScore(familyEnsuredInfo.getUnexpectedScore())
                .socialSecurityScore(familyEnsuredInfo.getSocialSecurityScore())
                .readContent(ensuredReadConfig.getReadContent())
                .coverTitle(ensuredReadConfig.getCoverTitle())
                .build();
        return ApiResult.of(familyEnsureVO);
    }
}
