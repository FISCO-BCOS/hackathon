package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.app.convertor.DictDataCmdConvertor;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.app.service.IInsuranceProductDictService;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.DictDataGateway;
import com.ekangji.policy.domain.gateway.UserGateway;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.command.dict.*;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * 字典数据
 *
 * @author zhangjun
 * @date 2021/11/28 14:05
 */
@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IDictDataService.class)
public class DictDataServiceImpl implements IDictDataService {


    @Resource
    private DictDataGateway dictDataGateway;

    @Resource
    private DictDataCmdConvertor dictDataCmdConvertor;

    @Resource
    private UserGateway userGateway;


    @Override
    public ApiResult add(DictDataAddCmd cmd) {
        DictData dictData = dictDataCmdConvertor.convert(cmd);
        DictData oldValue = dictDataGateway.get(DictData.builder().dictType(dictData.getDictType()).dictValue(dictData.getDictValue()).build());
        if (Objects.nonNull(oldValue)){
            return ApiResult.buildFailure("数据键值已存在");
        }
        DictData oldLabel = dictDataGateway.get(DictData.builder().dictType(dictData.getDictType()).dictLabel(dictData.getDictLabel()).build());
        if (Objects.nonNull(oldLabel)){
            return ApiResult.buildFailure("数据标签已存在");
        }
        Long save = dictDataGateway.save(dictData);
        return save > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public ApiResult delete(DictDataDeleteCmd cmd) {
        DictData dictData = dictDataCmdConvertor.convert(cmd);
        DictData oldDict = dictDataGateway.get(dictData);
        if (Objects.isNull(oldDict)){
            return ApiResult.buildFailure("数据库不存在！");
        }
        //正常状态的不能删除
        if (Objects.equals(oldDict.getStatus(),CommonStatusEnum.VALID.getCode())){
            return ApiResult.buildFailure("状态正常的字典不能删除");
        }
        int delete = dictDataGateway.delete(dictData);
        return delete > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public ApiResult edit(DictDataEditCmd cmd) {
        DictData dictData = dictDataCmdConvertor.convert(cmd);
        DictData oldData = dictDataGateway.get(DictData.builder().dictCode(dictData.getDictCode()).build());

        List<DictData> list = dictDataGateway.list(DictData.builder().dictType(oldData.getDictType()).build());

        //标签没变，看键值
        if (Objects.equals(oldData.getDictLabel(),dictData.getDictLabel())){
            if(!Objects.equals(oldData.getDictValue(),dictData.getDictValue())){
                for (DictData dictData1 : list){
                    if (Objects.equals(dictData1.getDictValue(),dictData.getDictValue())){
                        return ApiResult.buildFailure("数据键值已存在");
                    }
                }
            }
        }else {
            //标签改变，看标签
            for (DictData dictData1 : list){
                if (Objects.equals(dictData1.getDictLabel(),dictData.getDictLabel())){
                    return ApiResult.buildFailure("数据标签已存在");
                }
            }
        }
        //键值没变，看标签
        if (Objects.equals(oldData.getDictValue(),dictData.getDictValue())){
            if(!Objects.equals(oldData.getDictLabel(),dictData.getDictLabel())){
                for (DictData dictData1 : list){
                    if (Objects.equals(dictData1.getDictLabel(),dictData.getDictLabel())){
                        return ApiResult.buildFailure("数据标签已存在");
                    }
                }
            }
        }else {
            //键值改变，看键值
            for (DictData dictData1 : list){
                if (Objects.equals(dictData1.getDictValue(),dictData.getDictValue())){
                    return ApiResult.buildFailure("数据键值已存在");
                }
            }
        }

        int update = dictDataGateway.update(dictData);
        return update > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public ApiResult<List<DictDataVO>> queryList(DictDataQry qry) {
        DictData dictData = dictDataCmdConvertor.convert(qry);
        List<DictData> dictDataList = dictDataGateway.list(dictData);
        List<DictDataVO> dictDataVOList = dictDataCmdConvertor.convert(dictDataList);
        dictDataVOList.stream().forEach(vo -> {
            extracted(vo);
        });
        return ApiResult.of(dictDataVOList);
    }

    @Override
    public ApiResult<PageInfo<DictDataVO>> queryPage(DictDataPageQry qry) {
        DictData dictData = dictDataCmdConvertor.convert(qry);
        PageInfo<DictData> pageInfo = dictDataGateway.page(dictData);
        PageInfo<DictDataVO> voPageInfo = dictDataCmdConvertor.convert(pageInfo);
        voPageInfo.getList().stream().forEach(vo -> {
            extracted(vo);
        });
        return ApiResult.of(voPageInfo);
    }

    /**
     * 批量删除字典
     * @param cmd
     * @return
     */
    @Override
    public ApiResult batchDelete(DictDataBatchDeleteCmd cmd) {
        if (CollectionUtils.isEmpty(cmd.getDictCodes())){
            return ApiResult.buildFailure("请传入字典编码");
        }
        for (Long dictCode : cmd.getDictCodes()){
            DictData oldDict = dictDataGateway.get(DictData.builder().dictCode(dictCode).build());
            if (Objects.isNull(oldDict)){
                return ApiResult.buildFailure("数据库不存在"+ dictCode);
            }
            //正常状态的不能删除
            if (Objects.equals(oldDict.getStatus(),CommonStatusEnum.VALID.getCode())){
                return ApiResult.buildFailure("状态正常的字典不能删除");
            }
            dictDataGateway.delete(DictData.builder().dictCode(dictCode).build());
        }
        return ApiResult.buildSuccess();
    }

    private void extracted(DictDataVO vo) {
        vo.setStatusDesc(CommonStatusEnum.getMsgByCode(vo.getStatus()));
        vo.setCreateName(userGateway.getUserName(vo.getCreateBy()));
        vo.setUpdateName(userGateway.getUserName(vo.getUpdateBy()));
    }
}
