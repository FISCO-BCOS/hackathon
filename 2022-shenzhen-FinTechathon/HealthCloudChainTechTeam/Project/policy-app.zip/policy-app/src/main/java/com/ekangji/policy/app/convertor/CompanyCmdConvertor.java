package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.insurance.InsuranceCompany;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyEditCmd;
import com.ekangji.policy.dto.command.insurance.company.CompanyPageQry;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 */
@Mapper(componentModel = "spring")
public interface CompanyCmdConvertor {

    InsuranceCompany convert(CompanyQry param);

    InsuranceCompany convert(CompanyPageQry param);

    InsuranceCompany convert(CompanyEditCmd param);

    InsuranceCompanyVO convert(InsuranceCompany param);

    //List<InsuranceCompanyVO> convert(List<InsuranceCompany> param);

    List<InsuranceCompanyDropListVO> convert(List<InsuranceCompany> param);

    PageInfo<InsuranceCompanyVO> convert(PageInfo<InsuranceCompany> param);

}
