package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.starchain.CommandContentVO;
import com.ekangji.policy.dto.command.policy.ChainEditCmd;
import com.ekangji.policy.dto.command.policy.DigitalPolicyCmd;
import com.ekangji.policy.dto.command.policy.DigitalPolicyEditCmd;
import com.ekangji.policy.dto.command.policy.DigitalPolicyPageQry;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 */
@Mapper(componentModel = "spring")
public interface DigitalPolicyCmdConvertor {

    DigitalPolicyVO convert(DigitalPolicy digitalPolicy);

    DigitalPolicy convert(DigitalPolicyEditCmd digitalPolicy);

    DigitalPolicy convert(DigitalPolicyPageQry param);

    List<DigitalPolicyVO> convert(List<DigitalPolicy> param);

    ChainEditCmd convert(DigitalPolicyCmd digitalPolicy);

    PageInfo<DigitalPolicyVO> convert(PageInfo<DigitalPolicy> param);

    PageInfo<CommandContentVO> convert2(PageInfo<DigitalPolicy> param);
}
