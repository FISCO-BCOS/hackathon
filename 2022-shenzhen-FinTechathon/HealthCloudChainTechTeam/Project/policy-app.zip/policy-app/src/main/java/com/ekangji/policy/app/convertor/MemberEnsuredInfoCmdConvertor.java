package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.dto.clientobject.policy.MemberEnsureScoreVO;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 * @author sunqihua
 * @date 2022-05-22 14:05:49
 */
@Mapper(componentModel = "spring")
public interface MemberEnsuredInfoCmdConvertor {

    MemberEnsuredInfo convert(MemberEnsuredCalcCmd param);

    PageInfo<MemberEnsureScoreVO> convert(PageInfo<MemberEnsuredInfo> param);


}
