package com.ekangji.policy.app.service;

import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyBeneficiary;
import com.ekangji.policy.dto.command.policy.PolicyBeneficiaryAddCmd;

import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 保单受益人
 * @Date: 2022/05/20 14:05
 */
public interface PolicyBeneficiaryService {
    /**
     * 添加受益人
     * @param cmdList
     */
    void add(Long policyId, List<PolicyBeneficiaryAddCmd> cmdList);

    /**
     * 编辑受益人
     * @param cmdList
     */
    void edit(Long policyId, List<PolicyBeneficiaryAddCmd> cmdList) throws Exception;


    /**
     * 获取保单受益人
     * @param policy
     */
    List<PolicyBeneficiary> list(Policy policy);

}
