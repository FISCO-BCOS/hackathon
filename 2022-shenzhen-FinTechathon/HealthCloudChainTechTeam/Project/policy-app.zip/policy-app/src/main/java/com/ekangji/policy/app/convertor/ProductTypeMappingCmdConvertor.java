package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface ProductTypeMappingCmdConvertor {

    ProductTypeMapping convert(ParentCodeQry param);

    List<ProductTypeMappingVO> convert(List<ProductTypeMapping> param);

}
