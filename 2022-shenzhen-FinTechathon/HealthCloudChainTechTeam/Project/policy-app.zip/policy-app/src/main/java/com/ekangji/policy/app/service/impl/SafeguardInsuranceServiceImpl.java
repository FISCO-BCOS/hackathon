package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.ProductTypeMappingService;
import com.ekangji.policy.api.SafeguardInsuranceService;
import com.ekangji.policy.api.SafeguardOverviewService;
import com.ekangji.policy.app.convertor.ProductTypeMappingCmdConvertor;
import com.ekangji.policy.app.convertor.SafeguardInsuranceCmdConvertor;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import com.ekangji.policy.app.service.PolicyInsurantService;
import com.ekangji.policy.common.enums.*;
import com.ekangji.policy.domain.gateway.ProductTypeMappingGateway;
import com.ekangji.policy.domain.gateway.SafeguardInsuranceGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.policy.SafeguardInsurance;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.dto.clientobject.policy.PolicyAdditionalVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.clientobject.safeguardinsurance.SafeguardInsuranceVO;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.ekangji.policy.dto.command.safeguardinsurance.AssignValueEdit;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardinsurance.SafeguardInsuranceEditCompareValueCmd;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardInsuranceEditAssignCmd;
import com.ekangji.policy.infrastructure.utils.MathUtil;
import io.prometheus.client.Collector;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.ehcache.core.util.CollectionUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

/**
 * 产品类型映射
 *
 * @author xintao.li
 * @date 2021/11/28 14:05
 */
@Slf4j
@DubboService(version = "${policy-center.service.version}", interfaceClass = SafeguardInsuranceService.class)
public class SafeguardInsuranceServiceImpl implements SafeguardInsuranceService {


    @Resource
    private SafeguardInsuranceGateway safeguardInsuranceGateway;
    @Resource
    private SafeguardInsuranceCmdConvertor safeguardInsuranceCmdConvertor;
    @Resource
    private ProductTypeMappingService productTypeMappingService;
    @Resource
    private PolicyService policyService;
    @Resource
    private PolicyAdditionalService policyAdditionalService;
    @Resource
    private PolicyInsurantService policyInsurantService;

    @Override
    public ApiResult<List<SafeguardInsuranceVO>> queryList(InsuranceCommonQry qry) {
        SafeguardInsurance safeguardInsurance = safeguardInsuranceCmdConvertor.convert(qry);
        List<SafeguardInsurance> safeguardInsuranceList = safeguardInsuranceGateway.list(safeguardInsurance);
        return ApiResult.of(safeguardInsuranceCmdConvertor.convert(safeguardInsuranceList));
    }

    @Override
    public Map<String, Integer> listChildrenCompareValue(InsuranceCommonQry qry) {
        HashMap<String, Integer> map = new HashMap<>(16);
        ApiResult<List<SafeguardInsuranceVO>> listApiResult = queryList(qry);
        List<SafeguardInsuranceVO> list = listApiResult.getData();
        if (CollectionUtils.isEmpty(list)){
            return map;
        }
        for (SafeguardInsuranceVO safeguardInsurance : list){
            switch (safeguardInsurance.getCompareColumn()){
                case 1:
                    map.put(safeguardInsurance.getProductTypeCode(),safeguardInsurance.getAverValue());
                    break;
                case 2:
                    map.put(safeguardInsurance.getProductTypeCode(),safeguardInsurance.getMedianValue());
                    break;
                case 3:
                    map.put(safeguardInsurance.getProductTypeCode(),safeguardInsurance.getAssignValue());
                    break;
                default:
                    break;
            }
        }
        return map;
    }

    @Override
    public Map<String, Integer> listParentCompareValue(InsuranceCommonQry qry) {
        HashMap<String, Integer> map = new HashMap<>(16);
        ApiResult<List<SafeguardInsuranceVO>> listApiResult = queryList(qry);
        List<SafeguardInsuranceVO> list = listApiResult.getData();
        if (CollectionUtils.isEmpty(list)){
            return map;
        }
        for (SafeguardInsuranceVO safeguardInsurance : list){
            switch (safeguardInsurance.getCompareColumn()){
                case 1:
                    map.put(safeguardInsurance.getParentType(),safeguardInsurance.getAverValue());
                    break;
                case 2:
                    map.put(safeguardInsurance.getParentType(),safeguardInsurance.getMedianValue());
                    break;
                case 3:
                    map.put(safeguardInsurance.getParentType(),safeguardInsurance.getAssignValue());
                    break;
                default:
                    break;
            }
        }
        return map;    }


    @Override
    public ApiResult updateInsurance() {
        return null;
    }

    @Override
    public ApiResult updateAssignValue(List<SafeguardInsuranceEditAssignCmd> cmd) {
        return null;
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public ApiResult updateCompareValue(SafeguardInsuranceEditCompareValueCmd cmd) {

        SafeguardInsurance safeguardInsurance = safeguardInsuranceCmdConvertor.convert(cmd);
        //年龄段合法校验
        if (StringUtils.isBlank(AgeBracketEnum.getMsgByCode(safeguardInsurance.getAgeBracket()))){
            return ApiResult.buildFailure("年龄段非法");
        }
        //对比列合法校验
        if (StringUtils.isBlank(CompareColumnEnum.getMsgByCode(safeguardInsurance.getCompareColumn()))){
            return ApiResult.buildFailure("对比列非法");
        }
        //产品类型合法校验
        ApiResult<List<ProductTypeMappingVO>> typeCodes = productTypeMappingService.listChildrenByParentCode(new ParentCodeQry());
        List<ProductTypeMappingVO> data = typeCodes.getData();
        List<String> codeList = data.stream().map(ProductTypeMappingVO::getCode).distinct().collect(Collectors.toList());

        //对比列为指定值
        if (Objects.equals(safeguardInsurance.getCompareColumn(), CompareColumnEnum.ASSIGN.getCode())){
            //对比值为空，提示错误
            if (CollectionUtils.isEmpty(cmd.getAssigns())){
                return ApiResult.buildFailure("请输入指定值");
            }
            for (AssignValueEdit assignValueEdit : cmd.getAssigns()){
                if (!codeList.contains(assignValueEdit.getProductTypeCode())){
                    return ApiResult.buildFailure("产品类型非法");
                }
                if (assignValueEdit.getAssignValue()<=0 || assignValueEdit.getAssignValue()>1000){
                    return ApiResult.buildFailure("请输入小于等于1000的正整数");
                }
            }
            for (AssignValueEdit assignValueEdit : cmd.getAssigns()){
                safeguardInsurance.setAssignValue(assignValueEdit.getAssignValue());
                safeguardInsurance.setProductTypeCode(assignValueEdit.getProductTypeCode());
                safeguardInsuranceGateway.update(safeguardInsurance);
            }
        }
        //对比列为均值或中位数值，直接更新对比列
        safeguardInsuranceGateway.update(safeguardInsurance);
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult updateHealth() {
        long starTime = System.currentTimeMillis();
        log.info("健康险-保障图更新数据开始，time={}",new Date());
        //获取健康险对应的子项
        ParentCodeQry healthType = ParentCodeQry.builder()
                .parentCode(ScoreTypeEnum.HEALTH.getCode())
                .build();
        ApiResult<List<ProductTypeMappingVO>> listChildren = productTypeMappingService.listChildrenByParentCode(healthType);
        List<ProductTypeMappingVO> data = listChildren.getData();
        if (CollectionUtils.isEmpty(data)){
            log.info("没有获取到健康险对应的子类别，请配置");
            return ApiResult.buildFailure("没有获取到健康险对应的子类别，请配置");
        }

        //处理更新数据，保存
        int count = dealUpdate(data);

        long endTime = System.currentTimeMillis();
        log.info("健康险-保障图更新数据结束，time={}，耗时={}毫秒，更新了{}条数据",new Date(),endTime-starTime,count);
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult updateLifeInsurance() {
        long starTime = System.currentTimeMillis();
        log.info("人寿险-保障图更新数据开始，time={}",new Date());
        //获取人寿险对应的子项
        ParentCodeQry lifeInsuranceCode = ParentCodeQry.builder()
                .parentCode(ScoreTypeEnum.LIFEINSURANCE.getCode())
                .build();
        ApiResult<List<ProductTypeMappingVO>> listChildren = productTypeMappingService.listChildrenByParentCode(lifeInsuranceCode);
        List<ProductTypeMappingVO> data = listChildren.getData();
        if (CollectionUtils.isEmpty(data)){
            log.info("没有获取到人寿险对应的子类别，请配置");
            return ApiResult.buildFailure("没有获取到人寿险对应的子类别，请配置");
        }

        //处理更新数据，保存
        int count = dealUpdate(data);

        long endTime = System.currentTimeMillis();
        log.info("人寿险-保障图更新数据结束，time={}，耗时={}毫秒，更新了{}条数据",new Date(),endTime-starTime,count);
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult updateUnexpected() {
        long starTime = System.currentTimeMillis();
        log.info("意外险-保障图更新数据开始，time={}",new Date());
        //获取意外险对应的子项
        ParentCodeQry unexpectedCode = ParentCodeQry.builder()
                .parentCode(ScoreTypeEnum.UNEXPECTED.getCode())
                .build();
        ApiResult<List<ProductTypeMappingVO>> listChildren = productTypeMappingService.listChildrenByParentCode(unexpectedCode);
        List<ProductTypeMappingVO> data = listChildren.getData();
        if (CollectionUtils.isEmpty(data)){
            log.info("没有获取到意外险对应的子类别，请配置");
            return ApiResult.buildFailure("没有获取到意外险对应的子类别，请配置");
        }

        //处理更新数据，保存
        int count = dealUpdate(data);

        long endTime = System.currentTimeMillis();
        log.info("意外险-保障图更新数据结束，time={}，耗时={}毫秒，更新了{}条数据",new Date(),endTime-starTime,count);
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult updateAnnuity() {
        long starTime = System.currentTimeMillis();
        log.info("年金险-保障图更新数据开始，time={}",new Date());
        //获取年金险对应的子项
        ParentCodeQry renteCode = ParentCodeQry.builder()
                .parentCode(ScoreTypeEnum.RENTE.getCode())
                .build();
        ApiResult<List<ProductTypeMappingVO>> listChildren = productTypeMappingService.listChildrenByParentCode(renteCode);
        List<ProductTypeMappingVO> data = listChildren.getData();
        if (CollectionUtils.isEmpty(data)){
            log.info("没有获取到年金险对应的子类别，请配置");
            return ApiResult.buildFailure("没有获取到年金险对应的子类别，请配置");
        }

        //处理更新数据，保存
        int count = dealUpdate(data);

        long endTime = System.currentTimeMillis();
        log.info("意外险-保障图更新数据结束，time={}，耗时={}毫秒，更新了{}条数据",new Date(),endTime-starTime,count);
        return ApiResult.buildSuccess();
    }

    /**
     * 处理更新数据，保存
     * @param data
     * @return
     */
    private int dealUpdate(List<ProductTypeMappingVO> data) {
        int count = 0;
        Map<String, String> collect = data.stream().collect(
                Collectors.toMap(ProductTypeMappingVO::getCode, ProductTypeMappingVO::getMappingCode,(a,b)->a+","+b));
        Set<Map.Entry<String, String>> entries = collect.entrySet();
        //创建产品类别映射map
        HashMap<String, ArrayList<String>> map = new HashMap<>(16);
        for (Map.Entry<String, String> entry : entries){
            ArrayList<String> codeList = new ArrayList<>();
            String entryValue = entry.getValue();
            if (entryValue.contains(",")){
                String[] split = entryValue.split(",");
                for (String  s : split){
                    codeList.add(s);
                }

            }else {
                codeList.add(entry.getValue());
            }
            map.put(entry.getKey(),codeList);
        }
        Set<Map.Entry<String, ArrayList<String>>> sets = map.entrySet();
        //遍历年龄段
        for (int i = 1; i<= AgeBracketEnum.values().length; i++){
            //遍历子类别
            for (Map.Entry<String, ArrayList<String>> entry : sets){

                Map<Integer,Integer> statisticValues = queryStatisticValues(entry.getValue(),i);
                //封装数据
                SafeguardInsurance safeguardInsurance = SafeguardInsurance.builder()
                        .productTypeCode(entry.getKey())
                        .ageBracket(i)
                        .averValue(statisticValues.get(StatisticsValueEnum.AVER.getCode()))
                        .medianValue(statisticValues.get(StatisticsValueEnum.MEDIAN.getCode()))
                        .maxValue(statisticValues.get(StatisticsValueEnum.MAX.getCode()))
                        .minValue(statisticValues.get(StatisticsValueEnum.MIN.getCode()))
                        .build();
                //更新
                count += safeguardInsuranceGateway.update(safeguardInsurance);
            }
        }
        return count;
    }


    /**
     * 查询统计数据
     * @param codes
     * @param ageBracket
     * @return
     */
    private Map<Integer, Integer> queryStatisticValues(List<String> codes, int ageBracket) {
        HashMap<Integer, Integer> map = new HashMap<>(16);
        //保额之和
        BigDecimal policyAmount = BigDecimal.ZERO;
        //保额列表
        List<BigDecimal> amountList = new ArrayList<>();
        //保单列表
        ArrayList<PolicyVO> policyVOS = new ArrayList<>();

        for (String code : codes){
            //某种类型、某个年龄段的保额之和
            BigDecimal totalThisAmount = BigDecimal.ZERO;
            OverviewCommonQry commonQry = OverviewCommonQry.builder()
                    .ageBracket(ageBracket)
                    .status(CommonStatusEnum.VALID.getCode())
                    .typeCode(code)
                    .topLevel(YESORNOEnum.NO.getCode())
                    .build();

            //查询出指定年龄段、指定类别在保障中的保单
            List<PolicyVO> policyVOList = policyService.queryPolicyByAgeBracketAndProdType(commonQry);
            policyVOS.addAll(policyVOList);

       }

        ConcurrentMap<Long, List<PolicyVO>> collect1 = policyVOS.stream()
                .distinct()
                .collect(Collectors.groupingByConcurrent(PolicyVO::getInsurantId));

        //过滤重复保单列表
        List<PolicyVO> distinctColl = policyVOS.stream()
                .distinct()
                .collect(Collectors.toList());

        if (CollectionUtils.isNotEmpty(distinctColl)) {
            //计算保额之和
            for (PolicyVO policyVO : distinctColl) {
                policyAmount = policyAmount.add(policyVO.getInsuredAmount());
            }
        }
        //计算在保人数
        long insuranceCount = distinctColl.stream()
                .map(PolicyVO::getInsurantId)
                .distinct()
                .count();
        Set<Map.Entry<Long, List<PolicyVO>>> entries = collect1.entrySet();
        for (Map.Entry<Long, List<PolicyVO>> entry : entries){
            List<BigDecimal> collect = entry.getValue().stream()
                    .map(PolicyVO::getInsuredAmount)
                    .collect(Collectors.toList());
            BigDecimal amount = BigDecimal.ZERO;
            for (BigDecimal b : collect){
                amount = amount.add(b);
            }
            amountList.add(amount);
        }
        log.info("年龄段={}，保额之和={}",ageBracket,policyAmount);

        //计算均值
        long aver = MathUtil.aver(policyAmount, insuranceCount);
        log.info("用户均值={}",aver);
        //计算中位数值
        long median =  CollectionUtils.isNotEmpty(amountList)?MathUtil.medianDecimal(amountList):0;
        log.info("用户中位数值={}",median);
        //计算最小值
        long min =  CollectionUtils.isNotEmpty(amountList)?MathUtil.min(amountList):0;
        log.info("用户最小值={}",min);
        //计算最大值
        long max =  CollectionUtils.isNotEmpty(amountList)?MathUtil.max(amountList):0;
        log.info("用户最大值={}",max);

        map.put(StatisticsValueEnum.AVER.getCode(),(int) (aver/10000));
        map.put(StatisticsValueEnum.MEDIAN.getCode(),(int) (median/10000));
        map.put(StatisticsValueEnum.MAX.getCode(),(int) (max/10000));
        map.put(StatisticsValueEnum.MIN.getCode(),(int) (min/10000));

        return map;
    }
}
