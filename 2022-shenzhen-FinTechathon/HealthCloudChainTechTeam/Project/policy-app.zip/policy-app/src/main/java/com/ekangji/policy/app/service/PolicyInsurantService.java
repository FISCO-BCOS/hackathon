package com.ekangji.policy.app.service;

import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.dto.command.policy.PolicyInsurantAddCmd;

import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 保单被保险人
 * @Date: 2022/06/01 14:05
 */
public interface PolicyInsurantService {

    /**
     * 根据年龄段计算被保人数量
     * @param ageBracket
     * @return
     */
    long countByAgeBracket(int ageBracket);

    /**
     * 添加被保人
     *
     * @param cmdList
     */
    void add(Long policyId, List<PolicyInsurantAddCmd> cmdList);

    /**
     * 编辑被保人
     *
     * @param policyId
     * @param insurant
     */
    void edit(Long policyId, List<PolicyInsurantAddCmd> insurant);

    /**
     * 获取主险被保险人
     *
     * @param policy
     * @return
     */
    List<PolicyInsurant> findByPolicy(Policy policy);

    /**
     * 查询记录
     *
     * @param policyInsurant
     * @return
     */
    List<PolicyInsurant> queryList(PolicyInsurant policyInsurant);

}
