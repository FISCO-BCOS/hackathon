package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.api.RelPolicyPeopleService;
import com.ekangji.policy.app.convertor.RelPolicyPeopleCmdConvertor;
import com.ekangji.policy.common.constant.RedisKeys;
import com.ekangji.policy.common.enums.CustomerTypeEnum;
import com.ekangji.policy.common.enums.ProductCodeEnum;
import com.ekangji.policy.domain.gateway.InsuranceInfoGateway;
import com.ekangji.policy.domain.gateway.RelPolicyPeopleGateway;
import com.ekangji.policy.domain.policy.InsuranceInfo;
import com.ekangji.policy.domain.policy.RelPolicyPeople;
import com.ekangji.policy.dto.clientobject.policy.InsuredRankingVO;
import com.ekangji.policy.dto.clientobject.policy.RelPolicyPeopleVO;
import com.ekangji.policy.dto.command.policy.EditRelPolicyPeopleCmd;
import com.ekangji.policy.dto.command.policy.QueryPolicyPeopleCmd;
import com.ekangji.policy.infrastructure.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: wjx
 * @Desc: 玉惠保保单人员关系
 * @Date: 2022/05/16 11:05
 */
@Slf4j
@DubboService(version = "${policy-center.service.version}", interfaceClass = RelPolicyPeopleService.class)
public class RelPolicyPeopleServiceImpl implements RelPolicyPeopleService {

    @Resource
    private RelPolicyPeopleGateway relPolicyPeopleGateway;

    @Resource
    private RelPolicyPeopleCmdConvertor relPolicyPeopleCmdConvertor;

    @Resource
    private InsuranceInfoGateway insuranceInfoGateway;

    @Override
    public ApiResult<List<RelPolicyPeopleVO>> queryPolicyPeopleInfo(QueryPolicyPeopleCmd cmd) {
        if (StringUtils.isBlank(cmd.getName()) || StringUtils.isBlank(cmd.getIdNo())) {
            return ApiResult.buildFailure("姓名或身份证号不能为空");
        }
        // 根据条件查出投保单号
        RelPolicyPeople convert = relPolicyPeopleCmdConvertor.convert(cmd);
        convert.setRoleFlag(Integer.valueOf(CustomerTypeEnum.INSURED.getCode()));
        convert.setProductCode(ProductCodeEnum.YHB.getCode());
        convert.setStatus(CommonStatusEnum.VALID.getCode());
        List<RelPolicyPeople> insuredList = relPolicyPeopleGateway.list(convert);
        if (CollectionUtils.isEmpty(insuredList)) {
            List<RelPolicyPeopleVO> relPolicyPeopleVOS = relPolicyPeopleCmdConvertor.convert(insuredList);
            return ApiResult.of(relPolicyPeopleVOS);
        }

        //根据投保单号查出结果
        String quotationNo = insuredList.get(0).getQuotationNo();
        convert = new RelPolicyPeople();
        convert.setRoleFlag(Integer.valueOf(CustomerTypeEnum.POLICY_HOLDER.getCode()));
        convert.setQuotationNo(quotationNo);
        convert.setProductCode(ProductCodeEnum.YHB.getCode());
        convert.setStatus(CommonStatusEnum.VALID.getCode());
        List<RelPolicyPeople> policyHolderList = relPolicyPeopleGateway.list(convert);
        policyHolderList.addAll(insuredList);
        return ApiResult.of(relPolicyPeopleCmdConvertor.convert(policyHolderList));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ApiResult<String> edit(EditRelPolicyPeopleCmd cmd) {
        if (StringUtils.isBlank(cmd.getIdNo()) || StringUtils.isBlank(cmd.getQuotationNo())) {
            return ApiResult.buildFailure("身份证号或投保单号不能为空");
        }
        // 保单解析数据
        RelPolicyPeople convert = relPolicyPeopleCmdConvertor.convert(cmd);
        relPolicyPeopleGateway.update(convert);
        // 大屏数据查询太过频繁 改为物理删除
        InsuranceInfo insuranceInfo = new InsuranceInfo();
        insuranceInfo.setQuotationNo(cmd.getQuotationNo());
        insuranceInfo.setIdNo(cmd.getIdNo());
        insuranceInfoGateway.delete(insuranceInfo);
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult<InsuredRankingVO> queryInsuredRanking(Long id) {
        RelPolicyPeople relPolicyPeople = new RelPolicyPeople();
        relPolicyPeople.setId(id);
        RelPolicyPeople policyPeople = relPolicyPeopleGateway.get(relPolicyPeople);
        if (policyPeople == null) {
            return ApiResult.buildFailure("未查询到用户信息");
        }

        long count = relPolicyPeopleGateway.countSumLine();

        InsuredRankingVO result = new InsuredRankingVO();

        result.setIdNo(policyPeople.getIdNo());
        result.setQuotationNo(policyPeople.getQuotationNo());
        result.setRankingNum(0L);
        result.setSumNum(0L);
        result.setName(policyPeople.getName());
        if (count < 1){
            return ApiResult.of(result);
        }
        try {
            long lineNum = relPolicyPeopleGateway.queryInsuredInLine(id);
            result.setSumNum(count);
            result.setRankingNum(lineNum);
            return ApiResult.of(result);
        }catch (Exception e){
            result.setSumNum(count);
            result.setRankingNum(0L);
            return ApiResult.of(result);
        }
    }
}
