package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSON;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.bean.BeanUtil;
import com.ekangji.common.tool.enums.ResultCodeEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.api.PolicyBackupMessageService;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.app.convertor.PolicyBackupMessageCmdConvertor;
import com.ekangji.policy.app.service.PolicyUserRelationService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.PolicyBackupStatusEnum;
import com.ekangji.policy.common.enums.PolicyReceiveStatusEnum;
import com.ekangji.policy.domain.gateway.PolicyBackupMessageGateway;
import com.ekangji.policy.domain.gateway.PolicyGateway;
import com.ekangji.policy.domain.gateway.PolicyInsurantGateway;
import com.ekangji.policy.domain.gateway.UserFamilyInfoGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.dto.clientobject.policy.PolicyBackupValidationVO;
import com.ekangji.policy.dto.clientobject.policy.ToReceivePolicyVO;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageAddCmd;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.backup.ToBeBackupPolicyQry;
import com.ekangji.policy.dto.command.policy.backup.ToReceivePolicyQry;
import com.ekangji.policy.infrastructure.utils.StrUtils;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.api.UserInfoService;
import com.ekangji.user.center.client.dto.clientobject.UserChannelInfoVO;
import com.ekangji.user.center.client.dto.command.UserInfoQry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.validation.ValidationException;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = PolicyBackupMessageService.class)
public class PolicyBackupMessageServiceImpl implements PolicyBackupMessageService {

    @Resource
    private PolicyBackupMessageGateway policyBackupMessageGateway;

    @Resource
    private PolicyBackupMessageCmdConvertor policyBackupMessageCmdConvertor;

    @Resource
    private UserChannelInfoService userChannelInfoService;

    @Resource
    private UserInfoService userInfoService;

    @Resource
    private PolicyUserRelationService policyUserRelationService;

    @Resource
    private PolicyGateway policyGateway;

    @Resource
    private PolicyInsurantGateway policyInsurantGateway;

    @Resource
    private UserFamilyInfoGateway userFamilyInfoGateway;


    /**
     * 备份保单前置校验：
     * 1 接收人手机号不能是当前登录用户的
     * 2 根据接收人手机号 查出其已接收的备份保单数量
     * 3 根据接收人手机号 查出其待接收的备份保单数量
     * 4 过滤本次可备份的保单信息，拼接成简述
     *
     * @param qry
     * @return
     */
    @Override
    public ApiResult<PolicyBackupValidationVO> validateBeforeBackup(ToBeBackupPolicyQry qry) {
        // 用户ID不能为空
        if (StringUtils.isBlank(qry.getUserId())) {
            return ApiResult.buildFailure(ResultCodeEnum.UNAUTHO_ERROR.getMsg());
        }
        // 先校验手机号
        String receiverPhoneNumber = qry.getReceiverPhoneNumber();
        ApiResult<String> queryPhoneNumberResult = userChannelInfoService.getPhoneNumberByUserId(qry.getUserId());
        if (!queryPhoneNumberResult.getSuccess()) {
            return ApiResult.buildSuccess("发送人手机号不存在");
        }
        String phoneNumber = queryPhoneNumberResult.getData();
        if (receiverPhoneNumber.equals(phoneNumber)) {
            return ApiResult.buildSuccess("保单您已保存，无需备份给自己。");
        }

        List<Long> policyIds = qry.getPolicyIds();

        PolicyBackupValidationVO vo = new PolicyBackupValidationVO();
        // 待接收的保单数量
        int waitReceiveCount = 0;
        // 已接受的保单数量
        int receivedCount = 0;
        // 允许备份的保单ID集合
        List<Long> allowBackupPolicyIds = new ArrayList<>();

        // 根据保单ID数组+接收人手机号查询保单备份发起记录表
        List<PolicyBackupMessage> backupRecords = policyBackupMessageGateway.list(PolicyBackupMessage.builder()
                .policyIds(policyIds).receiveUserPhone(receiverPhoneNumber).build());

        // 若记录表无数据 说明本次选中的所有保单均可备份
        if (CollectionUtils.isEmpty(backupRecords)) {
            vo.setWaitReceiveCount(waitReceiveCount);
            vo.setReceivedCount(receivedCount);
            vo.setAllowBackupPolicyIds(policyIds);
            vo.setAllowBackupPolicyDesc(buildAllowBackupPolicyDesc(policyIds));
            return ApiResult.of(vo);
        }

        Map<Long, List<PolicyBackupMessage>> backupDetailListMap = backupRecords.stream().collect(Collectors.groupingBy(PolicyBackupMessage::getPolicyId));

        for (Long policyId : policyIds) {
            // 当前保单发起备份记录
            List<PolicyBackupMessage> currentPolicyBackupRecords = backupDetailListMap.get(policyId);
            if (CollectionUtils.isEmpty(currentPolicyBackupRecords)) {
                // 若该保单第一次备份 允许备份
                allowBackupPolicyIds.add(policyId);
                continue;
            }

            // 已拒绝数量
            long currentPolicyRejectedCount = currentPolicyBackupRecords.stream()
                    .filter(record -> Objects.equals(PolicyBackupStatusEnum.REJECTED.getCode(), record.getStatus())).count();
            // 待接收数量
            long currentPolicyWaitCount = currentPolicyBackupRecords.stream()
                    .filter(record -> Objects.equals(PolicyBackupStatusEnum.WAIT.getCode(), record.getStatus())).count();
            // 已接收数量
            long currentPolicyReceivedCount = currentPolicyBackupRecords.stream()
                    .filter(record -> Objects.equals(PolicyBackupStatusEnum.RECEIVED.getCode(), record.getStatus())).count();
            // 若发起记录全都是已拒绝 允许备份
            if (currentPolicyBackupRecords.size() == currentPolicyRejectedCount) {
                allowBackupPolicyIds.add(policyId);
                continue;
            }
            // 待接收数量
            if (currentPolicyWaitCount > 0) {
                waitReceiveCount++;
                continue;
            }
            // 已接收数量
            if (currentPolicyReceivedCount > 0) {
                receivedCount++;
            }
        }

        vo.setReceivedCount(receivedCount);
        vo.setWaitReceiveCount(waitReceiveCount);
        vo.setAllowBackupPolicyIds(allowBackupPolicyIds);
        if (CollectionUtils.isEmpty(allowBackupPolicyIds)) {
            // 可备份数量为0 不用往下走了
            return ApiResult.of(vo);
        }
        vo.setAllowBackupPolicyDesc(buildAllowBackupPolicyDesc(allowBackupPolicyIds));
        return ApiResult.of(vo);
    }

    @Override
    public ApiResult<ToReceivePolicyVO> getToReceivePolicyByUserId(ToReceivePolicyQry qry) {
        PolicyBackupMessage policyBackupMessage = new PolicyBackupMessage();
        //policyBackupMessage.setReceiveUserId(qry.getUserId());
        ApiResult<String> receivePhoneResult = userChannelInfoService.getPhoneNumberByUserId(qry.getUserId());
        if (!receivePhoneResult.getSuccess()) {
            throw new RuntimeException("请先授权手机号");
        }
        policyBackupMessage.setReceiveUserPhone(receivePhoneResult.getData());

        policyBackupMessage.setStatus(PolicyReceiveStatusEnum.TORECEIVE.getCode());
        PolicyBackupMessage pbm = policyBackupMessageGateway.countToReceivePolicy(policyBackupMessage);
        ToReceivePolicyVO toReceivePolicyVO = policyBackupMessageCmdConvertor.convert(pbm);
        ApiResult<String> phone = userChannelInfoService.getPhoneNumberByUserId(pbm.getLaunchUserId());
        String userPhone = StrUtils.phoneDesensitization(phone.getData());
        toReceivePolicyVO.setUserPhone(userPhone);
        return ApiResult.of(toReceivePolicyVO);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult policyBackupHandling(PolicyBackupMessageEditCmd cmd) {
        PolicyBackupMessage policyBackupMessage = policyBackupMessageCmdConvertor.convert(cmd);
        policyBackupMessage.setReceiveUserId(cmd.getUserId());
        if (PolicyReceiveStatusEnum.RECEIVED.getCode().equals(cmd.getStatus())) {
            policyBackupMessage.setStatus(PolicyReceiveStatusEnum.TORECEIVE.getCode());
            //将保单归属到接收人名下 复制一份原保单
            List<PolicyBackupMessage> messageList = policyBackupMessageGateway.selectToReceivePolicy(policyBackupMessage);
            if (CollectionUtils.isNotEmpty(messageList)) {
                policyUserRelationService.saveBackupPolicy(messageList);
            }
        }
        policyBackupMessage.setHandleTime(new Date());
        int update = policyBackupMessageGateway.update(policyBackupMessage);

        return update > Constants.ZERO ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

//    private void backupPolicy(List<PolicyBackupMessage> backupMessageList,String receiveUserId,String userPhone) {
//        List<Long> policyIds = backupMessageList.stream().map(PolicyBackupMessage::getPolicyId).collect(Collectors.toList());
//        List<Policy> policyList = policyGateway.list(Policy.builder().policyIds(policyIds).build());
//        for(Policy policy:policyList) {
//            policy.setId(null);
//            policy.setPolicyId(IdUtil.getSnowflakeNextId());
//            policy.setUserId();
//            policy.setUserPhone();
//        }
//    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult launchBackupPolicy(PolicyBackupMessageAddCmd cmd) {
        ToBeBackupPolicyQry qry = new ToBeBackupPolicyQry();
        BeanUtil.copyProperties(cmd, qry);

        ApiResult<PolicyBackupValidationVO> validateData = validateBeforeBackup(qry);
        if (!validateData.getSuccess() || (validateData.getSuccess() && Objects.isNull(validateData.getData()))) {
            return ApiResult.buildFailure("备份失败");
        }
        PolicyBackupValidationVO vv = validateData.getData();
        if (CollectionUtils.isEmpty(vv.getAllowBackupPolicyIds())) {
            return ApiResult.buildFailure("没有可备份的保单");
        }

        // 查询接收人用户信息 主要为了获取接收人用户ID
//        UserInfoQry userInfoQry = new UserInfoQry();
//        userInfoQry.setPhoneNumber(qry.getReceiverPhoneNumber());
//        userInfoQry.setChannelType(qry.getChannelType());
//        ApiResult<List<UserChannelInfoVO>> userInfoResult = userInfoService.queryUserChannelInfoByUserInfo(userInfoQry);
//        if (!userInfoResult.getSuccess() || CollectionUtils.isEmpty(userInfoResult.getData())) {
//            return ApiResult.buildFailure("未获取到接收人信息");
//        }

//        UserChannelInfoVO receiverUserInfo = userInfoResult.getData().get(0);
        List<PolicyBackupMessage> backupList = vv.getAllowBackupPolicyIds().stream().map(p -> {
            PolicyBackupMessage param = new PolicyBackupMessage();
            param.setMessageId(IdUtil.getSnowflakeNextId());
            param.setPolicyId(p);
            param.setLaunchUserId(qry.getUserId());
            param.setReceiveUserPhone(cmd.getReceiverPhoneNumber());
            param.setLaunchTime(new Date());
            return param;
        }).collect(Collectors.toList());
        policyBackupMessageGateway.batchSave(backupList);
        return ApiResult.buildSuccess("备份成功");
    }

    @Override
    public List<Long> selectToReceivePolicy(PolicyBackupMessageEditCmd cmd, String receiveUserPhone) {
        if (PolicyReceiveStatusEnum.RECEIVED.getCode().equals(cmd.getStatus())) {
            PolicyBackupMessage policyBackupMessage = PolicyBackupMessage.builder()
                    .launchUserId(cmd.getLaunchUserId())
                    .receiveUserPhone(receiveUserPhone)
                    .status(PolicyReceiveStatusEnum.TORECEIVE.getCode()).build();

            List<PolicyBackupMessage> messageList = policyBackupMessageGateway.selectToReceivePolicy(policyBackupMessage);
            if (CollectionUtils.isNotEmpty(messageList)) {
                return messageList.stream().map(PolicyBackupMessage::getPolicyId).collect(Collectors.toList());
            }
        }
        return Collections.emptyList();
    }

    @Override
    public ApiResult updateMessageStatus(PolicyBackupMessageEditCmd cmd, String receiveUserPhone) {
        log.info("备份：更新备份保单消息状态开始,param:{},receiveUserPhone:{}", JSON.toJSONString(cmd), receiveUserPhone);
        PolicyBackupMessage policyBackupMessage = policyBackupMessageCmdConvertor.convert(cmd);
        policyBackupMessage.setReceiveUserPhone(receiveUserPhone);
        policyBackupMessage.setHandleTime(new Date());
        policyBackupMessage.setStatus(cmd.getStatus());
        int update = policyBackupMessageGateway.update(policyBackupMessage);
        log.info("备份：更新备份保单消息状态结束,updateFlag:{},param:{},receiveUserPhone:{}", update, JSON.toJSONString(cmd), receiveUserPhone);
        return update > Constants.ZERO ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    /**
     * 组装允许备份的保单简要描述集合
     *
     * @param allowBackupPolicyIds
     * @return
     */
    private List<String> buildAllowBackupPolicyDesc(List<Long> allowBackupPolicyIds) {
        // 根据保单ID数组查询保单信息 这一步是为了获取保险产品名称
        List<Policy> policyList = policyGateway.list(Policy.builder().policyIds(allowBackupPolicyIds).build());
        // 保险产品名称map
        Map<Long, String> productNameMap = policyList.stream().collect(Collectors.toMap(Policy::getPolicyId, Policy::getProductName));
        /*
         * 根据保单ID数组查询保单与被保人关系表 得到被保人ID数组
         * 再用被保人ID数组查询家庭成员信息表
         * 这一步是为了获取被保人名称
         */
        List<PolicyInsurant> policyInsurants = policyInsurantGateway.list(PolicyInsurant.builder().policyIds(allowBackupPolicyIds).build());
        // 保单ID-被保人ID关系map
        Map<Long, Long> policyInsurantIdMap = policyInsurants.stream().collect(Collectors.toMap(PolicyInsurant::getPolicyId, PolicyInsurant::getInsurantId));
        List<Long> insurantIds = policyInsurants.stream().map(PolicyInsurant::getInsurantId).distinct().collect(Collectors.toList());
        List<UserFamilyInfo> insurantInfos = userFamilyInfoGateway.list(UserFamilyInfo.builder().memberIds(insurantIds).build());
        // 被保人ID-被保人名称map 注意处理重复key
        Map<Long, String> insurantNameMap = insurantInfos.stream().collect(Collectors.toMap(UserFamilyInfo::getMemberId, UserFamilyInfo::getNickName, (v1, v2) -> v2));
        // 允许备份的保单简要描述集合
        List<String> allowBackupPolicyDesc = new ArrayList<>();
        for (Long allowBackupPolicyId : allowBackupPolicyIds) {
            StringBuilder sb = new StringBuilder();
            // 被保人ID
            Long insurantId = policyInsurantIdMap.get(allowBackupPolicyId);
            // 被保人名称
            String insurantName = insurantNameMap.get(insurantId);
            // 保险产品名称
            String productName = productNameMap.get(allowBackupPolicyId);
            sb.append("被保人").append(insurantName).append("的").append(productName);
            allowBackupPolicyDesc.add(sb.toString());
        }
        return allowBackupPolicyDesc;
    }
}
