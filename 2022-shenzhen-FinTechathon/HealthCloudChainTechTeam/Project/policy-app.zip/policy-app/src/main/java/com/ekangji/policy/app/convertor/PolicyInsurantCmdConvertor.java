package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.PolicyInsurant;
import com.ekangji.policy.dto.command.policy.PolicyInsurantAddCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/06/01 16:21
 */
@Mapper(componentModel = "spring")
public interface PolicyInsurantCmdConvertor {

    PolicyInsurant convert(PolicyInsurantAddCmd param);

    List<PolicyInsurant> convert(List<PolicyInsurantAddCmd> param);
}
