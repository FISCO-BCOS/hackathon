package com.ekangji.policy.app.service;

import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.dto.command.policy.familyreport.MemberTotalInfoQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;

import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 成员保单信息统计
 * @Date: 2022/05/20 14:05
 */
public interface PolicyMemberStatisticsService {

    /**
     * 获取家庭保单总计信息
     * @param qry
     * @return
     */
    PolicyMemberStatistics findFamilyReportTotalInfo(LoginUserInfo qry);

    /**
     * 获取家庭成员(被保人)统计计信息
     * @param qry
     * @return
     */
    List<PolicyMemberStatistics> findFamilyMemberTotalInfo(MemberTotalInfoQry qry);

    /**
     * 更新家庭成员(被保人)的保单统计信息
     */
    void updateMemberStatisticsInfo(PolicyMemberStatistics pms);

    /**
     * 当家庭成员没有保单时删除用户保单统计信息
     * @param userId
     * @param memberId
     */
    void deleteMemberStatisticsInfo(String userId, Long memberId);
}
