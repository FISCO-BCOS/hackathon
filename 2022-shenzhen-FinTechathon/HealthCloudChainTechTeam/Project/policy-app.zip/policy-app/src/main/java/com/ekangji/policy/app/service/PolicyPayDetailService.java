package com.ekangji.policy.app.service;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.policy.PolicyPayDetail;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyPayCDetailVO;
import com.ekangji.policy.dto.command.policy.PolicyPayLabelEditCmd;

import java.util.List;

public interface PolicyPayDetailService {
    /**
     * 主险生成并添加缴费详情
     * @param policy
     */
    void add(Policy policy);

    /**
     * 附加险生成并添加缴费详情
     * @param policy
     */
    void add(Policy policy, PolicyAdditional additional);

    /**
     * 主险编辑缴费标签
     * @param policyEdit
     * @param oldPolicy
     */
    void edit(Policy policyEdit, Policy oldPolicy);

    /**
     * 删除附件险缴费标签
     * @param payDetail
     * @return
     */
    int deleteByPolicyAdditional(PolicyPayDetail payDetail);

    /**
     * 根据保单获取保费
     * @param policy
     */
    PolicyPayDetail findCurrentYearPremiumByPolicy(Policy policy);

    /**
     * 根据保单获取保费
     * @param policyList
     */
    PolicyPayDetail findCurrentYearPremiumByPolicy(List<Policy> policyList);

    /**
     * 获取保单缴费详情
     * @param policy
     */
    PolicyPayCDetailVO findPayDetailByPolicy(Policy policy);

    /**
     * 更新缴费标签缴费状态
     * @param cmd
     * @return
     */
    ApiResult updatePayLabelStatus(PolicyPayLabelEditCmd cmd);

    /**
     * 备份标签
     * @param parentPolicyId
     * @param newPolicyId
     * @param additionalId
     */
    void addBackup(Long parentPolicyId, Long newPolicyId, Long additionalId);
}
