package com.ekangji.policy.app.service;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceProductDictVO;
import com.ekangji.policy.dto.command.insurance.InsuranceProductDictCmd;

import java.util.List;
import java.util.Map;

/**
 * 保险产品字典
 */
public interface IInsuranceProductDictService {

    /**
     * 根据条件查询产品类型列表
     * @param cmd
     * @return
     */
    ApiResult<List<InsuranceProductDictVO>> queryProductTypeDict(InsuranceProductDictCmd cmd);

    /**
     * 根据字典类型获取数据
     * @return
     */
    Map<String, String> queryByType(String dictType);

}
