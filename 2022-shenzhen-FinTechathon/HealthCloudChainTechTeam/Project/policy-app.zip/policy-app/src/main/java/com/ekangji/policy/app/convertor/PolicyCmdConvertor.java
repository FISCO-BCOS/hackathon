package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.ekangji.policy.dto.clientobject.policy.PolicySimpleVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrAddCmd;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/05/18 16:21
 */
@Mapper(componentModel = "spring")
public interface PolicyCmdConvertor {

    Policy convert(PolicyAddCmd param);

    Policy convert(PolicyOcrAddCmd param);

    Policy convert(PolicyEditCmd param);

    Policy convert(PolicyDeleteCmd param);

    Policy convert(FamilyMemberPolicyQry param);

    List<PolicyVO> convert(List<Policy> param);

    List<PolicySimpleVO> convert2SimpleVO(List<Policy> param);

    PageInfo<PolicyVO> convert(PageInfo<Policy> param);

    PolicyQueryDTO convert(PolicyPageQry param);

    Policy convert(PolicyPrefectCmd param);

}
