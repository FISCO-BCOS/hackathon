package com.ekangji.policy.app.service;


import com.ekangji.policy.domain.policy.PolicyBackupRecord;

import java.util.List;

public interface PolicyBackupRecordService {

    /**
     * 保单备份记录
     * @param backupRecord
     */
    Long save(PolicyBackupRecord backupRecord);

    /**
     * 查询已接收保单记录集合
     * @param backupRecord
     * @return
     */
   List<PolicyBackupRecord> list(PolicyBackupRecord backupRecord);

    /**
     * 保单备份记录
     * @param newPolicyId
     * @param parentPolicyId
     * @param userId
     * @param userPhone
     * @param launchUserId
     * @param parentPolicyUserPhone
     * @return
     */
    Long save(Long newPolicyId, Long parentPolicyId, String userId, String userPhone, String launchUserId, String parentPolicyUserPhone);
}
