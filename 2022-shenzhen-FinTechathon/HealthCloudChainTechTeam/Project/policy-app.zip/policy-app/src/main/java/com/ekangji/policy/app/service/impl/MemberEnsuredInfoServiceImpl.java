package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.BigDecimalUtil;
import com.ekangji.common.tool.util.DesensitizedUtil;
import com.ekangji.policy.api.IFamilyEnsuredInfoService;
import com.ekangji.policy.api.SafeguardInsuranceService;
import com.ekangji.policy.api.SafeguardOverviewService;
import com.ekangji.policy.app.convertor.MemberEnsuredInfoCmdConvertor;
import com.ekangji.policy.api.IMemberEnsuredInfoService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.*;
import com.ekangji.policy.common.excel.EasyExcelUtil;
import com.ekangji.policy.domain.gateway.*;
import com.ekangji.policy.domain.policy.*;
import com.ekangji.policy.domain.policy.pojo.MemberEnsuredDTO;
import com.ekangji.policy.dto.clientobject.policy.MemberEnsureScoreExportVO;
import com.ekangji.policy.dto.clientobject.policy.MemberEnsureScoreVO;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigEditCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.ekangji.policy.dto.command.policy.MemberEnsureScoreExportQry;
import com.ekangji.policy.dto.command.policy.family.MemberEnsureScorePageQry;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.infrastructure.utils.*;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.dto.clientobject.UserChannelInfoVO;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.assertj.core.util.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.ekangji.policy.common.constant.Constants.CALC_POLICY_AMOUNT;
import static com.ekangji.policy.common.enums.ScoreTypeEnum.*;

@Slf4j
@Service
@Transactional(transactionManager = "policyCenterTransactionManager", rollbackFor = Exception.class)
@DubboService(version = "${policy-center.service.version}", interfaceClass = IMemberEnsuredInfoService.class)
public class MemberEnsuredInfoServiceImpl implements IMemberEnsuredInfoService {


    static Map<String, String> ageList = new HashMap<>();
    static List<String> oneLevelTypes = new ArrayList<>();

    static {
        ageList.put("[0,18)", "firstStage");
        ageList.put("[18,25)", "secondStage");
        ageList.put("[25,35)", "thirdStage");
        ageList.put("[35,50)", "fourthStage");
        ageList.put("[50", "fifthStage");

        oneLevelTypes.add(HEALTH.getCode());
        oneLevelTypes.add(LIFEINSURANCE.getCode());
        oneLevelTypes.add(UNEXPECTED.getCode());
        oneLevelTypes.add(RENTE.getCode());
        oneLevelTypes.add(SOCIALSECURITY.getCode());

    }

    @Resource
    private UserFamilyInfoGateway userFamilyInfoGateway;
    @Resource
    private FamilyEnsuredInfoGateway familyEnsuredInfoGateway;
    @Resource
    private MemberEnsuredInfoGateway memberEnsuredInfoGateway;
    @Resource
    private UserChannelInfoService userChannelInfoService;
    @Resource
    private EnsuredWeightConfigGateway ensuredWeightConfigGateway;
    @Resource
    private MemberEnsuredInfoCmdConvertor memberEnsuredInfoCmdConvertor;
    @Resource
    private PolicyInsurantGateway policyInsurantGateway;
    @Resource
    private PolicyGateway policyGateway;
    @Resource
    private PolicyAdditionalGateway policyAdditionalGateway;
    @Resource
    private SafeguardInsuranceService safeguardInsuranceService;
    @Resource
    private SafeguardOverviewService safeguardOverviewService;
    /**
     * 计算家庭成员保障分
     * step：
     * 1、取出所有成员有效保障分记录
     * 2、遍历1的集合获取到每个成员的年龄以及所属用户id 还有用户和成员的映射关系map  便于计算家庭分的时候使用
     * 3、遍历产品的四个一级类别 分别根据年龄获取到对应年龄区间的权重配置
     * 4、每个单项分*对应的权重之和 算出成员的个人保障分
     * 5、遍历2中的关系map  找到每个用户下的所有成员的成员保障分记录集合
     * 6、然后算出每个用户下的所有成员的各项分的一个平均值 保存到该用户的家庭保障分表中
     * 注意： 在业务方法中一般不需要catch异常，如果非要catch一定要抛出throw new RuntimeException()，或者注解中指定抛异常类型@Transactional(rollbackFor=Exception.class)，否则会导致事务失效
     * @param
     * @return
     */
    @Override
//    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public ApiResult calculateTotalScore() {
        log.info("-------------memberEnsured scheduler calculateTotalScore start-----------");
        StopWatch watch = new StopWatch();
        watch.start();
        Map<String, Set<Long>> userIds = new HashMap<>();
        Set<Long> memberIds = new HashSet<>();
        //取出所有成员有效保障分记录
        List<MemberEnsuredInfo> memberEnsuredInfos = memberEnsuredInfoGateway.selectEntityByStatus(CommonStatusEnum.VALID.getCode(), DeleteFlagEnum.NORMAL.getCode());
        log.info("定时任务调用家庭保障分计算开始 memberEnsuredInfos size:{}", memberEnsuredInfos.size());
        memberEnsuredInfos.forEach(x -> {
            log.info("定时任务调用家庭保障分计算开始进入第一个 x:{},size:{}", x.getMemberId(),memberEnsuredInfos.size());
            Set<String> productTopTypeSet = new HashSet<>();
            productTopTypeSet.add(HEALTH.getCode());
            productTopTypeSet.add(LIFEINSURANCE.getCode());
            productTopTypeSet.add(UNEXPECTED.getCode());
            productTopTypeSet.add(RENTE.getCode());
            MemberEnsuredCalcCmd calcCmd = new MemberEnsuredCalcCmd();
            calcCmd.setMemberId(x.getMemberId());
//            calcCmd.setUserId(userId);
            calcCmd.setProdTypeCodes(productTopTypeSet);
            log.info("定时任务调用家庭保障分计算接口开始 param:{},x:{}", JSONObject.toJSONString(calcCmd),JSONObject.toJSONString(x));
            this.calculateEnsuredScore(calcCmd);
        });
        memberEnsuredInfos.forEach(x -> {
            //获取到成员的年龄
            log.info("定时任务调用家庭保障分计算开始进入第二个 x:{},size:{}", x.getMemberId(),memberEnsuredInfos.size());

            UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(x.getMemberId());
            if (Objects.isNull(userFamilyInfo) || Objects.isNull(userFamilyInfo.getBirthday())) {
                return;
            }
            log.info("定时任务调用家庭保障分计算开始start1 x:{}", x.getMemberId());

            int age = DateUtil.getAgeByBirth(userFamilyInfo.getBirthday());
            String userId = userFamilyInfo.getBelongUserId();
            Set<Long> ids = userIds.containsKey(userId) ? userIds.get(userId) : new HashSet<>();
            ids.add(x.getMemberId());
            userIds.put(userId, ids);
            final BigDecimal[] memberPersonTotal = new BigDecimal[1];
            memberPersonTotal[0] = new BigDecimal(0);
            log.info("定时任务调用家庭保障分计算开始start2 x:{}", x.getMemberId());
            MemberEnsuredInfo  afterEntity= memberEnsuredInfoGateway.selectEntityByMemberId(x.getMemberId());
            log.info("定时任务调用家庭保障分计算接口结束,memberId:{},afterEntity:{}",x.getMemberId(),JSONObject.toJSONString(afterEntity));
            if (Objects.isNull(afterEntity)) {
                log.info("定时任务调用家庭保障分计算接口结束循环终止");
                return;
            }
            log.info("定时任务调用家庭保障分计算接口结束循环继续,afterEntity:{}",JSONObject.toJSONString(afterEntity));

            //遍历一级类别集合
            oneLevelTypes.forEach(type -> {
                //根据产品一级类别获取到该配置项
                EnsuredWeightConfig ensuredWeightConfig = ensuredWeightConfigGateway.selectEntityByLevelType(type);
                if (!Optional.ofNullable(ensuredWeightConfig).isPresent()) {
                    return;
                }
                BigDecimal weightScore = null;
                //根据年龄找到对应年龄区间的保障分权重值
                for (Map.Entry<String, String> entry : ageList.entrySet()) {
                    if (IntervalUtil.isInTheInterval(String.valueOf(age), entry.getKey())) {
                        Field f = null;
                        try {
                            f = ensuredWeightConfig.getClass().getDeclaredField(entry.getValue());
                            f.setAccessible(true);
                            weightScore = new BigDecimal(f.get((Object) ensuredWeightConfig).toString());
                        } catch (NoSuchFieldException | IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (Objects.isNull(weightScore)) {
                    return;
                }
                //计算各个保障单项分
                if (type.equals(HEALTH.getCode()) && Objects.nonNull(afterEntity.getHealthScore())) {
                    memberPersonTotal[0] = memberPersonTotal[0].add(new BigDecimal(afterEntity.getHealthScore()).multiply(weightScore));
                } else if (type.equals(SOCIALSECURITY.getCode()) && Objects.nonNull(afterEntity.getSocialSecurityScore())) {
                    memberPersonTotal[0] = memberPersonTotal[0].add(new BigDecimal(afterEntity.getSocialSecurityScore()).multiply(weightScore));
                } else if (type.equals(RENTE.getCode()) && Objects.nonNull(afterEntity.getRenteScore())) {
                    memberPersonTotal[0] = memberPersonTotal[0].add(new BigDecimal(afterEntity.getRenteScore()).multiply(weightScore));
                } else if (type.equals(UNEXPECTED.getCode()) && Objects.nonNull(afterEntity.getUnexpectedScore())) {
                    memberPersonTotal[0] = memberPersonTotal[0].add(new BigDecimal(afterEntity.getUnexpectedScore()).multiply(weightScore));
                } else if (type.equals(LIFEINSURANCE.getCode()) && Objects.nonNull(afterEntity.getLifeInsuranceScore())) {
                    memberPersonTotal[0] = memberPersonTotal[0].add(new BigDecimal(afterEntity.getLifeInsuranceScore()).multiply(weightScore));
                }

            });
            //更新个人保障总得分
            afterEntity.setPersonalTotalScore(memberPersonTotal[0].intValue());
            memberEnsuredInfoGateway.update(afterEntity);

        });
        log.info("memberEnsured scheduler calculateTotalScore 循环终止后继续");
        calculateFamilyScore(userIds);
        watch.stop();
        log.info("memberEnsured scheduler calculateTotalScore end cost: {} ms", watch.getTotalTimeMillis());
        return ApiResult.buildSuccess();
    }
    /**
     * 根据map关系 计算家庭保障分
     * @param userIds
     * @return
     */
    public void calculateFamilyScore(Map<String, Set<Long>> userIds) {
        //遍历所有用户  计算家庭的各项得分和总得分 更新记录
        for (Map.Entry<String, Set<Long>> entry : userIds.entrySet()) {
            Long[] ids = entry.getValue().toArray(new Long[entry.getValue().size()]);
            List<MemberEnsuredInfo> memberEnsuredInfos1 = memberEnsuredInfoGateway.selectListByMemberIds(ids);
            if (CollectionUtils.isEmpty(memberEnsuredInfos1)) {
                continue;
            }
            //分别统计出该用户下的所有成员的一个平均分情况
            Double familyHealthScore = memberEnsuredInfos1.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getHealthScore())).mapToInt(MemberEnsuredInfo::getHealthScore).average().orElse(0L);
            Double familyRenteScore = memberEnsuredInfos1.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getRenteScore())).mapToInt(MemberEnsuredInfo::getRenteScore).average().orElse(0L);
            Double familyLifeInsuranceScore = memberEnsuredInfos1.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getLifeInsuranceScore())).mapToInt(MemberEnsuredInfo::getLifeInsuranceScore).average().orElse(0L);
            Double familySocialSecurityScore = memberEnsuredInfos1.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getSocialSecurityScore())).mapToInt(MemberEnsuredInfo::getSocialSecurityScore).average().orElse(0L);
            Double familyUnexpectedScore = memberEnsuredInfos1.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getUnexpectedScore())).mapToInt(MemberEnsuredInfo::getUnexpectedScore).average().orElse(0L);
            Double familyTotalScore = memberEnsuredInfos1.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getPersonalTotalScore())).mapToInt(MemberEnsuredInfo::getPersonalTotalScore).average().orElse(0L);

            FamilyEnsuredInfo familyEnsuredInfo = familyEnsuredInfoGateway.selectFamilyByUserId(entry.getKey());
            if (Objects.isNull(familyEnsuredInfo)) {
                familyEnsuredInfo = FamilyEnsuredInfo.builder()
                        .userId(entry.getKey())
                        .familyTotalScore(familyTotalScore.intValue())
                        .healthScore(familyHealthScore.intValue())
                        .unexpectedScore(familyUnexpectedScore.intValue())
                        .lifeInsuranceScore(familyLifeInsuranceScore.intValue())
                        .socialSecurityScore(familySocialSecurityScore.intValue())
                        .renteScore(familyRenteScore.intValue())
                        .build();
                familyEnsuredInfoGateway.save(familyEnsuredInfo);
            } else {
                familyEnsuredInfo.setFamilyTotalScore(familyTotalScore.intValue());
                familyEnsuredInfo.setHealthScore(familyHealthScore.intValue());
                familyEnsuredInfo.setUnexpectedScore(familyUnexpectedScore.intValue());
                familyEnsuredInfo.setLifeInsuranceScore(familyLifeInsuranceScore.intValue());
                familyEnsuredInfo.setSocialSecurityScore(familySocialSecurityScore.intValue());
                familyEnsuredInfo.setRenteScore(familyRenteScore.intValue());
                familyEnsuredInfoGateway.update(familyEnsuredInfo);
            }
        }
    }

    @Override
    public ApiResult<PageInfo<MemberEnsureScoreVO>> queryPageByCondition(MemberEnsureScorePageQry qry) {
        PageInfo emptyPage = PageInfo.EMPTY;
        emptyPage.setPageSize(qry.getPageSize());
        emptyPage.setPageNum(qry.getPageNum());
        if (Objects.nonNull(qry.getFamilyMinScore())&&Objects.nonNull(qry.getFamilyMaxScore())){
            if(qry.getFamilyMinScore()>qry.getFamilyMaxScore()) {
                return ApiResult.buildFailure("最大值应大于等于最小值");
            }
        }
        if (Objects.nonNull(qry.getMemberMinScore())&&Objects.nonNull(qry.getMemberMaxScore())){
            if(qry.getMemberMinScore()>qry.getMemberMaxScore()) {
                return ApiResult.buildFailure("最大值应大于等于最小值");
            }
        }
        MemberEnsuredDTO memberEnsuredDTO = MemberEnsuredDTO.builder().build();
        BeanUtils.copyProperties(qry,memberEnsuredDTO);
        memberEnsuredDTO.setPageNum(qry.getPageNum());
        memberEnsuredDTO.setPageSize(qry.getPageSize());
        PageInfo<MemberEnsuredInfo> page = memberEnsuredInfoGateway.page(memberEnsuredDTO);
        PageInfo<MemberEnsureScoreVO> convert = memberEnsuredInfoCmdConvertor.convert(page);
        convert.getList().forEach(x -> {
            x.setRelationName(RelationEnum.getMsgByCode(x.getRelation()));
            x.setUserPhoneNumber(DesensitizedUtil.mobilePhone(x.getUserPhoneNumber()));
            x.setChannelName(PlatformEnum.getMsgByCode(x.getChannelType()));
            //根据用户id获取用户昵称
            ApiResult<UserChannelInfoVO> user = userChannelInfoService.getUserChannelInfoByUserId(x.getUserId());
            if(user.getSuccess()) {
                x.setUserNickName(user.getData().getNickname());
            }
        });
        return ApiResult.of(convert);


    }
    /**
     * 计算家庭成员各单项保障分
     * step：
     * 1、只有被保人才有此项保障分 故先根据传入的成员id找到所有的被保人记录集合
     * 2、遍历传入的所有产品一级类别集合
     * 3、根据1的集合统计出所有保单id集合
     * 4、根据3的保单id集合 分别找到所有主险的保单集合以及附加险的保单集合
     * 5、过滤出对应产品一级类别的集合 汇总出总的保额 记录下该类别对应的总保额的关系集合
     * 6、遍历5的关系集合 拿对应的保额 再除以 根据被保人年龄和产品类别算出来的对比值保额 算出保障单项分 进行入库操作
     * @param
     * @return
     */
    @Override
    public ApiResult<Long> calculateEnsuredScore(MemberEnsuredCalcCmd memberEnsuredCalcCmd) {
        log.info("calculateEnsuredScore param getProdTypeCodes:{},memberId:{}", JSONObject.toJSONString(memberEnsuredCalcCmd.getProdTypeCodes()),memberEnsuredCalcCmd.getMemberId());
        MemberEnsuredInfo memberEnsuredInfo = memberEnsuredInfoCmdConvertor.convert(memberEnsuredCalcCmd);
        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(memberEnsuredCalcCmd.getMemberId());
        if (Objects.isNull(userFamilyInfo)) {
            return ApiResult.buildFailure("该成员不存在");
        }
        if (CollectionUtils.isEmpty(memberEnsuredCalcCmd.getProdTypeCodes())) {
            return ApiResult.buildFailure("缺少产品类别，无法计算相关保障分");
        }
        if (Objects.isNull(userFamilyInfo.getBirthday())) {
            return ApiResult.buildFailure("该成员没有录入出生日期，无法计算相关保障分");

        }
        PolicyInsurant policyInsurant = PolicyInsurant.builder().insurantId(memberEnsuredCalcCmd.getMemberId()).build();
        log.info("calculateEnsuredScore policyInsurantEntity:{}",JSONObject.toJSONString(policyInsurant));

        List<PolicyInsurant> list = policyInsurantGateway.findByInsurantId(policyInsurant);
        if (CollectionUtils.isEmpty(list)) {
            return ApiResult.buildFailure("该成员不属于被保人,无法参与计算保障分");
        }
        log.info("calculateEnsuredScore policyInsurantList size:{}", list.size());

        //该map用于保存 该成员的每一种一级类别对应的保额
        Map<String, BigDecimal> mapAmount = new HashMap<>();
        for (String prodTypeCode : memberEnsuredCalcCmd.getProdTypeCodes()) {
            log.info("calculateEnsuredScore prodTypeCode:{}, memberId:{}",prodTypeCode, memberEnsuredCalcCmd.getMemberId());

            //计算主险和附加险保额之和
            BigDecimal insuredAmount = BigDecimal.ZERO;
            List<Long> policyIdList = list.stream().map(PolicyInsurant::getPolicyId).collect(Collectors.toList());
            Long[] ids = policyIdList.toArray(new Long[policyIdList.size()]);
            List<Policy> policiesMain = policyGateway.selectListByPolicyIds(ids);
            List<Policy> resultMain = policiesMain.stream().filter(x -> Objects.nonNull(x.getProductTopType()) && x.getProductTopType().equals(prodTypeCode)).collect(Collectors.toList());
            log.info("calculateEnsuredScore prodTypeCode:{}, memberId:{},resultMain size:{}",prodTypeCode, memberEnsuredCalcCmd.getMemberId(),resultMain.size());

            if (CollectionUtils.isNotEmpty(resultMain)) {
                BigDecimal sum = resultMain.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getInsuredAmount())).collect(CollectorsUtils.summingBigDecimal(Policy::getInsuredAmount));
                log.info("calculateEnsuredScore memberId:{}, prodTypeCode:{}, resultMain sum:{}",memberEnsuredCalcCmd.getMemberId(),prodTypeCode,sum);
                insuredAmount = insuredAmount.add(sum);
            }
            log.info("calculateEnsuredScore  memberId:{}, prodTypeCode:{}, policyIdList:{}, policiesMain:{}, insuredAmount1:{}",memberEnsuredCalcCmd.getMemberId(),prodTypeCode,JSONObject.toJSONString(policyIdList),JSONObject.toJSONString(policiesMain),insuredAmount);

            List<PolicyAdditional> policiesAdditional = policyAdditionalGateway.selectListByPolicyIds(ids);
            List<PolicyAdditional> resultAdditional = policiesAdditional.stream().filter(x ->Objects.nonNull(x.getProductTopType())&&x.getProductTopType().equals(prodTypeCode)).collect(Collectors.toList());
            log.info("calculateEnsuredScore prodTypeCode:{}, memberId:{},resultAdditional size:{}",prodTypeCode, memberEnsuredCalcCmd.getMemberId(),resultAdditional.size());
            if (CollectionUtils.isNotEmpty(resultAdditional)) {
                BigDecimal sum = resultAdditional.stream().filter(Objects::nonNull).filter(s -> Objects.nonNull(s.getInsuredAmount())).collect(CollectorsUtils.summingBigDecimal(PolicyAdditional::getInsuredAmount));
                log.info("calculateEnsuredScore  memberId:{},prodTypeCode:{}, resultAdditional sum:{}",memberEnsuredCalcCmd.getMemberId(),prodTypeCode,sum);
                insuredAmount = insuredAmount.add(sum);
            }
            log.info("calculateEnsuredScore  memberId:{},prodTypeCode:{}, policyIdList:{}, policiesMain:{}, insuredAmount2:{}",memberEnsuredCalcCmd.getMemberId(),prodTypeCode,JSONObject.toJSONString(policyIdList),JSONObject.toJSONString(policiesMain),insuredAmount);

            mapAmount.put(prodTypeCode, insuredAmount);
        }
        Long save = 0L;
        int update = 0;
        log.info("calculateEnsuredScore  memberId:{},mapAmount:{}",memberEnsuredCalcCmd.getMemberId(),JSONObject.toJSONString(mapAmount));

        for (Map.Entry<String, BigDecimal> entry : mapAmount.entrySet()) {
            int age = DateUtil.getAgeByBirth(userFamilyInfo.getBirthday());
            ScoreTypeEnum scoreTypeEnum = ScoreTypeEnum.getMsgByCode(entry.getKey());
            if(Objects.isNull(scoreTypeEnum)){
                continue;
            }
            memberEnsuredCalcCmd.setInsuredAmount(entry.getValue());
            log.info("calculateEnsuredScore age:{},memberId:{} entryKey:{}, entryValue:{}",age,userFamilyInfo.getMemberId(),entry.getKey(),entry.getValue());

            //该方法只更新单项分
            switch (Objects.requireNonNull(scoreTypeEnum)) {
                case HEALTH:
                    memberEnsuredInfo.setHealthScore(this.calcScore(memberEnsuredCalcCmd, age, HEALTH, entry.getKey()));
                    break;
                case LIFEINSURANCE:
                    memberEnsuredInfo.setLifeInsuranceScore(this.calcScore(memberEnsuredCalcCmd, age, LIFEINSURANCE, entry.getKey()));
                    break;
                case RENTE:
                    memberEnsuredInfo.setRenteScore(this.calcScore(memberEnsuredCalcCmd, age, RENTE, entry.getKey()));
                    break;
                case SOCIALSECURITY:
                    memberEnsuredInfo.setSocialSecurityScore(userFamilyInfo.getSocialSecurityFlag() == 1 ? 100 : 0);
                    break;
                case UNEXPECTED:
                    memberEnsuredInfo.setUnexpectedScore(this.calcScore(memberEnsuredCalcCmd, age, ScoreTypeEnum.UNEXPECTED, entry.getKey()));
                    break;
            }

            memberEnsuredInfo.setMemberId(memberEnsuredCalcCmd.getMemberId());
            MemberEnsuredInfo memberEnsuredInfo1 = memberEnsuredInfoGateway.selectEntityByMemberId(memberEnsuredCalcCmd.getMemberId());
            if (Objects.isNull(memberEnsuredInfo1)) {
                save = memberEnsuredInfoGateway.save(memberEnsuredInfo);
                log.info("calculateEnsuredScore save:{}",JSONObject.toJSONString(save));

            } else {
                update = memberEnsuredInfoGateway.update(memberEnsuredInfo);
                log.info("calculateEnsuredScore update:{}",JSONObject.toJSONString(update));

            }
        }

        return ApiResult.of(save + update);
    }

    @Override
    public List<MemberEnsureScoreExportVO> exportExcel(MemberEnsureScoreExportQry qry) {
        MemberEnsuredDTO memberEnsuredDTO = MemberEnsuredDTO.builder().build();
        BeanUtils.copyProperties(qry, memberEnsuredDTO);
        memberEnsuredDTO.setPageNum(null);
        memberEnsuredDTO.setPageSize(null);
        List<MemberEnsuredInfo> memberEnsuredInfoList = memberEnsuredInfoGateway.query(memberEnsuredDTO);
        if (CollectionUtils.isNotEmpty(memberEnsuredInfoList) && memberEnsuredInfoList.size() > 5000) {
            throw new RuntimeException("导出数量不可超过5000条，请重新筛选");
        }
        List<MemberEnsureScoreExportVO> memberEnsureScoreVOS = Lists.newArrayList();

        try {

            memberEnsuredInfoList.forEach(x -> {
                x.setChannelName(PlatformEnum.getMsgByCode(x.getChannelType()));
                MemberEnsureScoreExportVO memberEnsureScoreVO = new MemberEnsureScoreExportVO();
                BeanUtils.copyProperties(x, memberEnsureScoreVO);
                memberEnsureScoreVO.setRelationName(RelationEnum.getMsgByCode(x.getRelation()));
                //根据用户id获取昵称
                ApiResult<UserChannelInfoVO> user = userChannelInfoService.getUserChannelInfoByUserId(x.getUserId());
                if (user.getSuccess()) {
                    memberEnsureScoreVO.setUserNickName(user.getData().getNickname());
                }
                memberEnsureScoreVO.setUserPhoneNumber(DesensitizedUtil.mobilePhone(x.getUserPhoneNumber()));
                memberEnsureScoreVOS.add(memberEnsureScoreVO);
            });

            return memberEnsureScoreVOS;
//            EasyExcelUtil.exprotExcel(response,memberEnsureScoreVOS,"保障分列表","保障分列表", MemberEnsureScoreVO.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    /**
     * 根据年龄获取对应对比值的保额
     *
     * @param age
     * @return
     */
    private Integer calcScore(MemberEnsuredCalcCmd memberEnsuredCalcCmd, Integer age, ScoreTypeEnum scoreTypeEnum, String productType) {
        InsuranceCommonQry qry = new InsuranceCommonQry();
        qry.setParentType(productType);
        Integer ageBracket = convertAgeBracket(age);
        qry.setAgeBracket(ageBracket);

//        Map<String, Integer> compareValueMap = safeguardInsuranceService.listParentCompareValue(qry);
        OverviewCommonQry overviewCommonQry = OverviewCommonQry.builder().ageBracket(ageBracket).typeCode(productType).build();
        Integer compareAmount = Constants.ZERO;
        ApiResult<Integer> compareColumn = safeguardOverviewService.getCompareColumn(overviewCommonQry);
        if (compareColumn.getSuccess()) {
            compareAmount = compareColumn.getData() * 10000;
        }
//        Integer compareAmount = (Integer) compareColumn;// compareValueMap.getOrDefault(qry.getParentType(), Constants.ZERO);
        int score = compareAmount == Constants.ZERO ? Constants.ZERO : memberEnsuredCalcCmd.getInsuredAmount()
                .divide(new BigDecimal(compareAmount), 2, RoundingMode.HALF_UP).multiply(new BigDecimal(CALC_POLICY_AMOUNT)).intValue();
        log.info("calculateEnsuredScore age:{},memberId:{} ageBracket:{},insuredAmount:{},compareAmount:{},score:{}", age, memberEnsuredCalcCmd.getMemberId(), ageBracket, memberEnsuredCalcCmd.getInsuredAmount(), compareAmount, score);
        return Math.min(100, score);
    }

    /**
     * 年龄转年龄段
     *
     * @param age
     * @return
     */
    private Integer convertAgeBracket(Integer age) {
        if (age > AgeBracketEnum.ONESTEP.getBegin() && age < AgeBracketEnum.ONESTEP.getEnd()) {
            return AgeBracketEnum.ONESTEP.getCode();
        } else if (age >= AgeBracketEnum.TWOSTEP.getBegin() && age < AgeBracketEnum.TWOSTEP.getEnd()) {
            return AgeBracketEnum.TWOSTEP.getCode();
        } else if (age >= AgeBracketEnum.THREESTEP.getBegin() && age < AgeBracketEnum.THREESTEP.getEnd()) {
            return AgeBracketEnum.THREESTEP.getCode();
        } else if (age >= AgeBracketEnum.FOURSTEP.getBegin() && age < AgeBracketEnum.FOURSTEP.getEnd()) {
            return AgeBracketEnum.FOURSTEP.getCode();
        } else {
            return AgeBracketEnum.FIVESTEP.getCode();
        }
    }
}
