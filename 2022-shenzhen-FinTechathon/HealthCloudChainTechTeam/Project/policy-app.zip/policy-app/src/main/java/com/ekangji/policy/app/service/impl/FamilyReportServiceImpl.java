
package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.util.BigDecimalUtil;
import com.ekangji.policy.api.*;
import com.ekangji.policy.app.convertor.FamilyReportCmdConvertor;
import com.ekangji.policy.app.service.PolicyMemberProductTypeStatisticsService;
import com.ekangji.policy.app.service.PolicyMemberStatisticsService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.AgeBracketEnum;
import com.ekangji.policy.domain.gateway.UserFamilyInfoGateway;
import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.clientobject.policy.familyreport.*;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.command.policy.familyreport.MemberProductTypeAmountQry;
import com.ekangji.policy.dto.command.policy.familyreport.MemberTotalInfoQry;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.ekangji.policy.infrastructure.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.assertj.core.internal.BigDecimals;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.validation.ValidationException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.collectingAndThen;
import static java.util.stream.Collectors.toCollection;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = FamilyReportService.class)
public class FamilyReportServiceImpl implements FamilyReportService {

    @Resource
    private PolicyMemberStatisticsService policyMemberStatisticsService;

    @Resource
    private FamilyReportCmdConvertor familyReportCmdConvertor;

    @Resource
    private ProductTypeMappingService productTypeMappingService;

    @Resource
    private PolicyMemberProductTypeStatisticsService policyMemberProductTypeStatisticsService;

    @Resource
    private SafeguardOverviewService safeguardOverviewService;

    @Resource
    private UserFamilyInfoService userFamilyInfoService;

    @Resource
    private SafeguardInsuranceService safeguardInsuranceService;

    @Resource
    private UserFamilyInfoGateway userFamilyInfoGateway;


    @Override
    public ApiResult<FamilyReportTotalInfoVO> findFamilyReportTotalInfo(LoginUserInfo qry) {
        PolicyMemberStatistics rPms = policyMemberStatisticsService.findFamilyReportTotalInfo(qry);
        FamilyReportTotalInfoVO frtVO = familyReportCmdConvertor.convert(rPms);
        return ApiResult.of(frtVO);
    }

    /**
     * 1.获取被保人 有效保单数，今年保费
     * 2.获取被保人全部保障数据
     * 3.获取被保人同龄保额均值数据
     * @param qry
     * @return
     */
    @Override
    public ApiResult<FamilyMemberTotalInfoVO> findFamilyMemberTotalInfo(MemberTotalInfoQry qry) {
        FamilyMemberTotalInfoVO vo = new FamilyMemberTotalInfoVO();
        List<InsurantTotalInfoVO> data = new ArrayList();
        //获取所有家庭成员被保人的统计数据
        List<PolicyMemberStatistics> rPms = policyMemberStatisticsService.findFamilyMemberTotalInfo(qry);
        //获取一级保险类型
        List<ProductTypeMappingVO> productTopType = productTypeMappingService.listOneLevel();
        //组装前端tab列表
        List<InsuranceProductTypeInfoVO> tabList = assembleProductTopType(productTopType,true);

        //获取全部保障的基础数据
        rPms.forEach(p ->{
            InsurantTotalInfoVO insurantTotalInfo = new InsurantTotalInfoVO();
            InsuranceProductTypeAmountVO productTopTypeData = findMemberProductTopTypeInfo(p.getUserId(),p.getMemberId());
            UserFamilyInfo member = findMemberInfo(p.getUserId(),p.getMemberId());
            if (Objects.nonNull(member)) {
                insurantTotalInfo.setName(member.getNickName());
                insurantTotalInfo.setUserPhoto(member.getUserPhoto());
                insurantTotalInfo.setRelation(member.getRelation());
                insurantTotalInfo.setMemberCreateTime(member.getCreateTime());
            }
            insurantTotalInfo.setMemberId(p.getMemberId());
            insurantTotalInfo.setEffectivePolicyNum(p.getEffectivePolicyNum());
            insurantTotalInfo.setPremium(p.getPremium().setScale(2,BigDecimal.ROUND_DOWN).stripTrailingZeros());
            insurantTotalInfo.setProductType(tabList);
            //设置当前tab
            insurantTotalInfo.setCurrentProductTypeCode(Constants.PROD_TYPE_ALL_CODE);
            //设置用户保额
            insurantTotalInfo.setInsurantAmount(productTopTypeData.getInsurantAmount());
            //获取全部保障同龄保额均值
            insurantTotalInfo.setSameAgeAmount(productTopTypeData.getSameAgeAmount());
            insurantTotalInfo.setShownCompareValue(productTopTypeData.getShownCompareValue());
            data.add(insurantTotalInfo);
        });

        //排序
        Collections.sort(data, new Comparator<InsurantTotalInfoVO>() {
            @Override
            public int compare(InsurantTotalInfoVO o1, InsurantTotalInfoVO o2) {
                if (o1.getRelation().compareTo(o2.getRelation()) == 0) {
                    return o1.getMemberCreateTime().compareTo(o2.getMemberCreateTime());
                } else {
                    return o1.getRelation().compareTo(o2.getRelation());
                }
            }
        });

        vo.setInsurantTotalInfoList(data);
        return ApiResult.of(vo);
    }

    @Override
    public ApiResult<InsuranceProductTypeAmountVO> findMemberProductTypeAmountInfo(MemberProductTypeAmountQry qry) {
        InsuranceProductTypeAmountVO data = null;

        if (Constants.PROD_TYPE_ALL_CODE.equals(qry.getProductTypeCode())) {//全部保障数据
            data = findMemberProductTopTypeInfo(qry.getUserId(),qry.getMemberId());
        } else { //获取某一级保险类别下得子类别数据
            data = findMemberProductTypeInfo(qry);
        }
        return ApiResult.of(data);
    }

    /**
     * 获取一级类别下子类别统计数据
     * @param qry
     * @return
     */
    private InsuranceProductTypeAmountVO findMemberProductTypeInfo(MemberProductTypeAmountQry qry) {
        UserFamilyInfo member = findMemberInfo(qry.getUserId(),qry.getMemberId());
        if (Objects.isNull(member)) {
            throw new ValidationException("家庭成员不存在");
        }

        InsuranceProductTypeAmountVO vo = new InsuranceProductTypeAmountVO();
        //获取一级类别下得子类别
        List<ProductTypeMappingVO> productTypeList = findProductType(qry.getProductTypeCode());
        if (CollectionUtils.isNotEmpty(productTypeList)) {
            // 获取用户保额数据
            List<InsuranceProductTypeDataVO> categoryData = policyMemberProductTypeStatisticsService
                    .findMemberProductTypeInfo(qry.getUserId(),qry.getMemberId(),qry.getProductTypeCode(),productTypeList);
            vo.setInsurantAmount(categoryData);

            //获取一级类别下用户同龄保额对比值数据
            List<InsuranceProductTypeDataVO> sameAgeAmount = findProductTypeSameAgeAmount(qry.getUserId(),qry.getMemberId(),qry.getProductTypeCode(),productTypeList);
            vo.setSameAgeAmount(sameAgeAmount);
        }
        //生日为空直接返回不显示对比值
        if(Objects.isNull(member.getBirthday())) {
            vo.setShownCompareValue(Constants.ZERO);
            return vo;
        }

        //获取是否显示对比值
        OverviewQry overviewQry = new OverviewQry();
//        Integer ageBracket = AgeBracketEnum.FOURSTEP.getCode();
//        if(Objects.isNull(member.getBirthday())){
//            Integer age = DateUtil.getAgeByBirth(member.getBirthday());
//            ageBracket = convertAgeBracket(age);
//        }
        Integer age = DateUtil.getAgeByBirth(member.getBirthday());
        Integer ageBracket = convertAgeBracket(age);
        overviewQry.setAgeBracket(ageBracket);

        ApiResult<List<SafeguardOverviewVO>> apiResult = safeguardOverviewService.queryList(overviewQry);
        if (apiResult.getSuccess() && CollectionUtils.isNotEmpty(apiResult.getData())) {
            SafeguardOverviewVO sameAgeAmount = apiResult.getData().get(0);
            vo.setShownCompareValue(sameAgeAmount.getShownCompareValue());
        } else {
            vo.setShownCompareValue(Constants.ZERO);
        }
        return vo;
    }

    /**
     * 获取一级类别下得同龄保额均值
     * @param memberId
     * @return
     */
    private List<InsuranceProductTypeDataVO> findProductTypeSameAgeAmount(String userId, Long memberId, String productTopType, List<ProductTypeMappingVO> productTypeList) {
        UserFamilyInfo member = findMemberInfo(userId,memberId);
        if (Objects.isNull(member) && Objects.isNull(member.getBirthday())) {
            return Collections.emptyList();
        }
        InsuranceCommonQry qry = new InsuranceCommonQry();
        qry.setParentType(productTopType);
        Integer age = DateUtil.getAgeByBirth(member.getBirthday());
        Integer ageBracket = convertAgeBracket(age);
        qry.setAgeBracket(ageBracket);

        Map<String,Integer> compareValueMap = safeguardInsuranceService.listChildrenCompareValue(qry);
        List<ProductTypeMappingVO> disProductType = productTypeList.stream().collect(
                collectingAndThen(toCollection(() -> new TreeSet<>(Comparator.comparing(ProductTypeMappingVO::getCode))),ArrayList::new)
        );
        List<InsuranceProductTypeDataVO> sameAgeAmount = disProductType.parallelStream().map(p ->{
            InsuranceProductTypeDataVO vo = new InsuranceProductTypeDataVO();
            vo.setProductTypeName(p.getName());
            vo.setProductTypeCode(p.getCode());
            Integer compareValue = compareValueMap.getOrDefault(p.getCode(), Constants.ZERO);
            if(Objects.isNull(compareValue)){ //取不到值默认设置为0
                compareValue = 0;
            }
            vo.setInsuredAmount(new BigDecimal(compareValue));
            return vo;
        }).collect(Collectors.toList());

        return sameAgeAmount;
    }


    /**
     * 获取全部保障下得类别保额数据
     * @param userId
     * @param memberId
     * @return
     */
    private InsuranceProductTypeAmountVO findMemberProductTopTypeInfo(String userId, Long memberId) {
        InsuranceProductTypeAmountVO vo = new InsuranceProductTypeAmountVO();
        //获取一级保险类型
        List<ProductTypeMappingVO> productTop = productTypeMappingService.listOneLevel();

        //获取社保
        InsuranceProductTypeDataVO memberSocialSecurityVO = findSocialSecurity(memberId);

        //用户保额均值
        List<InsuranceProductTypeDataVO> userData = new ArrayList<>();
        userData.add(memberSocialSecurityVO);
        List<InsuranceProductTypeDataVO> categoryData = policyMemberProductTypeStatisticsService
                .findMemberProductTopTypeInfo(userId,memberId,productTop);
        userData.addAll(categoryData);

        vo.setInsurantAmount(userData);

        //获取全部保障同龄保额均值
        List<InsuranceProductTypeDataVO> userSameAgeData = new ArrayList<>();
        //获取社保
        InsuranceProductTypeDataVO socialSecurityVO = findSocialSecurity(memberId);
        socialSecurityVO.setMaxInsuredAmount(new BigDecimal(1));
        socialSecurityVO.setInsuredAmount(new BigDecimal(1));
        userSameAgeData.add(socialSecurityVO);
        List<InsuranceProductTypeDataVO> sameAgeAmount = findTopTypeSameAgeAmount(userId,memberId);
        //设置对比值是否显示
        if(CollectionUtils.isNotEmpty(sameAgeAmount)) {
            vo.setShownCompareValue(sameAgeAmount.get(0).getShownCompareValue());
        }
        userSameAgeData.addAll(sameAgeAmount);

        vo.setSameAgeAmount(userSameAgeData);

        return vo;
    }

    private InsuranceProductTypeDataVO findSocialSecurity(Long memberId){
        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.get(UserFamilyInfo.builder().memberId(memberId).build());
        BigDecimal socialSecurity = new BigDecimal(0) ;
        if (Objects.nonNull(userFamilyInfo)) {
            Integer socialSecurityFlag = userFamilyInfo.getSocialSecurityFlag(); //1:有社保
            if (Objects.nonNull(socialSecurityFlag)) {
                socialSecurity = BigDecimalUtil.toBigDecimal(socialSecurityFlag);
            }
        }

        //添加社保数据
        InsuranceProductTypeDataVO iptdvo = new InsuranceProductTypeDataVO();
        iptdvo.setProductTypeCode("socialSecurity");
        iptdvo.setProductTypeName("社保");
        iptdvo.setInsuredAmount(socialSecurity);
        iptdvo.setMaxInsuredAmount(socialSecurity);
        return iptdvo;
    }

    /**
     * 获取全部保障下得同龄保额均值
     * @param memberId
     * @return
     */
    private List<InsuranceProductTypeDataVO> findTopTypeSameAgeAmount(String userId, Long memberId) {
        UserFamilyInfo member = findMemberInfo(userId,memberId);
        if (Objects.isNull(member)) {
            return Collections.emptyList();
        }

        OverviewQry qry = new OverviewQry();
        Integer ageBracket = AgeBracketEnum.FOURSTEP.getCode();
        if(Objects.nonNull(member.getBirthday())){
            Integer age = DateUtil.getAgeByBirth(member.getBirthday());
            ageBracket = convertAgeBracket(age);
        }
        qry.setAgeBracket(ageBracket);

        ApiResult<List<SafeguardOverviewVO>> apiResult = safeguardOverviewService.queryList(qry);
        if (apiResult.getSuccess() && CollectionUtils.isNotEmpty(apiResult.getData())) {
            List<InsuranceProductTypeDataVO> sameAgeAmount = apiResult.getData().parallelStream().map(s ->{
                InsuranceProductTypeDataVO vo = new InsuranceProductTypeDataVO();
                vo.setProductTypeName(s.getOneLevelTypeAlias());
                vo.setProductTypeCode(s.getOneLevelTypeCode());
                vo.setInsuredAmount(BigDecimalUtil.toBigDecimal(Objects.isNull(s.getCompareValue())?0:s.getCompareValue()));
                vo.setMaxInsuredAmount(BigDecimalUtil.toBigDecimal(Objects.isNull(s.getRadarMapMaxValue())?0:s.getRadarMapMaxValue()));
                if (Objects.isNull(member.getBirthday())) {
                    vo.setShownCompareValue(Constants.ZERO);
                }else{
                    vo.setShownCompareValue(s.getShownCompareValue());
                }
                return vo;
            }).collect(Collectors.toList());

            return sameAgeAmount;
        }
        return Collections.EMPTY_LIST;
    }

    /**
     * 获取家庭成员详细信息
     * @param userId
     * @param memberId
     * @return
     */
    private UserFamilyInfo findMemberInfo(String userId,Long memberId) {
        /*
        UserFamilyQry qry = new UserFamilyQry();
        qry.setUserId(userId);
        qry.setMemberId(memberId);

        ApiResult<UserFamilyMemberDetailVO> memberInfoResult = userFamilyInfoService.findFamilyByMemberId(qry);
        if (memberInfoResult.getSuccess()) {
            return memberInfoResult.getData();
        }
        return null;
        */
        ;
        return userFamilyInfoGateway.get(UserFamilyInfo.builder().belongUserId(userId).memberId(memberId).build());
    }


    /**
     * 年龄转年龄段
     * @param age
     * @return
     */
    private Integer convertAgeBracket(Integer age) {
        if (age > AgeBracketEnum.ONESTEP.getBegin() && age < AgeBracketEnum.ONESTEP.getEnd()){
            return AgeBracketEnum.ONESTEP.getCode();
        } else if (age >= AgeBracketEnum.TWOSTEP.getBegin() && age < AgeBracketEnum.TWOSTEP.getEnd()) {
            return AgeBracketEnum.TWOSTEP.getCode();
        } else if (age >= AgeBracketEnum.THREESTEP.getBegin() && age < AgeBracketEnum.THREESTEP.getEnd()) {
            return AgeBracketEnum.THREESTEP.getCode();
        } else if (age >= AgeBracketEnum.FOURSTEP.getBegin() && age < AgeBracketEnum.FOURSTEP.getEnd()) {
            return AgeBracketEnum.FOURSTEP.getCode();
        } else {
            return AgeBracketEnum.FIVESTEP.getCode();
        }
    }

    /**
     * 根据一级类别编号获取子类别
     * @param productTopType
     * @return
     */
    private List<ProductTypeMappingVO> findProductType(String productTopType) {
        ParentCodeQry parentCodeQry = new ParentCodeQry();
        parentCodeQry.setParentCode(productTopType);
        ApiResult<List<ProductTypeMappingVO>> apiResult = productTypeMappingService.listChildrenByParentCode(parentCodeQry);
        if (apiResult.getSuccess()) {
            return apiResult.getData();
        }
        return Collections.emptyList();
    }

    /**
     * 组装一级类别tab
     * @param addAllType
     * @return
     */
    private List<InsuranceProductTypeInfoVO> assembleProductTopType(List<ProductTypeMappingVO> productTopType,boolean addAllType){
        List<InsuranceProductTypeInfoVO> tabList = productTopType.stream().map(v->{
            InsuranceProductTypeInfoVO ivo = new InsuranceProductTypeInfoVO();
            ivo.setProductTypeName(v.getName());
            ivo.setProductTypeCode(v.getCode());
            return ivo;
        }).collect(Collectors.toList());

        if (addAllType) {
            List<InsuranceProductTypeInfoVO> tabAllList = new ArrayList<>();
            InsuranceProductTypeInfoVO allTypeVO = InsuranceProductTypeInfoVO.builder()
                    .productTypeCode(Constants.PROD_TYPE_ALL_CODE)
                    .productTypeName(Constants.PROD_TYPE_ALL_NAME).build();
            tabAllList.add(allTypeVO);
            tabAllList.addAll(tabList);
            return tabAllList;
        }
        return tabList;
    }
}
