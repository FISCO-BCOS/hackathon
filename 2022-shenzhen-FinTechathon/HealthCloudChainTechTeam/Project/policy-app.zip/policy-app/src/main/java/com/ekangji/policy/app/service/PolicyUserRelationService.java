package com.ekangji.policy.app.service;

import com.ekangji.policy.domain.policy.PolicyBackupMessage;

import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 用户保单关系
 * @Date: 2022/05/16 11:05
 */
public interface PolicyUserRelationService {

    void saveBackupPolicy(List<PolicyBackupMessage> list);
}
