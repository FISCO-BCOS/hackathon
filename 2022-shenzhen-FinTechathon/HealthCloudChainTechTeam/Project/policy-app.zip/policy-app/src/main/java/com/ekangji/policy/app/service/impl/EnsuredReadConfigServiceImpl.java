package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.IEnsuredReadConfigService;
import com.ekangji.policy.api.IEnsuredWeightConfigService;
import com.ekangji.policy.app.convertor.EnsuredReadConfigCmdConvertor;
import com.ekangji.policy.app.convertor.EnsuredWeightConfigCmdConvertor;
import com.ekangji.policy.domain.gateway.EnsuredReadConfigGateway;
import com.ekangji.policy.domain.gateway.EnsuredWeightConfigGateway;
import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.ekangji.policy.dto.clientobject.policy.EnsuredReadConfigVO;
import com.ekangji.policy.dto.clientobject.policy.EnsuredWeightConfigVO;
import com.ekangji.policy.dto.command.member.EnsuredReadConfigBatchEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredReadConfigEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigEditCmd;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;
import sun.management.Sensor;

import javax.annotation.Resource;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IEnsuredReadConfigService.class)
public class EnsuredReadConfigServiceImpl implements IEnsuredReadConfigService {
    @Resource
    private EnsuredReadConfigGateway ensuredReadConfigGateway;
    @Resource
    private EnsuredReadConfigCmdConvertor ensuredReadConfigCmdConvertor;

    @Override
    public ApiResult<Integer> ensuredReadSet(EnsuredReadConfigBatchEditCmd ensuredReadConfigBatchEditCmd) {

        List<EnsuredReadConfigEditCmd> addCmdList = ensuredReadConfigBatchEditCmd.getEditCmdList();
        ApiResult buildFailure = this.checkRange(addCmdList);
        if (!buildFailure.getSuccess()) return buildFailure;
        ensuredReadConfigGateway.batchDelete();
        List<EnsuredReadConfig> convert = ensuredReadConfigCmdConvertor.convertBatchEditCmd(addCmdList);
        int batchInsert = ensuredReadConfigGateway.batchInsert(convert);
        return ApiResult.of(batchInsert);
    }

    @Override
    public ApiResult<List<EnsuredReadConfigVO>> findEnsuredReadList() {
        List<EnsuredReadConfig> ensuredReadConfigs = ensuredReadConfigGateway.selectReadList();
        List<EnsuredReadConfigVO> convert = ensuredReadConfigCmdConvertor.convert(ensuredReadConfigs);
        convert.forEach(x -> {
            x.setMaxOperator(">");
            x.setMinOperator("<=");

        });
        return ApiResult.of(convert);
    }

    private ApiResult checkRange(List<EnsuredReadConfigEditCmd> addCmdList) {
        int lastMin = 0;
        EnsuredReadConfigEditCmd minEntity = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getMinScore())).min(Comparator.comparing(EnsuredReadConfigEditCmd::getMinScore)).get();
        EnsuredReadConfigEditCmd maxEntity = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getMaxScore())).max(Comparator.comparing(EnsuredReadConfigEditCmd::getMaxScore)).get();
        if (Optional.ofNullable(minEntity).isPresent() && Optional.ofNullable(maxEntity).isPresent()) {
            if (minEntity.getMinScore() != 0 ||maxEntity.getMaxScore() != 100) {
                return ApiResult.buildFailure("不满足0-100的数字区间，请复核修改");

            }
        }
        for (EnsuredReadConfigEditCmd configEditCmd : addCmdList) {
            if (lastMin > 0) {
                if (configEditCmd.getMaxScore() != lastMin) {
                    return ApiResult.buildFailure("每列的最大值和上一列的最小值要相等，请复核修改");

                }
            }
            lastMin = configEditCmd.getMinScore();

        }
        return ApiResult.buildSuccess();
    }
}
