package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.dto.clientobject.policy.ToReceivePolicyVO;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.backup.ToReceivePolicyQry;
import org.mapstruct.Mapper;

/**
 * @Author: liuchen
 * @Date: 2022/05/16 16:21
 */
@Mapper(componentModel = "spring")
public interface PolicyBackupMessageCmdConvertor {

    PolicyBackupMessage convert(ToReceivePolicyQry param);

    PolicyBackupMessage convert(PolicyBackupMessageEditCmd param);

    ToReceivePolicyVO convert(PolicyBackupMessage param);
}
