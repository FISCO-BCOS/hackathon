package com.ekangji.policy.app.service.impl;

import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import com.ekangji.policy.app.service.PolicyMemberStatisticsService;
import com.ekangji.policy.domain.gateway.PolicyMemberStatisticsGateway;
import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.dto.command.policy.familyreport.MemberTotalInfoQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class PolicyMemberStatisticsServiceImpl implements PolicyMemberStatisticsService {

    @Resource
    private PolicyMemberStatisticsGateway policyMemberStatisticsGateway;

    @Resource
    private PolicyService policyService;

    @Resource
    private PolicyAdditionalService policyAdditionalService;

    @Override
    public PolicyMemberStatistics findFamilyReportTotalInfo(LoginUserInfo qry) {
        PolicyMemberStatistics pms = PolicyMemberStatistics.builder().userId(qry.getUserId()).build();
        return policyMemberStatisticsGateway.findFamilyReportTotalInfo(pms);
    }

    @Override
    public List<PolicyMemberStatistics> findFamilyMemberTotalInfo(MemberTotalInfoQry qry) {
        PolicyMemberStatistics pms =  new PolicyMemberStatistics();
        pms.setUserId(qry.getUserId());
        if(Objects.nonNull(qry.getMemberId())){
            pms.setMemberId(qry.getMemberId()); //当memberId为空时查全部的
        }
        return policyMemberStatisticsGateway.findFamilyMemberTotalInfo(pms);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = Exception.class,
            transactionManager = "policyCenterTransactionManager")
    public void updateMemberStatisticsInfo(PolicyMemberStatistics pms) {
        PolicyMemberStatistics rpm = policyMemberStatisticsGateway.findByUserIdAndMemberId(pms);
        if (Objects.isNull(rpm)) {
           policyMemberStatisticsGateway.save(pms);
        } else {
           policyMemberStatisticsGateway.update(pms);
        }
    }

    @Override
    public void deleteMemberStatisticsInfo(String userId, Long memberId) {
        PolicyMemberStatistics pms = PolicyMemberStatistics.builder().userId(userId).memberId(memberId).build();
        int delFlag = policyMemberStatisticsGateway.delete(pms);
        log.info("deleteMemberStatisticsInfo userId:{},memberId:{},delFlag:{}",userId,memberId,delFlag);
    }
}
