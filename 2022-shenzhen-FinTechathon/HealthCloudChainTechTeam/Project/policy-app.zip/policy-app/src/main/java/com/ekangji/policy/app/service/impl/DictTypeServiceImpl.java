package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.app.convertor.DictTypeCmdConvertor;
import com.ekangji.policy.api.IDictTypeService;
import com.ekangji.policy.domain.dict.DictType;
import com.ekangji.policy.domain.gateway.DictTypeGateway;
import com.ekangji.policy.domain.gateway.UserGateway;
import com.ekangji.policy.dto.clientobject.dict.DictTypeVO;
import com.ekangji.policy.dto.command.dict.*;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * 字典类型
 *
 * @author zhangjun
 * @date 2021/11/28 14:05
 */
@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IDictTypeService.class)
public class DictTypeServiceImpl implements IDictTypeService {

    @Resource
    private DictTypeGateway dictTypeGateway;

    @Resource
    private DictTypeCmdConvertor dictTypeCmdConvertor;

    @Resource
    private UserGateway userGateway;


    @Override
    public ApiResult add(DictTypeAddCmd cmd) {
        DictType dictData = dictTypeCmdConvertor.convert(cmd);
        //重复的不能添加
        DictType dictTypeByName = dictTypeGateway.get(DictType.builder().dictName(dictData.getDictName()).build());
        if (Objects.nonNull(dictTypeByName)){
            return ApiResult.buildFailure("字典名称已存在");
        }
        DictType dictTypeByType = dictTypeGateway.get(DictType.builder().dictType(dictData.getDictType()).build());
        if (Objects.nonNull(dictTypeByType)){
            return ApiResult.buildFailure("字典类型已存在");
        }
        Long save = dictTypeGateway.save(dictData);
        return save > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public ApiResult delete(DictTypeDeleteCmd cmd) {
        DictType dictData = dictTypeCmdConvertor.convert(cmd);
        DictType oldDict = dictTypeGateway.get(dictData);
        if (Objects.isNull(oldDict)){
            return ApiResult.buildFailure("数据库不存在！");
        }
        //正常状态的不能删除
        if (Objects.equals(oldDict.getStatus(),CommonStatusEnum.VALID.getCode())){
            return ApiResult.buildFailure("状态正常的字典类型不能删除");
        }
        int delete = dictTypeGateway.delete(dictData);
        return delete > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    /**
     * 批量删除字典类型
     * @param cmd
     * @return
     */
    @Override
    public ApiResult batchDelete(DictTypeBatchDeleteCmd cmd) {
        if (CollectionUtils.isEmpty(cmd.getDictIds())){
            return ApiResult.buildFailure("请传入字典类型编码");
        }
        for (Long dictId : cmd.getDictIds()){
            DictType oldDict = dictTypeGateway.get(DictType.builder().dictId(dictId).build());
            if (Objects.isNull(oldDict)){
                return ApiResult.buildFailure("数据库不存在"+ dictId);
            }
            //正常状态的不能删除
            if (Objects.equals(oldDict.getStatus(),CommonStatusEnum.VALID.getCode())){
                return ApiResult.buildFailure("状态正常的字典类型不能删除");
            }
            dictTypeGateway.delete(DictType.builder().dictId(dictId).build());
        }
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult edit(DictTypeEditCmd cmd) {
        DictType dictData = dictTypeCmdConvertor.convert(cmd);
        int update = dictTypeGateway.update(dictData);
        return update > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public ApiResult<List<DictTypeVO>> queryList(DictTypeQry qry) {
        DictType dictData = dictTypeCmdConvertor.convert(qry);
        List<DictType> dictDataList = dictTypeGateway.list(dictData);
        List<DictTypeVO> dictDataVOList = dictTypeCmdConvertor.convert(dictDataList);
        dictDataVOList.stream().forEach(vo -> {
            extracted(vo);
        });
        return ApiResult.of(dictDataVOList);
    }

    @Override
    public ApiResult<PageInfo<DictTypeVO>> queryPage(DictTypePageQry qry) {
        DictType dictData = dictTypeCmdConvertor.convert(qry);
        PageInfo<DictType> pageInfo = dictTypeGateway.page(dictData);
        PageInfo<DictTypeVO> voPageInfo = dictTypeCmdConvertor.convert(pageInfo);

        if (CollectionUtils.isNotEmpty(voPageInfo.getList())){
            voPageInfo.getList().stream().forEach(vo -> {
                extracted(vo);
            });
        }
        return ApiResult.of(voPageInfo);
    }

    private void extracted(DictTypeVO vo) {
        vo.setStatusDesc(CommonStatusEnum.getMsgByCode(vo.getStatus()));
        vo.setCreateName(userGateway.getUserName(vo.getCreateBy()));
        vo.setUpdateName(userGateway.getUserName(vo.getUpdateBy()));
    }
}
