package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.domain.policy.UserFamilyInfo;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberVO;
import com.ekangji.policy.dto.command.member.FamilyEnsuredCalcCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyMemberEditCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 * @author sunqihua
 * @date 2022-05-22 14:05:49
 */
@Mapper(componentModel = "spring")
public interface UserFamilyInfoCmdConvertor {

    UserFamilyInfo convert(UserFamilyMemberEditCmd userFamilyMemberEditCmd);

    List<UserFamilyMemberVO> convert(List<UserFamilyInfo> userFamilyInfoList);



}
