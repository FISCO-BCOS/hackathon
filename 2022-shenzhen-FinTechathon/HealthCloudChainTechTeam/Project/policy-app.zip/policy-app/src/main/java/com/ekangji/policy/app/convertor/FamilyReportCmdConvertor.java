package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.PolicyMemberStatistics;
import com.ekangji.policy.dto.clientobject.policy.familyreport.FamilyReportTotalInfoVO;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface FamilyReportCmdConvertor {

    FamilyReportTotalInfoVO convert(PolicyMemberStatistics param);
}
