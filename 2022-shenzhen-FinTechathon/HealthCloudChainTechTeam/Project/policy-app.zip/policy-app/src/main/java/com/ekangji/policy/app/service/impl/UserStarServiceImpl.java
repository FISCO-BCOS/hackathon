package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSON;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.common.tool.util.RandomUtil;
import com.ekangji.policy.api.ExecuteChainService;
import com.ekangji.policy.api.StarChainService;
import com.ekangji.policy.api.UserStarService;
import com.ekangji.policy.app.convertor.StarCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.MaterialTypeEnum;
import com.ekangji.policy.common.enums.PictureSerialEnum;
import com.ekangji.policy.domain.gateway.DigitalPolicyGateway;
import com.ekangji.policy.domain.gateway.PictureMaterialGateway;
import com.ekangji.policy.domain.gateway.StarChainGateway;
import com.ekangji.policy.domain.gateway.UserStarGateway;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.PictureMaterial;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.dto.clientobject.star.StarStatisticsVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.ekangji.policy.dto.command.policy.ChainEditCmd;
import com.ekangji.policy.dto.command.policy.UserStarAddCmd;
import com.ekangji.policy.dto.command.policy.UserStarEditCmd;
import com.ekangji.policy.dto.command.star.UserStarPageQry;
import com.ekangji.policy.dto.command.star.UserStarQry;
import com.ekangji.policy.dto.command.user.LoginUserInfo;
import com.ekangji.policy.infrastructure.utils.MathUtil;
import com.ekangji.policy.infrastructure.utils.RedisUtil;
import com.ekangji.policy.infrastructure.utils.StrUtils;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.policy.common.constant.RedisKeys;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = UserStarService.class)
public class UserStarServiceImpl implements UserStarService {

    @Resource
    private UserStarGateway userStarGateway;
    @Resource
    private PictureMaterialGateway pictureMaterialGateway;
    @Resource
    private RedisUtil redisUtil;

    @Resource
    private StarCmdConvertor convertor;

    @Resource
    private StarChainGateway starChainGateway;

    @Resource
    private DigitalPolicyGateway digitalPolicyGateway;
    @Resource
    private UserChannelInfoService userChannelInfoService;
    @Override
    public ApiResult checkUserHaveStar(LoginUserInfo loginUserInfo) {
        UserStar query = UserStar.builder().userId(loginUserInfo.getUserId()).build();
        UserStar userStar = userStarGateway.get(query);
        if (Objects.nonNull(userStar)) {
            return ApiResult.of(Constants.ONE);
        }
        return ApiResult.of(Constants.ZERO);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult buildUserStar(UserStarAddCmd userStarAddCmd) {
        PictureMaterial pictureMaterial1 = PictureMaterial.builder().materialId(userStarAddCmd.getMaterialId()).build();
        PictureMaterial entity = pictureMaterialGateway.get(pictureMaterial1);
        if (Objects.isNull(entity)
                || StringUtils.isBlank(entity.getFileId())) {
            return ApiResult.buildFailure("图片库文件未上传");
        }
        if (StringUtils.isNotEmpty(userStarAddCmd.getNickName())) {
            if (StrUtils.length(userStarAddCmd.getNickName()) > 12) {
                return ApiResult.buildFailure("星球名称不能太长哦！");
            }
            if (StrUtils.isSpecialChar(userStarAddCmd.getNickName())) {
                return ApiResult.buildFailure("昵称无法修改成功");
            }
        }
        entity.setUsedNum(Objects.isNull(entity.getUsedNum())?Constants.ONE: entity.getUsedNum() + 1);
        if(Objects.isNull(entity.getTotalNum())) {
            return ApiResult.buildFailure("图片库库存有误");
        }
        if (entity.getUsedNum() > entity.getTotalNum()) {
            return ApiResult.buildFailure("此星球已被抢空，请选择其他星球");
        }
        int diff = MathUtil.getNumLength(entity.getTotalNum()) - MathUtil.getNumLength(entity.getUsedNum());
        StringBuilder numBuilder = new StringBuilder();
        for (int i = 0; i < diff; i++) {
            numBuilder.append(Constants.ZERO);
        }
        String prefix = PictureSerialEnum.STAR.getCode();
        //根据规则 生成数字保单的编号
        String stringBuilder = prefix +
                entity.getCollectionNumber() +
                "#" +
                numBuilder.toString() + entity.getUsedNum() +
                "/" +
                entity.getTotalNum();
        String phoneNumber = Strings.EMPTY;
        ApiResult<String> phone = userChannelInfoService.getPhoneNumberByUserId(userStarAddCmd.getUserId());

        if (phone.getSuccess()) {
            phoneNumber = phone.getData();
        }
        UserStar userStar = UserStar.builder()
                .starId(IdUtil.getSnowflakeNextId())
                .userId(userStarAddCmd.getUserId())
                .nickName(userStarAddCmd.getNickName())
                .userPhone(phoneNumber)
                .fileId(entity.getFileId())
                .sequence(stringBuilder)
                .build();

        long l = userStarGateway.save(userStar);
        pictureMaterialGateway.updateById(entity);
        Object userNums = redisUtil.get(RedisKeys.STAR_DRAW_USER_NUM);
        String nowNum;
        if (ObjectUtils.isEmpty(userNums)) {
            nowNum = String.valueOf(Constants.DEFAULT_SCORE * Constants.DEFAULT_SCORE);
        } else {
            nowNum =String.valueOf(Integer.parseInt(userNums.toString()) + (int) (10 + Math.random() * (20 - 10 + 1)));
        }
        redisUtil.setEx(RedisKeys.STAR_DRAW_USER_NUM, nowNum, Constants.INTEGRAL_ENOUGH_STAY_TIME, TimeUnit.DAYS);
        return ApiResult.of(userStar.getStarId().toString());
//        return executeChainService.chainGateWay(convertor.convert(userStarAddCmd), MaterialTypeEnum.STAR_PIC);
    }

    @Override
    public ApiResult<StarVO> queryUserStar(UserStarQry userStarQry) {
        UserStar query = null;
        if (Objects.nonNull(userStarQry.getStarId())) {
            query = UserStar.builder().starId(userStarQry.getStarId()).build();
        } else {
            query = UserStar.builder().userId(userStarQry.getUserId()).build();
        }

        UserStar userStar = userStarGateway.get(query);
        if (Objects.isNull(userStar)) {
           return ApiResult.buildFailure("请先领取星球");
        }
        StarVO starVO = convertor.convert(userStar);
        return ApiResult.of(starVO);
    }

    @Override
    public ApiResult<Integer> editUserStar(UserStarEditCmd userStarEditCmd) {
        if(StringUtils.isBlank(userStarEditCmd.getNickName())){
            return ApiResult.buildFailure("昵称不能为空");
        }
        if (userStarEditCmd.getNickName().length() > 32) {
            return ApiResult.buildFailure("昵称不能超过32个字符");
        }
        UserStar entity = UserStar.builder().starId(userStarEditCmd.getStarId()).nickName(userStarEditCmd.getNickName()).build();
        return ApiResult.of(userStarGateway.update(entity));
    }

    @Override
    public ApiResult<PageInfo<StarStatisticsVO>> queryUserStarPage(UserStarPageQry qry) {
        UserStar userStar = convertor.convert(qry);
        PageInfo<UserStar> pageInfo = userStarGateway.page(userStar);
        PageInfo<StarStatisticsVO> pageVO = convertor.convert(pageInfo);
        buildStatisticsVO(pageVO.getList());
        return ApiResult.of(pageVO);
    }

    @Override
    public ApiResult<String> queryTotalStarNum() {
        Object totalNum = redisUtil.get(RedisKeys.STAR_DRAW_USER_NUM);
        if(Objects.isNull(totalNum)) {
            totalNum = RandomUtil.randomInt(10000,20000);
        }
        return ApiResult.of(String.valueOf(totalNum));
    }

    private void buildStatisticsVO(List<StarStatisticsVO> statisticsVOList) {
       List<String> userIdList = statisticsVOList.stream()
               .map(StarStatisticsVO::getUserId).collect(Collectors.toList());
       if (CollectionUtils.isNotEmpty(userIdList)) {
           List<StarChain> starChainList = starChainGateway.listByUserIds(userIdList);
           Map<String,Integer> chainLengthMap = starChainList.stream()
                   .collect(Collectors.toMap(StarChain::getUserId,StarChain::getLength, (v1, v2) -> v2));
           //统计用户数字保单
           List<DigitalPolicy> digitalPolicyList = digitalPolicyGateway.countDigitalNumByUserIds(userIdList);
           Map<String,Integer> digitalNumMap = digitalPolicyList.stream()
                   .collect(Collectors.toMap(DigitalPolicy::getUserId,DigitalPolicy::getDigitalNum, (v1, v2) -> v2));
           statisticsVOList.forEach(starStatisticsVO -> {
               Integer inviteNum = Constants.ZERO;
               Integer length = chainLengthMap.get(starStatisticsVO.getUserId());
               if(Objects.isNull(length)){
                   length = Constants.ZERO;
               } else {
                   inviteNum = length - Constants.ONE;
               }
               Integer digitalNum = digitalNumMap.get(starStatisticsVO.getUserId());
               starStatisticsVO.setDigitalNum(Objects.isNull(digitalNum)?Constants.ZERO:digitalNum);
               starStatisticsVO.setLength(length);
               starStatisticsVO.setInviteNum(inviteNum);
               starStatisticsVO.setUserPhone(StrUtils.phoneDesensitization(starStatisticsVO.getUserPhone()));
           });
       }
    }
}
