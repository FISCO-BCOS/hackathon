package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.domain.policy.MemberEnsuredInfo;
import com.ekangji.policy.dto.command.member.FamilyEnsuredCalcCmd;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.ekangji.policy.infrastructure.dao.dataobject.FamilyEnsuredInfoDO;
import org.mapstruct.Mapper;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 */
@Mapper(componentModel = "spring")
public interface FamilyEnsuredInfoCmdConvertor {

    FamilyEnsuredInfo convert(FamilyEnsuredCalcCmd familyEnsuredCalcCmd);



}
