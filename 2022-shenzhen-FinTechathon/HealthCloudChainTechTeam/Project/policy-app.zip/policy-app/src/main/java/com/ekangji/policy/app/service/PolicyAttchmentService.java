package com.ekangji.policy.app.service;

import com.ekangji.policy.domain.policy.Policy;

import java.util.List;

public interface PolicyAttchmentService {

    /**
     * 附件保存
     *
     * @param policyId
     * @param fileId
     * @return
     */
    int add(Long policyId, List<String> fileId);

    /**
     * 附件编辑
     *
     * @param policyId
     * @param fileId
     * @return
     */
    int edit(Long policyId, List<String> fileId);

    /**
     * 备份保存附件
     * @param parentPolicyId
     * @param newPolicyId
     */
    void addBackup(Long parentPolicyId, Long newPolicyId);

    /**
     * 获取附件
     * @param policy
     * @return
     */
    List<String> findAttchmentByPolicy(Policy policy);
}
