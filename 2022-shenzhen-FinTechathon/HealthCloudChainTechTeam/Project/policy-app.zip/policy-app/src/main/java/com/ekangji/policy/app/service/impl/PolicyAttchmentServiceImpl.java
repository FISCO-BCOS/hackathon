package com.ekangji.policy.app.service.impl;

import com.ekangji.policy.app.service.PolicyAttchmentService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.domain.gateway.PolicyAttchmentGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAttchment;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PolicyAttchmentServiceImpl implements PolicyAttchmentService {

    @Resource
    private PolicyAttchmentGateway policyAttchmentGateway;

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public int add(Long policyId, List<String> fileId) {
        if (CollectionUtils.isNotEmpty(fileId)) {
            List<PolicyAttchment> attchmentList = convertData(policyId,fileId);
            return policyAttchmentGateway.batchSave(attchmentList);
        }
        return Constants.ZERO;
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public int edit(Long policyId, List<String> fileId) {
        int num = policyAttchmentGateway.deleteByPolicy(PolicyAttchment.builder().policyId(policyId).build());
        log.info("policy attchment edit delete num:{}",num);

        if (CollectionUtils.isNotEmpty(fileId)) {
            List<PolicyAttchment> attchmentList = convertData(policyId,fileId);
            return policyAttchmentGateway.batchSave(attchmentList);
        }
        return Constants.ZERO;
    }

    @Override
    public void addBackup(Long parentPolicyId, Long newPolicyId) {
        PolicyAttchment policyAttchment = PolicyAttchment.builder().policyId(parentPolicyId)
                .delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        List<PolicyAttchment> policyAttchmentList = policyAttchmentGateway.list(policyAttchment);
        for (PolicyAttchment attchment : policyAttchmentList) {
            PolicyAttchment backupAttchment = PolicyAttchment.builder().policyId(newPolicyId).fileId(attchment.getFileId()).build();
            policyAttchmentGateway.save(backupAttchment);
        }
    }

    @Override
    public List<String> findAttchmentByPolicy(Policy policy) {
        PolicyAttchment policyAttchment = PolicyAttchment.builder().policyId(policy.getPolicyId())
                .delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        List<PolicyAttchment> policyAttchmentList = policyAttchmentGateway.list(policyAttchment);
        return policyAttchmentList.stream().map(PolicyAttchment::getFileId).collect(Collectors.toList());
    }

    private List<PolicyAttchment> convertData(Long policyId, List<String> fileId) {
        List<PolicyAttchment> attchmentList = fileId.parallelStream().map(f ->{
            return PolicyAttchment.builder().policyId(policyId).fileId(f).build();
        }).collect(Collectors.toList());
        return attchmentList;
    }

}
