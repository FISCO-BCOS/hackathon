package com.ekangji.policy.app.service.impl;

import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.schedulerx.shade.org.apache.http.entity.ContentType;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.file.center.client.api.FileCenterService;
import com.ekangji.file.center.client.clientobject.FileInfoVO;
import com.ekangji.file.center.client.clientobject.FileObjectVO;
import com.ekangji.file.center.client.command.FileQry;
import com.ekangji.file.center.client.command.FileUploadCmd;
import com.ekangji.policy.api.UserFamilyInfoService;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.RelationEnum;
import com.ekangji.policy.domain.gateway.PolicyBeneficiaryGateway;
import com.ekangji.policy.domain.gateway.PolicyGateway;
import com.ekangji.policy.domain.gateway.PolicyInsurantGateway;
import com.ekangji.policy.domain.gateway.UserFamilyInfoGateway;
import com.ekangji.policy.domain.policy.*;
import com.ekangji.policy.domain.user.User;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberDetailVO;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberVO;
import com.ekangji.policy.dto.clientobject.policy.UserMemberRelationVO;
import com.ekangji.policy.dto.command.policy.family.UserFamilyDeleteCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyMemberEditCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyQry;
import com.ekangji.policy.infrastructure.utils.*;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.common.constant.Constants;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.validation.ValidationException;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = UserFamilyInfoService.class)
public class UserFamilyInfoServiceImpl implements UserFamilyInfoService {

    @Resource
    private UserFamilyInfoGateway userFamilyInfoGateway;
    @Resource
    private UserChannelInfoService userChannelInfoService;
    @Resource
    private PolicyBeneficiaryGateway policyBeneficiaryGateway;
    @Resource
    private PolicyGateway policyGateway;
    @Resource
    private PolicyInsurantGateway policyInsurantGateway;
    @Resource
    private FileCenterService fileCenterService;

    @Value("${aliyun.bucketName}")
    private String bucketName;

    @Value("${nft.fileId}")
    private String nftFileId;

    @Value("${nft_url_prefix}")
    private String nftUrlPre;
    @Override
    public ApiResult<List<UserFamilyMemberVO>> findFamilyListByUserId(UserFamilyQry userFamilyQry) {
        List<UserFamilyInfo> userFamilyInfos = userFamilyInfoGateway.selectListByUserId(userFamilyQry.getUserId());
        List<UserFamilyMemberVO> resultList = new ArrayList<>();
        userFamilyInfos.forEach(x -> {
            UserFamilyMemberVO userFamilyMemberVO = new UserFamilyMemberVO();
            userFamilyMemberVO.setMemberId(x.getMemberId());
            userFamilyMemberVO.setRelation(RelationEnum.getMsgByCode(x.getRelation()));
            userFamilyMemberVO.setName(x.getNickName());
            userFamilyMemberVO.setUserPhoto(x.getUserPhoto());
            userFamilyMemberVO.setBackFlag(x.getBackFlag());
            resultList.add(userFamilyMemberVO);
        });
        return ApiResult.of(resultList);
    }

    /**
     * 根据用户ID查询该用户有保单的家庭成员列表
     * @param userFamilyQry
     * @return
     */
    @Override
    public ApiResult<List<UserFamilyMemberVO>> findFamilyListWithPolicyByUserId(UserFamilyQry userFamilyQry) {
        List<UserFamilyInfo> userFamilyInfos = userFamilyInfoGateway.selectListByUserId(userFamilyQry.getUserId());
        // 成员ID数组
        List<Long> memberIds = userFamilyInfos.stream().map(UserFamilyInfo::getMemberId).collect(Collectors.toList());
        // 被保人-保单关系对象集合
        List<PolicyInsurant> policyInsurantList = policyInsurantGateway.list(PolicyInsurant.builder().insurantIds(memberIds).build());
        if(CollectionUtils.isEmpty(policyInsurantList)){
            log.info("findFamilyListWithPolicyByUserId 用户{}的家庭成员均无保单",userFamilyQry.getUserId());
            return ApiResult.of(Collections.emptyList());
        }
        // 家庭成员ID集合Map
        Map<Long, Long> memberIdListMap = policyInsurantList.stream()
                .collect(Collectors.toMap(PolicyInsurant::getInsurantId, PolicyInsurant::getInsurantId,(v1,v2)->v1));
        // 初始化有保单的家庭成员集合
        List<UserFamilyMemberVO> memberWithPolicyList = new ArrayList<>();
        userFamilyInfos.forEach(memberInfo -> {
            if(Objects.nonNull(memberIdListMap.get(memberInfo.getMemberId()))){
                UserFamilyMemberVO userFamilyMemberVO = new UserFamilyMemberVO();
                userFamilyMemberVO.setMemberId(memberInfo.getMemberId());
                userFamilyMemberVO.setRelation(RelationEnum.getMsgByCode(memberInfo.getRelation()));
                userFamilyMemberVO.setName(memberInfo.getNickName());
                userFamilyMemberVO.setUserPhoto(memberInfo.getUserPhoto());
                userFamilyMemberVO.setBackFlag(memberInfo.getBackFlag());
                memberWithPolicyList.add(userFamilyMemberVO);
            }
        });
        return ApiResult.of(memberWithPolicyList);
    }


    @Override
    public ApiResult<UserFamilyMemberDetailVO> findFamilyByMemberId(UserFamilyQry userFamilyQry) {
        UserFamilyInfo entity = this.getEntity(userFamilyQry.getMemberId());
        if (Objects.isNull(entity)) {
            return ApiResult.buildFailure("不存在该成员信息");
        }
        UserFamilyMemberDetailVO userFamilyMemberDetailVO = new UserFamilyMemberDetailVO();
        BeanUtils.copyProperties(entity, userFamilyMemberDetailVO);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(entity.getBirthday());
        Date date = calendar.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        userFamilyMemberDetailVO.setBirthday(format.format(date));
        return ApiResult.of(userFamilyMemberDetailVO);
    }

    @Override
    public ApiResult<Integer> deleteFamilyMember(UserFamilyDeleteCmd userFamilyDeleteCmd) {
        //作为投保人的校验
        Policy policyOne= policyGateway.selectEntityByPolicyHolderId(Long.valueOf(userFamilyDeleteCmd.getMemberId()));
        if(Optional.ofNullable(policyOne).isPresent()){
            return ApiResult.buildFailure("该成员作为投保人有保单不能删除");
        }
        //作为被保人的校验
        PolicyInsurant policyInsurant=PolicyInsurant.builder().insurantId(Long.valueOf(userFamilyDeleteCmd.getMemberId())).build();
        List<PolicyInsurant> list = policyInsurantGateway.list(policyInsurant);
        if(CollectionUtils.isNotEmpty(list)){
            return ApiResult.buildFailure("该成员作为被保人有保单不能删除");
        }
        //作为受益人的校验
        PolicyBeneficiary policyBeneficiary = policyBeneficiaryGateway.selectEntityByMemberId(Long.valueOf(userFamilyDeleteCmd.getMemberId()));
        if(Optional.ofNullable(policyBeneficiary).isPresent()){
            return ApiResult.buildFailure("该成员作为收益人有保单不能删除");
        }
        UserFamilyInfo entity = this.getEntity(Long.valueOf(userFamilyDeleteCmd.getMemberId()));
        if(!Optional.ofNullable(entity).isPresent()){
            return ApiResult.buildFailure("不存在该成员信息");
        }
        entity.setDelFlag(DeleteFlagEnum.DELETED.getCode());
        int update = userFamilyInfoGateway.update(entity);
        return ApiResult.of(update);
    }

    @Override
    public ApiResult<Long> maintainFamilyMember(UserFamilyMemberEditCmd userFamilyMemberEditCmd) {
        UserFamilyInfo userFamilyInfo = JSON.parseObject(JSON.toJSONString(userFamilyMemberEditCmd), UserFamilyInfo.class);
        Long save = 0L;
        int update = 0;
        if(StringUtils.isNotBlank(userFamilyMemberEditCmd.getPhoneNumber())){
            if(!IdentityUtils.isMobile(userFamilyMemberEditCmd.getPhoneNumber())) {
                return ApiResult.buildFailure("手机号格式有误");
            }
        }
        //检查用户昵称字符长度
        if (Objects.nonNull(userFamilyMemberEditCmd.getNickName())&&StringUtils.isNotBlank(userFamilyMemberEditCmd.getNickName())) {
            if (!this.checkLength(userFamilyMemberEditCmd.getNickName())) {
                return ApiResult.buildFailure("名字不能超过20个字符");
            }
        }
        //检查用户真实姓名字符长度
        if (Objects.nonNull(userFamilyMemberEditCmd.getName())&&StringUtils.isNotBlank(userFamilyMemberEditCmd.getName())) {
            if (!this.checkLength(userFamilyMemberEditCmd.getName())) {
                return ApiResult.buildFailure("真实姓名不能超过20个字符");
            }
        }
        //校验每个用户下 本人的关系记录只能有一条
        if (RelationEnum.MYSELF.getCode().equals(userFamilyMemberEditCmd.getRelation())) {
            UserFamilyInfo entity0 = userFamilyInfoGateway.selectEntityByUserIdAndRelation(userFamilyMemberEditCmd.getBelongUserId(), userFamilyMemberEditCmd.getRelation());
            if (Objects.nonNull(entity0)) {
                if(Objects.isNull(userFamilyInfo.getMemberId())
                        ||!entity0.getMemberId().equals(userFamilyInfo.getMemberId())) {
                    return ApiResult.buildFailure("该用户下已存在本人关系的记录");
                }
            }
        }
        //检验统一用户下成员有没有同名的
        UserFamilyInfo entity1 = userFamilyInfoGateway.selectEntityByUserIdAndName(userFamilyMemberEditCmd.getBelongUserId(), userFamilyMemberEditCmd.getNickName());
        if (Objects.nonNull(entity1)) {
            if(Objects.isNull(userFamilyInfo.getMemberId())
                    ||!entity1.getMemberId().equals(userFamilyInfo.getMemberId())) {
                return ApiResult.buildFailure("该用户下已存在该成员名称");
            }
        }
        //检验统一用户下身份证信息有没有重复的
        if (Objects.nonNull(userFamilyMemberEditCmd.getIdentityCardType()) && StringUtils.isNotBlank(userFamilyMemberEditCmd.getIdentityCardNumber())) {
            //如果证件是身份证 需要校验身份证号
            if (userFamilyMemberEditCmd.getIdentityCardType().equals(0)) {
                if (!IdentityUtils.isIDNumber(userFamilyMemberEditCmd.getIdentityCardNumber())) {
                    return ApiResult.buildFailure("身份证号码格式有误");
                }
            }
            UserFamilyInfo entity2 = userFamilyInfoGateway.selectEntityByCard(userFamilyMemberEditCmd.getBelongUserId(), userFamilyMemberEditCmd.getIdentityCardType(), userFamilyMemberEditCmd.getIdentityCardNumber());
            if (Objects.nonNull(entity2)) {
                if(Objects.isNull(userFamilyInfo.getMemberId())
                        ||!entity2.getMemberId().equals(userFamilyInfo.getMemberId())) {
                    return ApiResult.buildFailure("该用户下已存在该证件信息");
                }
            }
        }
        //根据成员id 判断新增或者修改
        if (Objects.isNull(userFamilyInfo.getMemberId())) {
            //根据用户id获取手机号
            ApiResult<String> phone = userChannelInfoService.getPhoneNumberByUserId(userFamilyMemberEditCmd.getBelongUserId());
            if(phone.getSuccess()) {
//                String userPhone = StrUtils.phoneDesensitization(phone.getData());
                userFamilyInfo.setUserPhoneNumber(phone.getData());
            }
            userFamilyInfo.setMemberId(IdUtil.getSnowflakeNextId());
            save = userFamilyInfoGateway.save(userFamilyInfo);
        } else {
            UserFamilyInfo entity = this.getEntity(userFamilyInfo.getMemberId());
            if (Objects.nonNull(entity)) {
                if (Objects.nonNull(userFamilyInfo.getBirthday())) {
                    //比较该成员出生日期是否一致  如果不一致代表要修改出生日期 那么需要判断该人有没有作为被保人的保单 如果有 则不让修改
                    DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                    String d1 = format.format(entity.getBirthday());
                    String d2 = format.format(userFamilyInfo.getBirthday());
                    if (!d1.equals(d2)) {
                        PolicyInsurant policyInsurant = PolicyInsurant.builder().insurantId(entity.getMemberId()).build();
                        List<PolicyInsurant> list = policyInsurantGateway.list(policyInsurant);
                        if (CollectionUtils.isNotEmpty(list)) {
                            return ApiResult.buildFailure("该用户作为被保人有保单，不允许修改出生日期");
                        }
                    }
                }
                update = userFamilyInfoGateway.update(userFamilyInfo);
            }
        }
        return ApiResult.of(save + update);
    }

    @Override
    public ApiResult<List<UserMemberRelationVO>> relationList() {
        List<UserMemberRelationVO> list=new ArrayList<>();
        for (RelationEnum value : RelationEnum.values()) {
            UserMemberRelationVO userMemberRelationVO=new UserMemberRelationVO();
            userMemberRelationVO.setRelationId(value.getCode());
            userMemberRelationVO.setRelationName(value.getMsg());
            list.add(userMemberRelationVO);

        }
        return ApiResult.of(list);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW,rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public Long saveFamilyMember(UserFamilyMemberEditCmd userFamilyMemberEditCmd) {
        UserFamilyInfo userFamilyInfo = JSON.parseObject(JSON.toJSONString(userFamilyMemberEditCmd), UserFamilyInfo.class);
        if(StringUtils.isNotBlank(userFamilyMemberEditCmd.getPhoneNumber())){
            if(!IdentityUtils.isMobile(userFamilyMemberEditCmd.getPhoneNumber())) {
                throw new ValidationException("手机号格式有误");
            }
        }

        //检验统一用户下身份证信息有没有重复的
        if (Objects.nonNull(userFamilyMemberEditCmd.getIdentityCardType()) && StringUtils.isNotEmpty(userFamilyMemberEditCmd.getIdentityCardNumber())) {
            //如果证件是身份证 需要校验身份证号
            if (userFamilyMemberEditCmd.getIdentityCardType().equals(0)) {
                if (!IdentityUtils.isIDNumber(userFamilyMemberEditCmd.getIdentityCardNumber())) {
                    throw new ValidationException("身份证号码格式有误");
                }
            }else {
                if (!IdentityUtils.isCardNumber(userFamilyMemberEditCmd.getIdentityCardNumber())) {
                    throw new ValidationException("证件号码格式有误");
                }
            }
            UserFamilyInfo entity2 = userFamilyInfoGateway.selectEntityByCard(userFamilyMemberEditCmd.getBelongUserId(), userFamilyMemberEditCmd.getIdentityCardType(), userFamilyMemberEditCmd.getIdentityCardNumber());
            if (Objects.nonNull(entity2)) {
                return entity2.getMemberId();
            }
        }

        //检查用户昵称字符长度
        if (StringUtils.isNotEmpty(userFamilyMemberEditCmd.getNickName())) {
            if (!this.checkLength(userFamilyMemberEditCmd.getNickName())) {
                throw new ValidationException("名字不能超过20个字符");
            }
            //检验统一用户下成员有没有同名的
            UserFamilyInfo entity1 = userFamilyInfoGateway.selectEntityByUserIdAndName(userFamilyMemberEditCmd.getBelongUserId(), userFamilyMemberEditCmd.getNickName());
            if (Objects.nonNull(entity1)) {
               return entity1.getMemberId();
            }
        } else {
            throw new ValidationException("名字不能为空");
        }

        //检查用户真实姓名字符长度
        if (StringUtils.isNotEmpty(userFamilyMemberEditCmd.getName())) {
            if (!this.checkLength(userFamilyMemberEditCmd.getName())) {
                throw new ValidationException("真实姓名不能超过20个字符");
            } else {
                String birthday = userFamilyMemberEditCmd.getBirthday();
                UserFamilyInfo queryFamilyInfo = UserFamilyInfo.builder().belongUserId(userFamilyMemberEditCmd.getBelongUserId())
                        .name(userFamilyMemberEditCmd.getName()).birthday(DateUtil.parseDate(birthday,DateUtil.datePattern)).build();
                List<UserFamilyInfo> familyInfos = userFamilyInfoGateway.list(queryFamilyInfo);
                if (CollectionUtils.isNotEmpty(familyInfos)) {
                    return familyInfos.get(0).getMemberId();
                }
            }
        }

        //根据用户id获取手机号
        ApiResult<String> phone = userChannelInfoService.getPhoneNumberByUserId(userFamilyMemberEditCmd.getBelongUserId());
        if(phone.getSuccess()) {
//            String userPhone = StrUtils.phoneDesensitization(phone.getData());
            userFamilyInfo.setUserPhoneNumber(phone.getData());
        }
        userFamilyInfo.setMemberId(IdUtil.getSnowflakeNextId());
        return  userFamilyInfoGateway.save(userFamilyInfo);
    }

    @Override
    public ApiResult<String> generateNftPolicy(UserFamilyMemberEditCmd userFamilyMemberEditCmd) {
        //根据fileId下载下来样例文件
        ApiResult<FileObjectVO> download = fileCenterService.download(nftFileId);
        PrintImageUtil tt = new PrintImageUtil();
        File storeFile = new File(download.getData().getFileName());

        BufferedImage d = null;
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(download.getData().getBytes());    //将b作为输入流；
            d = ImageIO.read(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
        tt.modifyImage(d, userFamilyMemberEditCmd.getNickName(), -400, 708);
        tt.modifyImage(d, userFamilyMemberEditCmd.getIdentityCardNumber(), -280, 850);
        FileUploadCmd cmd = new FileUploadCmd();
        cmd.setBucketName(bucketName);
//        cmd.setCreateBy(ShiroUtils.getUserIdStr());
        // 这里设置OriginalFileName fileName也会赋上值
        cmd.setOriginalFileName(download.getData().getFileName());
        try {
            cmd.setBytes(bufferedImageToByteArray(d));
        } catch (IOException e) {
            e.printStackTrace();
        }
//        tt.writeImageLocal("D:\\earth2.jpg", d);
        ApiResult<String> result = fileCenterService.upload(cmd);
        ApiResult<String> stringApiResult = fileCenterService.queryFileUrl(result.getData().toString());

        //构造请求头
        Map<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json;charset=utf-8");

        //构造请求入参
        JSONObject params = new JSONObject();
        HashMap param = new HashMap();
        String paramJson = JSON.toJSONString(param);
        String getSecretUrl =nftUrlPre+"/secretKey/sm2";
        HttpResponse response = HttpUtil.httpPost(getSecretUrl, paramJson, headers);
        String body = response.body();
        JSONObject jsonObject = JSONObject.parseObject(body);
        JSONObject content = JSONObject.parseObject(jsonObject.get("body").toString());

        String uri = stringApiResult.getData();
        params = new JSONObject();
        params.put("account", content.get("address").toString());
        params.put("url", uri);
        paramJson = JSONObject.toJSONString(params, SerializerFeature.IgnoreErrorGetter);
        try {
            String postUrl = nftUrlPre+"/postUrl";
            String resultBody = HttpUtil.post(postUrl, paramJson);
            //得到云链那边执行后的结果 成功运行的结果格式如下
//            {
//                "code":200,
//                    "success":true,
//                    "body":{
//                "account":"0x2caeb0268badf3883f420765caffef9f9eb3060c",
//                        "tokenId":"0x0000000000000000000000000000000000000000000000000000000000000013",
//                        "uri":"bafym3jqbebpsrfpetu2ytfiwlhxt3xz2wont5at2bvv3grfazcyz4azxmkvzg",
//                        "icfsCatUrl":"https://icfs.qjz.world:18088/icfsapi/api/v0/cat?arg=bafym3jqbebpsrfpetu2ytfiwlhxt3xz2wont5at2bvv3grfazcyz4azxmkvzg"
//            }
//            }
            return ApiResult.of(resultBody);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ApiResult.of("");
    }

    /**
     * 将BufferedImage转换为byte[]
     * @param image
     * @return
     */
    private byte[] bufferedImageToByteArray(BufferedImage image) throws IOException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        ImageIO.write(image, "png", os);
        return os.toByteArray();
    }


    /**
     * 根据成员id获取成员对象
     * @param memberId
     * @return
     */
    private UserFamilyInfo getEntity(Long memberId) {
        UserFamilyInfo userFamilyInfo = UserFamilyInfo.builder()
                .memberId(memberId)
                .build();
        return userFamilyInfoGateway.get(userFamilyInfo);
    }
    /**
     * 检验名字字符数
     * @param content
     * @return
     */
    private boolean checkLength(String content) {
        Pattern p = Pattern.compile("^[a-z0-9A-Z\u4e00-\u9fa5]{1,20}+$");
        Matcher m = p.matcher(content);
        return m.matches();
    }

}
