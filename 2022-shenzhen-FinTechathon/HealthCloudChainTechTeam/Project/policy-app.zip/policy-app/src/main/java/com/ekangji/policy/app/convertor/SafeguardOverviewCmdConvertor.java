package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditCompareCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditRadarCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface SafeguardOverviewCmdConvertor {

    SafeguardOverview convert(SafeguardOverviewEditRadarCmd param);

    SafeguardOverview convert(OverviewQry param);

    List<SafeguardOverviewVO> convert(List<SafeguardOverview> param);

    List<SafeguardOverview> convert2(List<SafeguardOverviewEditRadarCmd> param);

    SafeguardOverview convert(SafeguardOverviewEditCompareCmd param);

    SafeguardOverview convert(OverviewCommonQry param);

}
