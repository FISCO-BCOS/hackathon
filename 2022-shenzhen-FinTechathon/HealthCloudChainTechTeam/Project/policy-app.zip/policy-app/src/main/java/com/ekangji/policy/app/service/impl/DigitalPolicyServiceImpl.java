
package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ekangji.ability.api.CloudChainService;
import com.ekangji.ability.dto.clientobject.CloudChainVO;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.DesensitizedUtil;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.file.center.client.api.FileCenterService;
import com.ekangji.file.center.client.clientobject.FileInfoVO;
import com.ekangji.file.center.client.command.FileQry;
import com.ekangji.marketing.client.api.UserDrawInfoService;
import com.ekangji.marketing.client.dto.clientobject.IntegralDetailRuleVO;
import com.ekangji.marketing.client.dto.command.userIntegral.UserIntegralDetailInsertCmd;
import com.ekangji.marketing.client.dto.command.userIntegral.UserIntegralInsertCmd;
import com.ekangji.marketing.client.dto.command.userdraw.UserDrawInfoCmd;
import com.ekangji.marketing.common.enums.ActivityEnum;
import com.ekangji.policy.api.DigitalPolicyService;
import com.ekangji.policy.api.ExecuteChainService;
import com.ekangji.policy.app.convertor.DigitalPolicyCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.*;
import com.ekangji.policy.domain.gateway.DigitalPolicyGateway;
import com.ekangji.policy.domain.gateway.PolicySimpleGateway;
import com.ekangji.policy.domain.gateway.UserInviteInfoGateway;
import com.ekangji.policy.domain.gateway.UserStarGateway;
import com.ekangji.policy.domain.policy.*;
import com.ekangji.policy.domain.policy.pojo.DigitalPolicyDTO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.policy.dto.command.starchain.RelStarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.StarChainAddCmd;
import com.ekangji.policy.infrastructure.utils.MathUtil;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.api.UserThirdMappingService;
import com.ekangji.user.center.client.dto.clientobject.UserChannelInfoVO;
import com.ekangji.user.center.client.dto.clientobject.UserThirdMappingVO;
import com.ekangji.user.center.client.dto.command.UserThirdMappingAddCmd;
import com.ekangji.user.center.client.dto.command.UserThirdMappingQry;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.logging.log4j.util.Strings;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.ekangji.policy.common.constant.Constants.*;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = DigitalPolicyService.class)
public class DigitalPolicyServiceImpl implements DigitalPolicyService {

    @Resource
    private DigitalPolicyGateway digitalPolicyGateway;
    @Resource
    private UserInviteInfoGateway userInviteInfoGateway;
    @Resource
    private DigitalPolicyCmdConvertor digitalPolicyCmdConvertor;
    @Resource
    private PolicySimpleGateway policySimpleGateway;
    @Resource
    private UserStarGateway userStarGateway;
    @Resource
    private UserThirdMappingService userThirdMappingService;
    @Resource
    private FileCenterService fileCenterService;
    @Resource
    private CloudChainService cloudChainService;
    @Resource
    private UserChannelInfoService userChannelInfoService;
    @Resource
    private UserDrawInfoService userDrawInfoService;
    @Override
    public ApiResult<DigitalPolicyVO> buildDigitalPolicy(DigitalPolicyCmd digitalPolicyCmd) {
        UserThirdMappingQry userThirdMappingQry = new UserThirdMappingQry();
        if (Objects.isNull(digitalPolicyCmd.getStarId())) {
            return ApiResult.buildFailure("无效星球id");
        }
        if (StringUtils.isBlank(digitalPolicyCmd.getUserId())) {
            return ApiResult.buildFailure("无效用户");
        }
        if (StringUtils.isNotEmpty(digitalPolicyCmd.getMediaContent()) && digitalPolicyCmd.getMediaContent().length() > 40) {
            return ApiResult.buildFailure("文字长度不能超过40个字符");
        }
        if (StringUtils.isNotEmpty(digitalPolicyCmd.getMediaFileIds())) {
            String[] split = digitalPolicyCmd.getMediaFileIds().split(",");
            if (split.length > Constants.THREE) {
                return ApiResult.buildFailure("上传图片不能超过" + Constants.THREE + "张");
            }
        }
        userThirdMappingQry.setUserId(digitalPolicyCmd.getUserId());
        UserStar query = UserStar.builder().userId(digitalPolicyCmd.getUserId()).build();
        UserStar userStar = userStarGateway.get(query);
        if (Objects.isNull(userStar)) {
            return ApiResult.buildFailure("该用户没有领取星球");
        }
        query = UserStar.builder().starId(digitalPolicyCmd.getStarId()).build();
        userStar = userStarGateway.get(query);
        if (Objects.isNull(userStar)) {
            return ApiResult.buildFailure("该星球id无效");
        }
        ApiResult<String> result = fileCenterService.queryFileUrl(digitalPolicyCmd.getFileId());
        if (!result.getSuccess()) {
            return ApiResult.buildFailure("无效的图片库文件id");
        }
        log.info("buildDigitalPolicy selectUserMappingByUserId start:{}", JSONObject.toJSONString(userThirdMappingQry));

        ApiResult<UserThirdMappingVO> userThirdMappingVOApiResult = userThirdMappingService.selectUserMappingByUserId(userThirdMappingQry);

        log.info("buildDigitalPolicy selectUserMappingByUserId end:{}", JSONObject.toJSONString(userThirdMappingVOApiResult));

        CloudChainVO upChainResponse = null;
        if (userThirdMappingVOApiResult.getSuccess() && Objects.nonNull(userThirdMappingVOApiResult.getData())) {
            log.info("buildDigitalPolicy upChain start:{}", JSONObject.toJSONString(userThirdMappingVOApiResult.getData()));
            ApiResult<CloudChainVO> stringApiResult = cloudChainService.upChain(userThirdMappingVOApiResult.getData().getThirdAccount(), result.getData());
            log.info("buildDigitalPolicy upChain end:{}", JSONObject.toJSONString(stringApiResult.getData()));

            if (stringApiResult.getSuccess()) {
                upChainResponse = stringApiResult.getData();
            } else {
                log.info("buildDigitalPolicy upChain no data");
            }
        } else {
            ApiResult<String> chainAccount = cloudChainService.getChainAccount();
            log.info("buildDigitalPolicy chainAccount:{}", JSONObject.toJSONString(chainAccount));
            if (chainAccount.getSuccess()) {
                UserThirdMappingAddCmd userThirdMappingAddCmd = new UserThirdMappingAddCmd();
                userThirdMappingAddCmd.setUserId(digitalPolicyCmd.getUserId());
                userThirdMappingAddCmd.setThirdAccount(chainAccount.getData());
                userThirdMappingService.add(userThirdMappingAddCmd);
                ApiResult<CloudChainVO> stringApiResult = cloudChainService.upChain(chainAccount.getData(), result.getData());
                log.info("buildDigitalPolicy stringApiResult:{}", JSONObject.toJSONString(stringApiResult));
                if (stringApiResult.getSuccess()) {
                    upChainResponse = stringApiResult.getData();
                } else {
                    log.info("buildDigitalPolicy upChain no data");
                }
            } else {
                log.info("buildDigitalPolicy getChainAccount no data");
            }
        }
        if (Objects.isNull(upChainResponse)) {
            return ApiResult.buildFailure("上链失败");
        }
        String phoneNumber = Strings.EMPTY;
        log.info("buildDigitalPolicy userChannelInfoService start:{}", digitalPolicyCmd.getUserId());

        ApiResult<String> phone = userChannelInfoService.getPhoneNumberByUserId(digitalPolicyCmd.getUserId());
        log.info("buildDigitalPolicy userChannelInfoService end:{}", phone.getData());

        if (phone.getSuccess()) {
            phoneNumber = phone.getData();
        }
        List<String> userIdList =new ArrayList<>();
        userIdList.add(digitalPolicyCmd.getUserId());
        List<DigitalPolicy> digitalPolicyList = digitalPolicyGateway.countDigitalNumByUserIds(userIdList);
        log.info("buildDigitalPolicy countDigitalNumByUserIds userIdList:{},size:{}", JSONObject.toJSONString(userIdList),digitalPolicyList.size());
        List<UserInviteInfo> userInviteInfos = userInviteInfoGateway.selectListByInviteeId(digitalPolicyCmd.getUserId());

        if(CollectionUtils.isEmpty(digitalPolicyList)){
            UserDrawInfoCmd userDrawInfoCmd=new UserDrawInfoCmd();
            userDrawInfoCmd.setUserId(digitalPolicyCmd.getUserId());
            userDrawInfoCmd.setOperateCount(ONE);
            userDrawInfoCmd.setOperateType(ZERO);
            userDrawInfoCmd.setSource(ZERO);
            userDrawInfoService.modifyUserDrawInfo(userDrawInfoCmd, ActivityEnum.STAR);

            log.info("buildDigitalPolicy modifyUserDrawInfo1 userDrawInfoCmd:{}", JSONObject.toJSONString(userDrawInfoCmd));

            if(CollectionUtils.isNotEmpty(userInviteInfos)) {
                Long inviteId=userInviteInfos.get(0).getInviteId();
                userDrawInfoCmd = new UserDrawInfoCmd();
                userDrawInfoCmd.setUserId(userInviteInfos.get(0).getInviterUserId());
                userDrawInfoCmd.setOperateCount(ONE);
                userDrawInfoCmd.setOperateType(ZERO);
                userDrawInfoCmd.setSource(ONE);
                userDrawInfoService.modifyUserDrawInfo(userDrawInfoCmd, ActivityEnum.STAR);
                log.info("buildDigitalPolicy modifyUserDrawInfo2 userDrawInfoCmd:{}", JSONObject.toJSONString(userDrawInfoCmd));

                UserInviteInfo userInviteInfo=UserInviteInfo.builder()
                        .policyStatus(ONE)
                        .inviteId(userInviteInfos.get(0).getInviteId())
                        .build();
                userInviteInfoGateway.update(userInviteInfo);


                userInviteInfos.removeIf(x -> inviteId.equals(x.getInviteId()));

                userInviteInfos.forEach(x->{
                    UserInviteInfo entity=UserInviteInfo.builder()
                            .policyStatus(TWO)
                            .inviteId(x.getInviteId())
                            .build();
                    userInviteInfoGateway.update(entity);
                });
            }

        }else {
            if(CollectionUtils.isNotEmpty(userInviteInfos)) {
                userInviteInfos.forEach(x->{
                    UserInviteInfo entity=UserInviteInfo.builder()
                            .policyStatus(TWO)
                            .inviteId(x.getInviteId())
                            .build();
                    userInviteInfoGateway.update(entity);
                });
            }
        }
        DigitalPolicy digitalPolicy = DigitalPolicy.builder()
                .digitalId(IdUtil.getSnowflakeNextId())
                .userId(digitalPolicyCmd.getUserId())
                .policyId(digitalPolicyCmd.getPolicyId())
                .productName(digitalPolicyCmd.getProductName())
                .fileId(digitalPolicyCmd.getFileId())
                .pictureUrl(upChainResponse.getBody().getIcfsCatUrl())
                .chainAddr(upChainResponse.getBody().getTransactionHash())
                .phoneNumber(phoneNumber)
                .starId(digitalPolicyCmd.getStarId())
//                .sequence(userStar)
                .mediaContent(digitalPolicyCmd.getMediaContent())
                .mediaImage(digitalPolicyCmd.getMediaFileIds())
                .build();
        digitalPolicyGateway.save(digitalPolicy);
        digitalPolicy.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        DigitalPolicy afterEntity = digitalPolicyGateway.get(digitalPolicy);
        DigitalPolicyVO digitalPolicyVO = digitalPolicyCmdConvertor.convert(afterEntity);
        digitalPolicyVO.setStarFileId(userStar.getFileId());
        digitalPolicyVO.setNickName(userStar.getNickName());
        return ApiResult.of(digitalPolicyVO);

//        return executeChainService.chainGateWay(digitalPolicyCmdConvertor.convert(digitalPolicyCmd), MaterialTypeEnum.POLICY_PIC);
    }

    @Override
    public ApiResult<Integer> editDigitalPolicy(DigitalPolicyEditCmd digitalPolicyCmd) {
        if (Objects.nonNull(digitalPolicyCmd.getSelfFlag())
                && digitalPolicyCmd.getSelfFlag().equals(Constants.ONE)) {
            DigitalPolicy byDigitalId = digitalPolicyGateway.getByDigitalId(digitalPolicyCmd.getDigitalId());
            if (Objects.nonNull(byDigitalId) && byDigitalId.getRecommendFlag().equals(Constants.ONE)) {
                if (Objects.isNull(digitalPolicyCmd.getRecommendFlag())) {
                    digitalPolicyCmd.setRecommendFlag(Constants.ZERO);
                }
            }
        }
        return ApiResult.of(digitalPolicyGateway.update(digitalPolicyCmdConvertor.convert(digitalPolicyCmd)));
    }

    @Override
    public ApiResult<List<DigitalPolicyVO>> queryDigitalPolicyList(DigitalPolicyQry qry) {
        UserStar userStar = findUserStar(qry.getUserId(),qry.getStarId());
        if (Objects.isNull(userStar)) {
            throw new RuntimeException("请先领取星球");
        }

        DigitalPolicy query = DigitalPolicy.builder().userId(userStar.getUserId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        List<DigitalPolicy> digitalPolicyList = digitalPolicyGateway.list(query);
        if (CollectionUtils.isNotEmpty(digitalPolicyList)) {
            List<DigitalPolicyVO> digitalPolicyVOS = digitalPolicyCmdConvertor.convert(digitalPolicyList);
            if(Objects.isNull(qry.getStarId())) { //当前登录用户的星球数字保单
                PolicySimple simpleQuery = PolicySimple.builder().userId(userStar.getUserId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
                PolicySimple policySimple = policySimpleGateway.get(simpleQuery);
                List<DigitalPolicyVO> digitalPolicyVOList = digitalPolicyVOS.stream().map(digitalPolicyVO -> {
                    digitalPolicyVO.setNickName(userStar.getNickName());
                    Integer bePerfect = Objects.nonNull(policySimple) && digitalPolicyVO.getPolicyId().equals(policySimple.getPolicyId()) ? Constants.ONE : Constants.ZERO;
                    digitalPolicyVO.setBePerfect(bePerfect);
                    return digitalPolicyVO;
                }).collect(Collectors.toList());
                return ApiResult.of(digitalPolicyVOList);
            } else { //他人星球数字保单
                List<DigitalPolicyVO> digitalPolicyVOList = digitalPolicyVOS.stream()
                        .filter(d-> Objects.equals(d.getSelfFlag(),YESORNOEnum.NO.getCode())).map(digitalPolicyVO -> {
                    digitalPolicyVO.setNickName(userStar.getNickName());
                    digitalPolicyVO.setBePerfect(Constants.ZERO);
                    return digitalPolicyVO;
                }).collect(Collectors.toList());
                return ApiResult.of(digitalPolicyVOList);
            }
        }

        return ApiResult.of(Collections.emptyList());
    }

    @Override
    public ApiResult<PageInfo<DigitalPolicyVO>> queryDigitalPolicyPage(DigitalPolicyPageQry qry) {
        DigitalPolicy digitalPolicy = digitalPolicyCmdConvertor.convert(qry);

        PageInfo<DigitalPolicy> page = digitalPolicyGateway.page(digitalPolicy);
        PageInfo<DigitalPolicyVO> convert = digitalPolicyCmdConvertor.convert(page);
        if(convert.getTotal() > ZERO) {
            List<Long> starIds = page.getList().stream().map(DigitalPolicy::getStarId).collect(Collectors.toList());
            List<UserStar> starList = userStarGateway.listByIds(starIds);
            Map<Long,UserStar> starMap = starList.stream().collect(Collectors.toMap(UserStar::getStarId, Function.identity(),(v1, v2) ->v2));
            convert.getList().forEach(dPolicy -> {
                FileQry fileQry=new FileQry();
                List<String> fileIds =new ArrayList<>();
                fileIds.add(dPolicy.getFileId());
                fileQry.setFileIds(fileIds);
                ApiResult<List<FileInfoVO>> listApiResult = fileCenterService.queryFileInfo(fileQry);
                if (listApiResult.getSuccess() && listApiResult.getData().size() > 0) {
                    dPolicy.setFileObjectName(listApiResult.getData().get(0).getObjectName());
                }
                fileIds =new ArrayList<>();
                if (StringUtils.isNotEmpty(dPolicy.getMediaImage())) {
                    String[] split = dPolicy.getMediaImage().split(",");
                    fileIds.addAll(Arrays.asList(split));
                    fileQry.setFileIds(fileIds);
                    listApiResult = fileCenterService.queryFileInfo(fileQry);
                    if (listApiResult.getSuccess() && listApiResult.getData().size() > 0) {
                        String names = listApiResult.getData().stream().map(FileInfoVO::getObjectName).collect(Collectors.joining(","));
                        dPolicy.setMediaImageObjectName(names);
                    }
                }


                UserStar star = starMap.get(dPolicy.getStarId());
                if(Objects.nonNull(star)) {
                    dPolicy.setStarSequence(star.getSequence());
                    dPolicy.setNickName(star.getNickName());
                    dPolicy.setStarFileId(star.getFileId());
                }
            });
        }
        return ApiResult.of(convert);
    }

    @Override
    public ApiResult<List<DigitalPolicyVO>> queryDigitalPolicyListNew(DigitalPolicyQry qry) {
        DigitalPolicy query = DigitalPolicy.builder().userId(qry.getUserId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        List<DigitalPolicy> digitalPolicyList = digitalPolicyGateway.list(query);
        if (CollectionUtils.isNotEmpty(digitalPolicyList)) {
            List<DigitalPolicyVO> digitalPolicyVOS = digitalPolicyCmdConvertor.convert(digitalPolicyList);
            digitalPolicyVOS.forEach(x->{
                UserStar userStar = userStarGateway.get(
                        UserStar.builder()
                                .userId(qry.getUserId())
                                .build()
                );
                if (Objects.isNull(userStar)){
                   return;
                }
                x.setStarSequence(userStar.getSequence());
            });
        }

        return ApiResult.of(Collections.emptyList());
    }

    @Override
    public ApiResult<DigitalPolicyVO> queryDigitalPolicy(DigitalPolicyQry qry) {

        if(Objects.nonNull(qry.getDigitalId())) {
            DigitalPolicy byDigitalId = digitalPolicyGateway.getByDigitalId(qry.getDigitalId());
            UserStar userStar = userStarGateway.get(
                    UserStar.builder()
                            .userId(byDigitalId.getUserId())
                            .build()
            );
            if(Objects.nonNull(userStar)) {
                byDigitalId.setNickName(userStar.getNickName());
                byDigitalId.setStarFileId(userStar.getFileId());
            }
            return ApiResult.of(digitalPolicyCmdConvertor.convert(byDigitalId));
        }

        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult<PageInfo<DigitalPolicyVO>> queryDigitalPolicyPageByCondition(DigitalPolicyPageQry qry) {
        DigitalPolicyDTO digitalPolicyDTO = DigitalPolicyDTO.builder().build();
        BeanUtils.copyProperties(qry,digitalPolicyDTO);
        digitalPolicyDTO.setPageNum(qry.getPageNum());
        digitalPolicyDTO.setPageSize(qry.getPageSize());
        PageInfo<DigitalPolicy> page = digitalPolicyGateway.page(digitalPolicyDTO);
        PageInfo<DigitalPolicyVO> convert = digitalPolicyCmdConvertor.convert(page);
        convert.getList().forEach(x -> {
            x.setPhoneNumber(DesensitizedUtil.mobilePhone(x.getPhoneNumber()));

        });
        return ApiResult.of(convert);
    }

    @Override
    public ApiResult digitalPolicyIsExist(PolicyQry qry) {
        DigitalPolicy digitalPolicy = digitalPolicyGateway.get(DigitalPolicy.builder().policyId(qry.getPolicyId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
        if (Objects.nonNull(digitalPolicy)) {
            return ApiResult.of(Constants.ONE);
        }
        return ApiResult.of(Constants.ZERO);
    }

    @Override
    public ApiResult<Integer> countDigitalNum(DigitalPolicyPageQry qry) {
        DigitalPolicy query = DigitalPolicy.builder().userId(qry.getUserId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        List<DigitalPolicy> digitalPolicyList = digitalPolicyGateway.list(query);
        return ApiResult.of(digitalPolicyList.size());
    }

    @Override
    public ApiResult<DigitalPolicyVO> queryManagerDigitalPolicyList(DigitalPolicyQry qry) {
        if (Objects.isNull(qry.getStarId())) {
            throw new RuntimeException("请先领取星球");
        }
        DigitalPolicy digitalPolicy = digitalPolicyGateway.getByStarId(qry.getStarId());
        if(Objects.nonNull(digitalPolicy)){
            DigitalPolicyVO convert = digitalPolicyCmdConvertor.convert(digitalPolicy);
            UserStar userStar = userStarGateway.get(
                    UserStar.builder()
                            .starId(qry.getStarId())
                            .build()
            );
            if(Objects.nonNull(userStar)) {
                convert.setStarSequence(userStar.getSequence());
            }
            return ApiResult.of(convert);
        }
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult<DigitalPolicyVO> queryChainByHash(DigitalPolicyQry qry) {
        if (Objects.isNull(qry.getChainAddr())) {
            throw new RuntimeException("请传入数据hash");
        }
        DigitalPolicy digitalPolicy = digitalPolicyGateway.getByHash(qry.getChainAddr());
        if(Objects.nonNull(digitalPolicy)){
            DigitalPolicyVO convert = digitalPolicyCmdConvertor.convert(digitalPolicy);
            UserStar query = UserStar.builder().starId(convert.getStarId()).build();
            UserStar userStar = userStarGateway.get(query);
            if (Objects.nonNull(userStar)) {
                convert.setStarFileId(userStar.getFileId());
                convert.setStarSequence(userStar.getSequence());
                convert.setNickName(userStar.getNickName());
            }
            return ApiResult.of(convert);
        }else {
            return ApiResult.buildFailure("未查询到相关信息");
        }
    }

    private UserStar findUserStar(String userId,Long starId) {
        if(Objects.nonNull(starId)) { //获取星球所属用户的userId
            return userStarGateway.get(UserStar.builder().starId(starId).build());
        }
        return userStarGateway.get(UserStar.builder().userId(userId).build());
    }
}
