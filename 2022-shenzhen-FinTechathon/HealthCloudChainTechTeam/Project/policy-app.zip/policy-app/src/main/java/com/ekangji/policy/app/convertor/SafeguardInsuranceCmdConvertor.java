package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.SafeguardInsurance;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.dto.clientobject.safeguardinsurance.SafeguardInsuranceVO;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardinsurance.SafeguardInsuranceEditCompareValueCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditCompareCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditRadarCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface SafeguardInsuranceCmdConvertor {

    SafeguardInsurance convert(InsuranceCommonQry param);

    SafeguardInsurance convert(SafeguardInsuranceEditCompareValueCmd param);

    List<SafeguardInsuranceVO> convert(List<SafeguardInsurance> param);

}
