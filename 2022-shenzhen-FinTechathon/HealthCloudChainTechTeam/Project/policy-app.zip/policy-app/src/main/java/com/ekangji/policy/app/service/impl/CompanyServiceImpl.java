package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.ICompanyService;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.app.convertor.CompanyCmdConvertor;
import com.ekangji.policy.common.enums.CompanyTypeEnum;
import com.ekangji.policy.domain.gateway.CompanyGateway;
import com.ekangji.policy.domain.insurance.InsuranceCompany;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyEditCmd;
import com.ekangji.policy.dto.command.insurance.company.CompanyPageQry;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.github.pagehelper.PageInfo;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;


/**
 * @author liuchen
 * @date 2022/2/10 17:13
 */
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = ICompanyService.class)
public class CompanyServiceImpl implements ICompanyService {

    @Resource
    private CompanyCmdConvertor companyCmdConvertor;

    @Resource
    private CompanyGateway companyGateway;

//    @Resource
//    private UserGateway userGateway;

//    @Resource
//    private AreaGateway areaGateway;

    @Override
    public ApiResult<List<InsuranceCompanyDropListVO>> queryList(CompanyQry qry) {
        InsuranceCompany company = companyCmdConvertor.convert(qry);
        List<InsuranceCompany> companyList = companyGateway.list(company);
        List<InsuranceCompanyDropListVO> companyVOList = companyCmdConvertor.convert(companyList);
//        companyVOList.stream().forEach(vo -> {
//            buildVO(vo);
//        });
        return ApiResult.of(companyVOList);
    }

    @Override
    public ApiResult<PageInfo<InsuranceCompanyVO>> queryPage(CompanyPageQry qry) {

        InsuranceCompany company = companyCmdConvertor.convert(qry);
        PageInfo<InsuranceCompany> pageInfo = companyGateway.page(company);
        PageInfo<InsuranceCompanyVO> voPageInfo =  companyCmdConvertor.convert(pageInfo);
        voPageInfo.getList().stream().forEach(vo -> {
            buildVO(vo);
        });
        return ApiResult.of(voPageInfo);
    }

    @Override
    @Transactional(transactionManager = "prodCenterTransactionManager", rollbackFor = Exception.class)
    public ApiResult edit(CompanyEditCmd cmd) {
        InsuranceCompany company = companyCmdConvertor.convert(cmd);
        int update = companyGateway.update(company);
        return update > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    private void buildVO(InsuranceCompanyVO vo) {
//        vo.setStatusDesc(CommonStatusEnum.getMsgByCode(vo.getStatus()));
//        vo.setCreateName(userGateway.getUserName(vo.getCreateBy()));
//        vo.setUpdateName(userGateway.getUserName(vo.getUpdateBy()));
        vo.setCompanyTypeDesc(CompanyTypeEnum.getMsgByCode(vo.getCompanyType()));
//        if (StringUtils.isNotBlank(vo.getProvinceCode())){
//            vo.setProvinceDesc(areaGateway.get(Area.builder().code(vo.getProvinceCode()).build()).getName());
//        }
//        if (StringUtils.isNotBlank(vo.getCityCode())){
//            vo.setCityDesc(areaGateway.get(Area.builder().code(vo.getCityCode()).build()).getName());
//        }
    }

}
