package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSON;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.app.service.PolicyBackupRecordService;
import com.ekangji.policy.domain.gateway.PolicyBackupRecordGateway;
import com.ekangji.policy.domain.policy.PolicyBackupRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import com.ekangji.policy.app.service.PolicyBackupRecordService;

import javax.annotation.Resource;
import java.util.List;

@Slf4j
@Service
public class PolicyBackupRecordServiceImpl implements PolicyBackupRecordService {

    @Resource
    private PolicyBackupRecordGateway policyBackupRecordGateway;

    @Override
    public Long save(PolicyBackupRecord backupRecord) {
        log.info("备份:生成备份记录开始:backupRecord:{}", JSON.toJSONString(backupRecord));
        Long backupId = policyBackupRecordGateway.save(backupRecord);
        log.info("备份:生成备份记录结束:backupId:{}", backupId);
        return backupId;
    }

    @Override
    public List<PolicyBackupRecord> list(PolicyBackupRecord backupRecord) {
        return policyBackupRecordGateway.list(backupRecord);
    }

    @Override
    public Long save(Long newPolicyId, Long parentPolicyId, String userId, String userPhone, String launchUserId, String parentPolicyUserPhone) {
        PolicyBackupRecord backupRecord =PolicyBackupRecord.builder()
                .policyId(newPolicyId)
                .parentPolicyId(parentPolicyId)
                .backupId(IdUtil.getSnowflakeNextId())
                .userId(userId)
                .userPhone(userPhone)
                .backupUserId(launchUserId)
                .backupUserPhone(parentPolicyUserPhone)
                .build();
        log.info("备份:生成备份记录开始:backupRecord:{}", JSON.toJSONString(backupRecord));
        Long backupId = policyBackupRecordGateway.save(backupRecord);
        log.info("备份:生成备份记录结束:backupId:{}", backupId);
        return backupId;
    }
}
