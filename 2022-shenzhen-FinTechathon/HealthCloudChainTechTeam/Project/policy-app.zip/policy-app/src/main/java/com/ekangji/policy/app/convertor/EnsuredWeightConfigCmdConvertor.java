package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.ekangji.policy.domain.policy.FamilyEnsuredInfo;
import com.ekangji.policy.dto.clientobject.policy.EnsuredWeightConfigVO;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigEditCmd;
import com.ekangji.policy.dto.command.member.FamilyEnsuredCalcCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 */
@Mapper(componentModel = "spring")
public interface EnsuredWeightConfigCmdConvertor {

    EnsuredWeightConfig convert(EnsuredWeightConfigEditCmd ensuredWeightConfigEditCmd);

    List<EnsuredWeightConfig> convertBatchEditCmd(List<EnsuredWeightConfigEditCmd> param);

    List<EnsuredWeightConfigVO> convert(List<EnsuredWeightConfig> ensuredWeightConfig);
}
