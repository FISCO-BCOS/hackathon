package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.command.dict.*;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 */
@Mapper(componentModel = "spring")
public interface DictDataCmdConvertor {

    DictData convert(DictDataAddCmd param);

    DictData convert(DictDataDeleteCmd param);

    DictData convert(DictDataEditCmd param);

    DictData convert(DictDataQry param);

    DictData convert(DictDataPageQry param);

    DictData convert(DictDataByTypeQry param);

    List<DictDataVO> convert(List<DictData> param);

    PageInfo<DictDataVO> convert(PageInfo<DictData> param);

}
