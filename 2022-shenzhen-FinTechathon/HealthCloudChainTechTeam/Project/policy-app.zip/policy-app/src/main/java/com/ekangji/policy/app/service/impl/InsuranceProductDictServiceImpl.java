package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.FamilyReportService;
import com.ekangji.policy.app.convertor.InsuranceProductDictCmdConvertor;
import com.ekangji.policy.app.service.IInsuranceProductDictService;
import com.ekangji.policy.domain.gateway.InsuranceProductDictGateway;
import com.ekangji.policy.domain.insurance.InsuranceProductDict;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceProductDictVO;
import com.ekangji.policy.dto.command.insurance.InsuranceProductDictCmd;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 *
 *
 * @author wjx
 * @date 2021/12/25 11:48
 */
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IInsuranceProductDictService.class)
public class InsuranceProductDictServiceImpl implements IInsuranceProductDictService {

    @Resource
    private InsuranceProductDictGateway insuranceProductDictGateway;

    @Resource
    private InsuranceProductDictCmdConvertor insuranceProductDictCmdConvertor;


    @Override
    public ApiResult<List<InsuranceProductDictVO>> queryProductTypeDict(InsuranceProductDictCmd cmd) {
        List<InsuranceProductDictVO> list = insuranceProductDictCmdConvertor.convert(insuranceProductDictGateway.queryProductType(insuranceProductDictCmdConvertor.convert(cmd)));
        if (CollectionUtils.isEmpty(list)){
            return ApiResult.of(Lists.newArrayList());
        }
        List<Long> idList = list.stream().map(InsuranceProductDictVO::getId).collect(Collectors.toList());
        List<InsuranceProductDict> sonList = insuranceProductDictGateway.querySonByIds(idList);
        if (CollectionUtils.isNotEmpty(sonList)){
            for (InsuranceProductDictVO insuranceProductDictVO : list) {
                for (InsuranceProductDict insuranceProductDict : sonList) {
                    if (Objects.equals(insuranceProductDictVO.getId(), insuranceProductDict.getParentId())){
                        insuranceProductDictVO.setIsLeaf(false);
                        break;
                    }
                }
            }
        }
        return ApiResult.of(list);
    }

    @Override
    public Map<String, String> queryByType(String dictType) {
        Map<String, String> map = Maps.newHashMap();

        InsuranceProductDict insuranceProductDict = new InsuranceProductDict();
        insuranceProductDict.setDictType(dictType);
        List<InsuranceProductDict> list = insuranceProductDictGateway.list(insuranceProductDict);
        if (CollectionUtils.isEmpty(list)){
            return map;
        }
        for (InsuranceProductDict productDict : list) {
            map.put(productDict.getDictValue(),productDict.getDictName());
        }
        return map;
    }
}
