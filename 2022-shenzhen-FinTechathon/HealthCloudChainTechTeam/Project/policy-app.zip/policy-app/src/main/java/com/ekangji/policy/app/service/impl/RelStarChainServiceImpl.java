package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.api.RelStarChainService;
import com.ekangji.policy.app.convertor.DictDataCmdConvertor;
import com.ekangji.policy.app.convertor.RelStarChainCmdConvertor;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.DictDataGateway;
import com.ekangji.policy.domain.gateway.RelStarChainGateway;
import com.ekangji.policy.domain.gateway.UserGateway;
import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.starchain.RelStarChainVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.starchain.RelStarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.RelStarChainQry;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * 星球-星链-关联
 *
 * @author xintao.li
 * @date 2021/11/28 14:05
 */
@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = RelStarChainService.class)
public class RelStarChainServiceImpl implements RelStarChainService {

    @Resource
    private RelStarChainCmdConvertor relStarChainCmdConvertor;

    @Resource
    private RelStarChainGateway relStarChainGateway;


    @Override
    public ApiResult add(RelStarChainAddCmd cmd) {
        RelStarChain relStarChain = relStarChainCmdConvertor.convert(cmd);
        relStarChain.setRelId(IdUtil.getSnowflakeNextId());
        Long save = relStarChainGateway.save(relStarChain);
        return save > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public List<RelStarChainVO> queryList(RelStarChainQry qry) {
        RelStarChain relStarChain = relStarChainCmdConvertor.convert(qry);
        List<RelStarChain> relStarChainList = relStarChainGateway.list(relStarChain);
        List<RelStarChainVO> relStarChainVOList = relStarChainCmdConvertor.convert(relStarChainList);
        return relStarChainVOList;
    }

}
