package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.api.*;
import com.ekangji.policy.app.convertor.ProductTypeMappingCmdConvertor;
import com.ekangji.policy.app.convertor.SafeguardOverviewCmdConvertor;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import com.ekangji.policy.app.service.PolicyInsurantService;
import com.ekangji.policy.common.enums.AgeBracketEnum;
import com.ekangji.policy.common.enums.CompareColumnEnum;
import com.ekangji.policy.common.enums.YESORNOEnum;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.ProductTypeMappingGateway;
import com.ekangji.policy.domain.gateway.SafeguardOverviewGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.domain.safeguard.SafeguardOverview;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyAdditionalVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.clientobject.policy.SafeguardOverviewVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.clientobject.safeguardinsurance.SafeguardInsuranceVO;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.ekangji.policy.dto.command.safeguardinsurance.InsuranceCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewQry;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditCompareCmd;
import com.ekangji.policy.dto.command.safeguardoverview.SafeguardOverviewEditRadarCmd;
import com.ekangji.policy.infrastructure.utils.MathUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

/**
 * 产品类型映射
 *
 * @author xintao.li
 * @date 2021/11/28 14:05
 */
@Slf4j
@DubboService(version = "${policy-center.service.version}", interfaceClass = SafeguardOverviewService.class)
public class SafeguardOverviewServiceImpl implements SafeguardOverviewService {


    @Resource
    private SafeguardOverviewGateway safeguardOverviewGateway;

    @Resource
    private SafeguardOverviewCmdConvertor safeguardOverviewCmdConvertor;

    @Resource
    private ProductTypeMappingService productTypeMappingService;

    @Resource
    private SafeguardInsuranceService safeguardInsuranceService;

    @Resource
    private PolicyService policyService;

    @Resource
    private PolicyAdditionalService policyAdditionalService;

    @Resource
    private PolicyInsurantService policyInsurantService;

    @Override
    public ApiResult updateOverview() {
        long starTime = System.currentTimeMillis();
        log.info("保障总图更新数据开始，time={}", new Date());
        int count = 0;
        //获取所有一级类别
        List<ProductTypeMappingVO> listOneLevel = productTypeMappingService.listOneLevel();
        if (CollectionUtils.isEmpty(listOneLevel)) {
            log.info("没有获取到一级类别，请配置");
            return ApiResult.buildFailure("没有获取到一级类别，请配置");
        }
        for (ProductTypeMappingVO productTypeMappingVO : listOneLevel) {
            //遍历年龄段
            for (int i = 1; i <= AgeBracketEnum.values().length; i++) {
                //保额之和
                BigDecimal policyAmount = new BigDecimal(0);
                //保额列表
                List<BigDecimal> amountList = new ArrayList<>();
                //在保人数
//                long insuranceCount = policyInsurantService.countByAgeBracket(i);
                //某种类型、某个年龄段的保额之和
                OverviewCommonQry commonQry = OverviewCommonQry.builder()
                        .ageBracket(i)
                        .status(CommonStatusEnum.VALID.getCode())
                        .typeCode(productTypeMappingVO.getCode())
                        .topLevel(YESORNOEnum.YES.getCode())
                        .build();

                //查询出指定年龄段、指定类别在保障中的保单
                List<PolicyVO> policyVOList = policyService.queryPolicyByAgeBracketAndProdType(commonQry);
                ConcurrentMap<Long, List<PolicyVO>> collect1 = policyVOList.stream()
                        .collect(Collectors.groupingByConcurrent(PolicyVO::getInsurantId));
                if (CollectionUtils.isNotEmpty(policyVOList)) {
                    //计算保额之和
                    for (PolicyVO policyVO : policyVOList) {
                        policyAmount = policyAmount.add(policyVO.getInsuredAmount());
                    }
                }

                Set<Map.Entry<Long, List<PolicyVO>>> entries = collect1.entrySet();
                for (Map.Entry<Long, List<PolicyVO>> entry : entries){
                    List<BigDecimal> collect = entry.getValue().stream()
                            .map(PolicyVO::getInsuredAmount)
                            .collect(Collectors.toList());
                    BigDecimal amount = BigDecimal.ZERO;
                    for (BigDecimal b : collect){
                        amount = amount.add(b);
                    }
                    amountList.add(amount);
                }
                //计算在保人数
                long insuranceCount = policyVOList.stream()
                        .map(PolicyVO::getInsurantId)
                        .distinct()
                        .count();
                //计算最小值
                long min = CollectionUtils.isNotEmpty(amountList) ? MathUtil.min(amountList) : 0;
                //计算最大值
                long max = CollectionUtils.isNotEmpty(amountList) ? MathUtil.max(amountList) : 0;
                //计算均值
                long aver = MathUtil.aver(policyAmount, insuranceCount);
                //计算中位数值
                long median = CollectionUtils.isNotEmpty(amountList) ? MathUtil.medianDecimal(amountList) : 0;
                //获取对比值
                long compare = 0;
                InsuranceCommonQry insuranceCommonQry = InsuranceCommonQry.builder()
                        .ageBracket(i)
                        .parentType(productTypeMappingVO.getCode()).build();
                ApiResult<List<SafeguardInsuranceVO>> listApiResult = safeguardInsuranceService.queryList(insuranceCommonQry);
                List<SafeguardInsuranceVO> data = listApiResult.getData();
                if (CollectionUtils.isNotEmpty(data)) {
                    int tem = 0;
                    for (SafeguardInsuranceVO safeguardInsuranceVO : data) {
                        tem += safeguardInsuranceVO.getAssignValue();
                    }
                    //获取对比列
                    Integer compareColumn = data.get(0).getCompareColumn();
                    switch (CompareColumnEnum.getEnumByCode(compareColumn)) {
                        case AVER:
                            compare = aver/10000;
                            break;
                        case MEDIAN:
                            compare = median/10000;
                            break;
                        case ASSIGN:
                            compare = tem;
                            break;
                        default:
                            compare = 0;
                            break;
                    }

                }
                //封装数据
                SafeguardOverview safeguardOverview = SafeguardOverview.builder()
                        .ageBracket(i)
                        .oneLevelTypeCode(productTypeMappingVO.getCode())
                        .averValue((int) (aver / 10000))
                        .medianValue((int) (median / 10000))
                        .minValue((int) (min / 10000))
                        .maxValue((int) (max / 10000))
                        .compareValue((int) compare)
                        .build();
                //更新
                count += safeguardOverviewGateway.update(safeguardOverview);
                log.info("保险类型={},年龄段={},均值={},中位数值={},最小值={},最大值={},指定值={}",productTypeMappingVO.getCode(),i,(int) (aver / 10000),(int) (median / 10000),(int) (min / 10000),(int) (max / 10000),(int) compare);
            }
        }
        long endTime = System.currentTimeMillis();
        log.info("保障总图更新数据结束，time={}，耗时={}毫秒，更新了{}条数据", new Date(), endTime - starTime, count);
        return ApiResult.buildSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public ApiResult updateRadarValue(List<SafeguardOverviewEditRadarCmd> cmd) {
        List<SafeguardOverview> safeguardOverviewList = safeguardOverviewCmdConvertor.convert2(cmd);
        //获取所有一级类别
        List<ProductTypeMappingVO> listOneLevel = productTypeMappingService.listOneLevel();
        List<String> oneLevelList = listOneLevel.stream().map(ProductTypeMappingVO::getCode).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(safeguardOverviewList)){
            return ApiResult.buildFailure("请输入需要调整的值");
        }
        for (SafeguardOverview safeguardOverview : safeguardOverviewList){
            Integer radarMapMaxValue = safeguardOverview.getRadarMapMaxValue();
            if (Objects.isNull(radarMapMaxValue) ||  radarMapMaxValue <= 0 || radarMapMaxValue> 1000 ){
                throw new RuntimeException("请输入1000以内的正整数");
            }
            if (StringUtils.isBlank(AgeBracketEnum.getMsgByCode(safeguardOverview.getAgeBracket()))){
                throw new RuntimeException("年龄段非法");
            }
            if (!oneLevelList.contains(safeguardOverview.getOneLevelTypeCode())){
                throw new RuntimeException("保险类别非法");
            }
            safeguardOverviewGateway.update(safeguardOverview);
        }
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult updateCompareColumn(SafeguardOverviewEditCompareCmd cmd) {
        SafeguardOverview safeguardOverview = safeguardOverviewCmdConvertor.convert(cmd);
        int update = safeguardOverviewGateway.update(safeguardOverview);
        return update > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    @Override
    public ApiResult<List<SafeguardOverviewVO>> queryList(OverviewQry qry) {
        SafeguardOverview safeguardOverview = safeguardOverviewCmdConvertor.convert(qry);
        List<SafeguardOverview> safeguardOverviewList = safeguardOverviewGateway.list(safeguardOverview);
        List<SafeguardOverviewVO> safeguardOverviewVOList = safeguardOverviewCmdConvertor.convert(safeguardOverviewList);
        return ApiResult.of(safeguardOverviewVOList);
    }

    @Override
    public ApiResult<Integer> getCompareColumn(OverviewCommonQry qry) {
        SafeguardOverview safeguardOverview = safeguardOverviewCmdConvertor.convert(qry);
        if (StringUtils.isNotBlank(qry.getTypeCode())) {
            safeguardOverview.setOneLevelTypeCode(qry.getTypeCode());
        }
        safeguardOverview.setStatus(CommonStatusEnum.VALID.getCode());
        SafeguardOverview safeguardOverview1 = safeguardOverviewGateway.get(safeguardOverview);
        if (Objects.nonNull(safeguardOverview1)) {
            return ApiResult.of(safeguardOverview1.getCompareValue());
        }
        return null;
    }
}
