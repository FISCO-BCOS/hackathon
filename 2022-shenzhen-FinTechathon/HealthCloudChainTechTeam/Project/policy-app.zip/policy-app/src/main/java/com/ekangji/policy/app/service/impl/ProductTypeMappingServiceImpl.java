package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.policy.api.IDictDataService;
import com.ekangji.policy.api.ProductTypeMappingService;
import com.ekangji.policy.api.SafeguardOverviewService;
import com.ekangji.policy.app.convertor.DictDataCmdConvertor;
import com.ekangji.policy.app.convertor.ProductTypeMappingCmdConvertor;
import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.gateway.DictDataGateway;
import com.ekangji.policy.domain.gateway.ProductTypeMappingGateway;
import com.ekangji.policy.domain.gateway.UserGateway;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.producttypemapping.ParentCodeQry;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * 产品类型映射
 *
 * @author xintao.li
 * @date 2021/11/28 14:05
 */
@Slf4j
@DubboService(version = "${policy-center.service.version}", interfaceClass = ProductTypeMappingService.class)
public class ProductTypeMappingServiceImpl implements ProductTypeMappingService {


    @Resource
    private ProductTypeMappingGateway productTypeMappingGateway;

    @Resource
    private ProductTypeMappingCmdConvertor productTypeMappingCmdConvertor;

    @Override
    public List<ProductTypeMappingVO> listOneLevel() {
        List<ProductTypeMapping> list = productTypeMappingGateway.listOneLevel();
        return productTypeMappingCmdConvertor.convert(list);
    }

    @Override
    public ApiResult<List<ProductTypeMappingVO>> listChildrenByParentCode(ParentCodeQry qry) {
        ProductTypeMapping productTypeMapping = productTypeMappingCmdConvertor.convert(qry);
        List<ProductTypeMapping> list = productTypeMappingGateway.list(productTypeMapping);
        return ApiResult.of(productTypeMappingCmdConvertor.convert(list));
    }

}
