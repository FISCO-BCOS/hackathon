package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.UserInviteInfo;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.policy.PolicySimpleVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteDetailVO;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrAddCmd;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UserInviteCmdConvertor {

    UserInviteInfo convert(InviteAddCmd param);

    UserInviteInfo convert(UserInviteQry param);

    PageInfo<UserInviteDetailVO> convert(PageInfo<UserInviteInfo> param);
}
