package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.dict.DictData;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.dto.clientobject.dict.DictDataVO;
import com.ekangji.policy.dto.clientobject.starchain.StarChainVO;
import com.ekangji.policy.dto.command.dict.*;
import com.ekangji.policy.dto.command.starchain.StarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.StarChainAddOneLengthCmd;
import com.ekangji.policy.dto.command.starchain.StarChainContentPageQry;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface StarChainCmdConvertor {

    StarChain convert(StarChainAddCmd param);

    StarChain convert(StarChainAddOneLengthCmd param);

    StarChain convert(StarChainContentPageQry param);

    PageInfo<StarChainVO> convert(PageInfo<StarChain> param);

}
