package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSON;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.bean.BeanUtil;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.api.ICompanyService;
import com.ekangji.policy.api.IInsuranceProductService;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.app.convertor.PolicyAdditionalCmdConvertor;
import com.ekangji.policy.app.service.PolicyAdditionalService;
import com.ekangji.policy.app.service.PolicyInsurantService;
import com.ekangji.policy.app.service.PolicyMemberProductTypeStatisticsService;
import com.ekangji.policy.app.service.PolicyPayDetailService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.*;
import com.ekangji.policy.domain.gateway.PolicyAdditionalGateway;
import com.ekangji.policy.domain.policy.*;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyAdditionalVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.ekangji.policy.dto.command.insurance.product.InsuranceProductQry;
import com.ekangji.policy.dto.command.policy.PolicyAddCmd;
import com.ekangji.policy.dto.command.policy.PolicyAdditionalAddCmd;
import com.ekangji.policy.dto.command.policy.PolicyInsurantAddCmd;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.dto.command.policy.PolicyEditCmd;
import com.ekangji.policy.infrastructure.dao.dataobject.PolicyBO;
import com.ekangji.policy.infrastructure.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PolicyAdditionalServiceImpl implements PolicyAdditionalService {

    @Resource
    private PolicyAdditionalCmdConvertor policyAdditionalCmdConvertor;

    @Resource
    private PolicyAdditionalGateway policyAdditionalGateway;

    @Resource
    private PolicyPayDetailService policyPayDetailService;

    @Resource
    private PolicyInsurantService policyInsurantService;

    @Resource
    private ICompanyService companyService;

    @Resource
    private IInsuranceProductService insuranceProductService;

    @Resource
    private PolicyMemberProductTypeStatisticsService policyMemberProductTypeStatisticsService;

    @Resource
    private PolicyService policyService;

    @Override
    public void add(Long policyId, List<PolicyAdditionalAddCmd> cmdList) {
        log.info("policyId:{},保存附加险开始...",policyId);
        if (CollectionUtils.isEmpty(cmdList)) {
            log.info("policyId:{},无附加险...",policyId);
            return;
        }

        List<PolicyAdditional> AdditionalList = cmdList.stream().map(c ->{
            PolicyAdditional additional =  policyAdditionalCmdConvertor.convert(c);
            additional.setPolicyId(policyId);
            //获取保险产品类型与产品库对应
            List<String> productTypeList = c.getProductTypeList();
            if (CollectionUtils.isNotEmpty(productTypeList)) {
                int size = productTypeList.size();
                if (size == Constants.ONE) {
                    additional.setProductTopType(productTypeList.get(Constants.ZERO));
                    additional.setProductType(productTypeList.get(Constants.ZERO));
                } else if (size > Constants.ONE) {
                    additional.setProductTopType(productTypeList.get(Constants.ZERO));
                    additional.setProductType(productTypeList.get(size-Constants.ONE));
                }
            }
            return additional;
        }).collect(Collectors.toList());

        int insertCount = policyAdditionalGateway.batchAdd(AdditionalList);
        log.info("policyId:{},PolicyAdditional add count:{}",policyId,insertCount);
        log.info("policyId:{},保存附加险结束...",policyId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void add(Policy policy, List<PolicyAdditionalAddCmd> additionalList) {
       // List<PolicyAdditionalAddCmd> additionalList = cmd.getAdditional();
        log.info("policyId:{},保存附加险开始...",policy.getPolicyId());
        if (CollectionUtils.isEmpty(additionalList)) {
            log.info("policyId:{},无附加险",policy.getPolicyId());
            return;
        }
        List<PolicyAdditional> policyAdditional = assembleAdditionalPolicy(policy,additionalList);
        int insertCount = policyAdditionalGateway.batchAdd(policyAdditional);
        log.info("PolicyAdditional add count:{}",insertCount);

        log.info("policyId:{},保存附加险结束...",policy.getPolicyId());

        //生成附加险缴费标签
        log.info("policyId:{},附加险生成缴费标签开始...",policy.getPolicyId());

        policyAdditional.forEach(a ->{
            policyPayDetailService.add(policy,a);
        });

        log.info("policyId:{},附加险生成缴费标签结束...",policy.getPolicyId());
    }

    private List<PolicyAdditional> assembleAdditionalPolicy(Policy policy,List<PolicyAdditionalAddCmd> additionalList) {
        List<PolicyAdditional> policyAdditionals = additionalList.stream().map(c ->{
            PolicyAdditional additional =  policyAdditionalCmdConvertor.convert(c);
            additional.setAdditionalId(IdUtil.getSnowflakeNextId());
            additional.setPolicyId(policy.getPolicyId());
            //设置保险产品类型
            setAdditionalProductType(additional,c.getProductTypeList());
            //计算保障结束日及当前保障状态
            Date guaranteeEndDate = calGuaranteeEndDate(policy,c);
            additional.setGuaranteeEndDate(guaranteeEndDate);
            if (Objects.nonNull(guaranteeEndDate)
                    && (DateUtil.compareDate(guaranteeEndDate,DateUtil.getCurrDate()) == Constants.NEGATIVE_ONE)) {
                //设置状态未在保障中，默认人保障中
                additional.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
            } else {
                additional.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
            }
            additional.setTotalPremium(calAdditionalTotalPremium(policy.getPayCycle(),policy.getEffectiveDate(),c,policy.getBirthDay()));
            return additional;
        }).collect(Collectors.toList());
        return policyAdditionals;
    }

    @Override
    public List<PolicyAdditional> list(Policy policy) {
        return policyAdditionalGateway.listByPolicy(PolicyAdditional.builder().policyId(policy.getPolicyId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void edit(Policy policy, PolicyEditCmd cmd) throws Exception {
        //先删除附加险
        int flag = policyAdditionalGateway.delete(PolicyAdditional.builder().policyId(policy.getPolicyId()).build());
        //删除附加险所有缴费信息
        int payFlag = policyPayDetailService.deleteByPolicyAdditional(PolicyPayDetail.builder().policyId(policy.getPolicyId()).build());

        if (flag < 0 || payFlag < 0) {
            throw new RuntimeException("附加险更新失败");
        }

        List<PolicyAdditionalAddCmd> additionalList = cmd.getAdditional();
        if (CollectionUtils.isEmpty(additionalList)) {
            log.info("policyId:{},无附加险",policy.getPolicyId());
            return;
        }

        List<PolicyAdditional> policyAdditionals = additionalList.stream().map(c ->{
            PolicyAdditional additional =  policyAdditionalCmdConvertor.convert(c);
            additional.setAdditionalId(IdUtil.getSnowflakeNextId());
            additional.setPolicyId(policy.getPolicyId());
            //设置保险产品类别
            setAdditionalProductType(additional,c.getProductTypeList());
            //计算保障结束日及当前保障状态
            Date guaranteeEndDate = calGuaranteeEndDate(policy,c);
            additional.setGuaranteeEndDate(guaranteeEndDate);
            if (Objects.nonNull(guaranteeEndDate)
                    && (DateUtil.compareDate(guaranteeEndDate,DateUtil.getCurrDate()) == Constants.NEGATIVE_ONE)) {
                //设置状态未在保障中，默认人保障中
                additional.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
            } else {
                additional.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
            }

            additional.setTotalPremium(calAdditionalTotalPremium(policy.getPayCycle(),policy.getEffectiveDate(),c,policy.getBirthDay()));
            return additional;
        }).collect(Collectors.toList());

        int insertCount = policyAdditionalGateway.batchAdd(policyAdditionals);
        log.info("PolicyAdditional add count:{}",insertCount);

        //生成附加险缴费标签
        policyAdditionals.forEach(a ->{
            policyPayDetailService.add(policy,a);
        });
    }

    /**
     * 设置保险产品类别
     * @param additional
     * @param productTypeList
     */
    private void setAdditionalProductType(PolicyAdditional additional,List<String> productTypeList) {
        if (CollectionUtils.isNotEmpty(productTypeList)) {
            int size = productTypeList.size();
            switch (size) {
                case Constants.ONE:
                    additional.setProductTopType(productTypeList.get(Constants.ZERO));
                    break;
                case Constants.TWO:
                    additional.setProductTopType(productTypeList.get(Constants.ZERO));
                    additional.setProductTwoType(productTypeList.get(Constants.ONE));
                    break;
                case Constants.THREE:
                    additional.setProductTopType(productTypeList.get(Constants.ZERO));
                    additional.setProductTwoType(productTypeList.get(Constants.ONE));
                    additional.setProductThreeType(productTypeList.get(Constants.TWO));
                    break;
                case Constants.FOUR:
                    additional.setProductTopType(productTypeList.get(Constants.ZERO));
                    additional.setProductTwoType(productTypeList.get(Constants.ONE));
                    additional.setProductThreeType(productTypeList.get(Constants.TWO));
                    additional.setProductFourType(productTypeList.get(Constants.THREE));
                    break;
                default:
                    log.info("无产品类型.......");
                    break;
            }
            additional.setProductType(productTypeList.get(size-Constants.ONE));
        }
    }

    /**
     * 计算保障结束日期
     * @param policy
     * @return
     */
    private Date calGuaranteeEndDate(Policy policy,PolicyAdditionalAddCmd additional){
        //生效日期（和主险一致）
        Date effectiveDate = policy.getEffectiveDate();
        //附加险保障期限
        Integer period = additional.getGuaranteePeriod();
        //保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)
        Integer periodUnit = additional.getGuaranteePeriodUnit();
        if (GuaranteePeriodUnitEnum.DAY.getCode().equals(periodUnit)) {
            return DateUtil.addDays(effectiveDate,period-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.MONTH.getCode().equals(periodUnit)) {
            return DateUtil.addDays(DateUtil.addMonths(effectiveDate,period),-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.YEAR.getCode().equals(periodUnit)) {
            return DateUtil.addDays(DateUtil.addYears(effectiveDate,period),-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.ENDAGE.getCode().equals(periodUnit)) {
            return DateUtil.addDays(DateUtil.addYears(policy.getBirthDay(), period+Constants.ONE),-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.OTHER.getCode().equals(periodUnit)) {
            return additional.getGuaranteeEndDate();
        }
        return null; //终身时返回null
    }

    /**
     * 计算保单附加险总保费
     * @param payCycle
     * @param effectiveDate
     * @param additional
     * @return
     */
    private BigDecimal calAdditionalTotalPremium(Integer payCycle,Date effectiveDate, PolicyAdditionalAddCmd additional,Date insurantBirthDay) {
        //缴费期间
        Integer payPeriod = additional.getPayPeriod();
        //缴费期间单位
        Integer payPeriodUnit = additional.getPayPeriodUnit();
        //单次保费
        BigDecimal singlePremium = additional.getSinglePremium();
        BigDecimal totalPremium = new BigDecimal(0);
        //一次性交清
        if (PayCycleEnum.LUMPSUMPAYMENT.getCode().equals(payCycle)) {
            return singlePremium;
        }
        //总保费计算 = 单次保费*期数(期数单位为至**数时需根据缴费周期转成具体期数单位)
        if (PayPeriodUnitEnum.ENDAGE.getCode().equals(payPeriodUnit)) {
            //至**岁时计算期数
            long period = calAdditionalPeriodNum(payCycle,effectiveDate,additional,insurantBirthDay);
            totalPremium = singlePremium.multiply(new BigDecimal(period));
        } else {
            totalPremium = singlePremium.multiply(new BigDecimal(payPeriod));
        }
        return totalPremium;
    }

    /**
     * 至**岁时根据缴费周期计算缴费期数
     * @param payCycle
     * @param effectiveDate
     * @param additional
     * @return
     */
    private static long calAdditionalPeriodNum(Integer payCycle,Date effectiveDate, PolicyAdditionalAddCmd additional,Date insurantBirthDay){

        //计算一定年龄后的日期
        Date birthDayEnd = DateUtil.addYears(insurantBirthDay,additional.getPayPeriod());

        Date baseDate = DateUtil.compareMonthDayDate(effectiveDate,birthDayEnd);
        String startDate =  DateUtil.format(effectiveDate,DateUtil.datePattern);
        String endDate =  DateUtil.format(baseDate,DateUtil.datePattern);

        long periodNum = 0;
        if (PayCycleEnum.ANNUALPAYMENT.getCode().equals(payCycle)) { //年缴
            periodNum = DateUtil.getDateDiff(startDate,endDate,payCycle) + 1;
        } else if (PayCycleEnum.MONTHLYPAYMENT.getCode().equals(payCycle)) { //月缴
            periodNum = DateUtil.getDateDiff(startDate,endDate,payCycle) + 1;
        } else if (PayCycleEnum.SEMIANNUALPAYMENT.getCode().equals(payCycle)){ //半年缴
            periodNum = DateUtil.getDateList(effectiveDate,baseDate,2,6).size();
        }
        return periodNum;
    }


    @Override
    public List<PolicyAdditionalVO> queryAddPolicyByAgeBracketAndProdType(OverviewCommonQry qry) {
        //年龄段非法处理
        if (StringUtils.isBlank(AgeBracketEnum.getMsgByCode(qry.getAgeBracket()))){
            return Lists.newArrayList();
        }
        PolicyAdditional policyAdditional = PolicyAdditional.builder()
                .insurantBirthdayBegin(buildPolicy(qry).getInsurantBirthdayBegin())
                .insurantBirthdayEnd(buildPolicy(qry).getInsurantBirthdayEnd())
                .status(qry.getStatus())
                .build();
        if (Objects.equals(qry.getTopLevel(), YESORNOEnum.YES.getCode())){
            //如果是一级类别，productTopType
            policyAdditional.setProductTopType(qry.getTypeCode());
        }else {
            //不是一级类别，封装productType
            policyAdditional.setProductType(qry.getTypeCode());
        }
        List<PolicyAdditional> policyAdditionals = policyAdditionalGateway.queryAddPolicyByAgeBracketAndProdType(policyAdditional);
        if (CollectionUtils.isNotEmpty(policyAdditionals)){
            return policyAdditionalCmdConvertor.convert(policyAdditionals);
        }

        return Lists.newArrayList();
    }

    /**
     * 根据年龄段组装出生日期的起止时间
     * @return
     */
    private PolicyAdditional buildPolicy(OverviewCommonQry qry){

        PolicyAdditional policyAdditional = new PolicyAdditional();
        if (Objects.equals(qry.getAgeBracket(), AgeBracketEnum.FIVESTEP.getCode())){
            // 年龄在50以上的
            policyAdditional.setInsurantBirthdayEnd(DateUtil.calBirthByAge(AgeBracketEnum.FIVESTEP.getBegin()));
        }else {
            // 年龄在其他段的
            policyAdditional.setInsurantBirthdayEnd(DateUtil.calBirthByAge(AgeBracketEnum.getBeginByCode(qry.getAgeBracket())));
            policyAdditional.setInsurantBirthdayBegin(DateUtil.calBirthByAge(AgeBracketEnum.getEndByCode(qry.getAgeBracket())));
        }
        return policyAdditional;
    }

    @Override
    public ApiResult compensateAdditionalPolicy() {
        log.info("====《附加险》补偿没有保司ID，产品ID，产品类别的保单数据，开始：{}=====",new Date());
        long begin = System.currentTimeMillis();
        //处理产品ID为空
        List<PolicyAdditional> policyProdList = policyAdditionalGateway.listProductIdEmpty();
        long countProdUpdate = 0;
        //过滤出产品名称不是空的
        List<PolicyAdditional> prodCollect = policyProdList.stream()
                .filter(policyAdditional -> StringUtils.isNotBlank(policyAdditional.getProductName()))
                .collect(Collectors.toList());
        //将产品查出来存储
        List<InsuranceProductVO> insuranceProductVOList = insuranceProductService.listByProductName(new InsuranceProductQry());
        HashMap<String, InsuranceProductVO> productMap = new HashMap<>(30000);
        for (InsuranceProductVO insuranceProductVO : insuranceProductVOList){
            productMap.put(insuranceProductVO.getProductName(),insuranceProductVO);
        }
        for (PolicyAdditional policyAdditional : prodCollect){
            InsuranceProductVO insuranceProductVO = productMap.get(policyAdditional.getProductName());
            if(Objects.nonNull(insuranceProductVO)){
                policyAdditional.setProductId(insuranceProductVO.getProductId());
                policyAdditional.setProductTopType(insuranceProductVO.getOneLevelType());
                //设置产品类别
                policyAdditional.setProductType(insuranceProductVO.getOneLevelType());
                if (StringUtils.isNotBlank(insuranceProductVO.getTwoLevelType())){
                    policyAdditional.setProductType(insuranceProductVO.getTwoLevelType());
                }
                if (StringUtils.isNotBlank(insuranceProductVO.getThreeLevelType())){
                    policyAdditional.setProductType(insuranceProductVO.getThreeLevelType());
                }
                if (StringUtils.isNotBlank(insuranceProductVO.getFourLevelType())){
                    policyAdditional.setProductType(insuranceProductVO.getFourLevelType());
                }
                countProdUpdate += policyAdditionalGateway.update(policyAdditional);
            }
        }
        log.info("附加险保单中产品更新了{}条记录",countProdUpdate);

        long end = System.currentTimeMillis();
        log.info("====《附加险》补偿产品ID，产品类别的保单数据，结束：{}，耗时{}毫秒=====",new Date(),end-begin);
        return ApiResult.buildSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public ApiResult updateInsuranceAmount() {
        log.info("====《附加险》更新家庭成员各类保险有效保额，开始：{}=====",new Date());
        long begin = System.currentTimeMillis();
        //根据被保人Id获取保单列表
        List<PolicyAdditional> policyList = policyAdditionalGateway.listPolicyByInsurantId(new PolicyInsurant());
        if (CollectionUtils.isEmpty(policyList)){
            throw new RuntimeException("附加险无保单列表");
        }
        //根据被保人分组
        ConcurrentMap<Long, List<PolicyAdditional>> insurantMap = policyList.stream()
                .collect(Collectors.groupingByConcurrent(PolicyAdditional::getInsurantId));
        Set<Map.Entry<Long, List<PolicyAdditional>>> entries = insurantMap.entrySet();
        for (Map.Entry<Long, List<PolicyAdditional>> entry : entries){
            List<PolicyAdditional> policies = entry.getValue();
            //对产品类别进行分组
            ConcurrentMap<String, List<PolicyAdditional>> prodTypeMap = policies.stream()
                    .filter(policy -> StringUtils.isNotBlank(policy.getProductType()))
                    .collect(Collectors.groupingByConcurrent(PolicyAdditional::getProductType));
            Set<Map.Entry<String, List<PolicyAdditional>>> entrySet = prodTypeMap.entrySet();
            for (Map.Entry<String, List<PolicyAdditional>> entry1 : entrySet){
                List<PolicyAdditional> policyList1 = entry1.getValue();
                //遍历，是否存在过期的保单
                boolean exist = false;
                for (PolicyAdditional policy : policyList1){
                    if (Objects.nonNull(policy.getGuaranteeEndDate()) && DateUtil.daysBetween(policy.getGuaranteeEndDate(), new Date()) <=2){
                        exist=true;
                        break;
                    }
                }
                //如果不存在过期保单，直接跳过本次循环
                if (!exist){
                    continue;
                }
                //过滤掉过期的保单
                List<PolicyAdditional> policyList2 = policyList1.stream()
                        .filter(policy -> Objects.equals(policy.getStatus(), CommonStatusEnum.VALID.getCode()))
                        .collect(Collectors.toList());
                BigDecimal amount = BigDecimal.ZERO;
                if (CollectionUtils.isNotEmpty(policyList2)){
                    String topType = "";
                    String userId = "";
                    for (PolicyAdditional policy : policyList2){
                        amount = amount.add(policy.getInsuredAmount());
                        topType = policy.getProductTopType();
                        if (StringUtils.isBlank(policyService.getUserIdByPolicyId(policy.getPolicyId()))){
                           continue;
                        }
                        userId = policyService.getUserIdByPolicyId(policy.getPolicyId());
                    }
                    //封装统计数据
                    PolicyMemberProductTypeStatistics build = PolicyMemberProductTypeStatistics.builder()
                            .userId(userId)
                            .memberId(entry.getKey())
                            .productType(entry1.getKey())
                            .productTopType(topType)
                            .additionalInsuredAmount(amount)
                            .build();
                    int update = policyMemberProductTypeStatisticsService.updateTotalAmountAddition(build);
                    if (update <= 0){
                        //插入
                        build.setInsuredAmountTotal(amount);
                        policyMemberProductTypeStatisticsService.add(build);
                    }
                }
            }
        }

        long end = System.currentTimeMillis();
        log.info("====《附加险》更新家庭成员各类保险有效保额，结束：{}，耗时{}毫秒=====",new Date(),end-begin);
        return ApiResult.buildSuccess();
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void updateSingleInsuranceAmount(Long insurantId) {
        //根据被保人Id获取保单列表
        PolicyInsurant policyInsurant = PolicyInsurant.builder()
                .insurantId(insurantId)
                .build();
        List<PolicyAdditional> policyList = policyAdditionalGateway.listPolicyByInsurantId(policyInsurant);
        if (CollectionUtils.isNotEmpty(policyList)){

            //对产品类别进行分组
            ConcurrentMap<String, List<PolicyAdditional>> prodTypeMap = policyList.stream()
                    .filter(policyAdditional -> Objects.nonNull(policyAdditional.getProductType()))
                    .collect(Collectors.groupingByConcurrent(PolicyAdditional::getProductType));
            Set<Map.Entry<String, List<PolicyAdditional>>> entrySet = prodTypeMap.entrySet();
            for (Map.Entry<String, List<PolicyAdditional>> entry1 : entrySet) {
                List<PolicyAdditional> policyList1 = entry1.getValue();
                //过滤掉过期的保单
                List<PolicyAdditional> policyList2 = policyList1.stream()
                        .filter(policy -> Objects.equals(policy.getStatus(),Constants.ONE))
                        .collect(Collectors.toList());
                BigDecimal amount = BigDecimal.ZERO;
                if (CollectionUtils.isNotEmpty(policyList2)) {
                    String topType = "";
                    String userId = "";
                    for (PolicyAdditional policy : policyList2) {
                        amount = amount.add(policy.getInsuredAmount());
                        topType = policy.getProductTopType();
                        userId = policyService.getUserIdByPolicyId(policy.getPolicyId());
                        if (StringUtils.isBlank(userId)){
                            continue;
                        }
                    }
                    //封装统计数据
                    PolicyMemberProductTypeStatistics build = PolicyMemberProductTypeStatistics.builder()
                            .userId(userId)
                            .memberId(insurantId)
                            .productType(entry1.getKey())
                            .productTopType(topType)
                            .additionalInsuredAmount(amount)
                            .delFlag(DeleteFlagEnum.NORMAL.getCode())
                            .build();
                    log.info("additional updateSingleInsuranceAmount insurantId:{},{}",insurantId,JSON.toJSONString(build));
                    int update = policyMemberProductTypeStatisticsService.updateTotalAmountAddition(build);
                    if (update <= 0) {
                        //插入
                        build.setInsuredAmountTotal(amount);
                        log.info("additional insert updateSingleInsuranceAmount insurantId:{},{}",insurantId, JSON.toJSONString(build));
                        policyMemberProductTypeStatisticsService.add(build);
                    }
                }
            }
        }
    }

    @Override
    public void addBackup(Long parentPolicyId, Policy policy) {
        log.info("parentPolicyId:{},newPolicyId:{},保存附加险开始...",parentPolicyId,policy.getPolicyId());

        PolicyAdditional policyAdditional = PolicyAdditional.builder().policyId(parentPolicyId).build();
        List<PolicyAdditional> additionalList = policyAdditionalGateway.listByPolicy(policyAdditional);
        if (CollectionUtils.isEmpty(additionalList)) {
            log.info("parentPolicyId:{},newPolicyId:{},无附加险...",parentPolicyId,policy.getPolicyId());
            return;
        }
        List<PolicyAdditional> saveAdditionalList = additionalList.stream().map(additional -> {
            PolicyAdditional pa = new PolicyAdditional();
            BeanUtil.copyProperties(additional,pa);
            pa.setId(null);
            pa.setPolicyId(policy.getPolicyId());
            pa.setOldAdditionalId(additional.getAdditionalId());
            pa.setAdditionalId(IdUtil.getSnowflakeNextId());
            return pa;
        }).collect(Collectors.toList());
        int additionalNum = policyAdditionalGateway.batchAdd(saveAdditionalList);
        log.info("parentPolicyId:{},newPolicyId:{},备份附加险结束...num:{}",parentPolicyId,policy.getPolicyId(),additionalNum);

        //生成附加险缴费标签
        log.info("parentPolicyId:{},newPolicyId:{},备份附加险生成缴费标签开始...",parentPolicyId,policy.getPolicyId());
        for(PolicyAdditional additional : saveAdditionalList) {
            System.out.println("new:{}"+additional.getAdditionalId()+"old:{}"+additional.getOldAdditionalId());
            policyPayDetailService.addBackup(parentPolicyId,policy.getPolicyId(),additional.getOldAdditionalId());
        }
        log.info("parentPolicyId:{},newPolicyId:{},备份附加险生成缴费标签结束...",parentPolicyId,policy.getPolicyId());
    }

}
