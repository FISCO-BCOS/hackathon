package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.IEnsuredWeightConfigService;
import com.ekangji.policy.api.IFamilyEnsuredInfoService;
import com.ekangji.policy.app.convertor.EnsuredWeightConfigCmdConvertor;
import com.ekangji.policy.domain.gateway.EnsuredWeightConfigGateway;
import com.ekangji.policy.domain.gateway.FamilyEnsuredInfoGateway;
import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.ekangji.policy.dto.clientobject.policy.EnsuredWeightConfigVO;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigBatchEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigEditCmd;
import com.ekangji.policy.infrastructure.utils.CollectorsUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = IEnsuredWeightConfigService.class)
public class EnsuredWeightConfigServiceImpl implements IEnsuredWeightConfigService {
    @Resource
    private EnsuredWeightConfigGateway ensuredWeightConfigGateway;
    @Resource
    private EnsuredWeightConfigCmdConvertor ensuredWeightConfigCmdConvertor;

    @Override
    public ApiResult<Integer> ensuredWeightSet(EnsuredWeightConfigBatchEditCmd ensuredWeightConfigEditCmd) {
        List<EnsuredWeightConfigEditCmd> addCmdList = ensuredWeightConfigEditCmd.getEditCmdList();
        ApiResult buildFailure = this.checkAgeWeight(addCmdList);
        if (buildFailure != null) return buildFailure;
        ensuredWeightConfigGateway.batchDelete();
        List<EnsuredWeightConfig> convert = ensuredWeightConfigCmdConvertor.convertBatchEditCmd(addCmdList);
        int batchInsert = ensuredWeightConfigGateway.batchInsert(convert);
        return ApiResult.of(batchInsert);
    }
    /**
     * 分别检查每个年龄段权重和1做比较
     *
     * @param addCmdList
     * @return
     */
    private ApiResult checkAgeWeight(List<EnsuredWeightConfigEditCmd> addCmdList) {
        BigDecimal firstSum = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getFirstStage())).collect(CollectorsUtils.summingBigDecimal(EnsuredWeightConfigEditCmd::getFirstStage));
        if(firstSum.compareTo(new BigDecimal(1))!=0){
            return ApiResult.buildFailure("0-18年龄段权重相加不为1，请检查");
        }
        BigDecimal secondSum = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getSecondStage())).collect(CollectorsUtils.summingBigDecimal(EnsuredWeightConfigEditCmd::getSecondStage));
        if(secondSum.compareTo(new BigDecimal(1))!=0){
            return ApiResult.buildFailure("18-25年龄段权重相加不为1，请检查");
        }
        BigDecimal thirdSum = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getThirdStage())).collect(CollectorsUtils.summingBigDecimal(EnsuredWeightConfigEditCmd::getThirdStage));
        if(thirdSum.compareTo(new BigDecimal(1))!=0){
            return ApiResult.buildFailure("25-35年龄段权重相加不为1，请检查");
        }
        BigDecimal fourthSum = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getFourthStage())).collect(CollectorsUtils.summingBigDecimal(EnsuredWeightConfigEditCmd::getFourthStage));
        if(fourthSum.compareTo(new BigDecimal(1))!=0){
            return ApiResult.buildFailure("35-50年龄段权重相加不为1，请检查");
        }
        BigDecimal fifthSum = addCmdList.stream().filter(Objects::nonNull).filter(s ->Objects.nonNull(s.getFifthStage())).collect(CollectorsUtils.summingBigDecimal(EnsuredWeightConfigEditCmd::getFifthStage));
        if(fifthSum.compareTo(new BigDecimal(1))!=0){
            return ApiResult.buildFailure("50岁及以上年龄段权重相加不为1，请检查");
        }
        return null;
    }

    @Override
    public ApiResult<List<EnsuredWeightConfigVO>> findEnsuredWeightList() {
        List<EnsuredWeightConfig> ensuredWeightConfigs = ensuredWeightConfigGateway.selectWeightList();
        List<EnsuredWeightConfigVO> convert = ensuredWeightConfigCmdConvertor.convert(ensuredWeightConfigs);
        return ApiResult.of(convert);
    }
}
