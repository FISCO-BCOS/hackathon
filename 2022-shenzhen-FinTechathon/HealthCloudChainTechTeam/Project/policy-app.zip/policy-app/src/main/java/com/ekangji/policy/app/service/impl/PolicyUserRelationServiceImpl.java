package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.app.service.PolicyUserRelationService;
import com.ekangji.policy.common.enums.SourceTypeEnum;
import com.ekangji.policy.domain.gateway.PolicyUserRelationGateway;
import com.ekangji.policy.domain.policy.PolicyBackupMessage;
import com.ekangji.policy.domain.policy.PolicyUserRelation;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class PolicyUserRelationServiceImpl implements PolicyUserRelationService {

    @Resource
    private PolicyUserRelationGateway policyUserRelationGateway;

    @Resource
    private UserChannelInfoService userChannelInfoService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveBackupPolicy(List<PolicyBackupMessage> list) {
        list.forEach(pbm ->{
            PolicyUserRelation userRelation = new PolicyUserRelation();
            userRelation.setPolicyId(pbm.getPolicyId());
            userRelation.setUserId(pbm.getReceiveUserId());
            PolicyUserRelation pur = policyUserRelationGateway.selectByUserIdAndPolicyId(userRelation);
            if (Objects.isNull(pur)) {
                userRelation.setRelationId(IdUtil.getSnowflakeNextId());
                userRelation.setBackupUserId(pbm.getLaunchUserId());
                String rUserPhone = userChannelInfoService.getPhoneNumberByUserId(pbm.getReceiveUserId()).getData();
                String lUserPhone = userChannelInfoService.getPhoneNumberByUserId(pbm.getLaunchUserId()).getData();
                userRelation.setUserPhone(rUserPhone);
                userRelation.setBackupUserPhone(lUserPhone);
                userRelation.setSourceType(SourceTypeEnum.BACKUP.getCode());
                policyUserRelationGateway.save(userRelation);
            } else {
                log.info("saveBackupPolicy 用户{}保单{}已存在,来自于{}",pbm.getReceiveUserId(),pbm.getPolicyId(),pbm.getLaunchUserId());
            }
        });
    }


}
