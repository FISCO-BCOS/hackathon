package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.dict.DictType;
import com.ekangji.policy.dto.clientobject.dict.DictTypeVO;
import com.ekangji.policy.dto.command.dict.*;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 */
@Mapper(componentModel = "spring")
public interface DictTypeCmdConvertor {

    DictType convert(DictTypeAddCmd param);

    DictType convert(DictTypeDeleteCmd param);

    DictType convert(DictTypeEditCmd param);

    DictType convert(DictTypeQry param);

    DictType convert(DictTypePageQry param);

    List<DictTypeVO> convert(List<DictType> param);

    PageInfo<DictTypeVO> convert(PageInfo<DictType> param);

}
