package com.ekangji.policy.app.service.impl;

import com.ekangji.policy.app.convertor.PolicyBeneficiaryCmdConvertor;
import com.ekangji.policy.app.service.PolicyBeneficiaryService;
import com.ekangji.policy.domain.gateway.PolicyBeneficiaryGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyBeneficiary;
import com.ekangji.policy.dto.command.policy.PolicyBeneficiaryAddCmd;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.validation.ValidationException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PolicyBeneficiaryServiceImpl implements PolicyBeneficiaryService {

    @Resource
    private PolicyBeneficiaryGateway policyBeneficiaryGateway;

    @Resource
    private PolicyBeneficiaryCmdConvertor policyBeneficiaryCmdConvertor;

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void add(Long policyId, List<PolicyBeneficiaryAddCmd> cmdList) {
        if (CollectionUtils.isEmpty(cmdList)) {
            return;
        }
        log.info("policyId:{},受益人保存开始...",policyId);
        List<PolicyBeneficiary> beneficiaryList = cmdList.stream().map(c ->{
           PolicyBeneficiary beneficiary =  policyBeneficiaryCmdConvertor.convert(c);
           beneficiary.setPolicyId(policyId);
           return beneficiary;
        }).collect(Collectors.toList());

        int insertNum = policyBeneficiaryGateway.batchAdd(beneficiaryList);
        log.info("policyId:{},PolicyBeneficiary add num:{}",policyId,insertNum);
        log.info("policyId:{},受益人保存结束...",policyId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void edit(Long policyId, List<PolicyBeneficiaryAddCmd> cmdList) throws Exception {
        if (CollectionUtils.isEmpty(cmdList)) {
            throw new ValidationException("受益人不能为空");
        }
        int flag = policyBeneficiaryGateway.delete(PolicyBeneficiary.builder().policyId(policyId).build());
        if (flag < 0) {
            throw new Exception("受益人更新失败");
        }

        List<PolicyBeneficiary> beneficiaryList = cmdList.stream().map(c ->{
            PolicyBeneficiary beneficiary =  policyBeneficiaryCmdConvertor.convert(c);
            beneficiary.setPolicyId(policyId);
            return beneficiary;
        }).collect(Collectors.toList());

        int insertCount = policyBeneficiaryGateway.batchAdd(beneficiaryList);
        log.info("PolicyBeneficiary edit count:{}",insertCount);
    }

    @Override
    public List<PolicyBeneficiary> list(Policy policy) {
        return policyBeneficiaryGateway.list(PolicyBeneficiary.builder().policyId(policy.getPolicyId()).build());
    }

}
