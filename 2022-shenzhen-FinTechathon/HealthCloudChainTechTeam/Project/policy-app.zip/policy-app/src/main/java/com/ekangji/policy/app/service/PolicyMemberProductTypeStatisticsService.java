package com.ekangji.policy.app.service;

import com.ekangji.policy.domain.policy.PolicyMemberProductTypeStatistics;
import com.ekangji.policy.dto.clientobject.policy.familyreport.InsuranceProductTypeDataVO;
import com.ekangji.policy.dto.clientobject.producttypemapping.ProductTypeMappingVO;

import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 成员保险类型统计
 * @Date: 2022/05/20 14:05
 */
public interface PolicyMemberProductTypeStatisticsService {

    /**
     * 获取被保人保险全部保障下得类别统计信息
     * @param userId
     * @param memberId
     * @return
     */
    List<InsuranceProductTypeDataVO> findMemberProductTopTypeInfo(String userId, Long memberId, List<ProductTypeMappingVO> productType);

    /**
     * 获取某一一级类别下的子类别保额
     * @param userId
     * @param memberId
     * @param productTopType
     * @param productType
     * @return
     */
    List<InsuranceProductTypeDataVO> findMemberProductTypeInfo(String userId, Long memberId, String productTopType, List<ProductTypeMappingVO> productType);

    /**
     * 更新-主险
     * @param policyMemberProductTypeStatistics
     * @return
     */
    int updateTotalAmountPrimary(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics);

    /**
     * 更新-附加险
     * @param policyMemberProductTypeStatistics
     * @return
     */
    int updateTotalAmountAddition(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics);


    /**
     * 插入
     * @param policyMemberProductTypeStatistics
     * @return
     */
    int add(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics);

    /**
     * 删除
     * @param policyMemberProductTypeStatistics
     * @return
     */
    int delete(PolicyMemberProductTypeStatistics policyMemberProductTypeStatistics);

    /**
     * 更新
     * @param build1
     */
    void update(PolicyMemberProductTypeStatistics build1);
}
