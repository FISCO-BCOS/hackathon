package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.bean.BeanUtil;
import com.ekangji.common.tool.enums.CommonIfEnum;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.enums.ResultCodeEnum;
import com.ekangji.common.tool.util.*;
import com.ekangji.policy.api.*;
import com.ekangji.policy.app.convertor.PolicyCmdConvertor;
import com.ekangji.policy.app.convertor.PolicySimpleCmdConvertor;
import com.ekangji.policy.app.service.*;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.*;
import com.ekangji.policy.domain.gateway.*;
import com.ekangji.policy.domain.insurance.InsuranceProductDict;
import com.ekangji.policy.domain.policy.*;
import com.ekangji.policy.domain.policy.pojo.PolicyQueryDTO;
import com.ekangji.policy.domain.safeguard.ProductTypeMapping;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceCompanyDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductVO;
import com.ekangji.policy.dto.clientobject.policy.*;
import com.ekangji.policy.dto.clientobject.policy.cdetail.MemberDetailVO;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyAdditionalCDetailVO;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyCDetailVO;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyPayCDetailVO;
import com.ekangji.policy.dto.command.insurance.company.CompanyQry;
import com.ekangji.policy.dto.command.insurance.product.InsuranceProductQry;
import com.ekangji.policy.dto.command.member.MemberEnsuredCalcCmd;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.policy.dto.command.policy.backup.PolicyBackupMessageEditCmd;
import com.ekangji.policy.dto.command.policy.family.UserFamilyMemberEditCmd;
import com.ekangji.policy.dto.command.policy.ocr.FamilyMemberCmd;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrAddCmd;
import com.ekangji.policy.dto.command.policy.ocr.PolicyOcrPrefectCmd;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;
import com.ekangji.policy.infrastructure.threadpool.ThreadPoolManager;
import com.ekangji.policy.infrastructure.utils.DateUtil;
import com.ekangji.policy.infrastructure.utils.IdentityUtils;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.dto.clientobject.UserChannelInfoVO;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.assertj.core.util.Lists;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import javax.validation.ValidationException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.ekangji.policy.common.constant.Constants.ZERO;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = PolicyService.class)
public class PolicyServiceImpl implements PolicyService {

    @Value("${policy.beneficiary.maxNum:6}")
    private int beneficiaryMaxNum;
    @Value("${policy.additional.maxNum:10}")
    private int additionalMaxNum;
    @Value("${hmb.to_insure.tip:未找到您的玉惠保保单，您需要先去投保}")
    private String hmbToInsureTip;
    @Value("${hmb.insure.confirm.tip:未找到您的玉惠保保单，请确认是否投保}")
    private String hmbInsureConfirmTip;

    @Resource
    private PolicyService policyService;

    @Resource
    private PolicyCmdConvertor policyCmdConvertor;

    @Resource
    private ProductTypeMappingGateway productTypeMappingGateway;

    @Resource
    private PolicyGateway policyGateway;

    @Resource
    private PolicyAdditionalGateway policyAdditionalGateway;
    @Resource
    private PolicyAttchmentGateway policyAttchmentGateway;
    @Resource
    private InsuranceProductDictGateway insuranceProductDictGateway;
    @Resource
    private PolicyInsurantGateway policyInsurantGateway;

    @Resource
    private PolicyBeneficiaryGateway policyBeneficiaryGateway;

    @Resource
    private PolicyAdditionalService policyAdditionalService;

    @Resource
    private PolicyBeneficiaryService policyBeneficiaryService;

    @Resource
    private PolicyPayDetailService policyPayDetailService;

    @Resource
    private UserFamilyInfoGateway userFamilyInfoGateway;

    @Resource
    private UserFamilyInfoService userFamilyInfoService;

    @Resource
    private PolicyMemberStatisticsService policyMemberStatisticsService;

    @Resource
    private PolicyMemberStatisticsGateway policyMemberStatisticsGateway;

    @Resource
    private ICompanyService companyService;

    @Resource
    private IInsuranceProductService insuranceProductService;

    @Resource
    private PolicyMemberProductTypeStatisticsService policyMemberProductTypeStatisticsService;

    @Resource
    private PolicyBackupMessageService policyBackupMessageService;

    @Resource
    private PolicyBackupRecordService policyBackupRecordService;

    @Resource
    private IMemberEnsuredInfoService memberEnsuredInfoService;

    @Resource
    private UserChannelInfoService userChannelInfoService;

    @Resource
    private PolicyInsurantService policyInsurantService;

    @Resource
    private PolicyAttchmentService policyAttchmentService;

    @Resource
    private PolicyPayDetailGateway policyPayDetailGateway;

    @Resource
    private PolicySimpleCmdConvertor policySimpleCmdConvertor;

    @Resource
    private PolicySimpleGateway policySimpleGateway;

    @Resource
    private DigitalPolicyGateway digitalPolicyGateway;

    @Override
    public Integer countUserWithGuarantee(OverviewCommonQry qry) {
        List<PolicyVO> policyVOList = queryPolicyByAgeBracketAndProdType(qry);
        return policyVOList.stream().collect(Collectors.groupingBy(PolicyVO::getInsurantId)).size();
    }

    /**
     * 更新保单状态
     * step：
     * 1、取出保单所有在保的有效记录
     * 2、通过保障结束时间以及保险生效日期和当前时间做比较  如果保障结束时间小于当前时间 或者当前日期还未到保险生效日期 即该保单状态都应该改为 未在保障中状态
     * 3、取出保单所有未在保的有效记录
     * 4、通过保障结束时间以及保险生效日期和当前时间做比较  保险生效日期小于等于当前日期并且保障结束日期在当前日期之后 保单状态应该改为 在保障中状态
     * 保险附加险逻辑同上
     *
     * @param
     * @return
     */
    @Override
    public ApiResult updatePolicyStatus() {
        log.info("-------------policy scheduler updatePolicyStatus start-----------");
        StopWatch watch = new StopWatch();
        watch.start();
        try {
            //----------------更新主险-----------------------
            //获取所有保障中的保单 查看是否目前不在为保障中了
            List<Policy> inList = policyGateway.list(Policy.builder()
                    .status(PolicyStatusEnum.IN_INSURED.getCode())
                    .delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
            inList.forEach(x -> {
                if (!x.getGuaranteePeriodUnit().equals(GuaranteePeriodUnitEnum.LIFELONG.getCode())) {
                    if ((Objects.nonNull(x.getGuaranteeEndDate())
                            && x.getGuaranteeEndDate().before(new Date()))
                            || x.getEffectiveDate().after(new Date())) {
                        x.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
                        policyGateway.update(x);
                    }
                }
            });

            //获取所有未在保障中的保单  判断是否当前在生效中了
            List<Policy> outList = policyGateway.list(Policy.builder()
                    .status(PolicyStatusEnum.OUT_INSURED.getCode())
                    .delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
            outList.forEach(x -> {
                if(x.getGuaranteePeriodUnit().equals(GuaranteePeriodUnitEnum.LIFELONG.getCode())){
                    if(x.getEffectiveDate().before(new Date())){
                        x.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
                        policyGateway.update(x);
                    }
                }else {
                    if ((x.getEffectiveDate().before(new Date())
                            && Objects.nonNull(x.getGuaranteeEndDate())
                            && x.getGuaranteeEndDate().after(new Date()))) {
                        x.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
                        policyGateway.update(x);
                    }
                }


            });

            //----------------更新附加险-----------------------
            //获取所有保障中的保单 查看是否目前不在为保障中了
            List<PolicyAdditional> inAdditionalList = policyAdditionalGateway.list(PolicyAdditional.builder()
                    .status(PolicyStatusEnum.IN_INSURED.getCode())
                    .delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
            inAdditionalList.forEach(x -> {
                Policy policy = Policy.builder().policyId(x.getPolicyId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
                Policy entity = policyGateway.get(policy);
                if ((Objects.nonNull(x.getGuaranteeEndDate()) && x.getGuaranteeEndDate().before(new Date()))
                        || (Objects.nonNull(entity) && (Objects.nonNull(x.getGuaranteeEndDate()))
                        && entity.getEffectiveDate().after(new Date()))) {
                    x.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
                    policyAdditionalGateway.update(x);
                }
            });

            //获取所有未在保障中的保单  判断是否当前在生效中了
            List<PolicyAdditional> outAdditionalList = policyAdditionalGateway.list(PolicyAdditional.builder()
                    .status(PolicyStatusEnum.OUT_INSURED.getCode())
                    .delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
            outAdditionalList.forEach(x -> {
                Policy policy = Policy.builder().policyId(x.getPolicyId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
                Policy entity = policyGateway.get(policy);
                if (Objects.nonNull(entity)
                        && entity.getEffectiveDate().before(new Date())
                        && Objects.nonNull(x.getGuaranteeEndDate())
                        && x.getGuaranteeEndDate().after(new Date())) {
                    x.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
                    policyAdditionalGateway.update(x);
                }
            });
        } catch (Exception ex) {
            log.error("policy scheduler updatePolicyStatus execute error:", ex);
        }

        watch.stop();
        log.info("policy scheduler updatePolicyStatus end cost: {} ms", watch.getTotalTimeMillis());
        return ApiResult.buildSuccess();

    }

    /**
     * 更新保单份数和今年保费
     * step：
     * 1、获取所有被保人的记录
     * 2、按被保人成员id分组 找到对应的保单id集合
     * 3、获取所有被保人的id集合  保存每个被保人对应的名下的所有保单id集合这样一个关系
     * 4、遍历3的关系集合 找到每个被保人下的所有保单对象集合
     * 5、根据被保人的所有保单对象集合计算今年的保费
     * 6、根据5统计出该被保人的保单份数
     * 7、相应的更新或新增该被保人家庭成员保单统计总表的记录
     *
     * @param
     * @return
     */
    @Override
    public ApiResult updatePolicyNumAndAmount() {
        log.info("-------------policy scheduler updatePolicyNumAndAmount start-----------");
        StopWatch watch = new StopWatch();
        watch.start();
        try {
            //存放结构 key=被保人成员id  value 为对应的保单id集合
            Map<Long, Set<Long>> mapRelation = new HashMap<>();

            //获取所有被保人的记录
            PolicyInsurant policyInsurant = PolicyInsurant.builder().status(DeleteFlagEnum.NORMAL.getCode()).build();
            List<PolicyInsurant> policyInsurantList = policyInsurantGateway.list(policyInsurant);
            //按被保人成员id分组 找到对应的保单id集合
            Map<Long, List<PolicyInsurant>> planMap = policyInsurantList.stream().collect(
                    Collectors.groupingBy(PolicyInsurant::getInsurantId));
            //获取所有被保人的id集合
            Set<Long> memberIds = policyInsurantList.stream().map(PolicyInsurant::getInsurantId).collect(Collectors.toSet());
            memberIds.forEach(x -> {
                Set<Long> policyIds = planMap.get(x).stream().map(PolicyInsurant::getPolicyId).collect(Collectors.toSet());
                mapRelation.put(x, policyIds);
            });
            //遍历 找到每个被保人的有效保单数
            for (Map.Entry<Long, Set<Long>> entry : mapRelation.entrySet()) {
                UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(entry.getKey());
                if (Objects.isNull(userFamilyInfo)) {
                    continue;
                }
                String belongUserId = userFamilyInfo.getBelongUserId();
                Long[] ids = entry.getValue().toArray(new Long[entry.getValue().size()]);
                List<Policy> policyList = policyGateway.selectListByPolicyIds(ids);
                if (CollectionUtils.isEmpty(policyList)) {
                    continue;
                }
                policyList = policyList.stream().filter(x -> x.getDelFlag().equals(DeleteFlagEnum.NORMAL.getCode())).collect(Collectors.toList());
                PolicyPayDetail ppd = policyPayDetailService.findCurrentYearPremiumByPolicy(policyList);
                int validNum = (int) entry.getValue().stream().map(x -> Policy.builder().policyId(x).delFlag(DeleteFlagEnum.NORMAL.getCode())
                        .status(PolicyStatusEnum.IN_INSURED.getCode()).build()).map(policy -> policyGateway.get(policy)).filter(Objects::nonNull).count();
                PolicyMemberStatistics policyMemberStatistics = PolicyMemberStatistics.builder()
                        .memberId(entry.getKey())
                        .build();
                PolicyMemberStatistics policyMemberStatistics1 = policyMemberStatisticsGateway.get(policyMemberStatistics);
                if (Objects.nonNull(policyMemberStatistics1)) {
                    policyMemberStatistics1.setEffectivePolicyNum(validNum);
                    policyMemberStatistics1.setPolicyNum(entry.getValue().size());
                    if (Objects.nonNull(ppd)) {
                        policyMemberStatistics1.setPremium(ppd.getPremium());
                    }
                    policyMemberStatisticsGateway.update(policyMemberStatistics1);
                } else {
                    policyMemberStatistics1 = PolicyMemberStatistics.builder()
                            .memberId(entry.getKey())
                            .effectivePolicyNum(validNum)
                            .userId(belongUserId)
                            .policyNum(entry.getValue().size())
                            .build();
                    if (Objects.nonNull(ppd)) {
                        policyMemberStatistics1.setPremium(ppd.getPremium());
                    }
                    policyMemberStatisticsGateway.save(policyMemberStatistics1);
                }
            }
        } catch (Exception ex) {
            log.error("policy scheduler updatePolicyNumAndAmount execute error:", ex);
        }
        watch.stop();
        log.info("policy scheduler updatePolicyNumAndAmount end cost: {} ms", watch.getTotalTimeMillis());
        return ApiResult.buildSuccess();
    }

    @Override
    public ApiResult<Integer> userPolicyInfo(PolicyPageQry qry) {
        Policy policy = policyGateway.get(Policy.builder()
                .delFlag(DeleteFlagEnum.NORMAL.getCode())
//                .status(PolicyStatusEnum.IN_INSURED.getCode())
                .userId(qry.getUserId()).build());
        if (Objects.isNull(policy)) {
            return ApiResult.of(DeleteFlagEnum.DELETED.getCode());
        }
        return ApiResult.of(DeleteFlagEnum.NORMAL.getCode());
    }

    @Override
    public ApiResult simpleAdd(PolicySimpleAddCmd cmd) {
        PolicySimple queryPolicySimple = PolicySimple.builder()
                .userId(cmd.getUserId()).delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        PolicySimple isExist = policySimpleGateway.get(queryPolicySimple);
        if (Objects.nonNull(isExist)) {
            return ApiResult.buildFailure("简单保单已存在!");
        }
        PolicySimple policySimple = policySimpleCmdConvertor.convert(cmd);

        policySimple.setPolicyId(IdUtil.getSnowflakeNextId());
        assembleSimplePolicy(policySimple,cmd);
        Long policyId = policySimpleGateway.save(policySimple);
        return ApiResult.of(String.valueOf(policyId));
    }

    @Override
    public ApiResult<PolicyCDetailVO> policyCSimpleDetail(PolicyQry policyQry) {
        PolicySimple query = PolicySimple.builder().policyId(policyQry.getPolicyId())
                .delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        PolicySimple policySimple = policySimpleGateway.get(query);
        if (Objects.isNull(policySimple)) {
            return ApiResult.buildFailure("保单不存在");
        }
        PolicyCDetailVO policyCDetailVO = new PolicyCDetailVO();
        BeanUtils.copyProperties(policySimple,policyCDetailVO);

        MemberDetailVO memberDetailVO = new MemberDetailVO();
        memberDetailVO.setNickName(policySimple.getInsurantName());
        memberDetailVO.setName(policySimple.getInsurantName());
        policyCDetailVO.setInsurant(memberDetailVO);

        policyCDetailVO.setDigitalFlag(getDigitalPolicyFlag(policyQry.getPolicyId()));
        return ApiResult.of(policyCDetailVO);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult simplePrefect(PolicyPrefectCmd cmd) {
        PolicySimple query = PolicySimple.builder().userId(cmd.getUserId()).policyId(cmd.getPolicyId()).build();
        PolicySimple policySimple = policySimpleGateway.get(query);
        if (Objects.isNull(policySimple)) {
            return ApiResult.buildFailure("保单不存在");
        }
        this.validateParams(cmd);

        Policy policy = policyCmdConvertor.convert(cmd);
        //使用原来保单的来源
        policy.setPlatform(policySimple.getPlatform());

        policy.setSourceType(SourceTypeEnum.QUICKENTER.getCode());
        assemblePolicy(policy, cmd);
        Long policyId = policyGateway.save(policy);

        //保存被保险人
        policyInsurantService.add(policyId, cmd.getInsurant());

        //保存受益人
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            policyBeneficiaryService.add(policyId, cmd.getBeneficiary());
        }

        //生成并保存主险缴费标签
        policyPayDetailService.add(policy);

        //保存附加险
        policyAdditionalService.add(policy, cmd.getAdditional());

        //保存附件
        policyAttchmentService.add(policyId, cmd.getFileId());
        policy.setMemberId(cmd.getInsurant().get(0).getInsurantId());

        //删除临时保单数据
        policySimple.setDelFlag(DeleteFlagEnum.DELETED.getCode());
        policySimpleGateway.update(policySimple);
        log.info("simplePrefect delete info:{}",JSON.toJSONString(policySimple));
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                //更新保单统计信息表 保额信息，家庭保障分
                asyncPolicyStaInfo(policy.getUserId(), policy.getMemberId(), findProductTopType(cmd.getProductTypeList(), null),
                        findProductTopType(null, cmd.getAdditional()));
            }
        });
        return ApiResult.of(String.valueOf(policyId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult simpleOcrPrefect(PolicyOcrPrefectCmd cmd) {
        PolicySimple query = PolicySimple.builder().userId(cmd.getUserId()).policyId(cmd.getPolicyId()).build();
        PolicySimple policySimple = policySimpleGateway.get(query);
        if (Objects.isNull(policySimple)) {
            return ApiResult.buildFailure("保单不存在");
        }
        this.validateOcrParams(cmd);

        Policy policy = policyCmdConvertor.convert(cmd);
        policy.setPolicyId(policySimple.getPolicyId());
        policy.setPlatform(policySimple.getPlatform());
        //1.保存投保人到家庭成员并返回成员ID
        UserFamilyInfo policyMember = saveFamilyMember(cmd.getPolicyHolder(), cmd.getUserId(), cmd.getPlatform());

        //2.保存被保人到家庭成员
        FamilyMemberCmd insurant = cmd.getInsurant().get(0);
        UserFamilyInfo insurantMember = saveFamilyMember(insurant, cmd.getUserId(), cmd.getPlatform());

        //设置保单唯一ID
        policy.setBirthDay(insurantMember.getBirthday());
        assemblePolicy(policy, cmd);
        policy.setPolicyHolderId(policyMember.getMemberId());
        //policy.setSourceType(SourceTypeEnum.OCR.getCode());
        log.info("ocr 新增完善保单主险开始,policyId:{}", policy.getPolicyId());
        Long policyId = policyGateway.save(policy);
        log.info("ocr 新增完善保单主险结束,policyId:{}", policyId);

        //保存被保险人
        PolicyInsurantAddCmd insurantAddCmd = new PolicyInsurantAddCmd();
        insurantAddCmd.setInsurantId(insurantMember.getMemberId());
        List<PolicyInsurantAddCmd> insurantList = new ArrayList<>();
        insurantList.add(insurantAddCmd);
        policyInsurantService.add(policyId, insurantList);

        //保存受益人
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            policyBeneficiaryService.add(policyId, cmd.getBeneficiary());
        }

        //生成并保存主险缴费标签
        policyPayDetailService.add(policy);

        //保存附加险
        policyAdditionalService.add(policy, cmd.getAdditional());

        //保存附件
        policyAttchmentService.add(policyId, cmd.getFileId());
        policy.setMemberId(insurantMember.getMemberId());

        //删除临时保单数据
        policySimple.setDelFlag(DeleteFlagEnum.DELETED.getCode());
        policySimpleGateway.update(policySimple);
        log.info("simpleOcrPrefect delete info:{}",JSON.toJSONString(policySimple));

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                asyncPolicyStaInfo(policy.getUserId(), policy.getMemberId(), findProductTopType(cmd.getProductTypeList(), null),
                        findProductTopType(null, cmd.getAdditional()));
            }
        });
        return ApiResult.of(String.valueOf(policyId));
    }

    @Override
    public ApiResult<PolicyCDetailVO> hmbPolicyDetail(PolicyHmbDetailQry qry) {
        String productCode = qry.getProductCode();
        HmbProductEnum hmbProductEnum = HmbProductEnum.getHmbProductEnumByCodeAndType(productCode,qry.getOrderType());
        if (Objects.isNull(hmbProductEnum)) {
            return ApiResult.buildFailure("产品不存在");
        }
        PolicyCDetailVO policyCDetailVO = new PolicyCDetailVO();
        Integer identity = IdentityEnum.IDENTITYCARD.getCode();
        MemberDetailVO holder =  assembleMember(qry.getName(),qry.getName(),identity,qry.getIdNo());
        policyCDetailVO.setPolicyHolder(holder);
        MemberDetailVO insured =  assembleMember(qry.getInsuredName(),qry.getInsuredName(),identity,qry.getInsuredIdNo());
        policyCDetailVO.setInsurant(insured);
        //基本信息
        assembleHmbPolicyDetail(hmbProductEnum,policyCDetailVO,qry);
        return ApiResult.of(policyCDetailVO);
    }

    @Override
    public ApiResult<PolicyTipsVO> hmbTips(PolicyHmbDetailQry qry) {
        String productCode = qry.getProductCode();
        HmbProductEnum hmbProductEnum = HmbProductEnum.getHmbProductEnumByCodeAndType(productCode,qry.getOrderType());
        if (Objects.isNull(hmbProductEnum)) {
            return ApiResult.buildFailure("产品不存在");
        }
        PolicyTipsVO tipsVO = new PolicyTipsVO();
        //获取投保日期起
        Date insureBeginDate = DateUtil.parseDate(hmbProductEnum.getInsureBeginDate(), DateUtil.datetimePattern);
        //获取投保日期止
        Date insureEndDate = DateUtil.parseDate(hmbProductEnum.getInsureEndDate(), DateUtil.datetimePattern);
        if (DateUtil.compareTime(insureBeginDate, DateUtil.getCurrTime()) == Constants.NEGATIVE_ONE && DateUtil.compareTime(insureEndDate, DateUtil.getCurrTime()) == Constants.ONE) {
            tipsVO.setNoPolicyTip(MessageFormat.format(hmbToInsureTip,hmbProductEnum.getName()));
        } else {
            tipsVO.setNoPolicyTip(MessageFormat.format(hmbInsureConfirmTip,hmbProductEnum.getName()));
        }
        return ApiResult.of(tipsVO);
    }

    @Override
    public ApiResult<PageInfo<PolicyVO>> queryChoicePolicyPage(PolicyPageQry qry) {
        PolicyQueryDTO policyQueryDTO = policyCmdConvertor.convert(qry);
        PageInfo<Policy> pageInfo = policyGateway.page(policyQueryDTO);
        PageInfo<PolicyVO> pagePolicyVO = policyCmdConvertor.convert(pageInfo);

        List<Long> policyIds = pagePolicyVO.getList().stream().map(PolicyVO::getPolicyId).collect(Collectors.toList());

        List<PolicyInsurant> insurantAndPolicyRelationList = policyInsurantGateway.list(PolicyInsurant.builder().policyIds(policyIds).build());
        if (CollectionUtils.isEmpty(insurantAndPolicyRelationList)) {
            return ApiResult.buildSuccess();
        }
        Map<Long,Long> insurantPolicyMap = insurantAndPolicyRelationList.stream().collect(Collectors.toMap(PolicyInsurant::getPolicyId,PolicyInsurant::getInsurantId,(v1,v2) -> v2));
        List<Long> insurantIds = insurantAndPolicyRelationList.stream().map(PolicyInsurant::getInsurantId).distinct().collect(Collectors.toList());
        List<UserFamilyInfo> familyInfos =userFamilyInfoGateway.list(UserFamilyInfo.builder().memberIds(insurantIds).build());
        Map<Long,String> insurantMap = familyInfos.stream().collect(Collectors.toMap(UserFamilyInfo::getMemberId,UserFamilyInfo::getNickName,(v1,v2) -> v2));
        pagePolicyVO.getList().forEach(pv -> {
            Long insurantId = insurantPolicyMap.get(pv.getPolicyId());
            String nickName = insurantMap.get(insurantId);
            pv.setInsurantName(nickName);
        });
        return ApiResult.of(pagePolicyVO);
    }

    @Override
    public ApiResult policyImport(PolicyImportAddCmd cmd) {
        List<PolicyOcrAddCmd> importList = new ArrayList<>();
        List<PolicyHmbDetailQry> hmbPolicyList = cmd.getImportPolicy();
        hmbPolicyList.forEach(policy ->{
            String productCode = policy.getProductCode();
            HmbProductEnum hmbProductEnum = HmbProductEnum.getHmbProductEnumByCodeAndType(productCode,policy.getOrderType());
            if (Objects.isNull(hmbProductEnum)) {
               throw new ValidationException("产品不存在");
            }

            PolicyOcrAddCmd ocrAddCmd = new PolicyOcrAddCmd();
            FamilyMemberCmd holder = new FamilyMemberCmd();
            holder.setNickName(policy.getName());
            holder.setName(policy.getName());
            holder.setIdentityCardType(IdentityEnum.IDENTITYCARD.getCode());
            holder.setIdentityCardNumber(policy.getIdNo());
            holder.setSex(IdentityUtils.gender(policy.getIdNo()));
            holder.setBirthday(DateUtil.format(IdcardUtil.getBirthDate(policy.getIdNo()),DateUtil.datePattern));

            FamilyMemberCmd insurant = new FamilyMemberCmd();
            insurant.setNickName(policy.getInsuredName());
            insurant.setName(policy.getInsuredName());
            insurant.setIdentityCardType(IdentityEnum.IDENTITYCARD.getCode());
            insurant.setIdentityCardNumber(policy.getInsuredIdNo());
            insurant.setSex(IdentityUtils.gender(policy.getInsuredIdNo()));
            insurant.setBirthday(DateUtil.format(IdcardUtil.getBirthDate(policy.getInsuredIdNo()),DateUtil.datePattern));
            ocrAddCmd.setPolicyHolder(holder);

            List<FamilyMemberCmd> insurantList = new ArrayList<>();
            insurantList.add(insurant);
            ocrAddCmd.setInsurant(insurantList);
            ocrAddCmd.setUserId(cmd.getUserId());
            ocrAddCmd.setSourceType(5);
            //基本信息
            assembleHmbImportPolicy(hmbProductEnum,ocrAddCmd,policy);
            importList.add(ocrAddCmd);
           // policyService.ocrAdd(ocrAddCmd);
        });
        return taskHandle(importList);
    }

    /**
     * 多线程处理任务
     * @param taskList
     * @return
     */
   // @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult taskHandle(List<PolicyOcrAddCmd> taskList) {
        log.info("taskHandle:{}, 惠民保批量导入开始",taskList.size());
       // Long start = System.currentTimeMillis();
        StopWatch sw = new StopWatch();
        sw.start();
        List<String> resultList = Collections.synchronizedList(new ArrayList<>());
        ThreadPoolExecutor threadPoolExecutor = ThreadPoolManager.getPool(BizTaskEnum.SYNCHRONIZATION_TASK);
        try {
            //全流式处理转换成CompletableFuture[]+组装成一个无返回值CompletableFuture，join等待执行完毕。返回结果whenComplete获取
            CompletableFuture[] cfs = taskList.stream().map(object-> CompletableFuture.supplyAsync(()->policyService.ocrAdd(object), threadPoolExecutor)
                    .whenComplete((v, e) -> {
                        if (v.getSuccess()) {
                            resultList.add(v.getData().toString());
                        }
                    })).toArray(CompletableFuture[]::new);
            //等待总任务完成，但是封装后无返回值，必须自己whenComplete()获取
            CompletableFuture.allOf(cfs).join();
          //  Long totalTime = System.currentTimeMillis()-start;
        } catch (Exception e) {
            log.error("taskHandle error",e);
        }
        sw.stop();
        log.info("taskHandle end, 惠民保批量导入结束,总任务数:{} 成功任务数:{},总计耗时:{}",taskList.size(),resultList.size(),sw.getTotalTimeMillis());
        if (resultList.size() > 0) {
            return  ApiResult.buildSuccess();
        } else {
            return  ApiResult.buildFailure("导入失败，请稍后再试");
        }
    }

    private void assembleHmbImportPolicy(HmbProductEnum productEnum, PolicyOcrAddCmd ocrAddCmd,PolicyHmbDetailQry policyQry) {
        //产品信息
        InsuranceProductVO insuranceProduct = insuranceProductService.queryByProductName(InsuranceProductQry.builder().productName(productEnum.getName()).build());
        ocrAddCmd.setProductId(insuranceProduct.getProductId());
        ocrAddCmd.setProductName(insuranceProduct.getProductName());
        ocrAddCmd.setCompanyName(insuranceProduct.getCompanyName());
        ocrAddCmd.setCompanyId(insuranceProduct.getCompanyId());
        ocrAddCmd.setProductTypeList(insuranceProduct.getCategory());

        //其他基本信息
        ocrAddCmd.setPlatform(ZERO);
        ocrAddCmd.setBeneficiaryType(BeneficiaryTypeEnum.OFFICIAL.getCode());
        ocrAddCmd.setEffectiveDate(DateUtil.parseDate(productEnum.getEffectiveDate(),DateUtil.datePattern));
        ocrAddCmd.setGuaranteeEndDate(DateUtil.parseDate(productEnum.getGuaranteeEndDate(),DateUtil.datePattern));
        ocrAddCmd.setGuaranteePeriod(productEnum.getGuaranteePeriod());
        ocrAddCmd.setGuaranteePeriodUnit(productEnum.getGuaranteePeriodUnit());
        ocrAddCmd.setPayCycle(productEnum.getPayCycle());
        ocrAddCmd.setSinglePremium(policyQry.getPremium());
        ocrAddCmd.setInsuredAmount(BigDecimalUtil.toBigDecimal(productEnum.getInsuredAmount()));
    }

    private void assembleHmbPolicyDetail(HmbProductEnum productEnum , PolicyCDetailVO policyCDetailVO, PolicyHmbDetailQry qry) {
        //其他基本信息
        policyCDetailVO.setPolicyNumber(qry.getQuotationNo());
        policyCDetailVO.setEffectiveDate(DateUtil.parseDate(productEnum.getEffectiveDate(),DateUtil.datePattern));
        policyCDetailVO.setGuaranteeEndDate(DateUtil.parseDate(productEnum.getGuaranteeEndDate(),DateUtil.datePattern));
        policyCDetailVO.setGuaranteePeriod(productEnum.getGuaranteePeriod());
        policyCDetailVO.setGuaranteePeriodUnit(productEnum.getGuaranteePeriodUnit());
        policyCDetailVO.setPayCycle(productEnum.getPayCycle());
        policyCDetailVO.setInsuredAmountYuan(BigDecimalUtil.toBigDecimal(productEnum.getInsuredAmount()));
        policyCDetailVO.setSinglePremium(qry.getPremium());
        policyCDetailVO.setBeneficiaryType(BeneficiaryTypeEnum.OFFICIAL.getCode());
        policyCDetailVO.setPayDetail(PolicyPayCDetailVO.builder().totalPremium(qry.getPremium()).perPremium(qry.getPremium()).build());
        policyCDetailVO.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
        Date currentDate = DateUtil.getCurrDate();
        if (DateUtil.compareDate(policyCDetailVO.getEffectiveDate(), currentDate) == Constants.ONE
            || DateUtil.compareDate(policyCDetailVO.getGuaranteeEndDate(), currentDate) == Constants.NEGATIVE_ONE) {
            //设置状态未在保障中
            policyCDetailVO.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
        }
        //产品信息
        InsuranceProductVO insuranceProduct = insuranceProductService.queryByProductName(InsuranceProductQry.builder().productName(productEnum.getName()).build());
        policyCDetailVO.setProductId(insuranceProduct.getProductId());
        policyCDetailVO.setProductName(insuranceProduct.getProductName());
        policyCDetailVO.setCompanyName(insuranceProduct.getCompanyName());
        policyCDetailVO.setCompanyId(insuranceProduct.getCompanyId());
        policyCDetailVO.setProductTopTypeName(insuranceProduct.getProductTypeDesc());
        policyCDetailVO.setProductTypeList(insuranceProduct.getCategory());
    }

    /**
     * 组装成员基本信息
     * @param name
     * @param nickName
     * @param cardType
     * @param cardNumber
     * @return
     */
    private MemberDetailVO assembleMember(String name,String nickName,Integer cardType,String cardNumber) {
        MemberDetailVO memberDetailVO = new MemberDetailVO();
        memberDetailVO.setName(name);
        memberDetailVO.setNickName(nickName);
        memberDetailVO.setIdentityCardType(cardType);
        memberDetailVO.setIdentityCardNumber(cardNumber);
        return memberDetailVO;
    }


    private void assembleSimplePolicy(PolicySimple policySimple, PolicySimpleAddCmd cmd) {
        if (CollectionUtils.isNotEmpty(cmd.getProductTypeList())) {
            List<String> productType = cmd.getProductTypeList();
            int size = cmd.getProductTypeList().size();
            switch (size) {
                case Constants.ONE:
                    policySimple.setProductTopType(productType.get(Constants.ZERO));
                    break;
                case Constants.TWO:
                    policySimple.setProductTopType(productType.get(Constants.ZERO));
                    policySimple.setProductTwoType(productType.get(Constants.ONE));
                    break;
                case Constants.THREE:
                    policySimple.setProductTopType(productType.get(ZERO));
                    policySimple.setProductTwoType(productType.get(Constants.ONE));
                    policySimple.setProductThreeType(productType.get(Constants.TWO));
                    break;
                case Constants.FOUR:
                    policySimple.setProductTopType(productType.get(Constants.ZERO));
                    policySimple.setProductTwoType(productType.get(Constants.ONE));
                    policySimple.setProductThreeType(productType.get(Constants.TWO));
                    policySimple.setProductFourType(productType.get(Constants.THREE));
                    break;
                default:
                    log.info("无产品类型......");
                    break;
            }
            policySimple.setProductType(productType.get(productType.size() - Constants.ONE));
        }
        //测试使用
        //policySimple.setUserPhone("18888888888");
        ApiResult<String> apiResult = userChannelInfoService.getPhoneNumberByUserId(policySimple.getUserId());
        if (apiResult.getSuccess()) {
            policySimple.setUserPhone(apiResult.getData());
        } else {
            log.info("assemblePolicy userId:{},从userCenter未获取到手机号", policySimple.getUserId());
            throw new ValidationException("请先授权手机号");
        }
    }

    @Override
    public List<PolicyVO> queryPolicyByAgeBracketAndProdType(OverviewCommonQry qry) {
        //年龄段非法处理
        if (StringUtils.isBlank(AgeBracketEnum.getMsgByCode(qry.getAgeBracket()))) {
            return Lists.newArrayList();
        }
        Policy policy = Policy.builder()
                .insurantBirthdayBegin(buildPolicy(qry).getInsurantBirthdayBegin())
                .insurantBirthdayEnd(buildPolicy(qry).getInsurantBirthdayEnd())
                .status(qry.getStatus())
                .build();
        if (Objects.equals(qry.getTopLevel(), YESORNOEnum.YES.getCode())) {
            //如果是一级类别，productTopType
            policy.setProductTopType(qry.getTypeCode());
        } else {
            //不是一级类别，封装productType
            policy.setProductType(qry.getTypeCode());
        }

        List<Policy> policyList = policyGateway.queryPolicyByAgeBracketAndProdType(policy);
        if (CollectionUtils.isNotEmpty(policyList)) {
            return policyCmdConvertor.convert(policyList);
        }
        return Lists.newArrayList();
    }

    @Override
    public ApiResult<PageInfo<PolicyVO>> queryPolicyPageByCondition(PolicyPageQry qry) {
        PageInfo emptyPage = PageInfo.EMPTY;
        emptyPage.setPageSize(qry.getPageSize());
        emptyPage.setPageNum(qry.getPageNum());
        PolicyQueryDTO policyQueryDTO = PolicyQueryDTO.builder().build();
        BeanUtils.copyProperties(qry, policyQueryDTO);
        policyQueryDTO.setPageNum(qry.getPageNum());
        policyQueryDTO.setPageSize(qry.getPageSize());
        PageInfo<Policy> page = policyGateway.page(policyQueryDTO);
        PageInfo<PolicyVO> convert = policyCmdConvertor.convert(page);
        convert.getList().forEach(x -> {
//            if (Objects.nonNull(x.getProductType())) {
//                InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
//                        .dictValue(x.getProductType()).build();
//                InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
//                if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
//
//                }
//            }
            StringBuilder stringBuilder = new StringBuilder();
            if (Objects.nonNull(x.getProductTopType())) {
                InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                        .dictValue(x.getProductTopType()).build();
                InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                    stringBuilder.append(insuranceProductDict1.getDictName());
                    stringBuilder.append("-");
                }
            }
            if (Objects.nonNull(x.getProductTwoType())) {
                InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                        .dictValue(x.getProductTwoType()).build();
                InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                    stringBuilder.append(insuranceProductDict1.getDictName());
                    stringBuilder.append("-");
                }
            }
            if (Objects.nonNull(x.getProductThreeType())) {
                InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                        .dictValue(x.getProductThreeType()).build();
                InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                    stringBuilder.append(insuranceProductDict1.getDictName());
                    stringBuilder.append("-");
                }
            }
            if (Objects.nonNull(x.getProductFourType())) {
                InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                        .dictValue(x.getProductFourType()).build();
                InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                    stringBuilder.append(insuranceProductDict1.getDictName());
                    stringBuilder.append("-");
                }
            }

            if (stringBuilder.toString().length() > 0 && stringBuilder.toString().charAt(stringBuilder.toString().length() - 1) == '-') {
                stringBuilder.deleteCharAt(stringBuilder.toString().length() - 1);
            }
            if (StringUtils.isNotBlank(stringBuilder.toString())) {
                x.setProductTypeName(stringBuilder.toString());
            }
            x.setPolicyStatusName(PolicyStatusEnum.getMsgByCode(x.getPolicyStatus()));
            x.setPhoneNumber(DesensitizedUtil.mobilePhone(x.getPhoneNumber()));
            x.setChannelName(PlatformEnum.getMsgByCode(x.getChannelType()));
            x.setSourceName(SourceTypeEnum.getMsgByCode(x.getSourceType()));
            PolicyInsurant policyInsurant = PolicyInsurant.builder().policyId(x.getPolicyId()).build();
            PolicyInsurant entity = policyInsurantGateway.get(policyInsurant);
            if (Objects.nonNull(entity)) {
                x.setInsurantId(entity.getInsurantId());
            }
            List<PolicyBeneficiary> list = policyBeneficiaryGateway.list(PolicyBeneficiary.builder().policyId(x.getPolicyId()).build());
            List<Long> memberIds = list.stream().map(PolicyBeneficiary::getMemberId).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(memberIds)) {
                String join = StringUtils.join(memberIds, ",");
                x.setBeneficiaryIds(join);
            }
            if (Objects.nonNull(x.getBeneficiaryIds())) {
                String[] ids = x.getBeneficiaryIds().split(",");
                List<String> strings = Arrays.asList(ids);
                Set<String> set = new HashSet(strings);
                set.forEach(n -> {
                    UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(Long.valueOf(n));
                    if (Objects.nonNull(userFamilyInfo)) {
                        if (Objects.nonNull(x.getBeneficiaryName())) {
                            x.setBeneficiaryName(x.getBeneficiaryName() + "," + userFamilyInfo.getNickName());
                        } else {
                            x.setBeneficiaryName(userFamilyInfo.getNickName());
                        }

                    }
                });


            }
            if (Objects.nonNull(x.getInsurantId())) {
                UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(x.getInsurantId());
                if (Objects.nonNull(userFamilyInfo)) {
                    x.setInsurantName(userFamilyInfo.getNickName());
                }

            }
            if (Objects.nonNull(x.getPolicyHolderId())) {
                UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(x.getPolicyHolderId());
                if (Objects.nonNull(userFamilyInfo)) {
                    x.setPolicyHolderName(userFamilyInfo.getNickName());
                }

            }
            //根据用户id获取昵称
            ApiResult<UserChannelInfoVO> user = userChannelInfoService.getUserChannelInfoByUserId(x.getUserId());
            if (user.getSuccess()) {
                x.setUserNickName(user.getData().getNickname());
            }
        });
        return ApiResult.of(convert);
    }

    /**
     * 根据家庭成员ID查询该成员保单列表
     * 思路：
     * 1、先用memberId查被保人与保单关系表 得到保单ID数组
     * 2、用保单ID数组查保单表 得到保单集合
     * 3、组装VO
     * 一级类别需要用product_top_type集合查b_product_type_mapping表，得到list，转map备用
     * 投保人名称需要用policy_holder_id集合查b_user_family_info表，得到list，转map备用
     * 被保人名称直接用memberId查b_user_family_info表，得到成员对象，取nickName即可
     * 基本保额需要处理成万元
     * 年保费=policy表单次保费* policy.缴费周期 + 附加险表单词保费 * policy.缴费周期
     * 需要用policyId数组查b_policy_additional附加险表，得到list，转map数组备用
     *
     * @param qry
     * @return
     */
    @Override
    public ApiResult<List<PolicySimpleVO>> queryFamilyMemberPolicyList(FamilyMemberPolicyQry qry) {
        if (Objects.isNull(qry.getFamilyMemberId())) {
            return ApiResult.buildFailure(ResultCodeEnum.BAD_REQUEST.getMsg());
        }
        // 先查被保人与保单关系表 得到被保人与保单关系集合
        List<PolicyInsurant> insurantAndPolicyRelationList = policyInsurantGateway.list(PolicyInsurant.builder().insurantId(qry.getFamilyMemberId()).build());
        if (CollectionUtils.isEmpty(insurantAndPolicyRelationList)) {
            log.info("queryFamilyMemberPolicyList 未查询到该成员保单信息 成员ID：{}", qry.getFamilyMemberId());
            return ApiResult.of(Collections.emptyList());
        }
        // 保单ID数组
        List<Long> policyIds = insurantAndPolicyRelationList.stream().map(PolicyInsurant::getPolicyId).collect(Collectors.toList());
        // 保单主表集合
        List<Policy> policyList = policyGateway.list(Policy.builder().policyIds(policyIds).build());
        if (CollectionUtils.isEmpty(policyList)) {
            log.info("queryFamilyMemberPolicyList 未查询到保单信息 保单ID数组：{}", policyIds);
            return ApiResult.of(Collections.emptyList());
        }

        /*
            转换集合为数组的时候，有两种方式：使用初始化大小的数组（这里指的是初始化大小的时候使用了集合的size()方法）和空数组。
            在低版本的 Java 中推荐使用初始化大小的数组，因为使用反射调用去创建一个合适大小的数组相对较慢。
            但是在 openJDK 6 之后的高版本中方法被优化了，传入空数组相比传入初始化大小的数组，效果是相同的甚至有时候是更优的。
            因为使用 concurrent 或 synchronized 集合时，如果集合进行了收缩，toArray()和size()方法可能会发生数据竞争，
            此时传入初始化大小的数组是危险的。
        */
        // 附加险列表
        List<PolicyAdditional> policyAdditionalList = policyAdditionalGateway.selectListByPolicyIds(policyIds.toArray(new Long[0]));
        // 转成附加险map key为policyId value为对应的附加险列表
        Map<Long, List<PolicyAdditional>> policyAdditionalListMap = policyAdditionalList.stream().collect(Collectors.groupingBy(PolicyAdditional::getPolicyId));
        // 一级类型代码数组 需要去重
        List<String> topTypeCodeList = policyList.stream().map(Policy::getProductTopType).distinct().collect(Collectors.toList());
        // 类型集合
        List<ProductTypeMapping> typeList = productTypeMappingGateway.list(ProductTypeMapping.builder().codeList(topTypeCodeList).build());
        // 一级类型代码-名称Map
        Map<String, String> topTypeNameMap = typeList.stream().collect(Collectors.toMap(ProductTypeMapping::getCode, ProductTypeMapping::getMappingName));
        // 投保人ID集合 需要去重
        List<Long> holderIds = policyList.stream().map(Policy::getPolicyHolderId).distinct().collect(Collectors.toList());
        // 投保人对象集合
        List<UserFamilyInfo> holderMemberInfoList = userFamilyInfoGateway.list(UserFamilyInfo.builder().memberIds(holderIds).build());
        // 投保人Map
        Map<Long, UserFamilyInfo> holderMap = holderMemberInfoList.stream().collect(Collectors.toMap(UserFamilyInfo::getMemberId, Function.identity()));
        // 被保人对象
        UserFamilyInfo insurantMemberInfo = userFamilyInfoGateway.selectEntityByMemberId(qry.getFamilyMemberId());
        // 已接收保单记录集合
        List<PolicyBackupRecord> policyBackupRecords = policyBackupRecordService.list(PolicyBackupRecord.builder().policyIds(policyIds).build());
        // 已接收保单记录集合Map
        Map<Long, PolicyBackupRecord> policyBackupRecordMap = policyBackupRecords.stream().collect(Collectors.toMap(PolicyBackupRecord::getPolicyId, Function.identity()));
        // 开始组装VO
        List<PolicySimpleVO> simpleVOList = new ArrayList<>();
        policyList.forEach(policy -> {
            PolicySimpleVO vo = new PolicySimpleVO();

            vo.setStatus(policy.getStatus());
            vo.setProductName(policy.getProductName());
            vo.setEffectiveDate(policy.getEffectiveDate());
            vo.setGuaranteeEndDate(policy.getGuaranteeEndDate());
            vo.setPolicyId(policy.getPolicyId());
            vo.setPolicyHolderId(policy.getPolicyHolderId());
            vo.setProductTopTypeCode(policy.getProductTopType());
            vo.setIsFromBackup(CommonIfEnum.NO.getCode());
            // 处理终身保障标识
            if (GuaranteePeriodUnitEnum.LIFELONG.getCode().equals(policy.getGuaranteePeriodUnit())) {
                vo.setIsGuaranteeAllLife(CommonIfEnum.YES.getCode());
            } else {
                vo.setIsGuaranteeAllLife(CommonIfEnum.NO.getCode());
            }
            // 处理公司名称 如果有简称，取简称
            if (StringUtils.isNotBlank(policy.getCompanyNameShort())) {
                vo.setCompanyName(policy.getCompanyNameShort());
            } else {
                vo.setCompanyName(policy.getCompanyName());
            }
            if (SourceTypeEnum.BACKUP.getCode().equals(policy.getSourceType())) {
                PolicyBackupRecord policyBackupRecord = policyBackupRecordMap.get(policy.getPolicyId());
                vo.setIsFromBackup(CommonIfEnum.YES.getCode());
                // 组装备份人信息
                if (Objects.nonNull(policyBackupRecord)) {
                    String tailNumber = String.valueOf(PhoneUtil.subAfter(policyBackupRecord.getBackupUserPhone()));
                    vo.setTailPhoneNumber(tailNumber);
                }
            }
            // 组装保障状态文本
            vo.setStatusDesc(PolicyStatusEnum.getMsgByCode(policy.getStatus()));
            // 组装一级类型中文名
            vo.setProductTopTypeName(topTypeNameMap.get(policy.getProductTopType()));
            // 组装投保人名称
            UserFamilyInfo holderInfo = holderMap.get(policy.getPolicyHolderId());
            if (Objects.nonNull(holderInfo)) {
                vo.setPolicyHolderName(holderInfo.getNickName());
            }
            // 组装被保人名称
            if (Objects.nonNull(insurantMemberInfo)) {
                vo.setInsurantName(insurantMemberInfo.getNickName());
                vo.setInsurantId(insurantMemberInfo.getMemberId());
            }
            // 总保费
            PolicyPayDetail payDetail = policyPayDetailGateway.findTotalPremiumByPolicy(PolicyPayDetail.builder().policyId(policy.getPolicyId()).build());
            if (Objects.isNull(payDetail)) {
                log.info("queryFamilyMemberPolicyList 总保费为null");
                vo.setTotalAmount(String.valueOf(ZERO));
            } else {
                vo.setTotalAmount(handleDecimalPoint(payDetail.getPremium()));
            }
            // 基本保额 等于主险保额+其附加险保额
            BigDecimal basicAmount = policy.getInsuredAmount();
            // 当前保单的附加险列表
            List<PolicyAdditional> currentAdditionalList = policyAdditionalListMap.get(policy.getPolicyId());
            if(CollectionUtils.isNotEmpty(currentAdditionalList)){
                for (PolicyAdditional additional : currentAdditionalList) {
                    // 基本保额等于主险保额+其附加险保额
                    basicAmount = basicAmount.add(additional.getInsuredAmount());
                }
            }
            vo.setBasicAmount(handleDecimalPoint(basicAmount));
            simpleVOList.add(vo);
        });
        return ApiResult.of(simpleVOList);
    }

    @Override
    public ApiResult<PolicyDetailVO> policyDetail(PolicyQry policyQry) {
        Policy policy = policyGateway.get(Policy.builder().delFlag(DeleteFlagEnum.NORMAL.getCode()).policyId(policyQry.getPolicyId()).build());
        if (Objects.isNull(policy)) {
            return ApiResult.buildFailure("保单不存在");
        }
        List<PolicyBeneficiary> list = policyBeneficiaryGateway.list(PolicyBeneficiary.builder().policyId(policyQry.getPolicyId()).build());
        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(policy.getPolicyHolderId());
        PolicyInsurant policyInsurant = policyInsurantGateway.get(PolicyInsurant.builder().policyId(policyQry.getPolicyId()).build());
        PolicyAdditional additional = PolicyAdditional.builder().policyId(policyQry.getPolicyId()).build();
        List<PolicyAdditional> policyAdditionalList = policyAdditionalGateway.listByPolicy(additional);
        UserFamilyInfo insurantFamilyInfo = null;

        if (Objects.nonNull(policyInsurant)) {
            insurantFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(policyInsurant.getInsurantId());

        }

        PolicyDetailVO policyDetailVO = PolicyDetailVO.builder().build();
        BeanUtils.copyProperties(policy, policyDetailVO);
        policyDetailVO.setChannelName(PlatformEnum.getMsgByCode(policy.getPlatform()));
        policyDetailVO.setBeneficiaryTypeName(BeneficiaryTypeEnum.getMsgByCode(policy.getBeneficiaryType()));
        policyDetailVO.setSourceName(SourceTypeEnum.getMsgByCode(policy.getSourceType()));

//        if (Objects.nonNull(policyDetailVO.getProductType())) {
//            InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
//                    .dictValue(policyDetailVO.getProductType()).build();
//            InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
//            if (Objects.nonNull(insuranceProductDict1)) {
//                policyDetailVO.setProductTypeName(insuranceProductDict1.getDictName());
//
//            }
//        }
        StringBuilder stringBuilder = new StringBuilder();
        if (Objects.nonNull(policyDetailVO.getProductTopType())) {
            InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                    .dictValue(policyDetailVO.getProductTopType()).build();
            InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
            if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                stringBuilder.append(insuranceProductDict1.getDictName());
                stringBuilder.append("-");
            }
        }
        if (Objects.nonNull(policyDetailVO.getProductTwoType())) {
            InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                    .dictValue(policyDetailVO.getProductTwoType()).build();
            InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
            if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                stringBuilder.append(insuranceProductDict1.getDictName());
                stringBuilder.append("-");
            }
        }
        if (Objects.nonNull(policyDetailVO.getProductThreeType())) {
            InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                    .dictValue(policyDetailVO.getProductThreeType()).build();
            InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
            if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                stringBuilder.append(insuranceProductDict1.getDictName());
                stringBuilder.append("-");
            }
        }
        if (Objects.nonNull(policyDetailVO.getProductFourType())) {
            InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                    .dictValue(policyDetailVO.getProductFourType()).build();
            InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
            if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                stringBuilder.append(insuranceProductDict1.getDictName());
                stringBuilder.append("-");
            }
        }

        if (stringBuilder.toString().length() > 0 && stringBuilder.toString().charAt(stringBuilder.toString().length() - 1) == '-') {
            stringBuilder.deleteCharAt(stringBuilder.toString().length() - 1);
        }
        if (StringUtils.isNotBlank(stringBuilder.toString())) {
            policyDetailVO.setProductTypeName(stringBuilder.toString());
        }

        policyDetailVO.setPolicyStatusName(PolicyStatusEnum.getMsgByCode(policy.getStatus()));
        List<PolicyAdditionalDetailVO> policyAdditionalDetailVOS = new ArrayList<>();

        policyAdditionalList.forEach(policyAdditional -> {
            if (Objects.nonNull(policyAdditional)) {
                PolicyAdditionalDetailVO policyAdditionalDetailVO = new PolicyAdditionalDetailVO();
                policyAdditionalDetailVO.setAdditionalProductName(policyAdditional.getProductName());
                policyAdditionalDetailVO.setAdditionalStatus(policyAdditional.getStatus());
                policyAdditionalDetailVO.setAdditionalStatusName(PolicyStatusEnum.getMsgByCode(policyAdditional.getStatus()));
                policyAdditionalDetailVO.setAdditionalGuaranteePeriod(policyAdditional.getGuaranteePeriod());
                policyAdditionalDetailVO.setAdditionalGuaranteePeriodUnit(policyAdditional.getGuaranteePeriodUnit());
                policyAdditionalDetailVO.setAdditionalGuaranteeEndDate(policyAdditional.getGuaranteeEndDate());
                policyAdditionalDetailVO.setAdditionalPayPeriod(policyAdditional.getPayPeriod());
                policyAdditionalDetailVO.setAdditionalPayPeriodUnit(policyAdditional.getPayPeriodUnit());
                policyAdditionalDetailVO.setAdditionalInsuredAmount(policyAdditional.getInsuredAmount());
                policyAdditionalDetailVO.setAdditionalProductType(policyAdditional.getProductType());
                policyAdditionalDetailVO.setAdditionalSinglePremium(policyAdditional.getSinglePremium());
                policyAdditionalDetailVO.setAdditionalProductType(policyAdditional.getProductType());
                StringBuilder stringBuilderAdditional = new StringBuilder();
                if (Objects.nonNull(policyAdditional.getProductTopType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(policyAdditional.getProductTopType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append("-");
                    }
                }
                if (Objects.nonNull(policyAdditional.getProductTwoType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(policyAdditional.getProductTwoType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append("-");
                    }
                }
                if (Objects.nonNull(policyAdditional.getProductThreeType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(policyAdditional.getProductThreeType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append("-");
                    }
                }
                if (Objects.nonNull(policyAdditional.getProductFourType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(policyAdditional.getProductFourType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append(insuranceProductDict1.getDictName());
                        stringBuilderAdditional.append("-");
                    }
                }

                if (stringBuilderAdditional.toString().length() > 0 && stringBuilderAdditional.toString().charAt(stringBuilderAdditional.toString().length() - 1) == '-') {
                    stringBuilderAdditional.deleteCharAt(stringBuilderAdditional.toString().length() - 1);
                }
                if (StringUtils.isNotBlank(stringBuilderAdditional.toString())) {
                    policyAdditionalDetailVO.setAdditionalProductTypeName(stringBuilderAdditional.toString());
                }
                policyAdditionalDetailVOS.add(policyAdditionalDetailVO);
            }
        });
        policyDetailVO.setPolicyAdditionalDetailVOS(policyAdditionalDetailVOS);
        if (Objects.nonNull(userFamilyInfo)) {
            policyDetailVO.setPolicyHolderName(userFamilyInfo.getNickName());
            policyDetailVO.setPolicyHolderIdentityCardType(userFamilyInfo.getIdentityCardType());
            policyDetailVO.setPolicyHolderIdentityCardTypeName(IdentityEnum.getMsgByCode(policyDetailVO.getPolicyHolderIdentityCardType()));
            policyDetailVO.setPolicyHolderIdentityCardNumber(userFamilyInfo.getIdentityCardNumber());
        }

        if (Objects.nonNull(insurantFamilyInfo)) {
            policyDetailVO.setInsurantBirthday(insurantFamilyInfo.getBirthday());
            policyDetailVO.setInsurantId(insurantFamilyInfo.getMemberId());
            policyDetailVO.setInsurantName(insurantFamilyInfo.getNickName());
            policyDetailVO.setInsurantIdentityCardTypeName(IdentityEnum.getMsgByCode(insurantFamilyInfo.getIdentityCardType()));
            policyDetailVO.setInsurantIdentityCardNumber(insurantFamilyInfo.getIdentityCardNumber());
            policyDetailVO.setInsurantIdentityCardType(insurantFamilyInfo.getIdentityCardType());
        }
        List<PolicyBeneficiaryDetailVO> policyBeneficiaryDetailVOS = new ArrayList<>();
        list.forEach(x -> {
            UserFamilyInfo beneficiaryFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(x.getMemberId());
            if (Objects.nonNull(beneficiaryFamilyInfo)) {
                PolicyBeneficiaryDetailVO policyBeneficiaryDetailVO = new PolicyBeneficiaryDetailVO();
                policyBeneficiaryDetailVO.setBeneficiaryIdentityCardNumber(beneficiaryFamilyInfo.getIdentityCardNumber());
                policyBeneficiaryDetailVO.setBeneficiaryIdentityCardTypeName(IdentityEnum.getMsgByCode(beneficiaryFamilyInfo.getIdentityCardType()));
                policyBeneficiaryDetailVO.setBeneficiaryIdentityCardType(beneficiaryFamilyInfo.getIdentityCardType());
                policyBeneficiaryDetailVO.setBeneficiaryName(beneficiaryFamilyInfo.getNickName());
                policyBeneficiaryDetailVO.setBeneficiaryId(x.getMemberId());
                policyBeneficiaryDetailVO.setBenefitRatio(x.getBenefitRatio());
                policyBeneficiaryDetailVOS.add(policyBeneficiaryDetailVO);
            }

        });
        policyDetailVO.setPolicyBeneficiaryDetailVOS(policyBeneficiaryDetailVOS);
        //根据用户id获取昵称
        ApiResult<UserChannelInfoVO> user = userChannelInfoService.getUserChannelInfoByUserId(policy.getUserId());
        if (user.getSuccess()) {
            policyDetailVO.setUserNickName(user.getData().getNickname());
        }
        PolicyAttchment policyAttchment = PolicyAttchment.builder().policyId(policy.getPolicyId())
                .delFlag(DeleteFlagEnum.NORMAL.getCode()).build();
        List<PolicyAttchment> policyAttchmentList = policyAttchmentGateway.list(policyAttchment);
        if (CollectionUtils.isNotEmpty(policyAttchmentList)) {
            List<String> fileIds = policyAttchmentList.stream().map(PolicyAttchment::getFileId).collect(Collectors.toList());
            policyDetailVO.setFileIds(fileIds);
        }
        ApiResult<String> phoneResult = userChannelInfoService.getPhoneNumberByUserId(policy.getUserId());
        if (!phoneResult.getSuccess()) {
            return ApiResult.buildFailure("接收失败，未获取到用户信息请稍后再试");
        }
        String userPhone = phoneResult.getData();
        policyDetailVO.setPhoneNumber(userPhone);
        return ApiResult.of(policyDetailVO);
    }

    @Override
    public ApiResult<PolicyCDetailVO> policyCDetail(PolicyQry policyQry) {
        Policy queryPolicy = Policy.builder().policyId(policyQry.getPolicyId()).delFlag(Constants.ONE).build();
        Policy policy = policyGateway.get(queryPolicy);
        if (Objects.isNull(policy)) {
            return ApiResult.buildFailure("保单不存在");
        }
        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(policy.getPolicyHolderId());
        PolicyInsurant policyInsurant = policyInsurantGateway.get(PolicyInsurant.builder().policyId(policyQry.getPolicyId()).build());
        UserFamilyInfo insurantFamilyInfo = null;
        if (Objects.nonNull(policyInsurant)) {
            insurantFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(policyInsurant.getInsurantId());
        }

        PolicyCDetailVO policyCDetailVO = new PolicyCDetailVO();
        BeanUtil.copyProperties(policy, policyCDetailVO);
        //处理主险保额
        BigDecimal insuredAmount = BigDecimalUtil.divide(policy.getInsuredAmount(), BigDecimalUtil.toBigDecimal(10000))
                .setScale(2, BigDecimal.ROUND_HALF_DOWN);
        policyCDetailVO.setInsuredAmount(insuredAmount.stripTrailingZeros());
        policyCDetailVO.setInsuredAmountYuan(policy.getInsuredAmount());

        //获取保险一级类别名称
        if (StringUtils.isNotEmpty(policy.getProductTopType())) {
            ProductTypeMapping productTypeMapping = productTypeMappingGateway.get(ProductTypeMapping.builder().mappingCode(policy.getProductTopType()).build());
            policyCDetailVO.setProductTopTypeCode(productTypeMapping.getMappingCode());
            policyCDetailVO.setProductTopTypeName(productTypeMapping.getMappingName());
        } else {
            policyCDetailVO.setProductTopTypeCode("");
            policyCDetailVO.setProductTopTypeName("");
        }


        if (Objects.nonNull(userFamilyInfo)) {
            MemberDetailVO memberDetailVO = MemberDetailVO.builder()
                    .memberId(userFamilyInfo.getMemberId())
                    .nickName(userFamilyInfo.getNickName())
                    .name(userFamilyInfo.getName()).build();
            policyCDetailVO.setPolicyHolder(memberDetailVO);
        }

        if (Objects.nonNull(insurantFamilyInfo)) {
            MemberDetailVO memberDetailVO = MemberDetailVO.builder()
                    .memberId(insurantFamilyInfo.getMemberId())
                    .nickName(insurantFamilyInfo.getNickName())
                    .name(insurantFamilyInfo.getName())
                    .birthday(policyInsurant.getInsurantBirthday()).build();
            policyCDetailVO.setInsurant(memberDetailVO);
        }

        //获取受益人
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(policy.getBeneficiaryType())) {
            List<PolicyBeneficiary> beneficiaryList = policyBeneficiaryService.list(policy);
            List<MemberDetailVO> bDetailList = beneficiaryList.parallelStream().map(b -> {
                MemberDetailVO vo = new MemberDetailVO();
                vo.setMemberId(b.getMemberId());
                vo.setBenefitRatio(b.getBenefitRatio());
                UserFamilyInfo beneficiary = userFamilyInfoGateway.selectEntityByMemberId(b.getMemberId());
                if (Objects.nonNull(beneficiary)) {
                    vo.setNickName(beneficiary.getNickName());
                    vo.setName(Objects.nonNull(beneficiary.getName()) ? beneficiary.getName() : "");
                } else {
                    log.info("policyCDetail beneficiaryMember is null memberId:{} ", b.getMemberId());
                }
                return vo;
            }).collect(Collectors.toList());
            policyCDetailVO.setBeneficiaryList(bDetailList);
        }

        //获取附加险
        List<PolicyAdditional> additionalList = policyAdditionalService.list(policy);
        List<PolicyAdditionalCDetailVO> aDetailList = additionalList.parallelStream().map(a -> {
            PolicyAdditionalCDetailVO vo = new PolicyAdditionalCDetailVO();
            BeanUtil.copyProperties(a, vo);
            //处理保额
            BigDecimal aInsuredAmount = BigDecimalUtil.divide(a.getInsuredAmount(), BigDecimalUtil.toBigDecimal(10000))
                    .setScale(2, BigDecimal.ROUND_HALF_DOWN);
            vo.setInsuredAmount(aInsuredAmount.stripTrailingZeros());
            vo.setInsuredAmountYuan(a.getInsuredAmount());
            vo.setEffectiveDate(policy.getEffectiveDate());
            return vo;
        }).collect(Collectors.toList());
        policyCDetailVO.setAdditionalList(aDetailList);

        //获取缴费详情
        PolicyPayCDetailVO payCDetailVO = policyPayDetailService.findPayDetailByPolicy(policy);
        policyCDetailVO.setPayDetail(payCDetailVO);
        List<String> fileIdList = policyAttchmentService.findAttchmentByPolicy(policy);
        policyCDetailVO.setFileId(fileIdList);

        policyCDetailVO.setDigitalFlag(getDigitalPolicyFlag(policyQry.getPolicyId()));
        return ApiResult.of(policyCDetailVO);
    }

    /**
     * 获取电子保单的数字标识
     * @param policyId
     * @return
     */
    private int getDigitalPolicyFlag(Long policyId) {
        DigitalPolicy digitalPolicy = digitalPolicyGateway.get(DigitalPolicy.builder()
                .policyId(policyId).delFlag(DeleteFlagEnum.NORMAL.getCode()).build());
        if(Objects.nonNull(digitalPolicy)) {
            return Constants.ONE;
        }
        return ZERO;
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult updateInsuranceAmount() {
        log.info("====《主险》更新家庭成员各类保险有效保额，开始：{}=====", new Date());
        long begin = System.currentTimeMillis();
        //获取保单列表
        List<Policy> policyList = policyGateway.listPolicyByInsurantId(new PolicyInsurant());
        if (CollectionUtils.isEmpty(policyList)) {
            throw new RuntimeException("主险无保单列表");
        }
        //根据被保人分组
        ConcurrentMap<Long, List<Policy>> InsurantMap = policyList.stream().collect(Collectors.groupingByConcurrent(Policy::getInsurantId));
        Set<Map.Entry<Long, List<Policy>>> entries = InsurantMap.entrySet();
        for (Map.Entry<Long, List<Policy>> entry : entries) {
            List<Policy> policies = entry.getValue();
            //对产品类别进行分组
            ConcurrentMap<String, List<Policy>> prodTypeMap = policies.stream()
                    .filter(policy -> StringUtils.isNotBlank(policy.getProductType()))
                    .collect(Collectors.groupingByConcurrent(Policy::getProductType));
            Set<Map.Entry<String, List<Policy>>> entrySet = prodTypeMap.entrySet();
            for (Map.Entry<String, List<Policy>> entry1 : entrySet) {
                List<Policy> policyList1 = entry1.getValue();
                //遍历，是否存在过期的保单
                boolean exist = false;
                for (Policy policy : policyList1) {
                    if (Objects.nonNull(policy.getGuaranteeEndDate()) && DateUtil.daysBetween(policy.getGuaranteeEndDate(), new Date()) <= 2) {
                        exist = true;
                        break;
                    }
                }
                //如果不存在过期保单，直接跳过本次循环
                if (!exist) {
                    continue;
                }
                //过滤掉过期的保单
                List<Policy> policyList2 = policyList1.stream()
                        .filter(policy -> Objects.equals(policy.getStatus(), CommonStatusEnum.VALID.getCode()))
                        .collect(Collectors.toList());
                BigDecimal amount = BigDecimal.ZERO;
                if (CollectionUtils.isNotEmpty(policyList2)) {
                    String topType = "";
                    String userId = "";
                    for (Policy policy : policyList2) {
                        amount = amount.add(policy.getInsuredAmount());
                        topType = policy.getProductTopType();
                        userId = policy.getUserId();
                    }
                    //封装统计数据
                    PolicyMemberProductTypeStatistics build = PolicyMemberProductTypeStatistics.builder()
                            .userId(userId)
                            .memberId(entry.getKey())
                            .productType(entry1.getKey())
                            .productTopType(topType)
                            .insuredAmount(amount)
                            .build();
                    int update = policyMemberProductTypeStatisticsService.updateTotalAmountPrimary(build);
                    if (update <= 0) {
                        //插入
                        build.setInsuredAmountTotal(amount);
                        policyMemberProductTypeStatisticsService.add(build);
                    }
                }
            }
        }

        long end = System.currentTimeMillis();
        log.info("====《主险》更新家庭成员各类保险有效保额，结束：{}，耗时{}毫秒=====", new Date(), end - begin);
        return ApiResult.buildSuccess();
    }

    @Override
    public String getUserIdByPolicyId(Long policyId) {
        return policyGateway.getUserIdByPolicyId(policyId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public void updateSingleInsuranceAmount(Long insurantId) {
        //获取保单列表
        PolicyInsurant policyInsurant = PolicyInsurant.builder()
                .insurantId(insurantId)
                .build();
        List<Policy> policyList = policyGateway.listPolicyByInsurantId(policyInsurant);
        //先将当前被保人在统计表中的数据逻辑删除
        PolicyMemberProductTypeStatistics build1 = PolicyMemberProductTypeStatistics.builder()
                .memberId(insurantId)
                .delFlag(DeleteFlagEnum.DELETED.getCode())
                .build();
        policyMemberProductTypeStatisticsService.update(build1);

        if (CollectionUtils.isEmpty(policyList)) {
            //删除当前被保人统计信息
            PolicyMemberProductTypeStatistics build = PolicyMemberProductTypeStatistics.builder()
                    .memberId(insurantId)
                    .build();
            policyMemberProductTypeStatisticsService.delete(build);
        } else {
            //对产品类别进行分组
            ConcurrentMap<String, List<Policy>> prodTypeMap = policyList.stream()
                    .filter(policy -> Objects.nonNull(policy.getProductType()))
                    .collect(Collectors.groupingByConcurrent(Policy::getProductType));
            Set<Map.Entry<String, List<Policy>>> entrySet = prodTypeMap.entrySet();
            for (Map.Entry<String, List<Policy>> entry1 : entrySet) {
                List<Policy> policyList1 = entry1.getValue();
                //过滤掉过期的保单
                List<Policy> policyList2 = policyList1.stream()
                        .filter(policy -> Objects.equals(policy.getStatus(),Constants.ONE))
                        .collect(Collectors.toList());
                BigDecimal amount = BigDecimal.ZERO;
                if (CollectionUtils.isNotEmpty(policyList2)) {
                    String topType = "";
                    String userId = "";
                    for (Policy policy : policyList2) {
                        amount = amount.add(policy.getInsuredAmount());
                        topType = policy.getProductTopType();
                        userId = policy.getUserId();
                    }
                    //封装统计数据
                    PolicyMemberProductTypeStatistics build = PolicyMemberProductTypeStatistics.builder()
                            .userId(userId)
                            .memberId(insurantId)
                            .productType(entry1.getKey())
                            .productTopType(topType)
                            .insuredAmount(amount)
                            .additionalInsuredAmount(BigDecimal.ZERO)
                            .delFlag(DeleteFlagEnum.NORMAL.getCode())
                            .build();
                    log.info("main updateSingleInsuranceAmount insurantId:{},{}",insurantId,JSON.toJSONString(build));
                    int update = policyMemberProductTypeStatisticsService.updateTotalAmountPrimary(build);
                    if (update <= 0) {
                        //插入
                        build.setInsuredAmountTotal(amount);
                        log.info("main insert updateSingleInsuranceAmount insurantId:{},{}",insurantId,JSON.toJSONString(build));
                        policyMemberProductTypeStatisticsService.add(build);
                    }
                }
            }
        }

    }

    @Override
    public List<PolicyExcelExportVO> exportExcel(PolicyPageExportQry qry) {
        PolicyQueryDTO policyQueryDTO = PolicyQueryDTO.builder().build();
        BeanUtils.copyProperties(qry, policyQueryDTO);
        policyQueryDTO.setPageNum(null);
        policyQueryDTO.setPageSize(null);
        List<Policy> policies = policyGateway.queryList(policyQueryDTO);
        if (CollectionUtils.isNotEmpty(policies) && policies.size() > 5000) {
            throw new RuntimeException("导出数量不可超过5000条，请重新筛选");
        }
        List<PolicyExcelExportVO> policyVOList = Lists.newArrayList();

        try {
            policies.forEach(x -> {
                PolicyExcelExportVO policyVO = new PolicyExcelExportVO();
                BeanUtils.copyProperties(x, policyVO);
                policyVO.setChannelName(PlatformEnum.getMsgByCode(x.getChannelType()));
                List<PolicyBeneficiary> list = policyBeneficiaryGateway.list(PolicyBeneficiary.builder().policyId(x.getPolicyId()).build());
                List<Long> memberIds = list.stream().map(PolicyBeneficiary::getMemberId).collect(Collectors.toList());
                if (CollectionUtils.isNotEmpty(memberIds)) {
                    String join = StringUtils.join(memberIds, ",");
                    x.setBeneficiaryIds(join);
                }
                if (Objects.nonNull(x.getBeneficiaryIds())) {
                    String[] ids = x.getBeneficiaryIds().split(",");
                    List<String> strings = Arrays.asList(ids);
                    Set<String> set = new HashSet(strings);
                    set.forEach(n -> {
                        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(Long.valueOf(n));
                        if (Objects.nonNull(userFamilyInfo)) {
                            if (Objects.nonNull(policyVO.getBeneficiaryName())) {
                                policyVO.setBeneficiaryName(policyVO.getBeneficiaryName() + "," + userFamilyInfo.getNickName());
                            } else {
                                policyVO.setBeneficiaryName(userFamilyInfo.getNickName());
                            }

                        }
                    });

                }
                PolicyInsurant policyInsurant = PolicyInsurant.builder().policyId(x.getPolicyId()).build();
                PolicyInsurant entity = policyInsurantGateway.get(policyInsurant);
                if (Objects.nonNull(entity)) {
                    x.setInsurantId(entity.getInsurantId());
                }
                if (Objects.nonNull(x.getInsurantId())) {
                    UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(x.getInsurantId());
                    if (Objects.nonNull(userFamilyInfo)) {
                        policyVO.setInsurantName(userFamilyInfo.getNickName());
                    }

                }
//                if (Objects.nonNull(policyVO.getProductType())) {
//                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
//                            .dictValue(policyVO.getProductType()).build();
//                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
//                    if (Objects.nonNull(insuranceProductDict1)) {
//                        policyVO.setProductType(insuranceProductDict1.getDictName());
//
//                    }
//                }
                StringBuilder stringBuilder = new StringBuilder();
                if (Objects.nonNull(x.getProductTopType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(x.getProductTopType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilder.append(insuranceProductDict1.getDictName());
                        stringBuilder.append("-");
                    }
                }
                if (Objects.nonNull(x.getProductTwoType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(x.getProductTwoType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilder.append(insuranceProductDict1.getDictName());
                        stringBuilder.append("-");
                    }
                }
                if (Objects.nonNull(x.getProductThreeType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(x.getProductThreeType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilder.append(insuranceProductDict1.getDictName());
                        stringBuilder.append("-");
                    }
                }
                if (Objects.nonNull(x.getProductFourType())) {
                    InsuranceProductDict insuranceProductDict = InsuranceProductDict.builder()
                            .dictValue(x.getProductFourType()).build();
                    InsuranceProductDict insuranceProductDict1 = insuranceProductDictGateway.get(insuranceProductDict);
                    if (Objects.nonNull(insuranceProductDict1)) {
//                    x.setProductTypeName(insuranceProductDict1.getDictName());
                        stringBuilder.append(insuranceProductDict1.getDictName());
                        stringBuilder.append("-");
                    }
                }
                if (stringBuilder.toString().length() > 0 && stringBuilder.toString().charAt(stringBuilder.toString().length() - 1) == '-') {
                    stringBuilder.deleteCharAt(stringBuilder.toString().length() - 1);
                }

                if (StringUtils.isNotBlank(stringBuilder.toString())) {
                    x.setProductType(stringBuilder.toString());
                }
                if (Objects.nonNull(x.getPolicyHolderId())) {
                    UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(x.getPolicyHolderId());
                    if (Objects.nonNull(userFamilyInfo)) {
                        policyVO.setPolicyHolderName(userFamilyInfo.getNickName());
                    }

                }
                policyVO.setSourceName(SourceTypeEnum.getMsgByCode(x.getSourceType()));
                policyVO.setPoliceStatusName(PolicyStatusEnum.getMsgByCode(x.getPolicyStatus()));
//                //根据用户id获取昵称
                ApiResult<UserChannelInfoVO> user = userChannelInfoService.getUserChannelInfoByUserId(x.getUserId());
                if (user.getSuccess()) {
                    policyVO.setUserNickName(user.getData().getNickname());
                }
                policyVOList.add(policyVO);
            });

            return policyVOList;
//            EasyExcelUtil.exprotExcel(response,policyVOList,"保单列表","保单列表", PolicyExcelVO.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult policyBackupHandling(PolicyBackupMessageEditCmd cmd) {
        ApiResult<String> phoneResult = userChannelInfoService.getPhoneNumberByUserId(cmd.getUserId());
        if (!phoneResult.getSuccess()) {
            return ApiResult.buildFailure("接收失败，未获取到用户信息请稍后再试");
        }
        String userPhone = phoneResult.getData();
        List<Long> newPolicyIds = new ArrayList<>();
        if (PolicyReceiveStatusEnum.RECEIVED.getCode().equals(cmd.getStatus())) {
            //将保单归属到接收人名下 复制一份原保单
            List<Long> policyIds = policyBackupMessageService.selectToReceivePolicy(cmd, userPhone);
            if (CollectionUtils.isNotEmpty(policyIds)) {
                List<Policy> policyList = policyGateway.list(Policy.builder().policyIds(policyIds).build());

                for (Policy policy : policyList) {
                    String parentPolicyUserPhone = policy.getUserPhone();
                    //获取原保单被保人并创建新被保人家庭成员
                    List<PolicyInsurantAddCmd> backupInsurant = assembleBackupInsurant(policy, cmd.getUserId());

                    //原保单投保人被创建新投保人家庭成员
                    Long policyHolderId = policy.getPolicyHolderId();
                    UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(policyHolderId);
                    Long backupPolicyHolderId = saveBackupFamilyMember(userFamilyInfo, cmd.getUserId());

                    //获取原保单受益人并创建新受益人家庭成员
                    List<PolicyBeneficiaryAddCmd> backupBeneficaiary = assembleBackupBeneficiary(policy, cmd.getUserId());

                    //创建备份保单
                    Long parentPolicyId = policy.getPolicyId();
                    assembleBackupPolicy(policy, cmd.getUserId(), userPhone, backupPolicyHolderId);
                    Long newPolicyId = policyGateway.save(policy);
                    log.info("备份保单主险信息完毕:newPolicyId:{}", newPolicyId);

                    //备份保存被保险人
                    policyInsurantService.add(newPolicyId, backupInsurant);

                    //备份保存受益人
                    if (BeneficiaryTypeEnum.APPOINT.getCode().equals(policy.getBeneficiaryType())) {
                        policyBeneficiaryService.add(newPolicyId, backupBeneficaiary);
                    }

                    //备份生成并保存主险缴费标签
                    policyPayDetailService.addBackup(parentPolicyId,newPolicyId,null);

                    //备份保存附加险
                    policyAdditionalService.addBackup(parentPolicyId, policy);

                    //备份保存附件
                    policyAttchmentService.addBackup(parentPolicyId, newPolicyId);

                    //保存备份记录
                    policyBackupRecordService.save(newPolicyId, parentPolicyId, cmd.getUserId(), userPhone, cmd.getLaunchUserId(), parentPolicyUserPhone);
                    //添加新的policyId
                    newPolicyIds.add(newPolicyId);
                }
            } else {
                log.info("未查到可备份的保单,可能已被删除:param:{},receiveUserPhone:{}", JSON.toJSONString(cmd), userPhone);
            }
        }
        //更新备份消息表的状态
        ApiResult apiResult = policyBackupMessageService.updateMessageStatus(cmd, userPhone);
        log.info("backupPolicy,apiResult:{}", apiResult);
        //如果接收则统计
        if (PolicyReceiveStatusEnum.RECEIVED.getCode().equals(cmd.getStatus())
                && apiResult.getSuccess() && CollectionUtils.isNotEmpty(newPolicyIds)) {
            log.info("备份保单信息成功，开始更新统计信息");
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
                @Override
                public void afterCommit() {
                    List<Policy> policyList = policyGateway.list(Policy.builder().policyIds(newPolicyIds).build());
                    for (Policy policy : policyList) {
                        // 删除成功后 更新相关统计信息
                        log.info("备份保单信息后更新统计信息开始,policyId:{}", policy.getPolicyId());
                        updateStatisticsInfoAfterPolicyChanged(cmd.getUserId(), policy);
                        log.info("备份保单信息后更新统计信息结束,policyId:{}", policy.getPolicyId());
                    }
                }
            });
        }
        return apiResult;
    }

    private List<PolicyInsurantAddCmd> assembleBackupInsurant(Policy policy, String userId) {
        //获取原保单被保人
        List<PolicyInsurant> insurantList = policyInsurantService.findByPolicy(policy);
        List<PolicyInsurantAddCmd> backupInsurant = insurantList.stream().map(ins -> {
            PolicyInsurantAddCmd insurantAddCmd = new PolicyInsurantAddCmd();
            UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(ins.getInsurantId());
            Long insurantId = saveBackupFamilyMember(userFamilyInfo, userId);
            insurantAddCmd.setInsurantId(insurantId);
            return insurantAddCmd;
        }).collect(Collectors.toList());
        policy.setInsurant(insurantList);
        return backupInsurant;
    }

    private List<PolicyBeneficiaryAddCmd> assembleBackupBeneficiary(Policy policy, String userId) {
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(policy.getBeneficiaryType())) {
            List<PolicyBeneficiary> beneficiaryList = policyBeneficiaryService.list(policy);
            List<PolicyBeneficiaryAddCmd> backupBeneficaiary = beneficiaryList.stream().map(beneficiary -> {
                PolicyBeneficiaryAddCmd beneficiaryAddCmd = new PolicyBeneficiaryAddCmd();
                UserFamilyInfo userFamilyInfo1 = userFamilyInfoGateway.selectEntityByMemberId(beneficiary.getMemberId());
                Long memberId = saveBackupFamilyMember(userFamilyInfo1, userId);
                beneficiaryAddCmd.setMemberId(memberId);
                beneficiaryAddCmd.setBenefitRatio(beneficiary.getBenefitRatio());
                return beneficiaryAddCmd;
            }).collect(Collectors.toList());
            return backupBeneficaiary;
        }
        return null;
    }

    private void assembleBackupPolicy(Policy policy, String userId, String userPhone, Long backupPolicyHolderId) {
        policy.setId(null);
        policy.setPolicyId(IdUtil.getSnowflakeNextId());
        policy.setUserId(userId);
        policy.setUserPhone(userPhone);
        policy.setSourceType(SourceTypeEnum.BACKUP.getCode());
        policy.setPolicyHolderId(backupPolicyHolderId);
        policy.setCreateTime(new Date());
        policy.setUpdateTime(new Date());
    }

    @Override
    public ApiResult updatePayLabelStatus(PolicyPayLabelEditCmd cmd) {
        return policyPayDetailService.updatePayLabelStatus(cmd);
    }

    @Override
    public ApiResult compensatePolicy() {
        log.info("====《主险》补偿没有保司ID，产品ID，产品类别的保单数据，开始：{}=====", new Date());
        long begin = System.currentTimeMillis();
        //处理保司id为空
        List<Policy> policyList = policyGateway.listCompanyIdEmpty();
        long countCompanyUpdate = 0;
        //过滤出公司名称不是空的
        List<Policy> collect = policyList.stream().filter(policy -> StringUtils.isNotBlank(policy.getCompanyName())).collect(Collectors.toList());
        //将保司查出来存储
        List<InsuranceCompanyDropListVO> companyDropListVOList = companyService.queryList(new CompanyQry()).getData();
        HashMap<String, InsuranceCompanyDropListVO> map = new HashMap<>();
        for (InsuranceCompanyDropListVO insuranceCompanyDropListVO : companyDropListVOList) {
            map.put(insuranceCompanyDropListVO.getCompanyName(), insuranceCompanyDropListVO);
        }
        //更新
        if (CollectionUtils.isNotEmpty(collect)) {
            for (Policy policy : collect) {
                String companyName = policy.getCompanyName();
                InsuranceCompanyDropListVO insuranceCompanyDropListVO = map.get(companyName);
                if (Objects.nonNull(insuranceCompanyDropListVO)) {
                    policy.setCompanyId(insuranceCompanyDropListVO.getCompanyId());
                    policy.setCompanyNameShort(insuranceCompanyDropListVO.getCompanyNameShort());
                    countCompanyUpdate += policyGateway.update(policy);
                }
            }
        }
        log.info("保单中保司更新了{}条记录", countCompanyUpdate);

        //处理产品ID为空
        List<Policy> policyProdList = policyGateway.listProductIdEmpty();
        long countProdUpdate = 0;
        //过滤出产品名称不是空的
        List<Policy> prodCollect = policyProdList.stream().filter(policy -> StringUtils.isNotBlank(policy.getProductName())).collect(Collectors.toList());
        //将产品查出来存储
        List<InsuranceProductVO> insuranceProductVOList = insuranceProductService.listByProductName(new InsuranceProductQry());
        HashMap<String, InsuranceProductVO> productMap = new HashMap<>(30000);
        for (InsuranceProductVO insuranceProductVO : insuranceProductVOList) {
            productMap.put(insuranceProductVO.getProductName(), insuranceProductVO);
        }
        for (Policy policy : prodCollect) {
            InsuranceProductVO insuranceProductVO = productMap.get(policy.getProductName());
            if (Objects.nonNull(insuranceProductVO)) {
                policy.setProductId(insuranceProductVO.getProductId());
                policy.setProductTopType(insuranceProductVO.getOneLevelType());
                //设置产品类别
                policy.setProductType(insuranceProductVO.getOneLevelType());
                if (StringUtils.isNotBlank(insuranceProductVO.getTwoLevelType())) {
                    policy.setProductType(insuranceProductVO.getTwoLevelType());
                }
                if (StringUtils.isNotBlank(insuranceProductVO.getThreeLevelType())) {
                    policy.setProductType(insuranceProductVO.getThreeLevelType());
                }
                if (StringUtils.isNotBlank(insuranceProductVO.getFourLevelType())) {
                    policy.setProductType(insuranceProductVO.getFourLevelType());
                }
                countProdUpdate += policyGateway.update(policy);
            }
        }
        log.info("保单中产品更新了{}条记录", countProdUpdate);

        long end = System.currentTimeMillis();
        log.info("====《主险》补偿没有保司ID，产品ID，产品类别的保单数据，结束：{}，耗时{}毫秒=====", new Date(), end - begin);
        return ApiResult.buildSuccess();
    }

    /**
     * 根据年龄段组装出生日期的起止时间
     *
     * @return
     */
    private Policy buildPolicy(OverviewCommonQry qry) {

        Policy policy = new Policy();
        if (Objects.equals(qry.getAgeBracket(), AgeBracketEnum.FIVESTEP.getCode())) {
            // 年龄在50以上的
            policy.setInsurantBirthdayEnd(DateUtil.calBirthByAge(AgeBracketEnum.FIVESTEP.getBegin()));
        } else {
            // 年龄在其他段的
            policy.setInsurantBirthdayBegin(DateUtil.calBirthByAge(AgeBracketEnum.getEndByCode(qry.getAgeBracket())));
            policy.setInsurantBirthdayEnd(DateUtil.calBirthByAge(AgeBracketEnum.getBeginByCode(qry.getAgeBracket())));
        }
        return policy;
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult add(PolicyAddCmd cmd) {
         this.validateParams(cmd);

         Policy policy = policyCmdConvertor.convert(cmd);
        //设置保单唯一ID
        policy.setPolicyId(IdUtil.getSnowflakeNextId());
        policy.setSourceType(SourceTypeEnum.QUICKENTER.getCode());
        assemblePolicy(policy, cmd);
        Long policyId = policyGateway.save(policy);

        //保存被保险人
        policyInsurantService.add(policyId, cmd.getInsurant());

        //保存受益人
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            policyBeneficiaryService.add(policyId, cmd.getBeneficiary());
        }

        //生成并保存主险缴费标签
        policyPayDetailService.add(policy);

        //保存附加险
        policyAdditionalService.add(policy, cmd.getAdditional());

        //保存附件
        policyAttchmentService.add(policyId, cmd.getFileId());
        policy.setMemberId(cmd.getInsurant().get(0).getInsurantId());

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                //更新保单统计信息表 保额信息，家庭保障分
                // asyncPolicyStaInfo(policy.getUserId(),policy.getMemberId(),cmd.getProductTypeList(),cmd.getAdditional());
                asyncPolicyStaInfo(policy.getUserId(), policy.getMemberId(), findProductTopType(cmd.getProductTypeList(), null),
                        findProductTopType(null, cmd.getAdditional()));
            }
        });
        return ApiResult.of(String.valueOf(policyId));
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult ocrAdd(PolicyOcrAddCmd cmd){
        this.validateOcrParams(cmd);
        //1.保存投保人到家庭成员并返回成员ID
        UserFamilyInfo policyMember = saveFamilyMember(cmd.getPolicyHolder(), cmd.getUserId(), cmd.getPlatform());

        //2.保存被保人到家庭成员
        FamilyMemberCmd insurant = cmd.getInsurant().get(0);
        UserFamilyInfo insurantMember = saveFamilyMember(insurant, cmd.getUserId(), cmd.getPlatform());

        Policy policy = policyCmdConvertor.convert(cmd);
        //设置保单唯一ID
        policy.setBirthDay(insurantMember.getBirthday());
        policy.setPolicyId(IdUtil.getSnowflakeNextId());
        assemblePolicy(policy, cmd);
        policy.setPolicyHolderId(policyMember.getMemberId());
        //policy.setSourceType(SourceTypeEnum.OCR.getCode());
        log.info("ocr 新增保单主险开始,policyId:{}", policy.getPolicyId());
        Long policyId = policyGateway.save(policy);
        log.info("ocr 新增保单主险结束,policyId:{}", policyId);

        //保存被保险人
        PolicyInsurantAddCmd insurantAddCmd = new PolicyInsurantAddCmd();
        insurantAddCmd.setInsurantId(insurantMember.getMemberId());
        List<PolicyInsurantAddCmd> insurantList = new ArrayList<>();
        insurantList.add(insurantAddCmd);
        policyInsurantService.add(policyId, insurantList);

        //保存受益人
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            policyBeneficiaryService.add(policyId, cmd.getBeneficiary());
        }

        //生成并保存主险缴费标签
        policyPayDetailService.add(policy);

        //保存附加险
        policyAdditionalService.add(policy, cmd.getAdditional());

        //保存附件
        policyAttchmentService.add(policyId, cmd.getFileId());
        policy.setMemberId(insurantMember.getMemberId());

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                asyncPolicyStaInfo(policy.getUserId(), policy.getMemberId(), findProductTopType(cmd.getProductTypeList(), null),
                        findProductTopType(null, cmd.getAdditional()));
            }
        });
        return ApiResult.of(String.valueOf(policyId));
    }

    /**
     * 获取保险公司信息
     *
     * @param companyName
     * @return
     */
    private InsuranceCompanyDropListVO findCompanyInfo(String companyName) {
        ApiResult<List<InsuranceCompanyDropListVO>> apiResult = companyService.queryList(CompanyQry.builder().companyName(companyName).build());
        if (apiResult.getSuccess() && CollectionUtils.isNotEmpty(apiResult.getData())) {
            return apiResult.getData().get(0);
        }
        return null;
    }

    private Set<String> findProductTopType(List<String> productTypeList, List<PolicyAdditionalAddCmd> additional) {
        Set<String> topTypeSet = new HashSet<>();
        if (CollectionUtils.isNotEmpty(productTypeList)) {
            topTypeSet.add(productTypeList.get(0));
        }

        if (CollectionUtils.isNotEmpty(additional)) {
            topTypeSet.addAll(additional.stream().filter(na -> CollectionUtils.isNotEmpty(na.getProductTypeList()))
                    .map(o -> o.getProductTypeList().get(0)).collect(Collectors.toSet()));
        }
        return topTypeSet;
    }

    private UserFamilyInfo saveFamilyMember(FamilyMemberCmd member, String userId, Integer channelType) {
        List<Long> memberIds = new ArrayList<>();
        if (Objects.nonNull(member.getMemberId())) {
            memberIds.add(member.getMemberId());
            UserFamilyInfo userFamilyInfo = validFamilyMember(memberIds);
            return userFamilyInfo;
        }

        UserFamilyMemberEditCmd memberEditCmd = new UserFamilyMemberEditCmd();
        BeanUtils.copyProperties(member, memberEditCmd);
        memberEditCmd.setBelongUserId(userId);
        memberEditCmd.setChannelType(channelType);
        if (Objects.isNull(memberEditCmd.getRelation())) { //无关系时默认为其他
            memberEditCmd.setRelation(RelationEnum.OTHER.getCode());
        }
        Long memberId = userFamilyInfoService.saveFamilyMember(memberEditCmd);
        UserFamilyInfo userFamilyInfo = UserFamilyInfo.builder().memberId(memberId)
                .birthday(DateUtil.parseDate(member.getBirthday(),DateUtil.datePattern)).build();
        return userFamilyInfo;
    }

    private UserFamilyInfo validFamilyMember(List<Long> memberIds) {
        List<UserFamilyInfo> userFamilyInfos = userFamilyInfoGateway.list(UserFamilyInfo.builder().memberIds(memberIds).build());
        if (CollectionUtils.isEmpty(userFamilyInfos) || memberIds.size() > userFamilyInfos.size()) {
            throw new ValidationException("家庭成员不存在");
        }
        return userFamilyInfos.get(0);
    }

    private Long saveBackupFamilyMember(UserFamilyInfo userFamilyInfo, String userId) {
        userFamilyInfo.setId(null);
        userFamilyInfo.setMemberId(IdUtil.getSnowflakeNextId());
        userFamilyInfo.setBelongUserId(userId);
        userFamilyInfo.setRelation(RelationEnum.OTHER.getCode());
        UserFamilyMemberEditCmd memberEditCmd = new UserFamilyMemberEditCmd();
        BeanUtils.copyProperties(userFamilyInfo, memberEditCmd);
        if (Objects.isNull(userFamilyInfo.getBirthday())) {
            throw new RuntimeException("家庭成员出生日期未维护");
        }
        memberEditCmd.setBirthday(DateUtil.format(userFamilyInfo.getBirthday(),DateUtil.datePattern));
        Long memberId = userFamilyInfoService.saveFamilyMember(memberEditCmd);
        return memberId;
    }

    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult edit(PolicyEditCmd cmd) throws Exception {
        Policy policy = policyGateway.get(Policy.builder().policyId(cmd.getPolicyId()).delFlag(Constants.ONE).build());
        if (Objects.isNull(policy)) {
            return ApiResult.buildFailure("保单不存在");
        }
        this.validateParams(cmd);
        //获取原有被保人
        List<PolicyInsurant> oldInsurantList = policyInsurantService.findByPolicy(policy);
        policy.setInsurant(oldInsurantList);
        //获取原有附加险
        List<PolicyAdditional> oldAdditional = policyAdditionalService.list(policy);

        Policy policyEdit = policyCmdConvertor.convert(cmd);
        assemblePolicy(policyEdit, cmd);
        int flag = policyGateway.updateByPolicyId(policyEdit);
        //int flag = policyGateway.update(policyEdit);
        if (flag <= ZERO) {
            return ApiResult.buildFailure("保单更新失败");
        }

        //编辑被保险人
        policyInsurantService.edit(cmd.getPolicyId(), cmd.getInsurant());

        //保存受益人
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            policyBeneficiaryService.edit(policyEdit.getPolicyId(), cmd.getBeneficiary());
        }

        //生成并保存缴费标签
        policyPayDetailService.edit(policyEdit, policy);

        //保存附加险
        policyAdditionalService.edit(policyEdit, cmd);

        //保存附件
        policyAttchmentService.edit(cmd.getPolicyId(), cmd.getFileId());

        policy.setMemberId(cmd.getInsurant().get(0).getInsurantId());

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                //policy.getProductTopType(),
                Long oldInsurantId = oldInsurantList.get(0).getInsurantId();
                if (String.valueOf(policy.getMemberId()).equals(String.valueOf(oldInsurantId))) { //被保人未发生变化
                    insurantUnChanged(policy, policy.getProductTopType(), cmd.getProductTypeList(), oldAdditional, cmd.getAdditional());
                } else { //被保人发生变化
                    insurantChanged(policy, oldAdditional, oldInsurantId, cmd.getProductTypeList(), cmd.getAdditional());
                }
                // asyncPolicyStaInfo(policy.getUserId(), policy.getMemberId(), cmd.getProductTypeList(), cmd.getAdditional());

            }
        });
        return ApiResult.of(String.valueOf(policy.getPolicyId()));
    }


    private void insurantUnChanged(Policy policy, String oldProductTopType, List<String> newProductType,
                                   List<PolicyAdditional> oldAdditional, List<PolicyAdditionalAddCmd> newAdditional) {
        //被保人未发生变化
        //1.组装新，旧一级类别
        Set<String> topTypeSet = new HashSet<>();
        if (StringUtils.isNotEmpty(oldProductTopType)) {
            topTypeSet.add(oldProductTopType);
        }
        if (CollectionUtils.isNotEmpty(newProductType)) {
            topTypeSet.add(newProductType.get(0));
        }

        Set<String> additionalTopTypeSet = new HashSet<>();
        if (CollectionUtils.isNotEmpty(oldAdditional)) {
            additionalTopTypeSet.addAll(oldAdditional.stream().filter(oa -> StringUtils.isNotEmpty(oa.getProductTopType()))
                    .map(o -> o.getProductTopType()).collect(Collectors.toSet()));
        }

        if (CollectionUtils.isNotEmpty(newAdditional)) {
            additionalTopTypeSet.addAll(newAdditional.stream().filter(na -> CollectionUtils.isNotEmpty(na.getProductTypeList()))
                    .map(o -> o.getProductTypeList().get(0)).collect(Collectors.toSet()));
        }
        asyncPolicyStaInfo(policy.getUserId(), policy.getMemberId(), topTypeSet, additionalTopTypeSet);
    }

    private void insurantChanged(Policy oldPolicy, List<PolicyAdditional> oldAdditional, Long oldInsurantId,
                                 List<String> newProductType, List<PolicyAdditionalAddCmd> newAdditional) {
        //原被保人 主险一级类比处理
        Set<String> topTypeSet = new HashSet<>();
        if (StringUtils.isNotEmpty(oldPolicy.getProductTopType())) {
            topTypeSet.add(oldPolicy.getProductTopType());
        }
        //原被保人 附加险一级类比处理
        Set<String> additionalTopTypeSet = new HashSet<>();
        if (CollectionUtils.isNotEmpty(oldAdditional)) {
            additionalTopTypeSet.addAll(oldAdditional.stream().filter(oa -> StringUtils.isNotEmpty(oa.getProductTopType()))
                    .map(o -> o.getProductTopType()).collect(Collectors.toSet()));
        }
        asyncPolicyStaInfo(oldPolicy.getUserId(), oldInsurantId, topTypeSet, additionalTopTypeSet);

        //新被保人处理
        Set<String> newTopTypeSet = new HashSet<>();
        if (CollectionUtils.isNotEmpty(newProductType)) {
            newTopTypeSet.add(newProductType.get(0));
        }

        Set<String> newAdditionalTopTypeSet = new HashSet<>();
        if (CollectionUtils.isNotEmpty(newAdditional)) {
            newAdditionalTopTypeSet.addAll(newAdditional.stream().filter(na -> CollectionUtils.isNotEmpty(na.getProductTypeList()))
                    .map(o -> o.getProductTypeList().get(0)).collect(Collectors.toSet()));
        }

        asyncPolicyStaInfo(oldPolicy.getUserId(), oldPolicy.getMemberId(), newTopTypeSet, newAdditionalTopTypeSet);
    }

    /**
     * 删除保单（逻辑删除）
     *
     * @param cmd
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult logicDelete(PolicyDeleteCmd cmd) {
        log.info("PolicyServiceImpl logicDelete START.....");
        Policy originData = policyGateway.get(policyCmdConvertor.convert(cmd));
        if (Objects.isNull(originData)) {
            return ApiResult.buildFailure("保单不存在");
        }
        int updateResult = policyGateway.update(Policy.builder().policyId(originData.getPolicyId()).delFlag(DeleteFlagEnum.DELETED.getCode()).build());
        if (updateResult > 0) {
            updateResult = updateResult + policyGateway.deletePolicyLinkedData(cmd.getPolicyId());
            if (updateResult > 0) {
                log.info("删除保单关联信息成功，开始更新统计信息");
                TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
                    @Override
                    public void afterCommit() {
                        // 删除成功后 更新相关统计信息
                        updateStatisticsInfoAfterPolicyChanged(cmd.getUserId(), originData);
                    }
                });
            }
        }
        log.info("PolicyServiceImpl logicDelete END result:{}", updateResult);
        return updateResult > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }

    /**
     * 校验受益人及附加险及其他不规则参数
     *
     * @param cmd
     */
    private void validateParams(PolicyCmd cmd) {
        Date birthday = null;
        if(GuaranteePeriodUnitEnum.ENDAGE.getCode().equals(cmd.getGuaranteePeriodUnit())
                || PayPeriodUnitEnum.ENDAGE.getCode().equals(cmd.getPayPeriodUnit())) {
            UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(cmd.getInsurant().get(0).getInsurantId());
            if (Objects.isNull(userFamilyInfo)) {
                throw new ValidationException("被保人不存在");
            }
            birthday = userFamilyInfo.getBirthday();
            if (Objects.isNull(birthday)) {
                throw new ValidationException("被保人出生日期未维护");
            }
        }

        //校验缴费结束日
        validatePayEndDateParam(cmd.getPayPeriod(),cmd.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday);

        //保障结束日校验
        Date guaranteeEndDate = validateGuaranteePeriodParam(cmd.getGuaranteePeriod(),cmd.getGuaranteePeriodUnit(),cmd.getGuaranteeEndDate(),cmd.getEffectiveDate(), birthday);

        //保障期限校验
        validatePayPeriodParam(cmd.getPayCycle(),cmd.getPayPeriod(),cmd.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday,guaranteeEndDate);

        //受益人校验
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            if (CollectionUtils.isEmpty(cmd.getBeneficiary()) || cmd.getBeneficiary().size() > beneficiaryMaxNum) {
                throw new ValidationException("指定受益人至少为1人且不超过"+beneficiaryMaxNum+"人");
            }
            BigDecimal ratioSum1 = cmd.getBeneficiary().stream().map(b -> b.getBenefitRatio())
                    .reduce(BigDecimal.ZERO, (b1, b2) -> (b1.add(b2)));

            BigDecimal ratioSum = cmd.getBeneficiary().stream().map(PolicyBeneficiaryAddCmd::getBenefitRatio)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            if (ratioSum.compareTo(new BigDecimal(Constants.HUNDRED)) != ZERO) {
                throw new ValidationException("受益人受益比例总值有误");
            }
        }

        //其他信息校验
        validateOtherInfo(cmd.getBankName(), cmd.getPayCardNumber(), cmd.getHandler(), cmd.getHandlerPhone());

        //附加险最大条数校验
        List<PolicyAdditionalAddCmd> additionalList = cmd.getAdditional();
        if (CollectionUtils.isNotEmpty(additionalList) && additionalList.size() > additionalMaxNum) {
            throw new ValidationException("附加险最多不超过" + additionalMaxNum + "个");
        }

        //附加险部分字段规则校验
        if (CollectionUtils.isNotEmpty(additionalList)) {
            for (PolicyAdditionalAddCmd additional : additionalList) {
                if (Objects.isNull(birthday)) {
                    if(GuaranteePeriodUnitEnum.ENDAGE.getCode().equals(additional.getGuaranteePeriodUnit())
                            || PayPeriodUnitEnum.ENDAGE.getCode().equals(additional.getPayPeriodUnit())) {
                        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(cmd.getInsurant().get(0).getInsurantId());
                        if (Objects.isNull(userFamilyInfo)) {
                            throw new ValidationException("被保人不存在");
                        }
                        birthday = userFamilyInfo.getBirthday();
                        if (Objects.isNull(birthday)) {
                            throw new ValidationException("被保人出生日期未维护");
                        }
                    }
                }
                //校验缴费结束日
                validatePayEndDateParam(additional.getPayPeriod(),additional.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday);

                //保障结束日校验
                Date aGuaranteeEndDate = validateGuaranteePeriodParam(additional.getGuaranteePeriod(),
                        additional.getGuaranteePeriodUnit(),additional.getGuaranteeEndDate(),cmd.getEffectiveDate(), birthday);

                if ((Objects.nonNull(guaranteeEndDate) && Objects.isNull(aGuaranteeEndDate))
                        || (Objects.nonNull(guaranteeEndDate) && Objects.nonNull(aGuaranteeEndDate)
                           && DateUtil.compareDate(aGuaranteeEndDate,guaranteeEndDate) == 1)) {
                    throw new ValidationException("附加险的保障期限不能超过主险的保障期限");
                }
                //保障期限校验
                validatePayPeriodParam(cmd.getPayCycle(),additional.getPayPeriod(),additional.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday,aGuaranteeEndDate);

            }
        }
    }

    /**
     * 至**岁时校验缴费结束日不能小于保单生效日
     * @param payPeriod
     * @param payPeriodUnit
     * @param effectiveDate
     * @param birthday
     */
    private void validatePayEndDateParam(Integer payPeriod,Integer payPeriodUnit,Date effectiveDate,Date birthday) {
        if (PayPeriodUnitEnum.ENDAGE.getCode().equals(payPeriodUnit)) {
            Date payEndDate = DateUtil.addYears(birthday,payPeriod);
            Date payMaxEndDate = DateUtil.compareMonthDayDate(effectiveDate,payEndDate);
            if (DateUtil.compareDate(effectiveDate,payMaxEndDate) == Constants.ONE) {
                throw new ValidationException("缴费结束日不能小于生效日期");
            }
        }
    }

    /**
     * 校验保障期限
     * @param guaranteePeriod
     * @param guaranteePeriodUnit
     * @param guaranteeEndDate
     * @param effectiveDate
     * @param birthday
     */
    private Date validateGuaranteePeriodParam(Integer guaranteePeriod,Integer guaranteePeriodUnit,Date guaranteeEndDate,Date effectiveDate,Date birthday) {
        if ((guaranteePeriodUnit < GuaranteePeriodUnitEnum.LIFELONG.getCode())
                && Objects.isNull(guaranteePeriod)) {
            throw new ValidationException("保障期限必填");
        }

        //保障结束日
        GuaranteePeriodUnitEnum guaranteePeriodUnitEnum = GuaranteePeriodUnitEnum.getEnumByCode(guaranteePeriodUnit);
        switch (guaranteePeriodUnitEnum){
            case DAY:
                if (guaranteePeriod > 36500) {
                    throw new ValidationException("保障期限最大值不能超过36500天");
                } else {
                    guaranteeEndDate = DateUtil.addDays(effectiveDate,guaranteePeriod-Constants.ONE);
                }
                break;
            case MONTH:
                if (guaranteePeriod > 1200) {
                    throw new ValidationException("保障期限最大值不能超过1200月");
                } else {
                    guaranteeEndDate = DateUtil.addDays(DateUtil.addMonths(effectiveDate,guaranteePeriod),-Constants.ONE);
                }
                break;
            case YEAR:
                if (guaranteePeriod > 100) {
                    throw new ValidationException("保障期限最大值不能超过100年");
                } else {
                    guaranteeEndDate = DateUtil.addDays(DateUtil.addYears(effectiveDate,guaranteePeriod),-Constants.ONE);
                }
                break;
            case ENDAGE:
                //根据生日计算
                if (guaranteePeriod > 108) {
                    throw new ValidationException("保障期限最大值不能超过108岁");
                } else {
                    guaranteeEndDate = DateUtil.addDays(DateUtil.addYears(birthday,guaranteePeriod+Constants.ONE),-Constants.ONE);
                }
                break;
            case LIFELONG:
                break;
            case OTHER:
                if (Objects.isNull(guaranteeEndDate)) {
                    throw new ValidationException("保障结束日必填");
                } else {
                    if (DateUtil.compareDate(effectiveDate,guaranteeEndDate) == 1){
                        throw new ValidationException("保障结束日不能小于保单生效日期");
                    }
                }
                break;
        }

        return guaranteeEndDate;
    }

    /**
     * 校验缴费期间
     * @param payPeriod
     * @param payPeriodUnit
     */
    private void validatePayPeriodParam(Integer payCycle,Integer payPeriod,Integer payPeriodUnit,Date effectiveDate,Date birthday,Date guaranteeEndDate) {
        //一次性交清不校验
        if (PayCycleEnum.LUMPSUMPAYMENT.getCode().equals(payCycle)) {
          return;
        }

        if (Objects.isNull(payPeriod) || Objects.isNull(payPeriodUnit)) {
            throw new ValidationException("缴费期间必填");
        }

        //缴费期间结束日
        Date payPeriodEndDate = effectiveDate;
        PayPeriodUnitEnum payPeriodUnitEnum = PayPeriodUnitEnum.getEnumByCode(payPeriodUnit);
        switch (payPeriodUnitEnum){
            case MONTH:
                if (payPeriod > 1200) {
                    throw new ValidationException("缴费期间最大值不能超过1200月");
                } else {
                    payPeriodEndDate = DateUtil.addMonths(effectiveDate,payPeriod-1);
                }
                break;
            case HALFYEAR:
                if (payPeriod > 200) {
                    throw new ValidationException("缴费期间半年最大值不能超过200");
                } else {
                    payPeriodEndDate = DateUtil.addMonths(effectiveDate,payPeriod*6-1);
                }
                break;
            case YEAR:
                if (payPeriod > 100) {
                    throw new ValidationException("缴费期间最大值不能超过100年");
                } else {
                    payPeriodEndDate = DateUtil.addYears(effectiveDate,payPeriod-1);
                }
                break;
            case ENDAGE:
                //根据生日计算缴费期间结束日
                if (payPeriod > 108) {
                    throw new ValidationException("保障期限最大值不能超过108岁");
                } else {
                    payPeriodEndDate = DateUtil.addYears(birthday,payPeriod);
                }
                break;
        }

        //缴费期间结束日不能超过保障结束日 （计算保障结束日），（计算缴费期间）
        if (Objects.nonNull(guaranteeEndDate) && DateUtil.compareDate(payPeriodEndDate,guaranteeEndDate) >= 0) {
            throw new ValidationException("缴费期间不能超过保障结束日");
        }

    }

    /**
     * 组装保单数据
     *
     * @param policy
     * @param cmd
     */
    private void assemblePolicy(Policy policy, PolicyCmd cmd) {
        //获取保险产品类型与产品库对应
        setProductType(policy, cmd.getProductTypeList());
        //计算保障结束日及当前保障状态
        Long insurantMemberId = cmd.getInsurant().get(0).getInsurantId();
        UserFamilyInfo insurantMember = userFamilyInfoGateway.selectEntityByMemberId(insurantMemberId);

        Date birthday =  insurantMember.getBirthday();
        if (Objects.isNull(birthday)) {
            throw new RuntimeException("被保人出生日期未维护");
        }
        policy.setBirthDay(birthday);
        policy.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
        Date guaranteeEndDate = calGuaranteeEndDate(policy);
        policy.setGuaranteeEndDate(guaranteeEndDate);
        if (DateUtil.compareDate(cmd.getEffectiveDate(), DateUtil.getCurrDate()) == Constants.ONE) {
            //设置状态未在保障中
            policy.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
        } else if (Objects.nonNull(guaranteeEndDate) && (DateUtil.compareDate(guaranteeEndDate, DateUtil.getCurrDate()) == Constants.NEGATIVE_ONE)){
            //设置状态未在保障中
            policy.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
        }
        //计算总保费=缴费周期，缴费期间，保费
        policy.setTotalPremium(calTotalPremium(policy));
        ApiResult<String> apiResult = userChannelInfoService.getPhoneNumberByUserId(policy.getUserId());
        if (apiResult.getSuccess()) {
            policy.setUserPhone(apiResult.getData());
        } else {
            log.info("assemblePolicy userId:{},从userCenter未获取到手机号", policy.getUserId());
            throw new ValidationException("请先授权手机号");
        }
        // 测试使用
        //policy.setUserPhone("18111111112");
    }

    /**
     * 组装保单数据
     *
     * @param policy
     * @param cmd
     */
    private void assemblePolicy(Policy policy, PolicyOcrAddCmd cmd) {
        //获取保险产品类型与产品库对应
        setProductType(policy, cmd.getProductTypeList());
        //计算保障结束日及当前保障状态
        if (Objects.isNull(policy.getBirthDay())) {
            throw new RuntimeException("被保人出生日期未维护");
        }
        if (Objects.isNull(cmd.getSourceType())) {
            policy.setSourceType(SourceTypeEnum.OCR.getCode());
        } else {
            policy.setSourceType(cmd.getSourceType());
        }
        policy.setStatus(PolicyStatusEnum.IN_INSURED.getCode());
        Date guaranteeEndDate = calGuaranteeEndDate(policy);
        policy.setGuaranteeEndDate(guaranteeEndDate);
        if (DateUtil.compareDate(cmd.getEffectiveDate(), DateUtil.getCurrDate()) == Constants.ONE) {
            //设置状态未在保障中
            policy.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
        } else if (Objects.nonNull(guaranteeEndDate) && (DateUtil.compareDate(guaranteeEndDate, DateUtil.getCurrDate()) == Constants.NEGATIVE_ONE)){
            //设置状态未在保障中
            policy.setStatus(PolicyStatusEnum.OUT_INSURED.getCode());
        }

        //计算总保费=缴费周期，缴费期间，保费
        policy.setTotalPremium(calTotalPremium(policy));

        ApiResult<String> apiResult = userChannelInfoService.getPhoneNumberByUserId(policy.getUserId());
        if (apiResult.getSuccess()) {
            policy.setUserPhone(apiResult.getData());
        } else {
            log.info("assemblePolicy userId:{},从userCenter未获取到手机号", policy.getUserId());
            throw new ValidationException("请先授权手机号");
        }
        //测试使用
        //policy.setUserPhone("18884527154");

        //处理保司id和简称
        if (StringUtils.isEmpty(cmd.getCompanyId()) || StringUtils.isEmpty(cmd.getCompanyNameShort())) {
            InsuranceCompanyDropListVO companyInfo = findCompanyInfo(cmd.getCompanyName());
            if (Objects.nonNull(companyInfo)) {
                policy.setCompanyNameShort(companyInfo.getCompanyNameShort());
                policy.setCompanyId(companyInfo.getCompanyId());
            }
        }
    }

    /**
     * 计算主险保障结束日期
     *
     * @param policy
     * @return
     */
    private Date calGuaranteeEndDate(Policy policy) {
        //生效日期
        Date effectiveDate = policy.getEffectiveDate();
        //保障期限
        Integer period = policy.getGuaranteePeriod();
        //保障期限单位(1:天,2:月3:年,4:至**岁,5:终身,6:其他)
        Integer periodUnit = policy.getGuaranteePeriodUnit();
        if (GuaranteePeriodUnitEnum.DAY.getCode().equals(periodUnit)) {
            return DateUtil.addDays(effectiveDate, period - Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.MONTH.getCode().equals(periodUnit)) {
            return DateUtil.addDays(DateUtil.addMonths(effectiveDate, period),-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.YEAR.getCode().equals(periodUnit)) {
            return DateUtil.addDays(DateUtil.addYears(effectiveDate, period),-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.ENDAGE.getCode().equals(periodUnit)) {
            return DateUtil.addDays(DateUtil.addYears(policy.getBirthDay(), period+Constants.ONE),-Constants.ONE);
        } else if (GuaranteePeriodUnitEnum.OTHER.getCode().equals(periodUnit)) {
            return policy.getGuaranteeEndDate();
        }
        return null; //终身时返回null
    }

    /**
     * 计算保单主险总保费
     *
     * @param policy
     * @return
     */
    private BigDecimal calTotalPremium(Policy policy) {
        //缴费周期
        Integer payCycle = policy.getPayCycle();
        //缴费期间
        Integer payPeriod = policy.getPayPeriod();
        //缴费期间单位
        Integer payPeriodUnit = policy.getPayPeriodUnit();
        //单次保费
        BigDecimal singlePremium = policy.getSinglePremium();
        BigDecimal totalPremium = new BigDecimal(0);
        //一次性交清
        if (PayCycleEnum.LUMPSUMPAYMENT.getCode().equals(payCycle)) {
            return singlePremium;
        }
        //总保费计算 = 单次保费*期数(期数单位为至**数时需根据缴费周期转成具体期数单位)
        if (PayPeriodUnitEnum.ENDAGE.getCode().equals(payPeriodUnit)) {
            //至**岁时计算期数
            long period = calPeriodNum(policy);
            totalPremium = singlePremium.multiply(new BigDecimal(period));
        } else {
            totalPremium = singlePremium.multiply(new BigDecimal(payPeriod));
        }
        return totalPremium;
    }

    /**
     * 至**岁时根据缴费周期计算缴费期数
     *
     * @param policy
     * @return
     */
    private static long calPeriodNum(Policy policy) {
        Integer payCycle = policy.getPayCycle();
        Date effectiveDate = policy.getEffectiveDate();
        //计算一定年龄后的日期
        Date insurantBirthday = policy.getBirthDay();
        Date birthDayEnd = DateUtil.addYears(insurantBirthday, policy.getPayPeriod());

        Date baseDate = DateUtil.compareMonthDayDate(effectiveDate, birthDayEnd);
        String startDate = DateUtil.format(effectiveDate, DateUtil.datePattern);
        String endDate = DateUtil.format(baseDate, DateUtil.datePattern);

        long periodNum = 0;
        if (PayCycleEnum.ANNUALPAYMENT.getCode().equals(payCycle)) { //年缴
            periodNum = DateUtil.getDateDiff(startDate, endDate, payCycle) + 1;
        } else if (PayCycleEnum.MONTHLYPAYMENT.getCode().equals(payCycle)) { //月缴
            periodNum = DateUtil.getDateDiff(startDate, endDate, payCycle) + 1;
        } else if (PayCycleEnum.SEMIANNUALPAYMENT.getCode().equals(payCycle)) { //半年缴
            periodNum = DateUtil.getDateList(effectiveDate, baseDate, 2, 6).size();
        }
        return periodNum;
    }

    /**
     * 设置产品类型
     *
     * @param policy
     * @param productType
     */
    private void setProductType(Policy policy, List<String> productType) {
        if (CollectionUtils.isNotEmpty(productType)) {
            int size = productType.size();
            switch (size) {
                case Constants.ONE:
                    policy.setProductTopType(productType.get(Constants.ZERO));
                    break;
                case Constants.TWO:
                    policy.setProductTopType(productType.get(Constants.ZERO));
                    policy.setProductTwoType(productType.get(Constants.ONE));
                    break;
                case Constants.THREE:
                    policy.setProductTopType(productType.get(ZERO));
                    policy.setProductTwoType(productType.get(Constants.ONE));
                    policy.setProductThreeType(productType.get(Constants.TWO));
                    break;
                case Constants.FOUR:
                    policy.setProductTopType(productType.get(Constants.ZERO));
                    policy.setProductTwoType(productType.get(Constants.ONE));
                    policy.setProductThreeType(productType.get(Constants.TWO));
                    policy.setProductFourType(productType.get(Constants.THREE));
                    break;
                default:
                    log.info("无产品类型......");
                    break;
            }
            policy.setProductType(productType.get(productType.size() - Constants.ONE));
        }
    }

    /**
     * 保单新增，编辑，删除后调用 更新用户统计信息
     * 统计用户保单信息
     *
     * @param userId
     * @param memberId
     */
    @Override
    public void statisticsMemberInfo(String userId, Long memberId) {
        log.info("statisticsMemberInfo userId:{},memberId:{} start.....", userId, memberId);
        Policy policy = Policy.builder().userId(userId).memberId(memberId).delFlag(Constants.ONE).build();
        //policy.setMemberId(1529364611860561920l); //临时测试使用
        List<Policy> policyList = policyGateway.queryPolicyByUserIdAndMemberId(policy);
        if (CollectionUtils.isEmpty(policyList)) {
            log.info("statisticsMemberInfo userId:{},memberId:{} 无保单了，执行删除统计数据开始", userId, memberId);
            policyMemberStatisticsService.deleteMemberStatisticsInfo(userId, memberId);
            log.info("statisticsMemberInfo userId:{},memberId:{} 无保单了，执行删除统计数据结束", userId, memberId);
        } else {
            log.info("statisticsMemberInfo userId:{},memberId:{} 开始统计.....", userId, memberId);
            int policyTotalNum = policyList.size();
            int ePolicyNum = policyList.stream().filter(p -> p.getStatus().equals(Constants.ONE)).collect(Collectors.summingInt(Policy::getStatus));

            PolicyPayDetail ppd = policyPayDetailService.findCurrentYearPremiumByPolicy(policyList);
            PolicyMemberStatistics pms = new PolicyMemberStatistics();
            pms.setUserId(policy.getUserId());
            pms.setMemberId(policy.getMemberId());
            pms.setPolicyNum(policyTotalNum);
            pms.setEffectivePolicyNum(ePolicyNum);
            if (Objects.nonNull(ppd)) {
                pms.setPremium(ppd.getPremium());
            } else {
                log.info("statisticsMemberInfo memberId:{} 未获取到用户今年保费", memberId);
            }
            policyMemberStatisticsService.updateMemberStatisticsInfo(pms);
            log.info("statisticsMemberInfo userId:{},memberId:{} 结束统计.....", userId, memberId);
        }
    }

    private List<PolicySimpleVO> buildPolicySimpleVO(List<Policy> policyList) {
        return null;
    }

    /**
     * 根据保单信息和附加险信息计算年保费
     * 当缴费周期是月、半年、年时
     * 年保费 = policy.单次保费*12|2|1 + 每个附加险信息.单次保费*12|2|1
     * 当缴费周期是一次性缴清时
     * 年保费 = policy.总保费 + 每个附加险信息.总保费
     *
     * @param policyAdditionalList
     * @param policy
     * @return
     */
    private String calculateAnnualAmount(List<PolicyAdditional> policyAdditionalList, Policy policy) {
        // 缴费周期枚举
        PayCycleEnum payCycleEnum = PayCycleEnum.getEnumByCode(policy.getPayCycle());
        // 单次保费
        BigDecimal singlePremium = policy.getSinglePremium();
        switch (Objects.requireNonNull(payCycleEnum)) {
            // 一次性缴清
            case LUMPSUMPAYMENT:
                if (CollectionUtils.isEmpty(policyAdditionalList)) {
                    BigDecimal annualAmount = policy.getTotalPremium().setScale(2, BigDecimal.ROUND_HALF_UP);
                    log.info("calculateAnnualAmount 未获取到附加险信息 本次计算出的年保费为：{}元", annualAmount);
                    return annualAmount.toPlainString();
                }
                BigDecimal addtionalTotalAmount = new BigDecimal("0");
                for (PolicyAdditional policyAdditional : policyAdditionalList) {
                    addtionalTotalAmount = addtionalTotalAmount.add(policyAdditional.getTotalPremium());
                }
                BigDecimal annualAmount = NumberUtil.add(policy.getTotalPremium(), addtionalTotalAmount).setScale(2, RoundingMode.HALF_UP);
                log.info("calculateAnnualAmount 本次计算出的年保费为：{}元", annualAmount);
                return handleDecimalPoint(annualAmount);
            default:
                // 周期缴费
                return calculateAnnualAmountByCycle(payCycleEnum.getCountCycle(), policyAdditionalList, singlePremium);
        }
    }

    /**
     * 传入周期变量 计算年保费
     *
     * @param StringCycle
     * @param policyAdditionalList
     * @param singlePremium
     * @return
     */
    private String calculateAnnualAmountByCycle(String StringCycle, List<PolicyAdditional> policyAdditionalList, BigDecimal singlePremium) {
        BigDecimal cycle = new BigDecimal(StringCycle);
        // 没有附加险 直接算主保单的即可
        if (CollectionUtils.isEmpty(policyAdditionalList)) {
            BigDecimal annualAmount = NumberUtil.mul(singlePremium, cycle).setScale(2, RoundingMode.HALF_UP);
            log.info("calculateAnnualAmountByCycle 未获取到附加险信息 本次计算出的年保费为：{}元", annualAmount);
            return annualAmount.stripTrailingZeros().toPlainString();
        }
        // 主保单年保费
        BigDecimal mainTotalAmount = singlePremium.multiply(cycle);
        // 附加险年保费
        BigDecimal addtionalTotalAmount = new BigDecimal("0");
        for (PolicyAdditional policyAdditional : policyAdditionalList) {
            addtionalTotalAmount = addtionalTotalAmount.add(policyAdditional.getSinglePremium().multiply(cycle));
        }
        // 主+附 = 总年保费
        BigDecimal annualAmount = NumberUtil.add(mainTotalAmount, addtionalTotalAmount).setScale(2, RoundingMode.HALF_UP);
        log.info("calculateAnnualAmountByCycle 本次计算出的年保费为：{}元", annualAmount);
        return handleDecimalPoint(annualAmount);
    }

    /**
     * 校验受益人及附加险及其他不规则参数
     *
     * @param cmd
     */
    private void validateOcrParams(PolicyOcrAddCmd cmd) {
        FamilyMemberCmd policyHolder = cmd.getPolicyHolder();
        if (Objects.isNull(policyHolder.getMemberId()) && StringUtils.isEmpty(policyHolder.getBirthday())) {
            throw new ValidationException("投保人出生日期必填");
        }

        FamilyMemberCmd insurant = cmd.getInsurant().get(0);
        if (Objects.isNull(insurant.getMemberId()) && StringUtils.isEmpty(insurant.getBirthday())) {
            throw new ValidationException("被保人出生日期必填");
        }
        Date birthday = null;
        if (Objects.nonNull(insurant.getMemberId())) {
            UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(insurant.getMemberId());
            if (Objects.isNull(userFamilyInfo)) {
                throw new ValidationException("被保人不存在");
            }
            if (Objects.isNull(userFamilyInfo.getBirthday())) {
                throw new ValidationException("被保人出生日期未维护");
            }
            birthday = userFamilyInfo.getBirthday();
        } else {
            birthday = DateUtil.parseDate(insurant.getBirthday(),DateUtil.datePattern);
        }

        //校验缴费结束日
        validatePayEndDateParam(cmd.getPayPeriod(),cmd.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday);

        //校验保障期限
        Date guaranteeEndDate = validateGuaranteePeriodParam(cmd.getGuaranteePeriod(),cmd.getGuaranteePeriodUnit(),
                cmd.getGuaranteeEndDate(),cmd.getEffectiveDate(),birthday);

        //校验缴费期间
        validatePayPeriodParam(cmd.getPayCycle(),cmd.getPayPeriod(),cmd.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday,guaranteeEndDate);

        //受益人校验
        if (BeneficiaryTypeEnum.APPOINT.getCode().equals(cmd.getBeneficiaryType())) {
            if (CollectionUtils.isEmpty(cmd.getBeneficiary()) || cmd.getBeneficiary().size() > beneficiaryMaxNum) {
                throw new ValidationException("指定受益人至少为1人且不超过"+beneficiaryMaxNum+"人");
            }
            BigDecimal ratioSum1 = cmd.getBeneficiary().stream().map(b -> b.getBenefitRatio())
                    .reduce(BigDecimal.ZERO, (b1, b2) -> (b1.add(b2)));

            BigDecimal ratioSum = cmd.getBeneficiary().stream().map(PolicyBeneficiaryAddCmd::getBenefitRatio)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            if (ratioSum.compareTo(new BigDecimal(Constants.HUNDRED)) != ZERO) {
                throw new ValidationException("受益人受益比例总值有误");
            }
        }
        //其他信息校验
        validateOtherInfo(cmd.getBankName(), cmd.getPayCardNumber(), cmd.getHandler(), cmd.getHandlerPhone());

        //附加险最大条数校验
        List<PolicyAdditionalAddCmd> additionalList = cmd.getAdditional();
        if (CollectionUtils.isNotEmpty(additionalList) && additionalList.size() > additionalMaxNum) {
            throw new ValidationException("附加险最多不超过"+additionalMaxNum+"个");
        }

        //附加险部分字段规则校验
        if (CollectionUtils.isNotEmpty(additionalList)) {
            for (PolicyAdditionalAddCmd additional : additionalList) {
                if (Objects.isNull(birthday) && Objects.nonNull(insurant.getMemberId())) {
                    if(GuaranteePeriodUnitEnum.ENDAGE.getCode().equals(additional.getGuaranteePeriodUnit())
                            || PayPeriodUnitEnum.ENDAGE.getCode().equals(additional.getPayPeriodUnit())) {
                        UserFamilyInfo userFamilyInfo = userFamilyInfoGateway.selectEntityByMemberId(insurant.getMemberId());
                        if (Objects.isNull(userFamilyInfo)) {
                            throw new ValidationException("被保人不存在");
                        }
                        birthday = userFamilyInfo.getBirthday();
                        if (Objects.isNull(birthday)) {
                            throw new ValidationException("被保人出生日期未维护");
                        }
                    }
                }
                //校验缴费结束日
                validatePayEndDateParam(additional.getPayPeriod(),additional.getPayPeriodUnit(),cmd.getEffectiveDate(),birthday);

                //保障结束日校验
                Date aGuaranteeEndDate = validateGuaranteePeriodParam(additional.getGuaranteePeriod(),
                        additional.getGuaranteePeriodUnit(), additional.getGuaranteeEndDate(), cmd.getEffectiveDate(), birthday);

                if ((Objects.nonNull(guaranteeEndDate) && Objects.isNull(aGuaranteeEndDate))
                        || (Objects.nonNull(guaranteeEndDate) && Objects.nonNull(aGuaranteeEndDate)
                        && DateUtil.compareDate(aGuaranteeEndDate,guaranteeEndDate) == 1)) {
                    throw new ValidationException("附加险的保障期限不能超过主险的保障期限");
                }
                //保障期限校验
                validatePayPeriodParam(cmd.getPayCycle(), additional.getPayPeriod(), additional.getPayPeriodUnit(), cmd.getEffectiveDate(), birthday, aGuaranteeEndDate);
            }
        }
    }

    private void validateOtherInfo(String bankName, String payCardNumber, String handler, String handlerPhone) {
        if (StringUtils.isNotEmpty(bankName) && bankName.length() > 50) {
            throw new ValidationException("开户行不能超过50个字符");
        }
        if (StringUtils.isNotEmpty(payCardNumber) && payCardNumber.length() > 50) {
            throw new ValidationException("缴费卡号不能超过50个字符");
        }
        if (StringUtils.isNotEmpty(handler) && handler.length() > 20) {
            throw new ValidationException("经办人长度不能超过20个字符");
        }
        if (StringUtils.isNotEmpty(handlerPhone) && handlerPhone.length() > 20) {
            throw new ValidationException("经办人手机号不能超过20个字符");
        }
    }

    private void asyncPolicyStaInfo(String userId, Long memberId, Set<String> topTypeSet, Set<String> additionalTopTypeSet) {
        //更新保单统计信息表
        statisticsMemberInfo(userId, memberId);

        Set<String> productTopTypeSet = new HashSet<>();

        if (CollectionUtils.isNotEmpty(topTypeSet)) {
            productTopTypeSet.addAll(topTypeSet);
            log.info("asycnPolicyStaInfo memberId{} 统计用户保单类别保额开始", memberId);
            updateSingleInsuranceAmount(memberId);
            log.info("asycnPolicyStaInfo memberId{} 统计用户保单类别保额结束", memberId);
        } else {
            log.info("asycnPolicyStaInfo memberId{} policyTopType is null,不更新主险类别保额", memberId);
        }

        if (CollectionUtils.isNotEmpty(additionalTopTypeSet)) {
            productTopTypeSet.addAll(additionalTopTypeSet);
        }

        //附加险保险类别
        if (CollectionUtils.isNotEmpty(additionalTopTypeSet)) {
            policyAdditionalService.updateSingleInsuranceAmount(memberId);
        } else {
            log.info("asycnPolicyStaInfo memberId{} additionalTopType is null, 不更新附加险类别保额", memberId);
        }


        if (CollectionUtils.isEmpty(productTopTypeSet)) {
            log.info("memberId{} productTopTypeSet is null 不调用家庭保障分计算接口", memberId);
            return;
        }
        MemberEnsuredCalcCmd calcCmd = new MemberEnsuredCalcCmd();
        calcCmd.setMemberId(memberId);
        calcCmd.setUserId(userId);
        calcCmd.setProdTypeCodes(productTopTypeSet);
        String param = JSONObject.toJSONString(calcCmd);
        log.info("调用家庭保障分计算接口开始 param:{}", param);
        try {
            memberEnsuredInfoService.calculateEnsuredScore(calcCmd);
        }catch (Exception e){
            log.error("计算家庭保障分异常{}",param,e);
        }
        log.info("调用家庭保障分计算接口结束....");
    }

    private void asyncPolicyStaInfo(String userId, Long memberId, List<String> topTypeList, List<PolicyAdditionalAddCmd> additionalList) {
        //更新保单统计信息表
        statisticsMemberInfo(userId, memberId);

        Set<String> productTopTypeSet = new HashSet<>();

        if (CollectionUtils.isNotEmpty(topTypeList)) {
            productTopTypeSet.add(topTypeList.get(0));
            log.info("asycnPolicyStaInfo memberId{} 统计用户保单类别保额开始", memberId);
            updateSingleInsuranceAmount(memberId);
            log.info("asycnPolicyStaInfo memberId{} 统计用户保单类别保额结束", memberId);
        } else {
            log.info("asycnPolicyStaInfo memberId{} policyTopType is null,不更新主险类别保额", memberId);
        }

        if (CollectionUtils.isNotEmpty(additionalList)) {
            List<String> additionalProductTypeList = new ArrayList<>();
            for (PolicyAdditionalAddCmd tmp : additionalList) {
                List<String> additionalProductType = tmp.getProductTypeList();
                if (CollectionUtils.isNotEmpty(additionalProductType)) {
                    productTopTypeSet.add(additionalProductType.get(0));
                    additionalProductTypeList.add(additionalProductType.get(0));
                }
            }

            //附加险保险类别
            if (CollectionUtils.isNotEmpty(additionalProductTypeList)) {
                policyAdditionalService.updateSingleInsuranceAmount(memberId);
            } else {
                log.info("asycnPolicyStaInfo memberId{} additionalTopType is null, 不更新附加险类别保额", memberId);
            }
        }

        //更新保障分
        if (CollectionUtils.isEmpty(productTopTypeSet)) {
            log.info("memberId{} productTopTypeSet is null 不调用家庭保障分计算接口", memberId);
            return;
        }
        MemberEnsuredCalcCmd calcCmd = new MemberEnsuredCalcCmd();
        calcCmd.setMemberId(memberId);
        calcCmd.setUserId(userId);
        calcCmd.setProdTypeCodes(productTopTypeSet);
        log.info("调用家庭保障分计算接口开始 param:{}", JSONObject.toJSONString(calcCmd));
        memberEnsuredInfoService.calculateEnsuredScore(calcCmd);
        log.info("调用家庭保障分计算接口结束....");
    }

    /**
     * 删除保单后更新统计信息
     *
     * @param userId
     * @param policy
     */
    private void updateStatisticsInfoAfterPolicyChanged(String userId, Policy policy) {
        log.info("updateStatisticsInfoAfterPolicyChanged START..... userId:{}，policy:{}", userId, policy);
        Long policyId = policy.getPolicyId();

        PolicyInsurant policyInsurant = policyInsurantGateway.get(PolicyInsurant.builder().policyId(policyId).build());
        // 被保人ID
        Long memberId = policyInsurant.getInsurantId();

        // 主保单一级类别
        String topType = policy.getProductTopType();
        // 附加险一级类别列表
        List<PolicyAdditional> additionalList = policyAdditionalGateway.listByPolicy(PolicyAdditional.builder().policyId(policyId).build());
        //更新保单统计信息表
        statisticsMemberInfo(userId, memberId);
        // 初始化一级类别Set
        Set<String> productTopTypeSet = new HashSet<>();

        if (StringUtils.isNotBlank(topType)) {
            productTopTypeSet.add(topType);
            updateSingleInsuranceAmount(memberId);
        } else {
            log.info("updateStatisticsInfoAfterPolicyChanged policyId:{}，policyTopType is null,不更新主险类别保额", policyId);
        }
        // 如果有附加险
        if (CollectionUtils.isNotEmpty(additionalList)) {
            for (PolicyAdditional policyAdditional : additionalList) {
                productTopTypeSet.add(policyAdditional.getProductTopType());
            }
            policyAdditionalService.updateSingleInsuranceAmount(memberId);
        }
        log.info("updateStatisticsInfoAfterPolicyChanged policyId{} additionalTopType is null, 不更新附加险类别保额", policyId);

        if (CollectionUtils.isEmpty(productTopTypeSet)) {
            log.info("memberId{} productTopTypeSet is null 不调用家庭保障分计算接口", memberId);
            return;
        }

        MemberEnsuredCalcCmd calcCmd = new MemberEnsuredCalcCmd();
        calcCmd.setMemberId(memberId);
        calcCmd.setUserId(userId);
        calcCmd.setProdTypeCodes(productTopTypeSet);
        log.info("调用家庭保障分计算接口开始 param:{}", JSONObject.toJSONString(calcCmd));
        memberEnsuredInfoService.calculateEnsuredScore(calcCmd);
        log.info("调用家庭保障分计算接口结束....");
        log.info("updateStatisticsInfoAfterPolicyChanged END..... userId:{}，policy:{}", userId, policy);
    }

    /**
     * 处理数字精度
     * 保留2位小数点，2位后的数字直接舍去
     * 若小数点后均为0，则保留到整数位
     * @param originValue
     * @return
     */
    private String handleDecimalPoint(BigDecimal originValue) {
        originValue = originValue.setScale(2,RoundingMode.HALF_DOWN);
        // stripTrailingZeros()方法：如果有小数，保留 否则去掉小数点和小数
        BigDecimal noZeroValue = originValue.stripTrailingZeros();
        if (noZeroValue.scale() <= 0) {
            return noZeroValue.toPlainString();
        } else {
            return originValue.toPlainString();
        }
    }

    public static void main(String[] args) {
        HmbProductEnum hmbProductEnum = HmbProductEnum.getHmbProductEnumByCodeAndType("GXYLYHB","2");
        //获取投保日期起
        Date insureBeginDate = DateUtil.parseDate(hmbProductEnum.getInsureBeginDate(), DateUtil.datetimePattern);
        //获取投保日期止
        Date insureEndDate = DateUtil.parseDate(hmbProductEnum.getInsureEndDate(), DateUtil.datetimePattern);
        if (DateUtil.compareTime(insureBeginDate, DateUtil.getCurrTime()) == Constants.NEGATIVE_ONE && DateUtil.compareTime(insureEndDate, DateUtil.getCurrTime()) == Constants.ONE) {
            System.out.println("未找到您的玉惠保保单，您需要先去投保");
        } else {
            System.out.println("不能投保");
        }

        System.out.println(IdcardUtil.getBirthByIdCard("420621198912015117"));
        System.out.println(DateUtil.format(IdcardUtil.getBirthDate("420621198912015117"),DateUtil.datePattern));

    }
}
