package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.EnsuredReadConfig;
import com.ekangji.policy.domain.policy.EnsuredWeightConfig;
import com.ekangji.policy.dto.clientobject.policy.EnsuredReadConfigVO;
import com.ekangji.policy.dto.clientobject.policy.EnsuredWeightConfigVO;
import com.ekangji.policy.dto.command.member.EnsuredReadConfigEditCmd;
import com.ekangji.policy.dto.command.member.EnsuredWeightConfigEditCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * CQ-->DTO
 * DTO-->VO
 */
@Mapper(componentModel = "spring")
public interface EnsuredReadConfigCmdConvertor {

    EnsuredReadConfig convert(EnsuredReadConfigEditCmd ensuredWeightConfigEditCmd);

    List<EnsuredReadConfig> convertBatchEditCmd(List<EnsuredReadConfigEditCmd> param);

    List<EnsuredReadConfigVO> convert(List<EnsuredReadConfig> ensuredWeightConfig);
}
