package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.starchain.StarChain;
import com.ekangji.policy.dto.clientobject.star.StarStatisticsVO;
import com.ekangji.policy.dto.clientobject.star.StarVO;
import com.ekangji.policy.dto.command.policy.ChainEditCmd;
import com.ekangji.policy.dto.command.policy.UserStarAddCmd;
import com.ekangji.policy.dto.command.star.UserStarPageQry;
import com.ekangji.policy.dto.command.starchain.StarChainAddCmd;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author zhangjun
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface StarCmdConvertor {

    UserStar convert(StarVO param);

    StarVO convert(UserStar param);

    List<StarVO> convert2VO(List<UserStar> param);

    List<UserStar> convert(List<StarVO> param);

    ChainEditCmd convert(UserStarAddCmd cmd);

    UserStar convert(UserStarPageQry param);

    PageInfo<StarStatisticsVO> convert(PageInfo<UserStar> param);

}
