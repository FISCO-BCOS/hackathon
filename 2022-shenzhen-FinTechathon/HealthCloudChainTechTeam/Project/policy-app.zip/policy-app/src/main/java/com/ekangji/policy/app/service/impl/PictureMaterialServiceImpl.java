package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.api.PictureMaterialService;
import com.ekangji.policy.app.convertor.PictureMaterialCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.EnableOrDisableEnum;
import com.ekangji.policy.common.enums.HasUsedEnum;
import com.ekangji.policy.common.enums.MaterialTypeEnum;
import com.ekangji.policy.domain.gateway.PictureMaterialGateway;
import com.ekangji.policy.domain.policy.PictureMaterial;
import com.ekangji.policy.dto.clientobject.material.PictureMaterialVO;
import com.ekangji.policy.dto.command.material.*;
import com.ekangji.policy.infrastructure.utils.StrUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = PictureMaterialService.class)
public class PictureMaterialServiceImpl implements PictureMaterialService {

    @Resource
    private PictureMaterialGateway pictureMaterialGateway;

    @Resource
    private PictureMaterialCmdConvertor cmdConvertor;

    @Override
    public ApiResult<List<PictureMaterialVO>> queryMaterialList(PictureMaterialQry qry) {
        PictureMaterial pm = PictureMaterial.builder().materialType(qry.getMaterialType()).status(CommonStatusEnum.VALID.getCode()).build();
        List<PictureMaterial> materialList = pictureMaterialGateway.list(pm);
        if (CollectionUtils.isNotEmpty(materialList)) {
            List<PictureMaterialVO> voList = materialList.stream().map(m ->{
                PictureMaterialVO pmvo = new PictureMaterialVO();
                pmvo.setMaterialId(m.getMaterialId());
                pmvo.setCollectionNumber(m.getCollectionNumber());
                pmvo.setFileId(m.getFileId());
                pmvo.setPictureName(m.getPictureName());
                if (m.getUsedNum() >= m.getTotalNum()) {
                    pmvo.setIsAvailable(CommonStatusEnum.INVALID.getCode());
                } else {
                    pmvo.setIsAvailable(CommonStatusEnum.VALID.getCode());
                }
                return pmvo;
            }).collect(Collectors.toList());
            return ApiResult.of(voList);
        }
        return ApiResult.of(Collections.emptyList());
    }

    @Override
    public ApiResult<List<PictureMaterialVO>> queryList(PictureMaterialQry qry) {
        PictureMaterial pm = PictureMaterial.builder().materialType(qry.getMaterialType()).build();
        List<PictureMaterial> materialList = pictureMaterialGateway.list(pm);
        if (CollectionUtils.isEmpty(materialList)){
            return ApiResult.of(Collections.emptyList());
        }
        List<PictureMaterialVO> materialVOList = cmdConvertor.convert(materialList);
        materialVOList.stream().forEach(
                pictureMaterial -> {
                    pictureMaterial.setStatusDesc(EnableOrDisableEnum.getMsgByCode(pictureMaterial.getStatus()));
                }
        );
        return ApiResult.of(materialVOList);
    }

    @Override
    public ApiResult enableOrDisable(PictureMaterialEnableCmd qry) {

        PictureMaterial pictureMaterial = pictureMaterialGateway.get(
                PictureMaterial.builder().materialId(qry.getMaterialId()).build()
        );
        //如果启用，进行逻辑判断
        if (Objects.equals(qry.getStatus(),EnableOrDisableEnum.DISABLE.getCode())){
            //如果没有使用过，不能禁用
            if (Objects.equals(pictureMaterial.getHasUsed(), HasUsedEnum.NOUSED.getCode())){
                return ApiResult.buildFailure("没有使用过，不能禁用");
            }
        }else {
            if (StringUtils.isBlank(pictureMaterial.getCollectionNumber()) ||
                Objects.isNull(pictureMaterial.getTotalNum())){
                return ApiResult.buildFailure("藏品编号或总量不符合规则，请重新填写");
            }
        }

        int update = pictureMaterialGateway.update(
                PictureMaterial.builder()
                        .materialId(qry.getMaterialId())
                        .status(qry.getStatus())
                        .hasUsed(HasUsedEnum.USED.getCode())
                        .build()
        );
        return update>0 ? ApiResult.buildSuccess(): ApiResult.buildFailure();
    }

    @Override
    public ApiResult edit(PictureMaterialEditCmd qry) {
        //如果已经启用，则不允许编辑
        PictureMaterial pictureMaterial = pictureMaterialGateway.get(
                PictureMaterial.builder()
                        .materialId(qry.getMaterialId())
                        .build()
        );
        if (Objects.isNull(pictureMaterial)){
            return ApiResult.buildFailure("数据库不存在该记录");
        }
        if (Objects.equals(pictureMaterial.getHasUsed(),HasUsedEnum.USED.getCode())){
            return ApiResult.buildFailure("启用过的不能编辑");
        }
        try{
            check(qry);
        }catch (Exception e){
            return ApiResult.buildFailure(e.getMessage());
        }

        int update = pictureMaterialGateway.update(
                PictureMaterial.builder()
                        .materialId(qry.getMaterialId())
                        .collectionNumber(qry.getCollectionNumber())
                        .totalNum(qry.getTotalNum())
                        .pictureName(qry.getPictureName())
                        .build()
        );
        return update>0 ? ApiResult.buildSuccess(): ApiResult.buildFailure();
    }

    @Override
    public ApiResult add(PictureMaterialAddCmd cmd) {
        PictureMaterial pictureMaterial = cmdConvertor.convert(cmd);
        //设置默认禁用
        pictureMaterial.setStatus(EnableOrDisableEnum.DISABLE.getCode());
        pictureMaterial.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
        pictureMaterial.setMaterialId(IdUtil.getSnowflakeNextId());
        Long save = pictureMaterialGateway.save(pictureMaterial);
        return save > 0 ? ApiResult.buildSuccess() : ApiResult.buildFailure();
    }


    @Override
    public ApiResult delete(PictureMaterialDeleteCmd cmd) {

        PictureMaterial pictureMaterial = pictureMaterialGateway.get(
                PictureMaterial.builder()
                        .materialId(cmd.getMaterialId())
                        .build()
        );
        if (Objects.nonNull(pictureMaterial)){
            //已经启用过
            if (Objects.equals(pictureMaterial.getHasUsed(),Constants.ONE)) {
                return ApiResult.buildFailure("已经启用过的不能删除");
            }

        }

        //删除
        int update = pictureMaterialGateway.update(
                PictureMaterial.builder()
                        .materialId(cmd.getMaterialId())
                        .delFlag(DeleteFlagEnum.DELETED.getCode())
                        .build()
        );
        return update > 0 ? ApiResult.buildSuccess(): ApiResult.buildFailure();
    }

    /**
     * 检查图片合法性
     * @param qry
     * @return
     */
    private void check(PictureMaterialEditCmd qry){
        PictureMaterial pictureMaterial = pictureMaterialGateway.get(
                PictureMaterial.builder()
                        .materialId(qry.getMaterialId())
                        .build()
        );
        if (Objects.isNull(pictureMaterial)){
            throw new RuntimeException("未找到该记录");
        }
        if (StringUtils.isNotEmpty(qry.getPictureName())) {
            if (StrUtils.length(qry.getPictureName()) > 12) {
                throw new RuntimeException("图片名称不能太长哦！");
            }
            if (StrUtils.isSpecialChar(qry.getPictureName())) {
                throw new RuntimeException("昵称无法修改成功");
            }
        }
        //编号不能重复
        PictureMaterial material = PictureMaterial.builder()
                .materialType(pictureMaterial.getMaterialType())
                .build();
        List<PictureMaterial> pictureMaterials = pictureMaterialGateway.list(material);
        for (PictureMaterial pictureMaterial1 : pictureMaterials){
            if (Objects.equals(pictureMaterial1.getCollectionNumber(),qry.getCollectionNumber())
                    && !Objects.equals(pictureMaterial1.getMaterialId(),qry.getMaterialId())){
                throw new RuntimeException("藏品编号或总量不符合规则，请重新填写");
            }
            if (Objects.equals(pictureMaterial1.getPictureName(),qry.getPictureName())
                    && !Objects.equals(pictureMaterial1.getMaterialId(),qry.getMaterialId())){
                throw new RuntimeException("图片名称已经存在！");
            }
        }

        if (Integer.valueOf(qry.getCollectionNumber()) <= 0
                || Integer.valueOf(qry.getCollectionNumber()) > 10000
                || Integer.valueOf(qry.getTotalNum()) <= 0
                || Integer.valueOf(qry.getTotalNum()) > 1000000){
            throw new RuntimeException("藏品编号或总量不符合规则，请重新填写");
        }
    }
}
