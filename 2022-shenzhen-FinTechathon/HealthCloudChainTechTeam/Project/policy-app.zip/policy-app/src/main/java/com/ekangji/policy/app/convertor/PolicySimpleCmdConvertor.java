package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.PolicySimple;
import com.ekangji.policy.dto.command.policy.PolicySimpleAddCmd;
import org.mapstruct.Mapper;

/**
 * @Author: liuchen
 * @Date: 2022/07/12 16:21
 */
@Mapper(componentModel = "spring")
public interface PolicySimpleCmdConvertor {

    PolicySimple convert(PolicySimpleAddCmd param);
}
