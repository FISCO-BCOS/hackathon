package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.PolicyBeneficiary;
import com.ekangji.policy.dto.command.policy.PolicyBeneficiaryAddCmd;
import org.mapstruct.Mapper;

/**
 * @Author: liuchen
 * @Date: 2022/05/19 16:21
 */
@Mapper(componentModel = "spring")
public interface PolicyBeneficiaryCmdConvertor {

    PolicyBeneficiary convert(PolicyBeneficiaryAddCmd param);
}
