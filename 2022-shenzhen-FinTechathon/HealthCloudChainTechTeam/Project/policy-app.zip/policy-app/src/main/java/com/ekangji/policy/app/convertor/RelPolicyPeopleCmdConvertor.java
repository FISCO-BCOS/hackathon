package com.ekangji.policy.app.convertor;


import com.ekangji.policy.domain.policy.RelPolicyPeople;
import com.ekangji.policy.dto.clientobject.policy.RelPolicyPeopleVO;
import com.ekangji.policy.dto.command.policy.EditRelPolicyPeopleCmd;
import com.ekangji.policy.dto.command.policy.QueryPolicyPeopleCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @Author: wjx
 * @Date: 2022/05/16 16:21
 */
@Mapper(componentModel = "spring")
public interface RelPolicyPeopleCmdConvertor {

    List<RelPolicyPeopleVO> convert(List<RelPolicyPeople> param);

    RelPolicyPeople convert(QueryPolicyPeopleCmd param);

    RelPolicyPeople convert(EditRelPolicyPeopleCmd param);

}
