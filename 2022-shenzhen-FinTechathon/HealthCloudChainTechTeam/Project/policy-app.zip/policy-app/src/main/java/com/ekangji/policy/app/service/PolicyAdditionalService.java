package com.ekangji.policy.app.service;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.dto.clientobject.policy.PolicyAdditionalVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyVO;
import com.ekangji.policy.dto.command.policy.PolicyAddCmd;
import com.ekangji.policy.dto.command.policy.PolicyAdditionalAddCmd;
import com.ekangji.policy.dto.command.policy.PolicyEditCmd;
import com.ekangji.policy.dto.command.policy.PolicyInsurantAddCmd;
import com.ekangji.policy.dto.command.safeguardoverview.OverviewCommonQry;

import java.util.Date;
import java.util.List;

/**
 * @Author: liuchen
 * @Desc: 保单附件险
 * @Date: 2022/05/18 11:05
 */
public interface PolicyAdditionalService {

    /**
     * 添加附加险
     * @param policyId
     * @param cmdList
     */
    void add(Long policyId, List<PolicyAdditionalAddCmd> cmdList);

    /**
     * 添加附加险
     * @param policy
     * @param cmdList
     */
    void add(Policy policy, List<PolicyAdditionalAddCmd> cmdList);

    /**
     * 获取保单附加险
     * @param policy
     * @return
     */
    List<PolicyAdditional> list(Policy policy);

    /**
     * 根据年龄段和险种查询保单记录
     * @param qry
     * @return
     */
    List<PolicyAdditionalVO> queryAddPolicyByAgeBracketAndProdType(OverviewCommonQry qry);

    /**
     * 保单编辑更新附加险
     * @param policyEdit
     * @param cmd
     */
    void edit(Policy policyEdit, PolicyEditCmd cmd) throws Exception;

    /**
     * 补偿产品ID，产品类别的保单数据
     * @return
     */
    ApiResult compensateAdditionalPolicy();

    /**
     * 更新家庭成员各类保险有效保额
     * @return
     */
    ApiResult updateInsuranceAmount();

    /**
     * 更新单个被保人的有效保额
     * @return
     */
    void updateSingleInsuranceAmount(Long insurantId);

    /**
     * 保存备份保单的附加险
     * @param parentPolicyId
     * @param policy
     */
    void addBackup(Long parentPolicyId, Policy policy);
}
