package com.ekangji.policy.app.service.impl;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.bean.BeanUtil;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.BigDecimalUtil;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.policy.app.service.PolicyPayDetailService;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.PayCycleEnum;
import com.ekangji.policy.common.enums.PayPeriodUnitEnum;
import com.ekangji.policy.domain.gateway.PolicyPayDetailGateway;
import com.ekangji.policy.domain.policy.Policy;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.domain.policy.PolicyPayDetail;
import com.ekangji.policy.dto.clientobject.policy.cdetail.PolicyPayCDetailVO;
import com.ekangji.policy.dto.command.policy.PolicyPayLabelEditCmd;
import com.ekangji.policy.infrastructure.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PolicyPayDetailServiceImpl implements PolicyPayDetailService {

    @Resource
    private PolicyPayDetailGateway policyPayDetailGateway;


    /**
     * 主险缴费标签逻辑
     * 缴费周期 1.月缴  2.半年缴 3.年缴 4.一次性交清（无缴费详情）
     * 缴费期间 1.常规期数  2.至**岁
     * @param policy
     */
    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void add(Policy policy) {
        log.info("生成主险缴费标签开始...");
        //计算缴费日期
        List<Date> payDateList = calPayDate(policy,null);
        List<PolicyPayDetail> ppdList = convertData(policy,null,payDateList);
        int num = policyPayDetailGateway.batchSave(ppdList);
        log.info("policyId:{},批量插入主险缴费信息{}条",policy.getPolicyId(),num);

        log.info("生成主险缴费标签结束...");
    }



    /**
     * 附加险缴费标签逻辑
     * 缴费周期 1.月缴  2.半年缴 3.年缴 4.一次性交清（无缴费详情）
     * 缴费期间 1.常规期数  2.至**岁
     * @param policy
     */
    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void add(Policy policy, PolicyAdditional additional) {
        //计算缴费日期
        List<Date> payDateList = calPayDate(policy,additional);

        List<PolicyPayDetail> ppdList = convertData(policy,additional,payDateList);

        int num = policyPayDetailGateway.batchSave(ppdList);
        log.info("policyId:{},additionalId:{},批量插入缴费信息{}条",policy.getPolicyId(),additional.getAdditionalId(),num);
    }

    @Override
    @Transactional(rollbackFor = Exception.class,transactionManager = "policyCenterTransactionManager")
    public void edit(Policy policyEdit, Policy oldPolicy) {
//        Date newBirthday = policyEdit.getInsurant().get(0).getInsurantBirthday();
//        Date oldBirthday = oldPolicy.getInsurant().get(0).getInsurantBirthday();
//
//
//        if (policyEdit.getPayCycle().equals(oldPolicy.getPayCycle())
//                && policyEdit.getPayPeriod().equals(oldPolicy.getPayPeriod())
//                && policyEdit.getPayPeriodUnit().equals(oldPolicy.getPayPeriodUnit())
//                && policyEdit.getSinglePremium().compareTo(oldPolicy.getSinglePremium()) == Constants.ZERO
//                && DateUtil.compareDate(policyEdit.getEffectiveDate(),oldPolicy.getEffectiveDate()) == Constants.ZERO
//                && DateUtil.compareDate(newBirthday,oldBirthday) == Constants.ZERO
//        ) {
//            log.info("policyId:{} 编辑时关键信息未改变不再重新生成缴费信息",policyEdit.getPolicyId());
//            return;
//        }

        if(validatePayLabelLogicIsChanged(policyEdit,oldPolicy)){
            PolicyPayDetail ppd = PolicyPayDetail.builder().policyId(policyEdit.getPolicyId()).build();
            policyPayDetailGateway.delete(ppd);

            List<Date> payDateList = calPayDate(policyEdit,null);
            List<PolicyPayDetail> ppdList = convertData(policyEdit,null,payDateList);
            int num = policyPayDetailGateway.batchSave(ppdList);
            log.info("policyId:{},批量编辑插入主险缴费信息{}条",policyEdit.getPolicyId(),num);
        } else {
            log.info("policyId:{} 编辑时关键信息未改变不再重新生成缴费信息",policyEdit.getPolicyId());
        }
    }

    /**
     * 校验编辑时涉及到缴费标签的字段是否发生了变化
     * @return
     */
    private boolean validatePayLabelLogicIsChanged(Policy policyEdit, Policy oldPolicy) {
        if(!policyEdit.getPayCycle().equals(oldPolicy.getPayCycle())) {
            return true;
        }

        if(policyEdit.getSinglePremium().compareTo(oldPolicy.getSinglePremium()) != Constants.ZERO) {
            return true;
        }

        if(DateUtil.compareDate(policyEdit.getEffectiveDate(),oldPolicy.getEffectiveDate()) != Constants.ZERO){
           String newLabel = DateUtil.getDateLabel(policyEdit.getEffectiveDate(),1);
           String oldLabel = DateUtil.getDateLabel(oldPolicy.getEffectiveDate(),1);
           if (!newLabel.equals(oldLabel)) {
               return true;
           }
        }

        Integer newPayPeriod = Objects.isNull(policyEdit.getPayPeriod())?0:policyEdit.getPayPeriod();
        Integer oldPayPeriod = Objects.isNull(oldPolicy.getPayPeriod())?0:oldPolicy.getPayPeriod();
        if (!newPayPeriod.equals(oldPayPeriod)) {
            return true;
        }

        Integer newPayPeriodUnit = Objects.isNull(policyEdit.getPayPeriodUnit())?0:policyEdit.getPayPeriodUnit();
        Integer oldPayPeriodUnit = Objects.isNull(oldPolicy.getPayPeriodUnit())?0:oldPolicy.getPayPeriodUnit();
        if (!newPayPeriodUnit.equals(oldPayPeriodUnit)) {
            return true;
        }
        return false;
    }

    @Override
    public int deleteByPolicyAdditional(PolicyPayDetail payDetail) {
        return policyPayDetailGateway.deleteByPolicyAdditional(payDetail);
    }

    @Override
    public PolicyPayDetail findCurrentYearPremiumByPolicy(Policy policy) {
//        PolicyPayDetail policyPayDetail = new PolicyPayDetail();
//        String year = DateUtil.getDateLabel(DateUtil.getCurrDate(),3);
//        policyPayDetail.setPolicyId(policy.getPolicyId());
//        policyPayDetail.setPayLabel(year);
//        return policyPayDetailGateway.findCurrentYearPremiumByPolicy(policyPayDetail);
        return null;
    }

    @Override
    public PolicyPayDetail findCurrentYearPremiumByPolicy(List<Policy> policyList) {
        List<Long> policyIdList = policyList.stream().map(Policy::getPolicyId).collect(Collectors.toList());
        PolicyPayDetail policyPayDetail = new PolicyPayDetail();
        String year = getDateLabel(DateUtil.getCurrDate(),3);
        policyPayDetail.setPolicyIdList(policyIdList);
        policyPayDetail.setPayLabel(year+"%");
        return policyPayDetailGateway.findCurrentYearPremiumByPolicy(policyPayDetail);
    }

    @Override
    public PolicyPayCDetailVO findPayDetailByPolicy(Policy policy) {
        PolicyPayCDetailVO vo = new PolicyPayCDetailVO();
        PolicyPayDetail query = PolicyPayDetail.builder().policyId(policy.getPolicyId()).build();
        PolicyPayDetail policyPayDetail = policyPayDetailGateway.findTotalPremiumByPolicy(query);
        List<PolicyPayDetail> policyPayDetailList = policyPayDetailGateway.listByPolicy(query);
        int paidTimes = 0;
        int unPaidTimes = 0;
        Date lastPayDate = null;
        Date lastUnPayDate = null;
        List<PolicyPayCDetailVO.PayLabelDetail> labelDetailList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(policyPayDetailList)) {
             for (PolicyPayDetail tmp : policyPayDetailList){
                 PolicyPayCDetailVO.PayLabelDetail payLabelDetail = new PolicyPayCDetailVO.PayLabelDetail();
                 BeanUtil.copyProperties(tmp,payLabelDetail);
                 labelDetailList.add(payLabelDetail);
                 if (tmp.getStatus().intValue() == Constants.ONE) {
                     paidTimes++;
                 } else {
                     unPaidTimes++;
                     if (Objects.isNull(lastUnPayDate)) { //最近一次未缴费的日期
                         lastUnPayDate = tmp.getPayDate();
                     }
                 }
                 lastPayDate = tmp.getPayDate();
             }
        }
        vo.setPaidTimes(paidTimes);
        vo.setUnPaidTimes(unPaidTimes);
        vo.setPayLabelList(labelDetailList);
        vo.setPayDate(lastUnPayDate);

        //获取最近一次应缴未缴的保费 若已交清取最后一次
        PolicyPayDetail premiumDetail = new PolicyPayDetail();
        premiumDetail.setPolicyId(policy.getPolicyId());
        if (Objects.isNull(lastUnPayDate)){
            premiumDetail.setPayDate(lastPayDate);
        } else {
            premiumDetail.setPayDate(lastUnPayDate);
        }

        PolicyPayDetail premiumPayDetail = policyPayDetailGateway.findTotalPremiumByPolicy(premiumDetail);
        vo.setPerPremium(premiumPayDetail.getPremium());

        //处理总保费金额
        if (Objects.nonNull(policyPayDetail.getPremium())){
            BigDecimal totalPremium = policyPayDetail.getPremium().setScale(2, RoundingMode.HALF_DOWN);
            BigDecimal noZeroTotalPremium = totalPremium.stripTrailingZeros();
            if(noZeroTotalPremium.scale()<=0){
                vo.setTotalPremium(noZeroTotalPremium);
            }else{
                vo.setTotalPremium(totalPremium);
            }
        } else {
            vo.setTotalPremium(BigDecimal.ZERO);
        }

        return vo;
    }

    @Override
    public ApiResult updatePayLabelStatus(PolicyPayLabelEditCmd cmd) {
        if (cmd.getStatus() != Constants.ONE && cmd.getStatus() != Constants.ZERO) {
            return ApiResult.buildFailure("状态参数有误");
        }
        PolicyPayDetail queryParam = PolicyPayDetail.builder().payLabelId(cmd.getPayLabelId()).build();
        PolicyPayDetail payDetail = policyPayDetailGateway.get(queryParam);
        if (Objects.isNull(payDetail)) {
            return ApiResult.buildFailure("缴费标签不存在");
        }

        if (cmd.getStatus().equals(payDetail.getStatus())) {
            return ApiResult.buildSuccess("缴费状态更新成功");
        }
        payDetail.setStatus(cmd.getStatus());
//        PolicyPayDetail updatePayDetail = PolicyPayDetail.builder().policyId(payDetail.getPolicyId())
//                .payLabel(payDetail.getPayLabel()).status(cmd.getStatus()).build();
        int flagNum = policyPayDetailGateway.updateLabelStatus(payDetail);
        if(flagNum <= Constants.ZERO) {
            return ApiResult.buildFailure("缴费状态更新失败");
        }

        return ApiResult.buildSuccess();
    }

    @Override
    public void addBackup(Long parentPolicyId, Long newPolicyId, Long additionalId) {
        log.info("备份缴费标签开始,parentPolicyId:{},newPolicyId:{},oldAdditionalId:{}",parentPolicyId,newPolicyId,additionalId);
        PolicyPayDetail policyPayDetail = PolicyPayDetail.builder().policyId(parentPolicyId).build();
        if (Objects.nonNull(additionalId)) {
            policyPayDetail.setAdditionalId(additionalId);
        }
        List<PolicyPayDetail> payDetailList = policyPayDetailGateway.listByPolicy(policyPayDetail);
        if (CollectionUtils.isEmpty(payDetailList)) {
            log.info("parentPolicyId:{},newPolicyId:{},无缴费标签可备份",parentPolicyId,newPolicyId);
            return;
        }
        for (PolicyPayDetail payDetail : payDetailList) {
            payDetail.setPayLabelId(IdUtil.getSnowflakeNextId());
            payDetail.setPolicyId(newPolicyId);
            payDetail.setAdditionalId(additionalId);
            Date date = new Date();
            payDetail.setCreateTime(date);
            payDetail.setUpdateTime(date);
        }
        policyPayDetailGateway.batchSave(payDetailList);
        log.info("备份缴费标签结束,parentPolicyId:{},newPolicyId:{},additionalId:{}",parentPolicyId,newPolicyId,additionalId);
    }

    /**
     * 计算缴费时间
     * @param policy
     * @return
     */
    private List<Date> calPayDate(Policy policy,PolicyAdditional additional){
        Integer payCycle = policy.getPayCycle();
        List<Date> payDateList = new ArrayList<>();
        if(PayCycleEnum.LUMPSUMPAYMENT.getCode().equals(payCycle)) { //一次性缴费
            payDateList.add(policy.getEffectiveDate());
            return payDateList;
        }

        Integer payPeriod = policy.getPayPeriod();
        Integer payPeriodUnit = policy.getPayPeriodUnit();
        Date effectiveDate = policy.getEffectiveDate();
        if (Objects.nonNull(additional)) {
            payPeriod = additional.getPayPeriod();
            payPeriodUnit = additional.getPayPeriodUnit();
        }

        Date insurantBirthday = policy.getInsurant().get(0).getInsurantBirthday();
        if (Objects.isNull(insurantBirthday)) {
            insurantBirthday = policy.getBirthDay();
        }

        Date endDate = null; //缴费结束时间
        int dimension = 1; //跨度
        if (PayPeriodUnitEnum.ENDAGE.getCode().equals(payPeriodUnit)) { //缴费期间单位为至**岁
            Date birthDayEnd = DateUtil.addYears(insurantBirthday,payPeriod);
            endDate = DateUtil.compareMonthDayDate(effectiveDate,birthDayEnd);
            if (PayCycleEnum.SEMIANNUALPAYMENT.getCode().equals(payCycle)) { //缴费周期为半年
                dimension = 6;
            }
        } else {
            if (PayCycleEnum.MONTHLYPAYMENT.getCode().equals(payCycle)) { //缴费周期月缴
                //计算出最后一次缴费时间
                endDate = DateUtil.addMonths(effectiveDate,payPeriod - Constants.ONE);
            } else if (PayCycleEnum.SEMIANNUALPAYMENT.getCode().equals(payCycle)) { //缴费周期半年缴
                endDate =  DateUtil.addMonths(effectiveDate,(payPeriod - Constants.ONE)*6);
                dimension = 6;
            } else if (PayCycleEnum.ANNUALPAYMENT.getCode().equals(payCycle)) { //缴费周期年缴
                endDate = DateUtil.addYears(effectiveDate,payPeriod - Constants.ONE);
            }
        }
        return DateUtil.getDateList(effectiveDate,endDate,payCycle,dimension);
    }

    /**
     * 批量保存缴费详情
     * @param policy
     * @param additional
     * @param payDateList
     */
//    private void batchSave(Policy policy,PolicyAdditional additional,List<Date> payDateList) {
//        List<PolicyPayDetail> ppdList = payDateList.parallelStream().map(d ->{
//            PolicyPayDetail ppd =  new PolicyPayDetail();
//            ppd.setPayLabelId(IdUtil.getSnowflakeNextId());
//            ppd.setPolicyId(policy.getPolicyId());
//            ppd.setPayLabel(DateUtil.getDateLabel(d,policy.getPayCycle()));
//            ppd.setPayDate(d);
//            if (DateUtil.compareDate(d,new Date()) < Constants.ONE) {
//                ppd.setStatus(CommonStatusEnum.VALID.getCode());
//            } else {
//                ppd.setStatus(CommonStatusEnum.INVALID.getCode());
//            }
//            if (Objects.nonNull(additional)) {
//                ppd.setAdditionalId(additional.getAdditionalId());
//                ppd.setSinglePremium(additional.getSinglePremium());
//            } else {
//                ppd.setSinglePremium(policy.getSinglePremium());
//            }
//            return ppd;
//        }).collect(Collectors.toList());
//
//        int num = policyPayDetailGateway.batchSave(ppdList);
//        log.info("policyId:{},additionalId:{},批量插入缴费信息{}条",policy.getPolicyId(),additional == null?"无":additional.getAdditionalId(),num);
//    }

    /**
     * 转化缴费详情
     * @param policy
     * @param additional
     * @param payDateList
     * @return
     */
    private List<PolicyPayDetail> convertData(Policy policy,PolicyAdditional additional,List<Date> payDateList) {
        List<PolicyPayDetail> ppdList = payDateList.parallelStream().map(d ->{
            PolicyPayDetail ppd =  new PolicyPayDetail();
            ppd.setPayLabelId(IdUtil.getSnowflakeNextId());
            ppd.setPolicyId(policy.getPolicyId());
            ppd.setPayLabel(getDateLabel(d,policy.getPayCycle()));
            ppd.setPayDate(d);
            if (DateUtil.compareDate(d,new Date()) < Constants.ONE) {
                ppd.setStatus(CommonStatusEnum.VALID.getCode());
            } else {
                ppd.setStatus(CommonStatusEnum.INVALID.getCode());
            }
            if (Objects.nonNull(additional)) {
                ppd.setAdditionalId(additional.getAdditionalId());
                ppd.setSinglePremium(additional.getSinglePremium());
            } else {
                ppd.setSinglePremium(policy.getSinglePremium());
            }
            return ppd;
        }).collect(Collectors.toList());
        return ppdList;
    }

    /**
     * 获取缴费标签
     * @param labelDate
     * @param type
     * @return
     */
    private String getDateLabel(Date labelDate,Integer type){
        if (PayCycleEnum.ANNUALPAYMENT.getCode().equals(type)) {
            return DateUtil.convertDate2String(DateUtil.datePattern_yyyy,labelDate);
        } else if (PayCycleEnum.MONTHLYPAYMENT.getCode().equals(type) || PayCycleEnum.SEMIANNUALPAYMENT.getCode().equals(type)) {
            return DateUtil.convertDate2String(DateUtil.datePattern_yyyyMM,labelDate);
        } else {
            return DateUtil.convertDate2String(DateUtil.datePattern,labelDate);
        }
    }
}
