
package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.schedulerx.shade.org.apache.commons.lang.StringEscapeUtils;
import com.ekangji.ability.api.CloudChainService;
import com.ekangji.ability.dto.clientobject.CloudChainVO;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.enums.CommonStatusEnum;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.file.center.client.api.FileCenterService;
import com.ekangji.marketing.client.api.IntegralDetailRuleService;
import com.ekangji.marketing.client.api.UserIntegralDetailService;
import com.ekangji.marketing.client.api.UserIntegralService;
import com.ekangji.marketing.client.dto.clientobject.IntegralDetailRuleVO;
import com.ekangji.marketing.client.dto.command.userIntegral.UserIntegralDetailInsertCmd;
import com.ekangji.marketing.client.dto.command.userIntegral.UserIntegralInsertCmd;
import com.ekangji.policy.api.ExecuteChainService;
import com.ekangji.policy.api.RelStarChainService;
import com.ekangji.policy.api.StarChainService;
import com.ekangji.policy.app.convertor.DigitalPolicyCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.MaterialTypeEnum;
import com.ekangji.policy.common.enums.PictureSerialEnum;
import com.ekangji.policy.common.enums.UserIntegralRuleTypeEnum;
import com.ekangji.policy.domain.gateway.DigitalPolicyGateway;
import com.ekangji.policy.domain.gateway.PictureMaterialGateway;
import com.ekangji.policy.domain.gateway.UserStarGateway;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.PictureMaterial;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.command.policy.ChainEditCmd;
import com.ekangji.policy.dto.command.starchain.RelStarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.StarChainAddCmd;
import com.ekangji.policy.infrastructure.utils.MathUtil;
import com.ekangji.policy.infrastructure.utils.StrUtils;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.api.UserThirdMappingService;
import com.ekangji.user.center.client.dto.clientobject.UserThirdMappingVO;
import com.ekangji.user.center.client.dto.command.UserThirdMappingAddCmd;
import com.ekangji.user.center.client.dto.command.UserThirdMappingQry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

import static com.ekangji.policy.common.constant.Constants.*;

@Slf4j
@Service
public class ExecuteChainServiceImpl implements ExecuteChainService {

    @Resource
    private CloudChainService cloudChainService;
    @Resource
    private UserThirdMappingService userThirdMappingService;
    @Resource
    private PictureMaterialGateway pictureMaterialGateway;
    @Resource
    private DigitalPolicyGateway digitalPolicyGateway;
    @Resource
    private UserChannelInfoService userChannelInfoService;
    @Resource
    private FileCenterService fileCenterService;
    @Resource
    private DigitalPolicyCmdConvertor digitalPolicyCmdConvertor;
    @Resource
    private UserStarGateway userStarGateway;
    @Resource
    private StarChainService starChainService;
    @Resource
    private RelStarChainService relStarChainService;
    @Resource
    private IntegralDetailRuleService integralDetailRuleService;
    @Resource
    private UserIntegralDetailService userIntegralDetailService;
    @Resource
    private UserIntegralService userIntegralService;

    /**
     * 数字保单或星球上链
     * step：
     * 1、从相关素材图片库中取到对应上链的图片
     * 2、当前用户有没有映射区块链账户
     * 3、没有映射则映射，映射过则调用云链api上链
     * 4、上链完后 保存对应的星球表或者数字保单表
     *
     * @param
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class, transactionManager = "policyCenterTransactionManager")
    public ApiResult chainGateWay(ChainEditCmd chainEditCmd, MaterialTypeEnum materialTypeEnum) {
        log.info("-------------chainGateWay start,userId:{},materialTypeEnum:{}-----------",chainEditCmd.getUserId(),materialTypeEnum.getMsg());
        UserThirdMappingQry userThirdMappingQry = new UserThirdMappingQry();
        if (StringUtils.isBlank(chainEditCmd.getUserId())) {
            return ApiResult.buildFailure("无效用户");
        }
        userThirdMappingQry.setUserId(chainEditCmd.getUserId());
        PictureMaterial pictureMaterial = PictureMaterial.builder().materialType(materialTypeEnum.getCode()).status(CommonStatusEnum.VALID.getCode()).build();
        List<PictureMaterial> list = pictureMaterialGateway.list(pictureMaterial);
        log.info("chainGateWay pictureMaterial list size:{}",list.size());

        if (CollectionUtils.isEmpty(list)) {
            return ApiResult.buildFailure("没找到图片库");
        }
        PictureMaterial entity;
        if (materialTypeEnum == MaterialTypeEnum.STAR_PIC) {
            if (Objects.isNull(chainEditCmd.getMaterialId())) {
                return ApiResult.buildFailure("请传入星球图片id");
            }
            UserStar query=UserStar.builder().userId(chainEditCmd.getUserId()).build();
            UserStar userStar = userStarGateway.get(query);
            if (Objects.nonNull(userStar)) {
                return ApiResult.buildFailure("该用户已领取过星球");
            }
            PictureMaterial pictureMaterial1 = PictureMaterial.builder().materialId(chainEditCmd.getMaterialId()).build();
            entity = pictureMaterialGateway.get(pictureMaterial1);
            log.info("chainGateWay star pictureMaterial entity:{}",JSONObject.toJSONString(entity));

        } else {
            if (StringUtils.isNotEmpty(chainEditCmd.getMediaContent()) && chainEditCmd.getMediaContent().length() > 140) {
                return ApiResult.buildFailure("文字不能超过140个字符");
            }
            if (StringUtils.isNotEmpty(chainEditCmd.getMediaFileIds())) {
                String[] split = chainEditCmd.getMediaFileIds().split(",");
                if (split.length > Constants.THREE) {
                    return ApiResult.buildFailure("上传图片不能超过" + Constants.THREE + "张");
                }
            }
            //找到当前用户下所有的数字保单 先过滤掉
            DigitalPolicy digitalPolicy = DigitalPolicy.builder().userId(chainEditCmd.getUserId()).build();
            List<DigitalPolicy> policyList = digitalPolicyGateway.list(digitalPolicy);
            List<String> fileIds = policyList.stream().map(DigitalPolicy::getFileId).collect(Collectors.toList());
            log.info("chainGateWay digital fileIds:{}",JSONObject.toJSONString(fileIds));

            list.removeIf(x -> fileIds.contains(x.getFileId()));
            if (CollectionUtils.isEmpty(list)) {
                list = pictureMaterialGateway.list(pictureMaterial);
            }
            entity = list.get(new Random().nextInt(list.size()));
            log.info("chainGateWay digital pictureMaterial entity:{}",JSONObject.toJSONString(entity));

        }
        if (Objects.isNull(entity)
                || StringUtils.isBlank(entity.getFileId())) {
            return ApiResult.buildFailure("图片库文件未上传");
        }

        ApiResult<String> result = fileCenterService.queryFileUrl(entity.getFileId());
        if (!result.getSuccess()) {
            return ApiResult.buildFailure("无效的图片库文件id");
        }
        log.info("chainGateWay selectUserMappingByUserId start:{}",JSONObject.toJSONString(userThirdMappingQry));

        ApiResult<UserThirdMappingVO> userThirdMappingVOApiResult = userThirdMappingService.selectUserMappingByUserId(userThirdMappingQry);

        log.info("chainGateWay selectUserMappingByUserId end:{}",JSONObject.toJSONString(userThirdMappingVOApiResult));

        CloudChainVO upChainResponse = null;
        if (userThirdMappingVOApiResult.getSuccess() && Objects.nonNull(userThirdMappingVOApiResult.getData())) {
            log.info("chainGateWay upChain start:{}",JSONObject.toJSONString(userThirdMappingVOApiResult.getData()));
            ApiResult<CloudChainVO> stringApiResult = cloudChainService.upChain(userThirdMappingVOApiResult.getData().getThirdAccount(), result.getData());
            log.info("chainGateWay upChain end:{}",JSONObject.toJSONString(stringApiResult.getData()));

            if (stringApiResult.getSuccess()) {
                upChainResponse = stringApiResult.getData();
            } else {
                log.info("buildDigitalPolicy upChain no data");
            }
        } else {
            ApiResult<String> chainAccount = cloudChainService.getChainAccount();
            if (chainAccount.getSuccess()) {
                UserThirdMappingAddCmd userThirdMappingAddCmd = new UserThirdMappingAddCmd();
                userThirdMappingAddCmd.setUserId(chainEditCmd.getUserId());
                userThirdMappingAddCmd.setThirdAccount(chainAccount.getData());
                userThirdMappingService.add(userThirdMappingAddCmd);
                ApiResult<CloudChainVO> stringApiResult = cloudChainService.upChain(chainAccount.getData(), result.getData());
                if (stringApiResult.getSuccess()) {
                    upChainResponse = stringApiResult.getData();
                } else {
                    log.info("buildDigitalPolicy upChain no data");
                }
            } else {
                log.info("buildDigitalPolicy getChainAccount no data");
            }
        }
        if (Objects.isNull(upChainResponse)) {
            return ApiResult.buildFailure("上链失败");
        }
        String phoneNumber = Strings.EMPTY;
        log.info("chainGateWay userChannelInfoService start:{}",chainEditCmd.getUserId());

        ApiResult<String> phone = userChannelInfoService.getPhoneNumberByUserId(chainEditCmd.getUserId());
        log.info("chainGateWay userChannelInfoService end:{}",phone.getData());

        if (phone.getSuccess()) {
            phoneNumber = phone.getData();
        }
        entity.setUsedNum(entity.getUsedNum() + 1);
        if (entity.getUsedNum() > entity.getTotalNum()) {
            return ApiResult.buildFailure("此星球已被抢空，请选择其他星球");
        }
        pictureMaterialGateway.updateById(entity);

        log.info("chainGateWay after entity:{}",JSONObject.toJSONString(entity));

        int diff = MathUtil.getNumLength(entity.getTotalNum()) - MathUtil.getNumLength(entity.getUsedNum());
        StringBuilder numBuilder = new StringBuilder();
        for (int i = 0; i < diff; i++) {
            numBuilder.append(Constants.ZERO);
        }
        String prefix = materialTypeEnum == MaterialTypeEnum.STAR_PIC ? PictureSerialEnum.STAR.getCode() : PictureSerialEnum.DIGITAL.getCode();
        //根据规则 生成数字保单的编号
        String stringBuilder = prefix +
                entity.getCollectionNumber() +
                "#" +
                numBuilder.toString() + entity.getUsedNum() +
                "/" +
                entity.getTotalNum();
        log.info("chainGateWay stringBuilder:{}",stringBuilder);

        List<IntegralDetailRuleVO> integralDetailRules = integralDetailRuleService.queryCurList();
        if (materialTypeEnum == MaterialTypeEnum.STAR_PIC) {
            UserStar userStar = UserStar.builder()
                    .starId(IdUtil.getSnowflakeNextId())
                    .userId(chainEditCmd.getUserId())
                    .nickName(chainEditCmd.getNickName())
                    .pictureUrl(upChainResponse.getBody().getIcfsCatUrl())
                    .chainAddr(upChainResponse.getBody().getTransactionHash())
                    .userPhone(phoneNumber)
                    .fileId(entity.getFileId())
                    .sequence(stringBuilder)
                    .build();

            long l = userStarGateway.save(userStar);
            //生成星链
            StarChainAddCmd starChainAddCmd = StarChainAddCmd.builder().userId(chainEditCmd.getUserId()).build();
            ApiResult<Long> chainResult = starChainService.add(starChainAddCmd);
            if (chainResult.getSuccess()) {
                RelStarChainAddCmd relStarChainAddCmd = RelStarChainAddCmd.builder().chainId(chainResult.getData()).starId(userStar.getStarId()).build();
                relStarChainService.add(relStarChainAddCmd);
            }
            integralDetailRules = integralDetailRules.stream().filter(item ->item.getUseStatus().equals(Constants.ONE)
                            && item.getName().equals(UserIntegralRuleTypeEnum.GET_STAR.getMsg()))
                    .collect(Collectors.toList());
            log.info("chainGateWay star integralDetailRules:{}",JSONObject.toJSONString(integralDetailRules));

            if (CollectionUtils.isNotEmpty(integralDetailRules)) {
                UserIntegralDetailInsertCmd build = UserIntegralDetailInsertCmd.builder()
                        .userId(chainEditCmd.getUserId())
                        .amount(integralDetailRules.get(ZERO).getAmount() )
                        .type(ONE)
                        .source(UserIntegralRuleTypeEnum.GET_STAR.getMsg())
                        .integralDetailId(integralDetailRules.get(Constants.ZERO).getId().intValue())
                        .build();
                userIntegralDetailService.addUserIntegralDetailDmc(build);
                UserIntegralInsertCmd userIntegralInsertCmd=UserIntegralInsertCmd.builder()
                        .userId(chainEditCmd.getUserId())
                        .amount(integralDetailRules.get(Constants.ZERO).getAmount()).build();
                userIntegralService.insertUserIntegralByUserId(userIntegralInsertCmd);
            }
            return ApiResult.of(userStar.getStarId().toString());
        } else {
            DigitalPolicy digitalPolicy = DigitalPolicy.builder()
                    .digitalId(IdUtil.getSnowflakeNextId())
                    .userId(chainEditCmd.getUserId())
                    .policyId(chainEditCmd.getPolicyId())
                    .productName(chainEditCmd.getProductName())
                    .fileId(entity.getFileId())
                    .pictureUrl(upChainResponse.getBody().getIcfsCatUrl())
                    .chainAddr(upChainResponse.getBody().getTransactionHash())
                    .phoneNumber(phoneNumber)
                    .sequence(stringBuilder)
                    .mediaContent(chainEditCmd.getMediaContent())
                    .mediaImage(chainEditCmd.getMediaFileIds())
                    .build();
            digitalPolicyGateway.save(digitalPolicy);
            digitalPolicy.setDelFlag(DeleteFlagEnum.NORMAL.getCode());
            DigitalPolicy afterEntity = digitalPolicyGateway.get(digitalPolicy);
            DigitalPolicyVO digitalPolicyVO = digitalPolicyCmdConvertor.convert(afterEntity);
            integralDetailRules = integralDetailRules.stream().filter(item ->item.getUseStatus().equals(Constants.ONE)
                            &&  item.getName().equals(UserIntegralRuleTypeEnum.UPLOAD_INSURANCE_POLICY.getMsg()))
                    .collect(Collectors.toList());
            log.info("chainGateWay digital integralDetailRules:{}",JSONObject.toJSONString(integralDetailRules));

            if (CollectionUtils.isNotEmpty(integralDetailRules)) {
                UserIntegralDetailInsertCmd build = UserIntegralDetailInsertCmd.builder()
                        .userId(chainEditCmd.getUserId())
                        .amount(integralDetailRules.get(Constants.ZERO).getAmount())
                        .type(ONE)
                        .source(UserIntegralRuleTypeEnum.UPLOAD_INSURANCE_POLICY.getMsg())
                        .integralDetailId(integralDetailRules.get(Constants.ZERO).getId().intValue())
                        .build();
                userIntegralDetailService.addUserIntegralDetailDmc(build);
                UserIntegralInsertCmd userIntegralInsertCmd=UserIntegralInsertCmd.builder()
                        .userId(chainEditCmd.getUserId())
                        .amount(integralDetailRules.get(Constants.ZERO).getAmount()).build();
                userIntegralService.insertUserIntegralByUserId(userIntegralInsertCmd);
                digitalPolicyVO.setToastMsg("恭喜您获得" + integralDetailRules.get(Constants.ZERO).getAmount() + "保豆!继续上传保单可获取更多!");
            }
            return ApiResult.of(digitalPolicyVO);
        }

    }

}
