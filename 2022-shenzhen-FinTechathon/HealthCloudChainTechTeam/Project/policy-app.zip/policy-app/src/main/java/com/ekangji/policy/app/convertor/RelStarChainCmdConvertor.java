package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.starchain.RelStarChain;
import com.ekangji.policy.dto.clientobject.starchain.RelStarChainVO;
import com.ekangji.policy.dto.command.starchain.RelStarChainAddCmd;
import com.ekangji.policy.dto.command.starchain.RelStarChainQry;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author xintao.li
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface RelStarChainCmdConvertor {

    RelStarChain convert(RelStarChainAddCmd param);

    RelStarChain convert(RelStarChainQry param);

    List<RelStarChainVO> convert(List<RelStarChain> param);

}
