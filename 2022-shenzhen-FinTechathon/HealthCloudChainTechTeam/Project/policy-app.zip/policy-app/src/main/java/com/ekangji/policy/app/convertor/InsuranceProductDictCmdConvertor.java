package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.insurance.InsuranceProductDict;
import com.ekangji.policy.dto.clientobject.insurance.InsuranceProductDictVO;
import com.ekangji.policy.dto.command.insurance.InsuranceProductDictCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 * @author wjx
 * @date 2021/11/28 14:00
 */
@Mapper(componentModel = "spring")
public interface InsuranceProductDictCmdConvertor {

    InsuranceProductDict convert(InsuranceProductDictCmd param);

    List<InsuranceProductDictVO> convert(List<InsuranceProductDict> param);

}
