package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.dto.clientobject.policy.PolicyAdditionalVO;
import com.ekangji.policy.dto.command.policy.PolicyAdditionalAddCmd;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @Author: liuchen
 * @Date: 2022/05/19 16:21
 */
@Mapper(componentModel = "spring")
public interface PolicyAdditionalCmdConvertor {

    PolicyAdditional convert(PolicyAdditionalAddCmd param);

    List<PolicyAdditionalVO> convert(List<PolicyAdditional> param);
}
