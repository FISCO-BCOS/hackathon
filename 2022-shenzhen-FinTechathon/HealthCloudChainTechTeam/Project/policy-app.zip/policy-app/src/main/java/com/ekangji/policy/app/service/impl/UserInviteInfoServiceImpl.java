

package com.ekangji.policy.app.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ekangji.ability.api.CloudChainService;
import com.ekangji.ability.dto.clientobject.CloudChainVO;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.common.tool.util.DesensitizedUtil;
import com.ekangji.common.tool.util.IdUtil;
import com.ekangji.file.center.client.api.FileCenterService;
import com.ekangji.file.center.client.clientobject.FileInfoVO;
import com.ekangji.file.center.client.command.FileQry;
import com.ekangji.marketing.client.api.UserDrawContentService;
import com.ekangji.marketing.client.api.UserDrawInfoService;
import com.ekangji.marketing.client.dto.clientobject.UserDrawContentVO;
import com.ekangji.marketing.client.dto.command.userdraw.UserDrawInfoCmd;
import com.ekangji.marketing.common.enums.ActivityEnum;
import com.ekangji.policy.api.DigitalPolicyService;
import com.ekangji.policy.api.UserInviteInfoService;
import com.ekangji.policy.app.convertor.DigitalPolicyCmdConvertor;
import com.ekangji.policy.app.convertor.UserInviteCmdConvertor;
import com.ekangji.policy.common.constant.Constants;
import com.ekangji.policy.common.enums.DeleteFlagEnum;
import com.ekangji.policy.common.enums.YESORNOEnum;
import com.ekangji.policy.domain.gateway.*;
import com.ekangji.policy.domain.policy.DigitalPolicy;
import com.ekangji.policy.domain.policy.PolicySimple;
import com.ekangji.policy.domain.policy.UserInviteInfo;
import com.ekangji.policy.domain.policy.UserStar;
import com.ekangji.policy.domain.policy.pojo.DigitalPolicyDTO;
import com.ekangji.policy.dto.clientobject.policy.DigitalPolicyVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteDetailVO;
import com.ekangji.policy.dto.clientobject.policy.UserInviteVO;
import com.ekangji.policy.dto.command.policy.*;
import com.ekangji.user.center.client.api.UserChannelInfoService;
import com.ekangji.user.center.client.api.UserThirdMappingService;
import com.ekangji.user.center.client.dto.clientobject.UserChannelInfoVO;
import com.ekangji.user.center.client.dto.clientobject.UserThirdMappingVO;
import com.ekangji.user.center.client.dto.command.UserThirdMappingAddCmd;
import com.ekangji.user.center.client.dto.command.UserThirdMappingQry;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.ekangji.policy.common.constant.Constants.*;

@Slf4j
@Service
@DubboService(version = "${policy-center.service.version}", interfaceClass = UserInviteInfoService.class)
public class UserInviteInfoServiceImpl implements UserInviteInfoService {
    @Resource
    private UserChannelInfoService userChannelInfoService;
    @Resource
    private UserInviteInfoGateway userInviteInfoGateway;
    @Resource
    private UserInviteCmdConvertor userInviteCmdConvertor;
    @Resource
    private UserDrawContentService userDrawContentService;
    @Resource
    private DigitalPolicyGateway digitalPolicyGateway;
    @Override
    public ApiResult<PageInfo<UserInviteDetailVO>> queryInviteList(UserInviteQry qry) {
        UserInviteInfo userInviteInfo = userInviteCmdConvertor.convert(qry);
        PageInfo<UserInviteInfo> page = userInviteInfoGateway.page(userInviteInfo);
        PageInfo<UserInviteDetailVO> convert = userInviteCmdConvertor.convert(page);
        convert.getList().forEach(x -> {
            //根据用户id获取昵称
            ApiResult<UserChannelInfoVO> user = userChannelInfoService.getUserChannelInfoByUserId(x.getInviteeUserId());
            if (user.getSuccess()
                    && Objects.nonNull(user.getData())) {
                x.setWechatName(user.getData().getNickname());
            }
        });

        return ApiResult.of(convert);
    }

    @Override
    public ApiResult<UserInviteVO> queryInviteInfo(UserInviteQry qry) {
        UserInviteVO userInviteVO = UserInviteVO.builder().build();
        List<UserInviteInfo> userInviteInfos = userInviteInfoGateway.selectListByInviterId(qry.getInviterUserId());
        long count = userInviteInfos.stream().filter(s -> s.getPolicyStatus().equals(ONE)).count();
        userInviteVO.setInviteCount(userInviteInfos.size());
        userInviteVO.setDrawCount(count);
        ApiResult<UserDrawContentVO> userDrawContent = userDrawContentService.getUserDrawContent();
        if (userDrawContent.getSuccess()
                && Objects.nonNull(userDrawContent.getData())) {
            userInviteVO.setRuleContent(userDrawContent.getData().getRule());
            userInviteVO.setRuleTitle(userDrawContent.getData().getTitle());
        }
        return ApiResult.of(userInviteVO);
    }

    @Override
    public ApiResult<Long> AddInviteRelation(InviteAddCmd cmd) {
        log.info("AddInviteRelation cmd:{}",JSONObject.toJSONString(cmd));
        ApiResult<String> inviterUserIdByToken = userChannelInfoService.getUserChannelUserIdByToken(cmd.getInviterUserId());
        ApiResult<String> inviteeUserIdByToken = userChannelInfoService.getUserChannelUserIdByToken(cmd.getInviteeUserId());
        if (!inviterUserIdByToken.getSuccess()
                || !inviteeUserIdByToken.getSuccess()) {
            return ApiResult.buildFailure("无效用户");
        }
        UserInviteInfo builder = UserInviteInfo.builder()
                .inviterUserId(inviterUserIdByToken.getData())
                .inviteeUserId(inviteeUserIdByToken.getData()).build();
        log.info("AddInviteRelation builder:{}",JSONObject.toJSONString(builder));
        UserInviteInfo userInviteInfo = userInviteInfoGateway.get(builder);
        if (Objects.nonNull(userInviteInfo)) {
            return ApiResult.buildFailure("已存在邀请关系");
        }
        builder.setInviteId(IdUtil.getSnowflakeNextId());
        builder.setPolicyStatus(ZERO);
        List<String> userIdList =new ArrayList<>();
        userIdList.add(inviteeUserIdByToken.getData());
        List<DigitalPolicy> digitalPolicyList = digitalPolicyGateway.countDigitalNumByUserIds(userIdList);
        if(CollectionUtils.isNotEmpty(digitalPolicyList)){
            builder.setPolicyStatus(TWO);
        }
        Long save = userInviteInfoGateway.save(builder);
        return ApiResult.of(save);
    }
}
