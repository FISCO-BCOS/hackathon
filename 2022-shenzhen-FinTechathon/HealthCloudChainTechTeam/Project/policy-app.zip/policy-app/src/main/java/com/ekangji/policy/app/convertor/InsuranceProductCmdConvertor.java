package com.ekangji.policy.app.convertor;

import com.ekangji.policy.domain.insurance.InsuranceProduct;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductDropListVO;
import com.ekangji.policy.dto.clientobject.insurance.product.InsuranceProductVO;
import com.ekangji.policy.dto.command.insurance.product.*;
import com.github.pagehelper.PageInfo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * 数据转换
 */
@Mapper(componentModel = "spring")
public interface InsuranceProductCmdConvertor {

    InsuranceProduct convert(InsuranceProductQry param);

    InsuranceProduct convert(InsuranceProductPageQry param);

    InsuranceProduct convert(InsuranceProductByIdQry param);

    InsuranceProduct convert(InsuranceProductByCompanyIdQry param);

    InsuranceProduct convert(InsuranceProductTypeByProductIdQry param);

    InsuranceProductVO convert(InsuranceProduct param);

    List<InsuranceProductVO> convert(List<InsuranceProduct> param);

    PageInfo<InsuranceProductVO> convert(PageInfo<InsuranceProduct> param);


}
