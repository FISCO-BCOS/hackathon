package com.ekangji.policy.test.service;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PolicyBackupMessageService;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.dto.clientobject.policy.PolicyBackupValidationVO;
import com.ekangji.policy.dto.clientobject.policy.PolicySimpleVO;
import com.ekangji.policy.dto.command.policy.FamilyMemberPolicyQry;
import com.ekangji.policy.dto.command.policy.PolicyDeleteCmd;
import com.ekangji.policy.dto.command.policy.backup.ToBeBackupPolicyQry;
import com.ekangji.policy.test.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

/**
 * @author 何帅
 * @Description
 * @date 2022-06-02 13:14
 */
@Slf4j
public class PolicyBackupMessageTest extends BaseTest {
    @Resource
    private PolicyBackupMessageService policyBackupMessageService;
    @Test
    public void testValidate(){
        ToBeBackupPolicyQry qry = new ToBeBackupPolicyQry();
        qry.setReceiverPhoneNumber("15101133403");
        qry.setUserId("1506900036189122560");
        qry.setChannelType(0);
        List<Long> policyIds = Arrays.asList(1532285089864462336L, 1532285472699559936L, 1532324121507966976L);
        qry.setPolicyIds(policyIds);
        ApiResult<PolicyBackupValidationVO> result = policyBackupMessageService.validateBeforeBackup(qry);
        log.info("打印接口返回结果：{}",result);
        if(result.getSuccess()){
            PolicyBackupValidationVO validationVO = result.getData();
            log.info("打印VO对象：{}",validationVO);
        }
    }

}
