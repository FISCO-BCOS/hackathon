package com.ekangji.policy.test.gateway;

import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PolicyBackupMessageService;
import com.ekangji.policy.domain.gateway.PolicyAdditionalGateway;
import com.ekangji.policy.domain.policy.PolicyAdditional;
import com.ekangji.policy.dto.clientobject.policy.PolicyBackupValidationVO;
import com.ekangji.policy.dto.command.policy.backup.ToBeBackupPolicyQry;
import com.ekangji.policy.test.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.io.ResolverUtil;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

/**
 * @author 何帅
 * @Description
 * @date 2022-06-02 13:14
 */
@Slf4j
public class PolicyAdditionalTest extends BaseTest {
    @Resource
    private PolicyAdditionalGateway policyAdditionalGateway;
    @Test
    public void testLogicDelete(){
        int result = policyAdditionalGateway.logicDeleteByPolicyId(PolicyAdditional.builder().policyId(741852L).build());
        log.info("打印结果：{}", result);
    }

}
