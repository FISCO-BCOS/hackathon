package com.ekangji.policy.test.service;

import com.alibaba.fastjson.JSON;
import com.ekangji.common.tool.api.ApiResult;
import com.ekangji.policy.api.PolicyService;
import com.ekangji.policy.api.UserFamilyInfoService;
import com.ekangji.policy.dto.clientobject.policy.PolicySimpleVO;
import com.ekangji.policy.dto.clientobject.policy.PolicyTipsVO;
import com.ekangji.policy.dto.clientobject.policy.UserFamilyMemberVO;
import com.ekangji.policy.dto.command.policy.FamilyMemberPolicyQry;
import com.ekangji.policy.dto.command.policy.PolicyDeleteCmd;
import com.ekangji.policy.dto.command.policy.PolicyHmbDetailQry;
import com.ekangji.policy.dto.command.policy.family.UserFamilyQry;
import com.ekangji.policy.test.BaseTest;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author 何帅
 * @Description
 * @date 2022-06-02 13:14
 */
@Slf4j
public class PolicyTest extends BaseTest {
    @Resource
    private PolicyService policyService;
    @Resource
    private UserFamilyInfoService userFamilyInfoService;

    @Test
    public void testDelete(){
        PolicyDeleteCmd cmd = new PolicyDeleteCmd();
        cmd.setPolicyId(1532324801652109312L);
        cmd.setUserId("85");
        ApiResult apiResult = policyService.logicDelete(cmd);
        log.info("打印返回结果：{}",apiResult);
    }

    @Test
    public void testQueryByMemberId(){
        FamilyMemberPolicyQry qry = new FamilyMemberPolicyQry();
        qry.setFamilyMemberId(1529364611860561920L);
        ApiResult<List<PolicySimpleVO>> apiResult = policyService.queryFamilyMemberPolicyList(qry);
        if(apiResult.getSuccess()){
            List<PolicySimpleVO> policySimpleVOList = apiResult.getData();
            for (PolicySimpleVO policySimpleVO : policySimpleVOList) {
                log.info("打印查询到的保单对象：{}",policySimpleVO);
            }
        }
    }

    @Test
    public void testQueryMemberListWithPolicyByUserId(){
        UserFamilyQry qry = new UserFamilyQry();
        qry.setUserId("awazxUUUgHZe-DAb3XGuQ");
        ApiResult<List<UserFamilyMemberVO>> result = userFamilyInfoService.findFamilyListWithPolicyByUserId(qry);
        if(result.getSuccess()){
            List<UserFamilyMemberVO> memberVOList = result.getData();
            for (UserFamilyMemberVO policySimpleVO : memberVOList) {
                log.info("打印查询到的家庭成员对象：{}",policySimpleVO);
            }
        }
    }

    @Test
    public void testQueryMemberListByUserId(){
        UserFamilyQry qry = new UserFamilyQry();
        qry.setUserId("awazxUUUgHZe-DAb3XGuQ");
        ApiResult<List<UserFamilyMemberVO>> result = userFamilyInfoService.findFamilyListByUserId(qry);
        if(result.getSuccess()){
            List<UserFamilyMemberVO> memberVOList = result.getData();
            for (UserFamilyMemberVO policySimpleVO : memberVOList) {
                log.info("打印查询到的家庭成员对象：{}",policySimpleVO);
            }
        }
    }

    @Test
    public void testHmbTips(){
       PolicyHmbDetailQry qry = new PolicyHmbDetailQry();
       qry.setProductCode("GXYLYHB");
       ApiResult<PolicyTipsVO> apiResult = policyService.hmbTips(qry);
       log.info("==============testHmbTips:{}", JSON.toJSONString(apiResult));
    }
}
