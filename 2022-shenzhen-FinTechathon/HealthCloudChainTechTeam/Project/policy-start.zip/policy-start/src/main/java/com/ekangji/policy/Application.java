package com.ekangji.policy;

import com.ekangji.common.tool.net.ip.IpUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.TransactionManager;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.Resource;
import java.util.Arrays;

/**
 * 启动类
 */
@Slf4j
@EnableSwagger2
@EnableScheduling
@SpringBootApplication(scanBasePackages = {"com.ekangji.policy"})
@MapperScan("com.ekangji.policy.infrastructure.dao")
@EnableDubbo(scanBasePackages = "com.ekangji.policy.app.service.impl")
public class Application implements TransactionManagementConfigurer, CommandLineRunner {

    @Resource
    private Environment environment;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("\n----------------------------------------------------------\n\t" +
                        "Application '{}' is running! Access URLs:\n\t" +
                        "Local: \t\thttp://127.0.0.1:{}\n\t" +
                        "External: \thttp://{}:{}\n\t" +
                        "Profile(s): \t{}\n----------------------------------------------------------",
                environment.getProperty("spring.application.name"),
                environment.getProperty("server.port"),
                IpUtil.getLocalIP(),
                environment.getProperty("server.port"),
                Arrays.toString(environment.getActiveProfiles()));
    }

    @Override
    public TransactionManager annotationDrivenTransactionManager() {
        return null;
    }
}
