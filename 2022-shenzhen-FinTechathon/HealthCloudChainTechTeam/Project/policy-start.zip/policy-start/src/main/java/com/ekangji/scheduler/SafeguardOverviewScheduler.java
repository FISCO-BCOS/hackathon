package com.ekangji.scheduler;

import org.springframework.stereotype.Component;


@Component
public class SafeguardOverviewScheduler {

//    @Resource
//    private SafeguardOverviewService safeguardOverviewService;
//
//    /**
//     *  更新保障总图数据
//     *
//     * @return
//     */
//    @Override
//    public ProcessResult process(JobContext context) throws Exception {
//        safeguardOverviewService.updateOverview();
//        return new ProcessResult(true);
//    }


}
