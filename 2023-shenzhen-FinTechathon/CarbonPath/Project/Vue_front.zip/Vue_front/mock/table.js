const Mock = require('mockjs')

const data = Mock.mock({
  'items|30': [{
    id: '@id',
    title: '@sentence(10, 20)',
    status: '挂牌',
    author: 'name',
    'type|1': ['卖出', '买入'],
    display_time: '@date(2023-MM-dd)',
    companyName: 'xxx集团',
    transAmount: '@integer(300, 500)',
    price: '@integer(30, 100)'
  }]
})

const dataCCER = Mock.mock({
  'items|33': [{
    id: '@id',
    'name|1': ['xxx项目', 'yyy项目', 'zzz项目'],
    status: '挂牌',
    'type|1': ['能源工业',
      '能源分配',
      '能源需求',
      '制造业',
      '化学工业',
      '建筑',
      '交通运输',
      '采矿/矿产品生产',
      '金属生产',
      '燃料逸出性排放',
      '卤烃与六氟化硫的生产和使用过程中的逸出性排放',
      '溶剂使用',
      '废物处置',
      '造林与再造林',
      '农业'],
    author: 'name',
    display_time: '@date(2023-MM-dd)',
    reduction: '@integer(300, 5000)',
    price: '@integer(300, 5000)'
  }]
})

const listCCER = Mock.mock({
  'items|8': [{
    id: '@id',
    'name|1': ['xxx项目', 'yyy项目', 'zzz项目'],
    status: '审核完毕',
    'type|1': ['能源工业',
      '能源分配',
      '能源需求',
      '制造业',
      '化学工业',
      '建筑',
      '交通运输',
      '采矿/矿产品生产',
      '金属生产',
      '燃料逸出性排放',
      '卤烃与六氟化硫的生产和使用过程中的逸出性排放',
      '溶剂使用',
      '废物处置',
      '造林与再造林',
      '农业'],
    'companyName|1': ['aaaa组织', 'bbbb公司', '北京邮电大学'],
    date1: '@date(2023-MM-dd)',
    reductionExpected: '@integer(300, 5000)'
  }]
})

module.exports = [
  {
    url: '/vue-admin-template/table/list',
    type: 'get',
    response: config => {
      const items = data.items
      return {
        code: 20000,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/table/ccer_list',
    type: 'get',
    response: config => {
      const items = dataCCER.items
      return {
        code: 20000,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  },
  {
    url: '/table/ccer',
    type: 'get',
    response: config => {
      const items = listCCER.items
      return {
        code: 20000,
        data: {
          total: items.length,
          items: items
        }
      }
    }
  }
]
