<template>
  <div class="app-container">
    <div class="carbon-container">
      <div class="carbon-text1">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.carbonAmount }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年分配碳配额（吨）</div>
      </div>
      <div class="carbon-text2">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.sellAmount }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年购买碳配额（吨）</div>
      </div>
      <div class="carbon-text2">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.buyAmount }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年出售碳配额（吨）</div>
      </div>
      <div class="carbon-text3">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.carbonEmssion + 40000 }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年碳排放量（吨）</div>
      </div>
    </div>
    <div class="carbon-container">
      <div class="carbon-text1">
        <div style="font-size: 25px; margin: 5px;">
          {{ residue }}
        </div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年碳配额总量（吨）</div>
      </div>
      <div class="carbon-text2">
        <div style="font-size: 25px; margin: 5px;">
          {{ (residue - parseFloat(companyInfo.carbonEmssion) - 40000) > 0 ? parseFloat(residue -40000 - parseFloat(companyInfo.carbonEmssion)).toFixed(3) : 0 }}
        </div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年当前可出售碳配额（吨）</div>
      </div>
      <div class="carbon-text2">
        <div style="font-size: 25px; margin: 5px;">
          {{ (parseFloat(companyInfo.carbonEmssion) + 40000 - residue) > 0 ? parseFloat(parseFloat(companyInfo.carbonEmssion) + 40000 - residue).toFixed(3) : 0 }}
        </div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年当前应购入碳配额（吨）</div>
      </div>
      <div class="carbon-text3">
        <div style="font-size: 25px; margin: 5px;">
          {{ parseFloat(companyInfo.carbonAmount/10).toFixed(3) }}
        </div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年CCER项目抵消额度（吨）</div>
      </div>
    </div>
    <div
      style="margin: 10px 10px 10px 10px;
      padding: 10px;
      background-color: white;
      border-radius: 4px;
      box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);"
    >
      <el-table
        v-loading="listLoading"
        :data="list"
        element-loading-text="Loading"
        border
        stripe
        fit
        highlight-current-row
        height="375"
      >
        <el-table-column align="center" label="月份">
          <template slot-scope="scope">
            {{ dateFormate(scope.row.month) }}
          </template>
        </el-table-column>
        <el-table-column label="购买碳配额/吨" align="center">
          <template slot-scope="scope">
            {{ scope.row.sell }}
          </template>
        </el-table-column>
        <el-table-column label="出售碳配额/吨" align="center">
          <template slot-scope="scope">
            <span>{{ scope.row.buy }}</span>
          </template>
        </el-table-column>
        <el-table-column label="碳排放量/吨" align="center">
          <template slot-scope="scope">
            {{ scope.row.emssion }}
          </template>
        </el-table-column>
      </el-table>
      <div style="display: flex; width: 95%; margin: 10px; justify-content: end;">
        <el-button type="primary" @click="onSubmit()">申请清缴</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'CarbonClearance',
  data() {
    return {
      residue: 0,
      list: []
    }
  },
  computed: {
    ...mapGetters({
      companyInfo: 'user',
      carbonSell: 'sell',
      carbonBuy: 'buy'
    })
  },
  created() {
    this.residue = parseFloat(this.companyInfo.carbonAmount) - parseFloat(this.companyInfo.buyAmount) + parseFloat(this.companyInfo.sellAmount)
    for (var i = 0; i < 12; i++) {
      var item = {
        month: '',
        sell: '',
        buy: '',
        emssion: ''
      }
      item.month = new Date(2023, i)
      var sell = 0
      this.carbonSell.forEach(element => {
        if (element.updateTime.getMonth() === i) {
          sell += parseFloat(element.transAmount)
        }
      })
      item.sell = parseFloat(sell).toFixed(3)
      var buy = 0
      this.carbonBuy.forEach(element => {
        if (element.updateTime.getMonth() === i) {
          buy += parseFloat(element.transAmount)
        }
      })
      item.buy = parseFloat(buy).toFixed(3)
      item.emssion = 4000 + parseInt(i / 2) * 100 * (i % 2 === 0 ? -1 : 1)
      this.list.push(item)
    }
    this.list[10].emssion = this.companyInfo.carbonEmssion
    this.list[11].emssion = 0
  },
  methods: {
    onSubmit() {
      const jud = new Date().getMonth()
      if (jud !== 11) {
        this.$message({
          message: '当前不可申请清缴！',
          type: 'error'
        })
      } else {
        this.$message({
          message: '成功提交申请！',
          type: 'success'
        })
      }
    },
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1

        month = month > 9 ? month : '0' + month

        return year + '-' + month
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.carbon {
  &-container {
    display: flex;
    flex-wrap: wrap;
  }
  &-text1 {
    border-radius: 4px;
    background-color: white;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px auto 10px 10px;
  }
  &-text2 {
    border-radius: 4px;
    background-color: white;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px auto 10px auto;
  }
  &-text3 {
    border-radius: 4px;
    background-color: white;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px 10px 10px auto;
  }
}
</style>
