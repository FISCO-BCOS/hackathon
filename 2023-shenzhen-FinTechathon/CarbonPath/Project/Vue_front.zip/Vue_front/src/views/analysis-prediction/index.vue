<template>
  <div style="display: flex; flex-direction: column;">
    <div style="display: flex; flex-direction: row;">
      <div class="chart_card_right">
        <div id="chart_1" style="width: 100%; height: 300px;" />
      </div>
    </div>
    <div style="display: flex; flex-direction: row;">
      <div style="width: 50%; margin: 10px; padding: 10px; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);">
        <el-table
          v-loading="listLoading"
          :data="listAmount"
          element-loading-text="Loading"
          border
          fit
          highlight-current-row
        >
          <el-table-column align="center" label="月份">
            <template slot-scope="scope">
              {{ scope.row.date }}
            </template>
          </el-table-column>
          <el-table-column label="碳排放量/吨" align="center">
            <template slot-scope="scope">
              {{ scope.row.amount }}
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div style="width: 50%; margin: 10px; padding: 10px; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);">
        <el-table
          v-loading="listLoading"
          :data="listPre"
          element-loading-text="Loading"
          border
          fit
          highlight-current-row
        >
          <el-table-column align="center" label="月份">
            <template slot-scope="scope">
              {{ scope.row.date }}
            </template>
          </el-table-column>
          <el-table-column label="碳排放量/吨" align="center">
            <template slot-scope="scope">
              {{ scope.row.amount }}
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import * as echarts from 'echarts/core'
import {
  TitleComponent,
  ToolboxComponent,
  TooltipComponent,
  GridComponent,
  LegendComponent
} from 'echarts/components'
import { LineChart } from 'echarts/charts'
import { UniversalTransition } from 'echarts/features'
import { CanvasRenderer } from 'echarts/renderers'

echarts.use([
  TitleComponent,
  ToolboxComponent,
  TooltipComponent,
  GridComponent,
  LegendComponent,
  LineChart,
  CanvasRenderer,
  UniversalTransition
])

export default {
  name: 'AnalysisPrediction',
  data() {
    return {
      listLoading: false,
      active: 'first',
      listAmount: [],
      listPre: [],
      date: [],
      amounts: []
    }
  },
  computed: {
    ...mapGetters({
    })
  },
  created() {
    const tarTime = new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000))
    var time = null
    for (var i = 0; i < 14; i++) {
      time = this.dateFormat(new Date(tarTime.getTime() + (i * 24 * 60 * 60 * 1000)))
      this.date.push(time)
      var amount = Math.floor(Math.random() * 300) + 100
      var item = {
        date: time,
        amount: amount
      }
      this.amounts.push(amount)
      if (i < 7) {
        this.listAmount.push(item)
      } else {
        this.listPre.push(item)
      }
    }
  },
  mounted() {
    var liner_1 = echarts.init(document.getElementById('chart_1'))
    var option1

    option1 = {
      title: {
        text: 'Stacked Line'
      },
      tooltip: {
        trigger: 'axis'
      },
      legend: {
        data: ['Email', 'Union Ads', 'Video Ads', 'Direct', 'Search Engine']
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      toolbox: {
        feature: {
          saveAsImage: {}
        }
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          name: 'Email',
          type: 'line',
          stack: 'Total',
          data: [120, 132, 101, 134, 90, 230, 210],
          smooth: true
        },
        {
          name: 'Union Ads',
          type: 'line',
          stack: 'Total',
          data: [220, 182, 191, 234, 290, 330, 310],
          smooth: true
        }
      ]
    }

    option1 && liner_1.setOption(option1)
  },
  methods: {
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()
        // 时
        var hour = date.getHours()
        // 分
        var minute = date.getMinutes()
        // 秒
        var second = date.getSeconds()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        hour = hour > 9 ? hour : '0' + hour

        minute = minute > 9 ? minute : '0' + minute

        second = second > 9 ? second : '0' + second

        return year + '-' + month + '-' + strDate + ' ' + hour + ':' + minute + ':' + second
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.chart_card_right {
  width: 100%;
  margin: 10px;
  padding: 10px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
.carbon {
  &-container {
    margin: 30px;
    display: flex;
    flex-wrap: wrap;
  }
  &-text {
    border-radius: 4px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px;
  }
}
</style>
