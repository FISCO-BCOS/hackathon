<template>
  <div class="app-container">
    <div
      style="display: flex;
      flex-direction: column;
      border-radius: 4px;
      box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
      height: auto;
      background-color: white;"
    >
      <div
        style="margin: 10px 10px 0px 10px;
        display: flex;
        position: relative;"
      >
        <el-date-picker
          v-model="value1"
          type="month"
          placeholder="选择月份"
          style="margin-right: 10px;"
        />
        <el-select
          v-model="type"
          placeholder="请选择记录类别"
          style="width: 20%; margin-right: 10px;"
        >
          <el-option
            v-for="row in types"
            :key="row.value"
            :label="row.label"
            :value="row.value"
          />
        </el-select>
        <el-select
          v-if="type === 1"
          v-model="item"
          placeholder="请选择项目"
          style="width: 20%; margin-right: 10px;"
        >
          <el-option
            v-for="row in items"
            :key="row.value"
            :label="row.label"
            :value="row.value"
          />
        </el-select>
        <div v-if="!edit" style="float: right; position: absolute; right: 10px; display: flex;">
          <el-button type="primary" @click="onSubmit">提交</el-button>
        </div>
        <div v-else-if="edit" style="float: right; position: absolute; right: 10px; display: flex; ">
          <el-button type="primary" style="right: 10px;" @click="edit = !edit">保存</el-button>
        </div>
      </div>
      <div
        style="margin: 10px 10px 0px 10px;"
      >
        <!-- v-if="type === 1 & item === 3" -->
        <el-table
          v-loading="listLoading"
          :data="list"
          element-loading-text="Loading"
          border
          fit
          highlight-current-row
          height="480"
          @cell-click="cellHandleclick"
        >
          <el-table-column label="类型" align="center">
            <template slot-scope="scope">
              {{ scope.row.type }}
            </template>
          </el-table-column>
          <el-table-column label="消耗量/吨或10^4m³" align="center">
            <template slot-scope="scope">
              <span v-if="!edit">{{ parseFloat(scope.row.consume) }}</span>
              <el-input v-else-if="edit" v-model="scope.row.consume" type="number" @input="conversion(scope.row)" />
            </template>
          </el-table-column>
          <el-table-column label="CO₂排放量/吨" align="center">
            <template slot-scope="scope">
              {{ parseFloat(scope.row.emssion) }}
            </template>
          </el-table-column>
        </el-table>
        <!-- <el-upload
          ref="upload"
          class="upload-demo"
          action="https://file-unibhpdfgs-mp-a1ffa090-7d25-4c10-b9e8-0e387deba406.oss-cn-zhangjiakou.aliyuncs.com/"
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          :file-list="fileList"
          :auto-upload="false"
          style="margin: 10px;"
        >
          <el-button slot="trigger" size="small" type="primary">上传材料</el-button>
        </el-upload> -->
        <div style="display: flex; flex-direction: row; width: 100%;">
          <el-upload
            ref="upload"
            class="upload-demo"
            action="https://file-unibhpdfgs-mp-a1ffa090-7d25-4c10-b9e8-0e387deba406.oss-cn-zhangjiakou.aliyuncs.com/"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :file-list="fileList"
            :auto-upload="false"
            style="margin: 10px; width: 50%;"
          >
            <el-button slot="trigger" size="small" type="primary">上传材料</el-button>
          </el-upload>
          <div style="justify-content: end; width: 50%;">
            <div v-if="type === 1 & item === 3" style="display: flex; justify-content: end; width: 90%; margin: 20px 20px 0px auto;">
              <div style="font-size: 20px; margin: 5px; position: relative; color: gray">合计：</div>
              <div style="font-size: 20px; margin: 5px; position: relative;">{{ companyInfo.carbonEmssion }}</div>
            </div>
            <div v-if="type === 1 & item === 3" style="display: flex; justify-content: end; width: 90%; margin: 20px 20px 20px auto;">
              <div style="font-size: 20px; margin: 5px; position: relative; color: gray">2023年合计：</div>
              <div style="font-size: 20px; margin: 5px; position: relative;">{{ companyInfo.carbonEmssion + 40000 }}</div>
            </div>
          </div>
        </div>
        <!-- <el-table
          v-else-if="item & edit"
          v-loading="listLoading"
          :data="list"
          element-loading-text="Loading"
          border
          fit
          highlight-current-row
        >
          <el-table-column label="类型" align="center">
            <template slot-scope="scope">
              {{ scope.row.type }}
            </template>
          </el-table-column>
          <el-table-column label="消耗量（t或10^4m³）" align="center">
            <template slot-scope="scope">
              <el-input v-model="scope.row.consume" />
            </template>
          </el-table-column>
          <el-table-column label="CO₂排放量（t）" align="center">
            <template slot-scope="scope">
              {{ scope.row.emssion }}
            </template>
          </el-table-column>
        </el-table> -->
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'CarbonManage',
  data() {
    return {
      value1: new Date(),
      listLoading: false,
      edit: false,
      type: 1,
      item: 3,
      fileList: [],
      types: [{
        value: 1,
        label: '能源行业'
      }, {
        value: 2,
        label: '制造业'
      }, {
        value: 3,
        label: '商业'
      }, {
        value: 4,
        label: '农林牧渔'
      }, {
        value: 5,
        label: '建筑业'
      }, {
        value: 6,
        label: '采矿业'
      }],
      items: [{
        value: 1,
        label: '石油和天然气开采'
      }, {
        value: 2,
        label: '煤炭开采和洗选业'
      }, {
        value: 3,
        label: '电力、热力的生产和供应业'
      }, {
        value: 4,
        label: '燃气生产和供应业'
      }]
    }
  },
  computed: {
    ...mapGetters({
      companyInfo: 'user',
      list: 'list'
    })
  },
  created() {
    this.emssionAmount()
  },
  methods: {
    cellHandleclick(row, column, cell, event) {
      console.log(row)
      console.log(column)
      console.log(cell)
      console.log(event)
      // 如果规定点击某一列执行，利用column中的label属性
      if (column.label === '消耗量/吨或10^4m³' && this.edit === false) {
        // 执行逻辑
        this.edit = !this.edit
      }
    },
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1

        month = month > 9 ? month : '0' + month

        return year + '-' + month
      }
    },
    conversion(row) {
      row.emssion = parseFloat(row.consume * row.conversionFactor).toFixed(3)
    },
    onSubmit() {
      this.$store.dispatch('user/listSet', this.list).then(() => {
        this.emssionAmount()
      })
    },
    emssionAmount() {
      let amount = 0
      this.list.forEach(element => {
        amount += parseFloat(element.emssion)
      })
      this.companyInfo.carbonEmssion = amount
      this.$store.dispatch('userSet', this.companyInfo)
    }
  }
}
</script>

<style lang="scss" scoped>
.carbon {
  &-container {
    margin: 0px 10px 10px 0px;
    position: relative;
    display: flex;
    flex-wrap: wrap;
  }
  &-text {
    border-radius: 4px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px;
  }
}
</style>
