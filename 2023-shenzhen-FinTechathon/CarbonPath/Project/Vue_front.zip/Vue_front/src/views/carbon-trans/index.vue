<template>
  <div class="app-container">
    <el-tabs v-model="active1" type="border-card" style="height: 665px;" @tab-click="handleClick">
      <el-tab-pane label="交易列表" name="first" style="background-color: white;">
        <SearchButton @searchHandle="searchHandle" @resetHandle="resetHandle" @addHandle="addHandle">
          <el-form-item label="交易量下限">
            <el-input v-model.number="queryCar.amountLow" clearable type="number" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="交易量上限">
            <el-input v-model.number="queryCar.amountHigh" clearable type="number" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="交易类型">
            <el-select v-model="queryCar.type" placeholder="请选择">
              <el-option label="卖出" value="卖出" />
              <el-option label="买入" value="买入" />
            </el-select>
          </el-form-item>
          <!-- 需要折叠的查询条件，放在more插槽里即可 -->
          <!-- 如果是不需要显示更多查询，就在SearchButton传多一个变量 :no-more="true" -->
          <template #more>
            <el-form-item label="价格下限">
              <el-input v-model.number="queryCar.priceLow" clearable type="number" placeholder="请输入" />
            </el-form-item>
            <el-form-item label="价格上限">
              <el-input v-model.number="queryCar.priceHigh" clearable type="number" placeholder="请输入" />
            </el-form-item>
          </template>
        </SearchButton>
        <el-table
          v-loading="listLoading"
          :data="listCar"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
          height="535"
        >
          <!-- 模拟数据 -->
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="公司名称">
            <template slot-scope="scope">
              {{ scope.row.companyName }}
            </template>
          </el-table-column>
          <el-table-column label="交易量/吨" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.transAmount }}</span>
            </template>
          </el-table-column>
          <el-table-column label="价格/元每吨" width="140" align="center">
            <template slot-scope="scope">
              {{ scope.row.price }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="提交时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate2(scope.row.display_time) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toDetail(scope.$index, scope.row)"
              >查看详情</el-button>
            </template>
          </el-table-column>
          <!-- 实际数据 -->
          <!-- <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.row['CEA Demand ID'] }}
            </template>
          </el-table-column>
          <el-table-column label="公司名称">
            <template slot-scope="scope">
              {{ scope.row['Company Name'] }}
            </template>
          </el-table-column>
          <el-table-column label="交易量（吨）" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row['CEA Demand Amount'] }}</span>
            </template>
          </el-table-column>
          <el-table-column label="交易价格（万元/吨）" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row['CEA Demand min price'] }}
            </template>
          </el-table-column>
          <el-table-column label="交易类型" width="110" align="center">
            {{ type[Math.floor(Math.random()*type.length)] }}
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="提交时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ scope.row['Demand Publish Time'] }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="status" label="状态" width="110" align="center">
            <template slot-scope="scope">
              <el-tag :type="scope.row.status | statusFilter">{{ status[scope.row['Demand status']] }}</el-tag>
            </template>
          </el-table-column> -->
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="历史交易" name="third">
        <el-table
          v-loading="listLoading"
          :data="listTrans"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
        >
          <!-- 模拟数据 -->
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="买方公司">
            <template slot-scope="scope">
              {{ scope.row.buyer }}
            </template>
          </el-table-column>
          <el-table-column label="卖方公司">
            <template slot-scope="scope">
              {{ scope.row.seller }}
            </template>
          </el-table-column>
          <el-table-column label="购买量/吨" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.realAmount }}</span>
            </template>
          </el-table-column>
          <el-table-column label="价格/元每吨" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row.realPrice }}
            </template>
          </el-table-column>
          <el-table-column label="交易时间" width="110" align="center">
            <template slot-scope="scope">
              {{ dateFormate(scope.row.updateTime) }}
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toTrans(scope.$index, scope.row)"
              >查看交易</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="我的提交" name="fourth">
        <el-table
          v-loading="listLoading"
          :data="listMy"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
          height="550"
        >
          <!-- 模拟数据 -->
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="公司名称">
            <template slot-scope="scope">
              {{ scope.row.companyName }}
            </template>
          </el-table-column>
          <el-table-column label="交易量/吨" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.transAmount }}</span>
            </template>
          </el-table-column>
          <el-table-column label="参考价格/元每吨" width="140" align="center">
            <template slot-scope="scope">
              {{ scope.row.price }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="提交时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate2(scope.row.display_time) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toMy(scope.$index, scope.row)"
              >查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
    <el-dialog title="登记项目" :visible.sync="dialogCarVisible" width="75%" top="50px">
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="公司名称">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ form.companyName }}
          </div>
        </el-form-item>
        <el-form-item label="交易量">
          <el-input v-model="form.transAmount" placeholder="单位：吨" />
        </el-form-item>
        <el-form-item label="提交日期">
          <el-col :span="11">
            <el-date-picker v-model="form.display_time" type="date" placeholder="请选择日期" style="width: 100%;" />
          </el-col>
        </el-form-item>
        <el-form-item label="价格">
          <el-input v-model="form.price" placeholder="单位：元" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="交易详情" :visible.sync="detailVisible" width="75%" top="30px">
      <el-form ref="detail" :model="detail" label-width="120px">
        <el-form-item label="公司名称">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.companyName }}
          </div>
        </el-form-item>
        <el-form-item label="联系人">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.contactPerson }}
          </div>
        </el-form-item>
        <el-form-item label="联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.contactWay }}
          </div>
        </el-form-item>
        <el-form-item label="提交时间">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate2(detail.display_time) }}
          </div>
        </el-form-item>
        <el-form-item label="交易量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.transAmount }}
          </div>
        </el-form-item>
        <el-form-item label="价格/元每吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.price }}
          </div>
        </el-form-item>
        <el-form-item label="购买量/吨">
          <el-input v-model="detail.realAmount" @input="refresh()" />
        </el-form-item>
        <el-form-item label="购买价格/元每吨">
          <el-input v-model="detail.realPrice" @input="refresh()" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onTrans">交易</el-button>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="交易详情" :visible.sync="transVisible" width="75%" top="50px">
      <el-form ref="trans" :model="trans" label-width="120px">
        <el-form-item label="买方公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.buyer }}
          </div>
        </el-form-item>
        <el-form-item label="买方联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.buyerContact }}
          </div>
        </el-form-item>
        <el-form-item label="卖方公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.seller }}
          </div>
        </el-form-item>
        <el-form-item label="卖方联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.sellerContact }}
          </div>
        </el-form-item>
        <el-form-item label="购买量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.realAmount }}
          </div>
        </el-form-item>
        <el-form-item label="价格/元每吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.realPrice }}
          </div>
        </el-form-item>
        <el-form-item label="更新时间">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate(trans.updateTime) }}
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="交易详情" :visible.sync="MyVisible" width="75%" top="30px">
      <el-form ref="my" :model="my" label-width="120px">
        <el-form-item label="公司名称">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.companyName }}
          </div>
        </el-form-item>
        <el-form-item label="联系人">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.contactPerson }}
          </div>
        </el-form-item>
        <el-form-item label="联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.contactWay }}
          </div>
        </el-form-item>
        <el-form-item label="提交时间">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate2(my.display_time) }}
          </div>
        </el-form-item>
        <el-form-item label="交易量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.transAmount }}
          </div>
        </el-form-item>
        <el-form-item label="参考价格/元每吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.price }}
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getList } from '@/api/table'
import SearchButton from '@/layout/components/SearchButton.vue'

export default {
  name: 'CarbonTrans',
  components: {
    SearchButton
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        挂牌: 'success',
        交易中: 'gray',
        交易完成: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      formTarget: '', // 填写上传项目表单时，选择的目标对象
      type: ['卖出', '买入'],
      status: ['交易完成', '挂牌'],
      queryCar: {},
      detail: {},
      detailId: 0,
      my: {},
      myId: 0,
      trans: {},
      transId: 0,
      active1: 'first',
      listLoading: false,
      form: {
        name: '',
        region: '',
        display_time: new Date(),
        delivery: false,
        resource: '',
        desc: ''
      },
      dialogCarVisible: false,
      detailVisible: false,
      transVisible: false,
      MyVisible: false
    }
  },
  computed: {
    ...mapGetters({
      myCompany: 'name',
      companyInfo: 'user',
      listSell: 'sell',
      listBuy: 'buy',
      listTrans: 'carbonTrans',
      listCar: 'carbonData',
      listMy: 'carbonMy'
    })
  },
  created() {
  },
  mounted() {
    this.tran1Tab()
  },
  methods: {
    refresh() {
      this.$forceUpdate()
    },
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()
        // 时
        var hour = date.getHours()
        // 分
        var minute = date.getMinutes()
        // 秒
        var second = date.getSeconds()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        hour = hour > 9 ? hour : '0' + hour

        minute = minute > 9 ? minute : '0' + minute

        second = second > 9 ? second : '0' + second

        return year + '-' + month + '-' + strDate + ' ' + hour + ':' + minute + ':' + second
      }
    },
    dateFormate2(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        return year + '-' + month + '-' + strDate
      }
    },
    toTrans(index, row) {
      this.trans = row
      this.transId = index
      this.transVisible = true
    },
    toMy(index, row) {
      this.my = row
      this.myId = index
      this.MyVisible = true
    },
    toDetail(index, row) {
      console.log(index, row)
      this.detail = row
      this.detail['realAmount'] = row.transAmount
      this.detail['realPrice'] = row.price
      this.detailId = index
      this.detailVisible = true
    },
    onTrans() {
      const trans = {
        seller: this.detail.companyName,
        sellerContact: this.detail.contactWay,
        buyer: this.myCompany,
        buyerContact: this.companyInfo.contactWay,
        transAmount: this.detail.transAmount,
        price: this.detail.price,
        realAmount: this.detail.realAmount,
        realPrice: this.detail.realPrice,
        updateTime: new Date(),
        contactPerson: this.detail.contactPerson,
        contactWay: this.detail.contactWay
      }
      this.listSell.push(trans)
      this.$store.dispatch('sellSet', this.listSell)
      this.listCar.splice(this.detailId, 1)
      this.$store.dispatch('carbonDataSet', this.listCar)
      this.$message({
        message: '交易成功',
        type: 'success'
      })
      this.listTrans.push(trans)
      this.$store.dispatch('carbonTransSet', this.listTrans)
      this.detailVisible = false
    },
    onSubmit() {
      // 实际数据
      // if (this.active2 === 'first') {
      //   this.axios.get('/displayCEA_demand/publish', {
      //     params: {
      //       amount: this.form.transAmount,
      //       maxPrice: this.form.highPrice,
      //       minPrice: this.form.lowPrice,
      //       companyName: this.form.name,
      //       time: this.form.date1 + this.form.date2,
      //       status: 1
      //     }
      //   }).then(res => {
      //     if (res.data === 'Success') {
      //       this.$message({
      //         message: '上传成功',
      //         type: 'success'
      //       })
      //       this.fetchCar()
      //       this.dialogCarVisible = false
      //     }
      //   })
      // }
      // 模拟数据
      const item = this.form
      const residue = parseFloat(this.companyInfo.carbonAmount) + parseFloat(this.companyInfo.buyAmount) - parseFloat(this.companyInfo.sellAmount)
      if ((residue - parseFloat(this.companyInfo.carbonEmssion) - 40000) > item.transAmount) {
        item.contactPerson = this.companyInfo.contactPerson
        item.contactWay = this.companyInfo.contactWay
        item.companyName = this.companyInfo.companyName
        this.listCar.push(item)
        this.listMy.push(item)
        this.$store.dispatch('carbonDataSet', this.listCCER)
        this.$store.dispatch('ccerMySet', this.listMy)
        this.$message({
          message: '创建交易成功！',
          type: 'success'
        })
      } else {
        this.$message({
          message: '当前碳配额不足，创建交易失败！',
          type: 'error'
        })
      }
      this.dialogCarVisible = false
    },
    onCancel() {
      this.dialogCarVisible = false
      this.detailVisible = false
      this.transVisible = false
    },
    fetchCar() {
      // 模拟数据
      this.listLoading = true
      getList().then(response => {
        this.listCar = response.data.items
        this.listLoading = false
      })
      // 实际数据
      // this.listLoading = true
      // this.axios.get('/displayCEA_demand/getAll').then(res => {
      //   let list = JSON.parse(res.data)
      //   this.listCar = list
      //   this.listLoading = false
      // })
    },
    handleClick(tab) {
      localStorage.setItem('tran_1_tab', tab.name)
    },
    tran1Tab() {
      if (localStorage.getItem('tran_1_tab') != null) {
        this.active1 = localStorage.getItem('tran_1_tab')
      }
    },
    addHandle() {
      // 登记相关代码
      this.form.companyName = this.companyInfo.companyName
      this.dialogCarVisible = true
    },
    searchHandle() {
      // 查询相关代码
    },
    resetHandle() {
      // 重置条件相关代码
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
