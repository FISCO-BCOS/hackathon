<template>
  <div class="app-container">
    <SearchButton @searchHandle="searchHandle" @resetHandle="resetHandle">
      <el-form-item label="任务编码">
        <el-input v-model.trim="queryParams.taskNo" placeholder="请输入" clearable />
      </el-form-item>
      <el-form-item label="任务名称">
        <el-input v-model.trim="queryParams.strategyName" placeholder="请输入" clearable />
      </el-form-item>
      <el-form-item label="任务编码">
        <el-input v-model.trim="queryParams.taskNo" placeholder="请输入" clearable />
      </el-form-item>
      <el-form-item label="任务名称">
        <el-input v-model.trim="queryParams.strategyName" placeholder="请输入" clearable />
      </el-form-item>
      <!-- 需要折叠的查询条件，放在more插槽里即可 -->
      <!-- 如果是不需要显示更多查询，就在SearchButton传多一个变量 :noMore="true" -->
      <template #more>
        <el-form-item label="任务编码">
          <el-input v-model.trim="queryParams.taskNo" placeholder="请输入" clearable />
        </el-form-item>
        <el-form-item label="任务名称">
          <el-input v-model.trim="queryParams.strategyName" placeholder="请输入" clearable />
        </el-form-item>
      </template>
    </SearchButton>
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
      <el-table-column align="center" label="ID" width="95">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="Title">
        <template slot-scope="scope">
          {{ scope.row.title }}
        </template>
      </el-table-column>
      <el-table-column label="Author" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.author }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Pageviews" width="110" align="center">
        <template slot-scope="scope">
          {{ scope.row.pageviews }}
        </template>
      </el-table-column>
      <el-table-column class-name="status-col" label="Status" width="110" align="center">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status | statusFilter">{{ scope.row.status }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="Display_time" width="200">
        <template slot-scope="scope">
          <i class="el-icon-time" />
          <span>{{ scope.row.display_time }}</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { getList } from '@/api/table'
import SearchButton from '@/layout/components/SearchButton.vue'

export default {
  components: {
    SearchButton
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        draft: 'gray',
        deleted: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      queryParams: {},
      list: null,
      listLoading: true
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    fetchData() {
      this.listLoading = true
      getList().then(response => {
        this.list = response.data.items
        this.listLoading = false
      })
    },
    searchHandle() {
      // 查询相关代码
    },
    resetHandle() {
      // 重置条件相关代码
    }
  }
}
</script>
<style scoped>
.btnRow {
    display: block
}
.unBtnRow {
    display: none
}
</style>
