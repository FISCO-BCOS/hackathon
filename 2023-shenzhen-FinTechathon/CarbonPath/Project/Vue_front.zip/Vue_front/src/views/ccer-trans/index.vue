<template>
  <div class="app-container">
    <el-tabs v-model="active1" type="border-card" style="height: 665px;" @tab-click="handleClick">
      <el-tab-pane label="交易列表" name="first">
        <SearchButton @searchHandle="searchHandle" @resetHandle="resetHandle" @addHandle="addHandle">
          <el-form-item label="减排量下限">
            <el-input v-model.number="queryCCER.amountLow" type="number" placeholder="请输入" clearable />
          </el-form-item>
          <el-form-item label="减排量上限">
            <el-input v-model.trim="queryCCER.amountHigh" type="number" placeholder="请输入" clearable />
          </el-form-item>
          <el-form-item label="交易类别">
            <el-select v-model="queryCCER.type" placeholder="请选择">
              <el-option
                v-for="item in type"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <!-- 需要折叠的查询条件，放在more插槽里即可 -->
          <!-- 如果是不需要显示更多查询，就在SearchButton传多一个变量 :no-more="true" -->
          <template #more>
            <el-form-item label="价格下限">
              <el-input v-model.number="queryCCER.priceLow" type="number" placeholder="请输入" clearable />
            </el-form-item>
            <el-form-item label="价格上限">
              <el-input v-model.trim="queryCCER.priceHigh" type="number" placeholder="请输入" clearable />
            </el-form-item>
          </template>
        </SearchButton>
        <el-table
          v-loading="listLoading"
          :data="listCCER"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
          height="550"
        >
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="公司名称">
            <template slot-scope="scope">
              {{ scope.row.item.companyName }}
            </template>
          </el-table-column>
          <el-table-column label="减排量/吨" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.item.reductionExpected }}</span>
            </template>
          </el-table-column>
          <el-table-column label="价格/万元每吨" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row.price }}
            </template>
          </el-table-column>
          <el-table-column label="项目类型" align="center">
            <template slot-scope="scope">
              {{ scope.row.item.type }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="提交时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate(scope.row.display_time) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toDetail(scope.$index, scope.row)"
              >查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="历史交易" name="third">
        <el-table
          v-loading="listLoading"
          :data="listTrans"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
          height="550"
        >
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="买方公司">
            <template slot-scope="scope">
              {{ scope.row.buyer }}
            </template>
          </el-table-column>
          <el-table-column label="卖方公司">
            <template slot-scope="scope">
              {{ scope.row.seller }}
            </template>
          </el-table-column>
          <el-table-column label="购买量/吨" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.item.reductionBuy }}</span>
            </template>
          </el-table-column>
          <el-table-column label="成交价格/万元每吨" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row.realPrice }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="交易时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate(scope.row.updateTime) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toTrans(scope.$index, scope.row)"
              >查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="我的提交" name="fourth">
        <el-table
          v-loading="listLoading"
          :data="listMy"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
          height="550"
        >
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="项目名称">
            <template slot-scope="scope">
              {{ scope.row.item.name }}
            </template>
          </el-table-column>
          <el-table-column label="减排量/吨" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.item.reductionExpected }}</span>
            </template>
          </el-table-column>
          <el-table-column label="价格/万元每吨" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row.price }}
            </template>
          </el-table-column>
          <el-table-column label="项目类型" align="center">
            <template slot-scope="scope">
              {{ scope.row.item.type }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="提交时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate(scope.row.display_time) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toMy(scope.$index, scope.row)"
              >查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
    <el-dialog title="登记交易" :visible.sync="dialogCCERVisible" width="75%" top="20px">
      <el-form ref="form" :model="form" label-width="120px">
        <el-form-item label="交易项目">
          <el-select v-model="formItemIndex" placeholder="请选择" @change="select()">
            <el-option
              v-for="item in list"
              :key="list.indexOf(item)"
              :label="item.name"
              :value="list.indexOf(item)"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="项目类型">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ form.item.type }}
          </div>
        </el-form-item>
        <el-form-item label="减排量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ form.item.reductionExpected }}
          </div>
        </el-form-item>
        <el-form-item label="价格/万元每吨">
          <el-input v-model="form.price" />
        </el-form-item>
        <el-form-item label="提交日期">
          <el-col :span="11">
            <el-date-picker v-model="form.display_time" type="date" placeholder="请选择日期" style="width: 100%;" />
          </el-col>
        </el-form-item>
        <el-form-item label="项目描述">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 200px;">
            {{ form.item.description }}
          </div>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="交易详情" :visible.sync="detailVisible" width="75%" top="20px">
      <el-form ref="detail" :model="detail" label-width="120px">
        <el-form-item label="交易项目">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detailItem.name }}
          </div>
        </el-form-item>
        <el-form-item label="项目类型">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detailItem.type }}
          </div>
        </el-form-item>
        <el-form-item label="联系人">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.contactPerson }}
          </div>
        </el-form-item>
        <el-form-item label="联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.contactWay }}
          </div>
        </el-form-item>
        <el-form-item label="所属公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detailItem.companyName }}
          </div>
        </el-form-item>
        <el-form-item label="减排量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detailItem.reductionExpected }}
          </div>
        </el-form-item>
        <el-form-item label="价格/万元每吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.price }}
          </div>
        </el-form-item>
        <el-form-item label="购买量/吨">
          <el-input v-model.number="detailItem.reductionBuy" type="number" placeholder="请输入" />
        </el-form-item>
        <el-form-item label="提交日期">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate(detail.display_time) }}
          </div>
        </el-form-item>
        <el-form-item label="项目描述">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 200px;">
            {{ detailItem.description }}
          </div>
        </el-form-item>
        <el-form-item label="相关材料">
          <el-upload
            ref="upload"
            class="upload-demo"
            action="https://file-unibhpdfgs-mp-a1ffa090-7d25-4c10-b9e8-0e387deba406.oss-cn-zhangjiakou.aliyuncs.com/"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :file-list="detailItem.fileList"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onTrans">交易</el-button>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="交易详情" :visible.sync="transVisible" width="75%" top="20px">
      <el-form ref="trans" :model="trans" label-width="120px">
        <el-form-item label="交易项目">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ transItem.name }}
          </div>
        </el-form-item>
        <el-form-item label="项目类型">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ transItem.type }}
          </div>
        </el-form-item>
        <el-form-item label="买方公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.buyer }}
          </div>
        </el-form-item>
        <el-form-item label="买方联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.buyerContact }}
          </div>
        </el-form-item>
        <el-form-item label="卖方公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.seller }}
          </div>
        </el-form-item>
        <el-form-item label="卖方联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.sellerContact }}
          </div>
        </el-form-item>
        <el-form-item label="购买量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ transItem.reductionBuy }}
          </div>
        </el-form-item>
        <el-form-item label="价格/万元每吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ trans.price }}
          </div>
        </el-form-item>
        <el-form-item label="交易日期">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate(trans.updateTime) }}
          </div>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="交易详情" :visible.sync="myVisible" width="75%" top="20px">
      <el-form ref="my" :model="my" label-width="120px">
        <el-form-item label="交易项目">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ myItem.name }}
          </div>
        </el-form-item>
        <el-form-item label="项目类型">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ myItem.type }}
          </div>
        </el-form-item>
        <el-form-item label="联系人">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.contactPerson }}
          </div>
        </el-form-item>
        <el-form-item label="联系方式">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.contactWay }}
          </div>
        </el-form-item>
        <el-form-item label="所属公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ myItem.companyName }}
          </div>
        </el-form-item>
        <el-form-item label="减排量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ myItem.reductionExpected }}
          </div>
        </el-form-item>
        <el-form-item label="价格/万元每吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ my.price }}
          </div>
        </el-form-item>
        <el-form-item label="提交日期">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate(my.display_time) }}
          </div>
        </el-form-item>
        <el-form-item label="项目描述">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 200px;">
            {{ myItem.description }}
          </div>
        </el-form-item>
        <el-form-item label="相关材料">
          <el-upload
            ref="upload"
            class="upload-demo"
            action="https://file-unibhpdfgs-mp-a1ffa090-7d25-4c10-b9e8-0e387deba406.oss-cn-zhangjiakou.aliyuncs.com/"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :file-list="myItem.fileList"
          />
        </el-form-item>
        <el-form-item>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import SearchButton from '@/layout/components/SearchButton.vue'
import { mapGetters } from 'vuex'

export default {
  name: 'CCERTrans',
  components: {
    SearchButton
  },
  data() {
    return {
      detail: {},
      detailItem: {},
      detailId: 0,
      trans: {},
      transItem: {},
      transId: 0,
      my: {},
      myItem: {},
      myId: 0,
      formTarget: '', // 填写上传项目表单时，选择的目标对象
      type: ['能源工业',
        '能源分配',
        '能源需求',
        '制造业',
        '化学工业',
        '建筑',
        '交通运输',
        '采矿/矿产品生产',
        '金属生产',
        '燃料逸出性排放',
        '卤烃与六氟化硫的生产和使用过程中的逸出性排放',
        '溶剂使用',
        '废物处置',
        '造林与再造林',
        '农业'],
      status: ['交易完成', '挂牌'],
      queryCCER: {},
      active1: 'first',
      listLoading: false,
      form: {
        display_time: new Date(),
        price: '',
        contactPerson: '',
        contactWay: '',
        item: {
          name: '',
          type: '',
          reductionExpected: '',
          description: ''
        }
      },
      formItemIndex: null,
      dialogCCERVisible: false,
      detailVisible: false,
      transVisible: false,
      myVisible: false
    }
  },
  computed: {
    ...mapGetters({
      companyInfo: 'user',
      list: 'ccerList',
      listCCER: 'ccerData',
      listMy: 'ccerMy',
      listTrans: 'ccerTrans'
    })
  },
  created() {
  },
  mounted() {
    this.tran1Tab()
  },
  methods: {
    dateFormate2(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()
        // 时
        var hour = date.getHours()
        // 分
        var minute = date.getMinutes()
        // 秒
        var second = date.getSeconds()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        hour = hour > 9 ? hour : '0' + hour

        minute = minute > 9 ? minute : '0' + minute

        second = second > 9 ? second : '0' + second

        return year + '-' + month + '-' + strDate + ' ' + hour + ':' + minute + ':' + second
      }
    },
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        return year + '-' + month + '-' + strDate
      }
    },
    select() {
      this.form.item = this.list[this.formItemIndex]
    },
    toDetail(index, row) {
      this.detail = row
      this.detail.realPrice = this.detail.price
      this.detailItem = row.item
      this.detailId = index
      this.detailVisible = true
    },
    toMy(index, row) {
      this.my = row
      this.myItem = row.item
      this.myId = index
      this.myVisible = true
    },
    toTrans(index, row) {
      this.trans = row
      this.transItem = row.item
      this.transId = index
      this.transVisible = true
    },
    onTrans() {
      var tran = this.detail
      tran.item = this.detailItem
      tran['updateTime'] = new Date()
      tran['seller'] = tran.item.companyName
      tran['sellerContact'] = tran.contactWay
      tran['buyer'] = this.companyInfo.companyName
      tran['buyerContact'] = this.companyInfo.contactWay
      var red = tran.item.reductionExpected - tran.item.reductionBuy
      console.log(red)
      if (red < 0) {
        this.$message({
          message: '超出最大出售量',
          type: 'error'
        })
      } else {
        if (red === 0) {
          this.listCCER.splice(this.detailId, 1)
          console.log(1)
        } else {
          this.listCCER[this.detailId].item.reductionExpected = red
          console.log(2)
        }
        console.log(3)
        this.listTrans.push(JSON.parse(JSON.stringify(tran)))
        console.log(this.listTrans)
        this.$store.dispatch('ccerTransSet', this.listTrans)
        this.list.push(JSON.parse(JSON.stringify(tran.item)))
        this.$store.dispatch('ccerListSet', this.list)
        this.$store.dispatch('ccerDataSet', this.listCCER)
        this.$message({
          message: '交易成功',
          type: 'success'
        })
        tran = null
        this.detailVisible = false
      }
    },
    onSubmit() {
      const item = this.form
      item.contactPerson = this.companyInfo.contactPerson
      item.contactWay = this.companyInfo.contactWay
      item.item.companyName = this.companyInfo.companyName
      this.listCCER.push(JSON.parse(JSON.stringify(item)))
      this.listMy.push(JSON.parse(JSON.stringify(item)))
      this.$store.dispatch('ccerDataSet', this.listCCER)
      this.$store.dispatch('ccerMySet', this.listMy)
      this.$message({
        message: '创建交易成功！',
        type: 'success'
      })
      this.dialogCCERVisible = false
    },
    onCancel() {
      this.dialogCCERVisible = false
      this.detailVisible = false
      this.myVisible = false
    },
    handleClick(tab) {
      localStorage.setItem('tran_1_tab', tab.name)
    },
    tran1Tab() {
      if (localStorage.getItem('tran_1_tab') != null) {
        this.active1 = localStorage.getItem('tran_1_tab')
      }
    },
    addHandle() {
      // 登记相关代码
      this.dialogCCERVisible = true
    },
    searchHandle() {
      // 查询相关代码
    },
    resetHandle() {
      // 重置条件相关代码
    }
  }
}
</script>

<style lang="scss" scoped>
 .text-disabled >>> .el-input__inner {
  -webkit-text-fill-color: #000502; //修改输入框文字颜色
  color:#000502 !important;
  font-size: large;
  font-weight: bolder;
}
</style>
