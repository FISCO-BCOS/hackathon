<template>
  <div class="app-container">
    <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
      <el-tab-pane label="CCER项目" name="first">
        <SearchButton :no-more="true" @searchHandle="searchHandle" @resetHandle="resetHandle" @addHandle="addHandle">
          <el-form-item label="项目类型">
            <el-select v-model="queryParams.type" placeholder="请选择">
              <el-option
                v-for="item in type"
                :key="item"
                :label="item"
                :value="item"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="减排量下限" style="width: 200px;">
            <el-input
              v-model.number="queryParams.amountLow"
              type="number"
              placeholder="请输入"
              style="width: 100px;"
            />
          </el-form-item>
          <el-form-item label="减排量上限" style="width: 200px;">
            <el-input v-model.trim="queryParams.amountHigh" type="number" placeholder="请输入" style="width: 100px;" />
          </el-form-item>
          <!-- 需要折叠的查询条件，放在more插槽里即可 -->
          <!-- 如果是不需要显示更多查询，就在SearchButton传多一个变量 :no-more="true" -->
          <template #more>
            <el-form-item label="任务名称">
              <el-input v-model.trim="queryParams.strategyName" placeholder="请输入" clearable />
            </el-form-item>
            <el-form-item label="任务编码">
              <el-input v-model.trim="queryParams.taskNo" placeholder="请输入" clearable />
            </el-form-item>
            <el-form-item label="任务名称">
              <el-input v-model.trim="queryParams.strategyName" placeholder="请输入" clearable />
            </el-form-item>
          </template>
        </SearchButton>
        <el-table
          v-loading="listLoading"
          :data="list"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
        >
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="项目名称">
            <template slot-scope="scope">
              {{ scope.row.name }}
            </template>
          </el-table-column>
          <el-table-column label="项目类型" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.type }}</span>
            </template>
          </el-table-column>
          <el-table-column label="预计年减排量（吨）" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row.reductionExpected }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="开工时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate(scope.row.date1) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="110" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toDetail(scope.$index, scope.row)"
              >查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="待审项目" name="second">
        <el-table
          v-loading="listLoading"
          :data="ccerJud"
          element-loading-text="Loading"
          border
          stripe
          fit
          highlight-current-row
        >
          <el-table-column align="center" label="ID" width="95">
            <template slot-scope="scope">
              {{ scope.$index }}
            </template>
          </el-table-column>
          <el-table-column label="项目名称">
            <template slot-scope="scope">
              {{ scope.row.name }}
            </template>
          </el-table-column>
          <el-table-column label="项目类型" width="110" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.type }}</span>
            </template>
          </el-table-column>
          <el-table-column label="预计年减排量（吨）" width="110" align="center">
            <template slot-scope="scope">
              {{ scope.row.reductionExpected }}
            </template>
          </el-table-column>
          <el-table-column align="center" prop="created_at" label="开工时间" width="200">
            <template slot-scope="scope">
              <i class="el-icon-time" />
              <span>{{ dateFormate(scope.row.date1) }}</span>
            </template>
          </el-table-column>
          <el-table-column class-name="operate" label="操作" width="200" align="center">
            <template slot-scope="scope">
              <el-button
                size="mini"
                @click="toDetail(scope.$index, scope.row)"
              >查看详情</el-button>
              <el-button
                size="mini"
                @click="setBack(scope.$index)"
              >撤回</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
    <el-dialog title="登记项目" :visible.sync="dialogVisible" width="70%" top="10px">
      <el-form ref="form" :model="form" label-width="130px">
        <el-form-item label="项目名称">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="所属公司">
          <el-input v-model="form.companyName" :disabled="true" />
        </el-form-item>
        <el-form-item label="项目类型">
          <el-select v-model="form.type" placeholder="请选择项目类型">
            <el-option
              v-for="item in type"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>
        <!-- <el-form-item label="减排气体种类">
          <el-radio-group v-model="form.resource">
            <el-radio label="CO₂" />
            <el-radio label="CH₄" />
            <el-radio label="其他：" />
          </el-radio-group>
          <el-input v-if="form.resource === '其他：'" v-model="form.gas" style="width: 20%;" />
        </el-form-item> -->
        <el-form-item label="预期年减排量/吨">
          <el-input v-model="form.reductionExpected" type="number" />
        </el-form-item>
        <el-form-item label="开工时间">
          <el-col :span="11">
            <el-date-picker v-model="form.date1" type="date" placeholder="请选择日期" style="width: 100%;" />
          </el-col>
        </el-form-item>
        <el-form-item label="项目描述">
          <el-input v-model="form.description" type="textarea" :rows="4" />
        </el-form-item>
        <el-form-item label="相关材料">
          <el-upload
            ref="upload"
            class="upload-demo"
            action="https://file-unibhpdfgs-mp-a1ffa090-7d25-4c10-b9e8-0e387deba406.oss-cn-zhangjiakou.aliyuncs.com/"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :file-list="form.fileList"
            :auto-upload="false"
          >
            <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <el-dialog title="项目详情" :visible.sync="detailVisible" width="70%" top="10px">
      <el-form ref="detail" :model="detail" label-width="130px">
        <el-form-item label="项目名称">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.name }}
          </div>
        </el-form-item>
        <el-form-item label="所属公司">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.companyName }}
          </div>
        </el-form-item>
        <el-form-item label="项目类型">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.type }}
          </div>
        </el-form-item>
        <!-- <el-form-item label="减排气体种类">
          {{ detail.resource }}
        </el-form-item> -->
        <el-form-item label="预期年减排量/吨">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ detail.reductionExpected }}
          </div>
        </el-form-item>
        <el-form-item label="开工时间">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding-left: 15px; height: 40px;">
            {{ dateFormate(detail.date1) }}
          </div>
        </el-form-item>
        <el-form-item label="项目描述">
          <div style="border-style:solid; border-radius: 4px; border-width: 1px; border-color: rgb(220, 225, 220); padding:0px 15px 0px 15px; height: 160px;">
            {{ detail.description }}
          </div>
        </el-form-item>
        <el-form-item label="相关材料">
          <el-upload
            ref="upload"
            class="upload-demo"
            action="https://file-unibhpdfgs-mp-a1ffa090-7d25-4c10-b9e8-0e387deba406.oss-cn-zhangjiakou.aliyuncs.com/"
            :on-preview="handlePreview"
            :on-remove="handleRemove"
            :file-list="detail.fileList"
          />
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import { getUser } from '@/utils/auth'
// import { getList } from '@/api/table'
import SearchButton from '@/layout/components/SearchButton.vue'

export default {
  name: 'CCERManage',
  components: {
    SearchButton
  },
  filters: {
    statusFilter(status) {
      const statusMap = {
        审核完毕: 'success'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      user: getUser(),
      fileList: [],
      queryParams: {},
      activeName: 'first',
      listLoading: false,
      type: ['能源工业',
        '能源分配',
        '能源需求',
        '制造业',
        '化学工业',
        '建筑',
        '交通运输',
        '采矿/矿产品生产',
        '金属生产',
        '燃料逸出性排放',
        '卤烃与六氟化硫的生产和使用过程中的逸出性排放',
        '溶剂使用',
        '废物处置',
        '造林与再造林',
        '农业'],
      form: {
        name: '',
        date1: '',
        type: '',
        companyName: '',
        reductionExpected: '',
        description: '',
        fileList: []
      },
      empty: {
        name: '',
        date1: '',
        type: '',
        companyName: '',
        reductionExpected: '',
        description: '',
        fileList: []
      },
      detail: {},
      dialogVisible: false,
      detailVisible: false
    }
  },
  computed: {
    ...mapGetters({
      companyName: 'name',
      list: 'ccerList',
      ccerJud: 'ccerJud'
    })
  },
  created() {
  },
  mounted() {
    this.ccerTab()
  },
  methods: {
    setBack(index) {
      this.ccerJud.splice(index, 1)
      this.$store.dispatch('ccerJudSet', this.ccerJud)
      this.$message({
        message: '已撤回该请求',
        type: 'success'
      })
    },
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        return year + '-' + month + '-' + strDate
      }
    },
    handleRemove(file, fileList) {
      console.log(file, fileList)
    },
    handlePreview(file) {
      console.log(file)
    },
    toDetail(index, row) {
      console.log(index, row)
      this.detail = row
      this.detailVisible = true
    },
    onSubmit() {
      const jud = this.form
      jud.fileList = [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
      this.ccerJud.push(jud)
      this.$store.dispatch('ccerJudSet', this.ccerJud)
      this.$message({
        message: '成功提交审核',
        type: 'success'
      })
      this.form = this.empty
      this.dialogVisible = false
    },
    onCancel() {
      this.form = this.empty
      this.dialogVisible = false
    },
    handleClick(tab) {
      localStorage.setItem('ccer_tab', tab.name)
    },
    ccerTab() {
      if (localStorage.getItem('ccer_tab') != null) {
        this.activeName = localStorage.getItem('ccer_tab')
      }
    },
    addHandle() {
      // 登记相关代码
      this.form.companyName = this.companyName
      this.dialogVisible = true
    },
    searchHandle() {
      // 查询相关代码
    },
    resetHandle() {
      // 重置条件相关代码
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
