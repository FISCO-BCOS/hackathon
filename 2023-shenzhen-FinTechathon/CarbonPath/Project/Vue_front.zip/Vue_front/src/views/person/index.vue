<template>
  <div class="person-container">
    <div class="person-text">姓名: {{ name }}</div>
    <div class="person-text">公司: {{ name }}</div>
    <div class="person-text">地址: {{ name }}</div>
    <div class="person-text">行业: {{ name }}</div>
    <div class="person-text">联系方式: {{ name }}</div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
// import { getUser } from '@/utils/auth'
export default {
  name: 'Person',
  computed: {
    ...mapGetters([
      'name'
    ])
  }
}
</script>

<style lang="scss" scoped>
.person {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 20px;
    line-height: 46px;
  }
}
</style>

