<template>
  <div class="app-container" style="height: 705px;">
    <SearchModel :no-more="true" @searchHandle="searchHandle" @resetHandle="resetHandle">
      <el-form-item label="需求量" style="width: 300px;">
        <el-input v-model.number="queryItem.amount" clearable type="number" placeholder="单位吨" />
      </el-form-item>
      <el-form-item label="预算">
        <el-input v-model.number="queryItem.cost" clearable type="number" placeholder="单位万元" />
      </el-form-item>
      <el-form-item label="CCER占比">
        <el-input v-model.number="queryItem.proportionOfCCER" clearable type="number" placeholder="百分比" />
      </el-form-item>
      <!-- 需要折叠的查询条件，放在more插槽里即可 -->
      <!-- 如果是不需要显示更多查询，就在SearchButton传多一个变量 :no-more="true" -->
      <!-- <template #more>
        <el-form-item label="价格下限">
          <el-input v-model.number="queryCar.priceLow" clearable type="number" placeholder="请输入" />
        </el-form-item>
        <el-form-item label="价格上限">
          <el-input v-model.number="queryCar.priceHigh" clearable type="number" placeholder="请输入" />
        </el-form-item>
      </template> -->
    </SearchModel>
    <el-table
      v-if="!tableShow"
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      stripe
      fit
      highlight-current-row
      height="600"
    >
      <el-table-column align="center" label="ID" width="95">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="公司名称">
        <template slot-scope="scope">
          {{ scope.row.companyName }}
        </template>
      </el-table-column>
      <el-table-column label="交易量/吨" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.transAmount }}</span>
        </template>
      </el-table-column>
      <el-table-column label="价格/元每吨" width="140" align="center">
        <template slot-scope="scope">
          {{ scope.row.price }}
        </template>
      </el-table-column>
      <el-table-column label="项目类型" width="140" align="center">
        <template slot-scope="scope">
          {{ scope.row.type }}
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="总价/元" width="200">
        <template slot-scope="scope">
          {{ scope.row.price*scope.row.transAmount }}
        </template>
      </el-table-column>
      <el-table-column class-name="operate" label="操作" width="110" align="center">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="toDetail(scope.$index, scope.row)"
          >查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-table
      v-if="tableShow"
      ref="table1"
      v-loading="listLoading"
      :data="list1"
      element-loading-text="Loading"
      border
      :summary-method="getSummaries1"
      show-summary
      sum-text="方案一"
      stripe
      fit
      highlight-current-row
    >
      <el-table-column align="center" label="ID" width="95">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="公司名称">
        <template slot-scope="scope">
          {{ scope.row.companyName }}
        </template>
      </el-table-column>
      <el-table-column label="价格/元每吨" width="140" align="center">
        <template slot-scope="scope">
          {{ scope.row.price }}
        </template>
      </el-table-column>
      <el-table-column label="项目类型" width="140" align="center">
        <template slot-scope="scope">
          {{ scope.row.type }}
        </template>
      </el-table-column>
      <el-table-column label="交易量/吨" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.transAmount }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="总价" width="200">
        <template slot-scope="scope">
          {{ scope.row.price*scope.row.transAmount }}
        </template>
      </el-table-column>
      <el-table-column class-name="operate" label="操作" width="110" align="center">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="toDetail(scope.$index, scope.row)"
          >查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-table
      v-if="tableShow"
      ref="table2"
      v-loading="listLoading"
      :data="list2"
      element-loading-text="Loading"
      border
      :summary-method="getSummaries2"
      show-summary
      sum-text="方案二"
      stripe
      fit
      highlight-current-row
    >
      <el-table-column align="center" label="ID" width="95">
        <template slot-scope="scope">
          {{ scope.$index }}
        </template>
      </el-table-column>
      <el-table-column label="公司名称">
        <template slot-scope="scope">
          {{ scope.row.companyName }}
        </template>
      </el-table-column>
      <el-table-column label="价格/元每吨" width="140" align="center">
        <template slot-scope="scope">
          {{ scope.row.price }}
        </template>
      </el-table-column>
      <el-table-column label="项目类型" width="140" align="center">
        <template slot-scope="scope">
          {{ scope.row.type }}
        </template>
      </el-table-column>
      <el-table-column label="交易量/吨" width="110" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.transAmount }}</span>
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="总价/元" width="200">
        <template slot-scope="scope">
          {{ scope.row.price*scope.row.transAmount }}
        </template>
      </el-table-column>
      <el-table-column class-name="operate" label="操作" width="110" align="center">
        <template slot-scope="scope">
          <el-button
            size="mini"
            @click="toDetail(scope.$index, scope.row)"
          >查看详情</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import SearchModel from '@/layout/components/SearchModel.vue'

function sortNum(a, b) {
  return a.price - b.price
}
export default {
  name: 'TransMate',
  components: {
    SearchModel
  },
  data() {
    return {
      tableShow: false,
      listLoading: false,
      active: 'first',
      queryItem: {
        amount: 0,
        cost: 0,
        proportionOfCCER: 0
      },
      list: [],
      list1: [],
      list2: []
    }
  },
  computed: {
    ...mapGetters({
      myCompany: 'name',
      companyInfo: 'user',
      listCCER: 'ccerData',
      listCar: 'carbonData'
    })
  },
  updated() {
    this.$nextTick(() => {
      this.$refs.table1.doLayout()
    })
  },
  created() {
    var i = 0
    for (i = 0; i < this.listCar.length; i++) {
      var itemCar = this.listCar[i]
      itemCar['type'] = '碳配额'
      this.list.push(JSON.parse(JSON.stringify(itemCar)))
    }
    for (i = 0; i < this.listCCER.length; i++) {
      var itemCCER = this.listCCER[i]
      itemCCER['companyName'] = itemCCER.item.companyName
      itemCCER['transAmount'] = itemCCER.item.reductionExpected
      itemCCER['type'] = 'CCER'
      this.list.push(JSON.parse(JSON.stringify(itemCCER)))
    }
    this.list.sort(sortNum)
  },
  methods: {
    getSummaries1(param) {
      const { columns, data } = param
      console.log(columns)
      console.log(data)
      const sums = ['方案一总价', '', '', '', '10000吨', '352560元']
      return sums
    },
    getSummaries2(param) {
      const { columns, data } = param
      console.log(columns)
      console.log(data)
      const sums = ['方案二总价', '', '', '', '10000吨', '280560元']
      return sums
    },
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()
        // 时
        var hour = date.getHours()
        // 分
        var minute = date.getMinutes()
        // 秒
        var second = date.getSeconds()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        hour = hour > 9 ? hour : '0' + hour

        minute = minute > 9 ? minute : '0' + minute

        second = second > 9 ? second : '0' + second

        return year + '-' + month + '-' + strDate + ' ' + hour + ':' + minute + ':' + second
      }
    },
    searchHandle() {
      // 查询相关代码
      if (this.queryItem.amount === 0 || this.queryItem.cost === 0) {
        this.$message({
          message: '请输入确切的预算与需求量',
          type: 'error'
        })
      } else {
        this.list1 = [{
          companyName: '维多能源有限公司',
          price: 20,
          transAmount: 1000,
          type: 'CCER'
        }, {
          companyName: '和路雪（中国）有限公司',
          price: 26,
          transAmount: 2360,
          type: '碳配额'
        }, {
          companyName: '富泰京精密电子有限公司',
          price: 30,
          transAmount: 3640,
          type: '碳配额'
        }, {
          companyName: '百度云计算技术(北京)有限公司',
          price: 54,
          transAmount: 3000,
          type: '碳配额'
        }]
        this.list2 = [{
          companyName: '维多能源有限公司',
          price: 20,
          transAmount: 1000,
          type: 'CCER'
        }, {
          companyName: '和路雪（中国）有限公司',
          price: 26,
          transAmount: 2360,
          type: '碳配额'
        }, {
          companyName: '富泰京精密电子有限公司',
          price: 30,
          transAmount: 6640,
          type: '碳配额'
        }]
        this.tableShow = true
      }
    },
    resetHandle() {
      // 重置条件相关代码
      this.tableShow = false
      this.queryItem = {
        amount: 0,
        cost: 0,
        proportionOfCCER: 0
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.carbon {
  &-container {
    margin: 30px;
    display: flex;
    flex-wrap: wrap;
  }
  &-text {
    border-radius: 4px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px;
  }
}
</style>
