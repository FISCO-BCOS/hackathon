<template>
  <div class="app-container">
    <div class="carbon-container">
      <div class="carbon-text">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.carbonAmount }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年分配碳配额/吨</div>
      </div>
      <div class="carbon-text">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.sellAmount }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年购买碳配额/吨</div>
      </div>
      <div class="carbon-text">
        <div style="font-size: 25px; margin: 5px;">{{ companyInfo.buyAmount }}</div>
        <div style="font-size: 10px; margin: 5px; color: gray">2023年出售碳配额/吨</div>
      </div>
    </div>
    <div
      style="border-radius: 4px;
      margin: 10px;
      padding-top: 5px;
      box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
      background-color: white;
      height: 550px;"
    >
      <el-tabs v-model="active" type="card" style="margin: 10px;" @tab-click="handleClick">
        <el-tab-pane label="购买记录" name="first">
          <el-table
            v-loading="listLoading"
            :data="listSell"
            element-loading-text="Loading"
            border
            fit
            highlight-current-row
          >
            <el-table-column label="卖方公司">
              <template slot-scope="scope">
                {{ scope.row.seller }}
              </template>
            </el-table-column>
            <el-table-column label="交易量（吨）" width="110" align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.transAmount }}</span>
              </template>
            </el-table-column>
            <el-table-column label="成交价格（元/吨）" width="150" align="center">
              <template slot-scope="scope">
                {{ scope.row.realPrice }}
              </template>
            </el-table-column>
            <el-table-column label="联系人" width="110" align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.contactPerson }}</span>
              </template>
            </el-table-column>
            <el-table-column label="联系方式" width="150" align="center">
              <template slot-scope="scope">
                {{ scope.row.contactWay }}
              </template>
            </el-table-column>
            <el-table-column label="成交时间" width="110" align="center">
              <template slot-scope="scope">
                {{ dateFormate(scope.row.updateTime) }}
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="出售记录" name="second">
          <el-table
            v-loading="listLoading"
            :data="listBuy"
            element-loading-text="Loading"
            border
            fit
            highlight-current-row
          >
            <el-table-column label="买方公司">
              <template slot-scope="scope">
                {{ scope.row.buyer }}
              </template>
            </el-table-column>
            <el-table-column label="交易量（吨）" width="110" align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.transAmount }}</span>
              </template>
            </el-table-column>
            <el-table-column label="成交价格（元/吨）" width="150" align="center">
              <template slot-scope="scope">
                {{ scope.row.realPrice }}
              </template>
            </el-table-column>
            <el-table-column label="联系人" width="110" align="center">
              <template slot-scope="scope">
                <span>{{ scope.row.contactPerson }}</span>
              </template>
            </el-table-column>
            <el-table-column label="联系方式" width="150" align="center">
              <template slot-scope="scope">
                {{ scope.row.contactWay }}
              </template>
            </el-table-column>
            <el-table-column label="成交时间" width="110" align="center">
              <template slot-scope="scope">
                {{ dateFormate(scope.row.updateTime) }}
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'CarbonManage',
  data() {
    return {
      listLoading: false,
      active: 'first'
    }
  },
  computed: {
    ...mapGetters({
      companyInfo: 'user',
      listSell: 'sell',
      listBuy: 'buy'
    })
  },
  created() {
    var amount1 = 0
    var amount2 = 0
    this.listBuy.forEach(element => {
      amount1 += parseFloat(element.transAmount)
    })
    this.listSell.forEach(element => {
      amount2 += parseFloat(element.transAmount)
    })
    this.companyInfo.buyAmount = parseFloat(amount1).toFixed(3)
    this.companyInfo.sellAmount = parseFloat(amount2).toFixed(3)
    this.$store.dispatch('userSet', this.companyInfo)
  },
  methods: {
    dateFormate(date) {
      if (date) {
        // 年
        var year = date.getFullYear()
        // 月
        var month = date.getMonth() + 1
        // 日
        var strDate = date.getDate()
        // 时
        var hour = date.getHours()
        // 分
        var minute = date.getMinutes()
        // 秒
        var second = date.getSeconds()

        month = month > 9 ? month : '0' + month

        strDate = strDate > 9 ? strDate : '0' + strDate

        hour = hour > 9 ? hour : '0' + hour

        minute = minute > 9 ? minute : '0' + minute

        second = second > 9 ? second : '0' + second

        return year + '-' + month + '-' + strDate + ' ' + hour + ':' + minute + ':' + second
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.carbon {
  &-container {
    display: flex;
    flex-wrap: wrap;
  }
  &-text {
    border-radius: 4px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 200px;
    height: 75px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 10px;
    background-color: white;
  }
}
</style>
