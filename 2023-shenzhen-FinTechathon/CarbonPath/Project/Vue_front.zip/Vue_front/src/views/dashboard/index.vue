<template>
  <div class="app-container">
    <div class="dashboard-container">
      <div
        class="dashboard-text"
        style="margin: 10px auto 10px 10px; display: flex; flex-direction: row;"
        @mouseenter="enter(1)"
        @mouseleave="leave(1)"
        @click="select(1)"
      >
        <transition mode="out-in">
          <el-image v-if="transShow" key="trans1" :src="require('../../images/form_fill.png')" style="height: 80px; width: 80px; margin: 20px;" />
          <el-image v-else key="trans2" :src="require('../../images/form.png')" style="height: 80px; width: 80px; margin: 20px;" />
        </transition>
        <div style="display: flex; flex-direction: column; justify-content: center; margin: 0px 20px 0px auto;">
          <div style="font-size: 35px; margin: 5px;">{{ amounts[6] }}</div>
          <div style="font-size: 20px; margin: 5px; color: gray">当日交易总量/件</div>
        </div>
      </div>
      <div
        class="dashboard-text"
        style="margin: 10px auto 10px auto; display: flex; flex-direction: row;"
        @mouseenter="enter(2)"
        @mouseleave="leave(2)"
        @click="select(2)"
      >
        <transition mode="out-in">
          <el-image v-if="userShow" key="user1" :src=" require('../../images/friend_fill.png')" style="height: 80px; width: 80px; margin: 20px;" />
          <el-image v-else key="user2" :src=" require('../../images/friend.png')" style="height: 80px; width: 80px; margin: 20px;" />
        </transition>
        <div style="display: flex; flex-direction: column; justify-content: center; margin: 0px 20px 0px auto;">
          <div style="font-size: 35px; margin: 5px;">{{ users[6] }}</div>
          <div style="font-size: 20px; margin: 5px; color: gray">当前在线用户数/人</div>
        </div>
      </div>
      <div
        class="dashboard-text"
        style="margin: 10px 10px 10px auto; display: flex; flex-direction: row;"
        @mouseenter="enter(3)"
        @mouseleave="leave(3)"
        @click="select(3)"
      >
        <transition mode="out-in">
          <el-image v-if="priceShow" key="price1" :src="require('../../images/recharge_fill.png')" style="height: 80px; width: 80px; margin: 20px;" />
          <el-image v-else key="price2" :src="require('../../images/recharge.png')" style="height: 80px; width: 80px; margin: 20px;" />
        </transition>
        <div style="display: flex; flex-direction: column; justify-content: center; margin: 0px 20px 0px auto;">
          <div style="font-size: 35px; margin: 5px;">{{ prices[6] }}</div>
          <div style="font-size: 20px; margin: 5px; color: gray">当日成交均价/万元</div>
        </div>
      </div>
    </div>
    <div style="display: flex;flex-wrap: wrap; margin: 10px 0px 10px 0px;">
      <div style="background-color: white; width: 48%; margin: 10px; padding: 10px; border-radius: 4px; box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);">
        <el-table
          v-loading="listLoading"
          :data="list"
          element-loading-text="Loading"
          border
          fit
          highlight-current-row
          height="450"
        >
          <el-table-column align="center" label="日期">
            <template slot-scope="scope">
              {{ scope.row.date }}
            </template>
          </el-table-column>
          <el-table-column label="交易总量/件" align="center">
            <template slot-scope="scope">
              {{ scope.row.amount }}
            </template>
          </el-table-column>
          <el-table-column label="在线用户数/人" align="center">
            <template slot-scope="scope">
              <span>{{ scope.row.user }}</span>
            </template>
          </el-table-column>
          <el-table-column label="交易均价/万元" align="center">
            <template slot-scope="scope">
              {{ scope.row.price }}
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="chart_card_right">
        <div id="chart_1" style="width: 100%; height: 400px;" />
        <div style="font-size: 15px; color: gray; text-align: center;">{{ chartTitle }}</div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts/core'
import { TooltipComponent, GridComponent } from 'echarts/components'
import { LineChart, BarChart } from 'echarts/charts'
import { UniversalTransition } from 'echarts/features'
import { CanvasRenderer } from 'echarts/renderers'

echarts.use([GridComponent, LineChart, CanvasRenderer,
  UniversalTransition, TooltipComponent, GridComponent, BarChart, CanvasRenderer])
var liner_1
export default {
  name: 'Dashboard',
  data() {
    return {
      linerChart: [
        {
          name: '交易数',
          data: [],
          type: 'line',
          smooth: true
        }
      ],
      chosen: 1,
      transShow: false,
      userShow: false,
      priceShow: false,
      list: [],
      date: [],
      amounts: [],
      users: [],
      prices: [],
      listLoading: false,
      chartTitle: '系统交易总量（近十日）'
    }
  },
  created() {
    const tarTime = new Date(new Date().getTime() - (6 * 24 * 60 * 60 * 1000))
    var time = null
    for (var i = 0; i < 10; i++) {
      time = this.dateFormat(new Date(tarTime.getTime() + (i * 24 * 60 * 60 * 1000)))
      this.date.push(time)
      var amount = Math.floor(Math.random() * 300) + 100
      var user = Math.floor(Math.random() * 300) + 100
      var price = Math.floor(Math.random() * 3000) + 1000
      var item = {
        date: time,
        amount: amount,
        user: user,
        price: price
      }
      this.amounts.push(amount)
      this.users.push(user)
      this.prices.push(price)
      this.list.push(item)
    }
    this.select(this.chosen)
  },
  mounted() {
    liner_1 = echarts.init(document.getElementById('chart_1'))
    window.addEventListener('resize', function() {
      liner_1.resize()
    })
    liner_1.setOption(
      {
        tooltip: {
          trigger: 'axis'
        },
        xAxis: {
          type: 'category',
          name: '日期',
          data: this.date
        },
        yAxis: {
          type: 'value',
          name: '交易数/件'
        },
        series: [
          {
            name: '交易数',
            data: this.amounts,
            type: 'line',
            smooth: true,
            color: ['#00B26A']
          }
        ]
      }
    )
  },
  methods: {
    select(index) {
      this.chosen = index
      switch (index) {
        case 1:
          this.transShow = true
          this.userShow = false
          this.priceShow = false
          this.chartTitle = '系统交易总量（近十日）'
          liner_1.setOption({
            yAxis: {
              name: '交易数/件'
            },
            series: [{
              name: '交易数',
              data: this.amounts,
              color: ['#00B26A']
            }]
          })
          break
        case 2:
          this.transShow = false
          this.userShow = true
          this.priceShow = false
          this.chartTitle = '系统登录用户数（近十日）'
          liner_1.setOption({
            yAxis: {
              name: '用户数/件'
            },
            series: [{
              name: '用户数',
              data: this.users,
              color: ['#5470C6']
            }]
          })
          break
        case 3:
          this.transShow = false
          this.userShow = false
          this.priceShow = true
          this.chartTitle = '平均交易金额（近十日）'
          liner_1.setOption({
            yAxis: {
              name: '金额/万元'
            },
            series: [{
              name: '金额',
              data: this.prices,
              color: ['#D4237A']
            }]
          })
          break
      }
      console.log(this.linerChart)
    },
    enter(index) {
      if (index !== this.chosen) {
        switch (index) {
          case 1:
            this.transShow = true
            break
          case 2:
            this.userShow = true
            break
          case 3:
            this.priceShow = true
            break
        }
      }
    },
    leave(index) {
      if (index !== this.chosen) {
        switch (index) {
          case 1:
            this.transShow = false
            break
          case 2:
            this.userShow = false
            break
          case 3:
            this.priceShow = false
            break
        }
      }
    },
    dateFormat(date) { // date为中国标准时间:例 new Date()结果的格式
      var month = date.getMonth() + 1
      if (month < 10) {
        month = '0' + month.toString()
      } else {
        month = month.toString()
      }
      var day = date.getDate()
      if (day < 10) {
        day = '0' + day.toString()
      } else {
        day = day.toString()
      }
      return month + '-' + day // 返回格式为06-15
    }
  }
}
</script>

<style lang="scss" scoped>
.chart_card_left {
  width: 48%;
  margin: 10px auto 10px 10px;
  padding: 10px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  background-color: white;
}
.chart_card_right {
  width: 48%;
  justify-self: end;
  margin: 10px 10px 10px auto;
  padding: 10px;
  border-radius: 4px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  background-color: white;
}
.dashboard {
  &-container {
    display: flex;
    flex-wrap: wrap;
  }
  &-text {
    background-color: white;
    border-radius: 4px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    width: 30%;
    padding: 5px;
    margin: 10px;
  }
}
.v-enter,
.v-leave-to {
  opacity: 0;
}

.v-enter-active,
.v-leave-acitve {
  transition: opacity 1s;
}
</style>
