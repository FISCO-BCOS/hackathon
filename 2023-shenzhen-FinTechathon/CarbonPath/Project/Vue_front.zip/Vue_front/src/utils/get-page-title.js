import defaultSettings from '@/settings'

const title = defaultSettings.title || '基于区块链的碳资产管理与可信交易平台'

export default function getPageTitle(pageTitle) {
  if (pageTitle) {
    return `${pageTitle} - ${title}`
  }
  return `${title}`
}
