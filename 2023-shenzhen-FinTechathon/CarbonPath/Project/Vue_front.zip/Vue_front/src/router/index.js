import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },

  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
  // 用户版
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: '主页',
      component: () => import('@/views/dashboard/index'),
      meta: { title: '主页', icon: 'dashboard' }
    }]
  },

  {
    path: '/trans',
    component: Layout,
    redirect: '/trans/carbon',
    name: '碳资产交易',
    meta: { title: '碳资产交易', icon: 'trans' },
    children: [
      {
        path: 'carbon',
        name: '碳配额交易',
        component: () => import('@/views/carbon-trans/index'),
        meta: { title: '碳配额交易', icon: 'transaction' }
      },
      {
        path: 'ccer',
        name: 'CCER交易',
        component: () => import('@/views/ccer-trans/index'),
        meta: { title: 'CCER交易', icon: 'ccer' }
      },
      {
        path: 'mate',
        name: '交易撮合',
        component: () => import('@/views/trans-mate/index'),
        meta: { title: '交易撮合', icon: 'transaction' }
      }
    ]
  },

  {
    path: '/ccer',
    component: Layout,
    redirect: '/ccer/regis',
    name: 'CCER管理',
    meta: { title: 'CCER管理', icon: 'ccer' },
    children: [
      {
        path: 'regis',
        name: '项目登记',
        component: () => import('@/views/ccer-manage/index'),
        meta: { title: '项目登记', icon: 'ccer' }
      },
      {
        path: 'reduction',
        name: '减排量上报',
        component: () => import('@/views/ccer-reduction/index'),
        meta: { title: '减排量上报', icon: 'ccer' }
      }
    ]
  },

  {
    path: '/carbon',
    component: Layout,
    redirect: '/carbon/mangement',
    name: '碳配额管理',
    meta: { title: '碳配额管理', icon: 'carbon' },
    children: [
      {
        path: 'mangement',
        name: '碳配额详情',
        component: () => import('@/views/carbon-manage/index'),
        meta: { title: '碳配额详情', icon: 'carbon' }
      },
      {
        path: 'record',
        name: '碳排放核算',
        component: () => import('@/views/carbon-record/index'),
        meta: { title: '碳排放核算', icon: 'carbon' }
      },
      {
        path: 'clear',
        name: '碳配额清缴',
        component: () => import('@/views/carbon-clearance/index'),
        meta: { title: '碳配额清缴', icon: 'carbon' }
      }
    ]
  },

  {
    path: '/analysis',
    component: Layout,
    redirect: '/analysis/prediction',
    name: '碳数据分析',
    meta: { title: '碳数据分析', icon: 'analysis' },
    children: [
      {
        path: 'prediction',
        name: '碳排放预测分析',
        component: () => import('@/views/analysis-prediction/index'),
        meta: { title: '碳排放预测分析', icon: 'analysis' }
      },
      {
        path: 'cost',
        name: '碳排放成本分析',
        component: () => import('@/views/analysis-cost/index'),
        meta: { title: '碳排放成本分析', icon: 'analysis' }
      }
    ]
  },

  {
    path: '/manage',
    component: Layout,
    redirect: '/manage/person',
    name: '账户管理',
    alwaysShow: true,
    meta: { title: '账户管理', icon: 'manage' },
    children: [
      {
        path: 'person',
        name: '个人信息',
        component: () => import('@/views/person/index'),
        meta: { title: '个人信息', icon: 'person' }
      }
    ]
  },

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
