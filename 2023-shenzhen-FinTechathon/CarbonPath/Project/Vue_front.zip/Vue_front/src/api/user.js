import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/vue-admin-template/user/login',
    method: 'post',
    data
  })
}

// export function login(data) {
//   return this.axios.post('/vue-admin-template/user/login', {
//     params: {
//       data
//     }
//   })
// }

// export function login(data) {
//   return request({
//     url: '/test/login2',
//     method: 'get',
//     params: { data }
//   })
// }

export function getInfo(token) {
  return request({
    url: '/vue-admin-template/user/info',
    method: 'get',
    params: { token }
  })
}

// export function getInfo(token) {
//   return this.axios.get('/vue-admin-template/user/info', {
//     params: {
//       token
//     }
//   })
// }

// export function getInfo(token) {
//   return request({
//     url: 'test/info',
//     method: 'get',
//     params: { token }
//   })
// }

export function logout() {
  return request({
    url: '/vue-admin-template/user/logout',
    method: 'post'
  })
}
