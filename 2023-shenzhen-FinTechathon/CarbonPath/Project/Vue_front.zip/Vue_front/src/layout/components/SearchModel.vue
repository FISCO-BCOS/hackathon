<template>
  <el-form inline class="clearfix" label-width="90px" size="mini" style="background-color: white; padding-top: 10px;">
    <el-row class="leftSear" :style="`width:${show ? '100%' : ''};float:left`">
      <slot />
      <el-form-item v-show="show" style="float: right;">
        <el-button type="primary" icon="el-icon-search" size="mini" @click="searchClick">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetClick">重置</el-button>
        <el-button v-if="!noMore" type="text" size="mini" @click="moreClick">更多
          <i :class="show ? 'el-icon-arrow-down' : 'el-icon-arrow-up'" />
        </el-button>
      </el-form-item>
    </el-row>
    <el-row v-show="!show" :class="!show ? 'btnRow' : 'unBtnRow'">
      <slot name="more" />
      <el-form-item style="float: right;margin: 0;">
        <el-button type="primary" icon="el-icon-search" size="mini" @click="searchClick">查询</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetClick">重置</el-button>
        <el-button v-if="!noMore" type="text" size="mini" @click="moreClick">收起
          <i :class="show ? 'el-icon-arrow-down' : 'el-icon-arrow-up'" />
        </el-button>
      </el-form-item>
    </el-row>
  </el-form>
</template>
<script>
export default {
  props: {
    noMore: {
      type: Boolean
    }
  },
  data() {
    return {
      show: false
    }
  },
  mounted() {
    this.$nextTick(function() {
      this.moreClick()
    })
  },
  methods: {
    moreClick() {
      this.show = !this.show
    },
    searchClick() {
      this.$emit('searchHandle')
    },
    resetClick() {
      this.$emit('resetHandle')
    }
  }
}
</script>
<style scoped>
.btnRow {
  display: block;
}

.unBtnRow {
  display: none;
}
</style>
