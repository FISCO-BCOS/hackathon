import { login, logout } from '@/api/user'
import { getToken, setToken, removeToken, getUser, setUser, removeUser } from '@/utils/auth'
import { resetRouter } from '@/router'
import Axios from 'axios'

function randomDate(start, end) {
  if (start != null && end != null) {
    const _start = new Date(start).getTime()
    const _end = new Date(end).getTime()
    const differ = _end - _start
    const time_stamp = Math.random() * differ
    const time = _start + time_stamp
    // 格式化时间
    const datetime = new Date()
    datetime.setTime(time)
    return datetime
  } else {
    return '---'
  }
}

const getDefaultState = () => {
  return {
    token: getToken(),
    name: '',
    avatar: '',
    user: getUser(),
    // ccer政府审核页面所需数据
    ccerJudGovernment: [{
      name: '南非节能炉灶项目',
      status: '审核完毕',
      type: '能源工业',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '4520',
      description: '该炉灶项目计划向克鲁格到峡谷生物圈、沃特贝格市和北开普省以及南非其他地区的家庭分发400,000个高效、低排放木柴炉灶。' +
      '该项目采用Verra（一个全球公认认证机构，被南非政府批准为碳信用签发单位）批准的VMR0006--安装高效木柴炉灶的方法学，' +
      '依据 Verra 标准下规划类（Grouped Project）节能炉灶标准设计开发，产生的碳信用依据南非碳税法规定进行使用。' +
      '我们使用炉灶项目产生的碳信用来帮助为贫困农村社区提供炉灶供资金。' +
      '我们的节能炉灶在南非生产。',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }],
    ccerListGovernment: [{
      name: '社区畜牧业减碳项目',
      status: '审核完毕',
      type: '农业',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '430',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '惠罗水稻栽培项目',
      status: '审核完毕',
      type: '农业',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '1310',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '天津市工厂能耗优化项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '重庆商业中心建筑节能项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '新疆植树造林项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '北京市水稻栽培项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '西安市垃圾处理项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '威海市水产废品回收项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '天津市工厂能耗优化项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '南非节能炉灶项目',
      status: '审核完毕',
      type: '能源工业',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '4520',
      description: '该炉灶项目计划向克鲁格到峡谷生物圈、沃特贝格市和北开普省以及南非其他地区的家庭分发400,000个高效、低排放木柴炉灶。' +
      '该项目采用Verra（一个全球公认认证机构，被南非政府批准为碳信用签发单位）批准的VMR0006--安装高效木柴炉灶的方法学，' +
      '依据 Verra 标准下规划类（Grouped Project）节能炉灶标准设计开发，产生的碳信用依据南非碳税法规定进行使用。' +
      '我们使用炉灶项目产生的碳信用来帮助为贫困农村社区提供炉灶供资金。' +
      '我们的节能炉灶在南非生产。',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '聊城市工业废品回收项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '节能灯替换项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '维多能源有限公司',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }],
    // 已出售列表
    sellList: [{
      seller: '北京盛通印刷股份有限公司',
      contactPerson: '王武',
      contactWay: '516461@163.com',
      transAmount: 635.12,
      realPrice: 65,
      updateTime: new Date(2023, 5, 10)
    }, {
      seller: '北京博大开拓热力有限公司',
      contactPerson: '赵久',
      contactWay: '154612@163.com',
      transAmount: 2890.22,
      realPrice: 60,
      updateTime: new Date(2023, 5, 10)
    }],
    // 已购买列表
    buyList: [{
      buyer: '联华林德气体（北京）有限公司',
      contactPerson: '李翔',
      contactWay: '168466@163.com',
      transAmount: 365.12,
      realPrice: 65,
      updateTime: new Date(2023, 5, 10)
    }, {
      buyer: '北京恒长数码科技有限公司',
      contactPerson: '朱毅',
      contactWay: '435168@163.com',
      transAmount: 3890.22,
      realPrice: 60,
      updateTime: new Date(2023, 5, 10)
    }],
    // 碳排放列表
    emssionList: [{
      type: '原煤',
      consume: 0,
      emssion: 0,
      conversionFactor: 1.981
    }, {
      type: '洗精煤',
      consume: 0,
      emssion: 0,
      conversionFactor: 2.405
    }, {
      type: '焦炭',
      consume: 0,
      emssion: 0,
      conversionFactor: 2.860
    }, {
      type: '天然气',
      consume: 0,
      emssion: 0,
      conversionFactor: 21.622
    }, {
      type: '汽油',
      consume: 0,
      emssion: 0,
      conversionFactor: 2.925
    }, {
      type: '柴油',
      consume: 0,
      emssion: 0,
      conversionFactor: 3.096
    }, {
      type: '脱硫剂（K2CO3）',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.318
    }, {
      type: '脱硫剂（BaCO3）',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.223
    }, {
      type: '脱硫剂（MgCO3）',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.522
    }, {
      type: '脱硫剂（CaCO3）',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.440
    }],
    redList: [{
      type: '水稻',
      consume: 0,
      emssion: 0,
      conversionFactor: 3.208
    }, {
      type: '小麦',
      consume: 0,
      emssion: 0,
      conversionFactor: 3.307
    }, {
      type: '大豆',
      consume: 0,
      emssion: 0,
      conversionFactor: 2.016
    }, {
      type: '草地',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.042
    }, {
      type: '湖泊',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.093
    }, {
      type: '滩地',
      consume: 0,
      emssion: 0,
      conversionFactor: 0.173
    }],
    // 碳配额历史交易
    carbonTrans: [],
    // 碳配额我的提交
    carbonMy: [],
    // ccer我的提交
    ccerMy: [],
    // 碳配额协商列表
    carbonTalk: [{
      seller: '北京邮电大学',
      sellerContact: '456712@163.com',
      buyer: '北京博大开拓热力有限公司',
      buyerContact: '955545@163.com',
      transAmount: 630,
      price: 50,
      realAmount: 600,
      realPrice: 40,
      updateTime: new Date()
    }],
    // 碳配额交易数据
    carbonData: [{
      companyName: '百度云计算技术(北京)有限公司',
      transAmount: 3000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: 54,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '北京国中生物科技有限公司',
      transAmount: 5600,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: 59,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '富泰京精密电子有限公司',
      transAmount: 6640,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: 30,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '和路雪（中国）有限公司',
      transAmount: 2360,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: 26,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '北京生物制品研究所有限责任公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '利乐包装有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '北京恒长数码科技有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '北京泰德制药股份有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '康宁显示科技（中国）有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: 'SMC（中国）有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '悦康药业集团有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }, {
      companyName: '中芯国际集成电路制造有限公司',
      transAmount: Math.floor(Math.random() * 3000) + 1000,
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 60,
      contactPerson: '庄世',
      contactWay: '468451@163.com'
    }],
    // ccer协商列表
    ccerTalk: [],
    // ccer历史交易
    ccerTrans: [],
    // ccer交易数据
    ccerData: [{
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '南非节能炉灶项目',
        status: '审核完毕',
        type: '能源工业',
        companyName: '维多能源有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: 4520,
        description: '该炉灶项目计划向克鲁格到峡谷生物圈、沃特贝格市和北开普省以及南非其他地区的家庭分发400,000个高效、低排放木柴炉灶。' +
      '该项目采用Verra（一个全球公认认证机构，被南非政府批准为碳信用签发单位）批准的VMR0006--安装高效木柴炉灶的方法学，' +
      '依据 Verra 标准下规划类（Grouped Project）节能炉灶标准设计开发，产生的碳信用依据南非碳税法规定进行使用。' +
      '我们使用炉灶项目产生的碳信用来帮助为贫困农村社区提供炉灶供资金。' +
      '我们的节能炉灶在南非生产。',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '北京市水稻栽培项目',
        status: '审核完毕',
        type: '农业',
        companyName: '北京国中生物科技有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '北京市垃圾处理项目',
        status: '审核完毕',
        type: '废物处置',
        companyName: '北京生物制品研究所有限责任公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '威海市水产废品回收项目',
        status: '审核完毕',
        type: '废物处置',
        companyName: '山东威海富强有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '新疆植树造林项目',
        status: '审核完毕',
        type: '造林与再造林',
        companyName: '新疆维泰开发建设(集团)股份有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '天津市工厂能耗优化项目',
        status: '审核完毕',
        type: '能源工业',
        companyName: '环晟新能源(天津)有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '聊城市工业废品回收项目',
        status: '审核完毕',
        type: '废物处置',
        companyName: '山东未蓝环保设备有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '重庆商业中心建筑节能项目',
        status: '审核完毕',
        type: '建筑',
        companyName: '重庆市电力公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: 'LNG公共交通替代柴油公交车项目',
        status: '审核完毕',
        type: '交通运输',
        companyName: '南宁公共交通有限责任公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}, {
      display_time: randomDate(new Date(2023, 5, 16), new Date()),
      price: Math.floor(Math.random() * 50) + 20,
      contactPerson: '魏勋',
      contactWay: '412114@163.com',
      item: {
        name: '节能灯替换项目',
        status: '审核完毕',
        type: '能源需求',
        companyName: '维多能源有限公司',
        date1: new Date(2023, 4, 16),
        reductionExpected: Math.floor(Math.random() * 3000) + 1000,
        description: '',
        fileList: [{
          name: '项目描述.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }, {
          name: '证明材料.pdf',
          url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
        }]
      }}],
    // ccer项目审核列表
    ccerJud: [],
    // ccer项目列表
    ccerList: [{
      name: '南非节能炉灶项目',
      status: '审核完毕',
      type: '能源工业',
      companyName: '北京邮电大学',
      date1: new Date(2023, 4, 16),
      reductionExpected: '4520',
      description: '该炉灶项目计划向克鲁格到峡谷生物圈、沃特贝格市和北开普省以及南非其他地区的家庭分发400,000个高效、低排放木柴炉灶。' +
      '该项目采用Verra（一个全球公认认证机构，被南非政府批准为碳信用签发单位）批准的VMR0006--安装高效木柴炉灶的方法学，' +
      '依据 Verra 标准下规划类（Grouped Project）节能炉灶标准设计开发，产生的碳信用依据南非碳税法规定进行使用。' +
      '我们使用炉灶项目产生的碳信用来帮助为贫困农村社区提供炉灶供资金。' +
      '我们的节能炉灶在南非生产。',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '社区畜牧业减碳项目',
      status: '审核完毕',
      type: '农业',
      companyName: '北京邮电大学',
      date1: new Date(2023, 4, 16),
      reductionExpected: '430',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '惠罗水稻栽培项目',
      status: '审核完毕',
      type: '农业',
      companyName: '北京邮电大学',
      date1: new Date(2023, 4, 16),
      reductionExpected: '1310',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }, {
      name: '宣城堆肥项目',
      status: '审核完毕',
      type: '废物处置',
      companyName: '北京邮电大学',
      date1: new Date(2023, 4, 16),
      reductionExpected: '2530',
      description: '',
      fileList: [{
        name: '项目描述.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: '证明材料.pdf',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }]
  }
}

const state = getDefaultState()

const mutations = {
  SET_CCER_LIST_GOVERNMENT: (state, list) => {
    state.ccerListGovernment = list
  },
  RESET_STATE: (state) => {
    Object.assign(state, getDefaultState())
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_USER: (state, user) => {
    state.user = user
  },
  SET_LIST: (state, list) => {
    state.emssionList = list
  },
  SET_LIST_red: (state, list) => {
    state.redList = list
  },
  SET_SELL: (state, list) => {
    state.sellList = list
  },
  SET_BUY: (state, list) => {
    state.buyList = list
  },
  SET_CCER_LIST: (state, list) => {
    state.ccerList = list
  },
  SET_CCER_JUD: (state, list) => {
    state.ccerJud = list
  },
  SET_CCER_JUD_GOVERNMENT: (state, list) => {
    state.ccerJudGovernment = list
  },
  SET_CCER_TRANS: (state, list) => {
    state.ccerTrans = list
  },
  SET_CCER_DATA: (state, list) => {
    state.ccerDATA = list
  },
  SET_CCER_MY: (state, list) => {
    state.ccerMy = list
  },
  SET_CCER_TALK: (state, list) => {
    state.ccerTalk = list
  },
  SET_CARBON_TRANS: (state, list) => {
    state.carbonTrans = list
  },
  SET_CARBON_DATA: (state, list) => {
    state.carbonData = list
  },
  SET_CARBON_MY: (state, list) => {
    state.carbonMy = list
  },
  SET_CARBON_TALK: (state, list) => {
    state.carbonTalk = list
  },
  GET_INFO: (state) => {
    return new Promise((resolve, reject) => {
      // 模拟数据
      Axios.get('/user/info\.*', {
        params: {
          token: state.token
        }
      // 实际链接
      // Axios.get('/test/showCompanyInfo', {
      //   params: {
      //     nameToQuery: state.token
      //   }
      }).then(response => {
        const info = response.data.data
        // const info = {
        //   roles: ['editor'],
        //   introduction: 'I am an editor',
        //   avatar: 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
        //   companyName: '北京邮电大学',
        //   carbonAmount: 55000,
        //   sellAmount: 0,
        //   buyAmount: 0,
        //   carbonEmssion: 0,
        //   contactPerson: '张三',
        //   contactWay: '123456@163.com'
        // }

        if (!info) {
          return reject('Verification failed, please Login again.')
        }

        const { companyName } = info
        state.user = info
        setUser(info)
        state.name = companyName
        state.avatar = 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif'
        resolve(info)
      }).catch(error => {
        reject(error)
      })
    })
  }
}

const actions = {
  tokenSet({ commit }, token) {
    const { username } = token
    return new Promise((resolve) => {
      commit('SET_TOKEN', username)
      setToken(username)
      resolve()
    })
  },
  // user login
  login({ commit }, userInfo) {
    const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      login({ username: username.trim(), password: password }).then(response => {
        const { data } = response
        // commit('SET_TOKEN', data.token)// token暂定为用户名
        // setToken(data.token)
        // resolve()
        if (data === 'Success') {
          commit('SET_TOKEN', username)// token暂定为用户名
          setToken(username)
          resolve()
        } else {
          this.$message({
            message: '登录错误',
            type: 'error'
          })
        }
      }).catch(error => {
        reject(error)
      })
    })
  },
  carbonTransSet({ commit }, list) {
    commit('SET_CARBON_TRANS', list)
  },
  carbonMySet({ commit }, list) {
    commit('SET_CARBON_MY', list)
  },
  carbonDataSet({ commit }, list) {
    commit('SET_CARBON_DATA', list)
  },
  carbonTalkSet({ commit }, list) {
    commit('SET_CARBON_TALK', list)
  },
  ccerMySet({ commit }, list) {
    commit('SET_CCER_MY', list)
  },
  ccerTalkSet({ commit }, list) {
    commit('SET_CCER_TALK', list)
  },
  ccerDataSet({ commit }, list) {
    commit('SET_CCER_DATA', list)
  },
  ccerTransSet({ commit }, list) {
    commit('SET_CCER_TRANS', list)
  },
  ccerJudSet({ commit }, list) {
    commit('SET_CCER_JUD', list)
  },
  ccerJudGovernmentSet({ commit }, list) {
    commit('SET_CCER_JUD_GOVERNMENT', list)
  },
  ccerListSet({ commit }, list) {
    commit('SET_CCER_LIST', list)
  },
  ccerListGovernmentSet({ commit }, list) {
    commit('SET_CCER_LIST_GOVERNMENT', list)
  },
  userSet({ commit }, userInfo) {
    commit('SET_USER', userInfo)
  },
  listSet({ commit }, list) {
    commit('SET_LIST', list)
  },
  redSet({ commit }, list) {
    commit('SET_LIST_RED', list)
  },
  sellSet({ commit }, list) {
    commit('SET_SELL', list)
  },
  buySet({ commit }, list) {
    commit('SET_BUY', list)
  },
  // get user info
  // getInfo({ commit, state }) {
  //   return new Promise((resolve, reject) => {
  //     // getInfo(state.token).then(response => {
  //     this.$axios.get('/vue-admin-template/user/info', state.token).then(response => {
  //       const info = response.data.info

  //       if (!info) {
  //         return reject('Verification failed, please Login again.')
  //       }

  //       const { name } = info
  //       commit('SET_USER', info)
  //       setUser(info)
  //       commit('SET_NAME', name)
  //       commit('SET_AVATAR', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif')
  //       resolve(info)
  //     }).catch(error => {
  //       reject(error)
  //     })
  //   })
  // },

  getInfo({ commit }) {
    commit('GET_INFO')
  },
  logout2({ commit, state }) {
    return new Promise((resolve, reject) => {
      removeToken() // must remove  token  first
      removeUser()
      resetRouter()
      commit('RESET_STATE')
      resolve()
    })
  },
  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        removeToken() // must remove  token  first
        removeUser()
        resetRouter()
        commit('RESET_STATE')
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      removeToken() // must remove  token  first
      commit('RESET_STATE')
      resolve()
    })
  },

  // remove user
  resetUser({ commit }) {
    return new Promise(resolve => {
      removeUser() // must remove  token  first
      commit('RESET_STATE')
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

