package org.example.TanLu_v3.Controller;

import org.example.TanLu_v3.service.EmissionAccountingService;
import org.example.TanLu_v3.utils.ParserTools;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("EmissionAccounting")
public class EmissionAccounting_Controller {
    @Autowired
    private EmissionAccountingService service;

    @GetMapping("DisplayMonthlyEmissions")
    public String get12Emissions() throws Exception {
        int size = 12;
        JSONArray Emissions = new JSONArray();
        List<Object> list1 = service._queryEmission().getReturnObject(); // Assume it returns a list of 12 elements

        for (int index = 0; index < size; index++) {
            JSONObject monthlyEmission = new JSONObject();

            // Check if it is the last month
            if (index == size - 1) {
                // Assuming the last element in list1 is a number and needs to be divided by 1000
                monthlyEmission.put("month"+(index + 1), ((Number) list1.get(index)).doubleValue() / 1000);
            } else {
                monthlyEmission.put("month"+(index + 1), list1.get(index));
            }


            Emissions.put(monthlyEmission);
        }
        return Emissions.toString();
    }

    @GetMapping("DisplayYearTotal")
    public int sumEmissions() throws Exception {
        String response = service._sumEmission().getValues();
        int returnValue = ParserTools.ExtractInt(response);
        System.out.println("size of entries is: " + returnValue);
        return returnValue;
    }
}

// http://localhost:8080/EmissionAccounting/DisplayYearTotal 展示该公司本年所有碳排放量
// http://localhost:8080/EmissionAccounting/DisplayMonthlyEmissions 展示该公司本年每月碳排放量
