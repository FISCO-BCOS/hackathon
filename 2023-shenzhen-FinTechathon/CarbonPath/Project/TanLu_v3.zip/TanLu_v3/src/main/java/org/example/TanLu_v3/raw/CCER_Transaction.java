package org.example.TanLu_v3.raw;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple2;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple5;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple6;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class CCER_Transaction extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405260006105145560006105155534801561001c57600080fd5b506115598061002c6000396000f300608060405260043610610078576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff1680630dba29d81461007d578063718d2371146102da5780637876414d14610465578063aee021b314610490578063b72c7ef21461062f578063e85be5b7146107bb575b600080fd5b34801561008957600080fd5b506100a8600480360381019080803590602001909291905050506108cd565b60405180806020018060200180602001806020018781526020018060200186810386528c818151815260200191508051906020019080838360005b838110156100fe5780820151818401526020810190506100e3565b50505050905090810190601f16801561012b5780820380516001836020036101000a031916815260200191505b5086810385528b818151815260200191508051906020019080838360005b83811015610164578082015181840152602081019050610149565b50505050905090810190601f1680156101915780820380516001836020036101000a031916815260200191505b5086810384528a818151815260200191508051906020019080838360005b838110156101ca5780820151818401526020810190506101af565b50505050905090810190601f1680156101f75780820380516001836020036101000a031916815260200191505b50868103835289818151815260200191508051906020019080838360005b83811015610230578082015181840152602081019050610215565b50505050905090810190601f16801561025d5780820380516001836020036101000a031916815260200191505b50868103825287818151815260200191508051906020019080838360005b8381101561029657808201518184015260208101905061027b565b50505050905090810190601f1680156102c35780820380516001836020036101000a031916815260200191505b509b50505050505050505050505060405180910390f35b3480156102e657600080fd5b50610463600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929080359060200190929190803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610cda565b005b34801561047157600080fd5b5061047a610e43565b6040518082815260200191505060405180910390f35b34801561049c57600080fd5b50610619600480360381019080803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929080359060200190929190803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290505050610e4e565b6040518082815260200191505060405180910390f35b34801561063b57600080fd5b5061065a60048036038101908080359060200190929190505050610fe8565b60405180868152602001806020018581526020018060200180602001848103845288818151815260200191508051906020019080838360005b838110156106ae578082015181840152602081019050610693565b50505050905090810190601f1680156106db5780820380516001836020036101000a031916815260200191505b50848103835286818151815260200191508051906020019080838360005b838110156107145780820151818401526020810190506106f9565b50505050905090810190601f1680156107415780820380516001836020036101000a031916815260200191505b50848103825285818151815260200191508051906020019080838360005b8381101561077a57808201518184015260208101905061075f565b50505050905090810190601f1680156107a75780820380516001836020036101000a031916815260200191505b509850505050505050505060405180910390f35b3480156107c757600080fd5b506107e6600480360381019080803590602001909291905050506112a7565b604051808060200180602001838103835285818151815260200191508051906020019080838360005b8381101561082a57808201518184015260208101905061080f565b50505050905090810190601f1680156108575780820380516001836020036101000a031916815260200191505b50838103825284818151815260200191508051906020019080838360005b83811015610890578082015181840152602081019050610875565b50505050905090810190601f1680156108bd5780820380516001836020036101000a031916815260200191505b5094505050505060405180910390f35b60608060608060006060610514548711151515610952576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f5472616e73616374696f6e20494420646f6573206e6f7420657869737400000081525060200191505060405180910390fd5b6101f48760648110151561096257fe5b016102588860648110151561097357fe5b016102bc8960648110151561098457fe5b016103208a60648110151561099557fe5b016103848b6064811015156109a657fe5b01546103e88c6064811015156109b857fe5b01858054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610a4e5780601f10610a2357610100808354040283529160200191610a4e565b820191906000526020600020905b815481529060010190602001808311610a3157829003601f168201915b50505050509550848054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610aea5780601f10610abf57610100808354040283529160200191610aea565b820191906000526020600020905b815481529060010190602001808311610acd57829003601f168201915b50505050509450838054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610b865780601f10610b5b57610100808354040283529160200191610b86565b820191906000526020600020905b815481529060010190602001808311610b6957829003601f168201915b50505050509350828054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610c225780601f10610bf757610100808354040283529160200191610c22565b820191906000526020600020905b815481529060010190602001808311610c0557829003601f168201915b50505050509250808054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610cbe5780601f10610c9357610100808354040283529160200191610cbe565b820191906000526020600020905b815481529060010190602001808311610ca157829003601f168201915b5050505050905095509550955095509550955091939550919395565b6000806105155414151515610d57576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260118152602001807f496e76616c6964207265636f726420494400000000000000000000000000000081525060200191505060405180910390fd5b610515549050866102bc82606481101515610d6e57fe5b019080519060200190610d82929190611488565b508561032082606481101515610d9457fe5b019080519060200190610da8929190611488565b508461038482606481101515610dba57fe5b0181905550836103e882606481101515610dd057fe5b019080519060200190610de4929190611488565b508261044c82606481101515610df657fe5b019080519060200190610e0a929190611488565b50816104b082606481101515610e1c57fe5b019080519060200190610e30929190611488565b5060006105158190555050505050505050565b600061051454905090565b600080606461051454101515610ecc576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f5472616e73616374696f6e206c696d697420726561636865640000000000000081525060200191505060405180910390fd5b6001610514540190506105146000815480929190600101919050555080600082606481101515610ef857fe5b018190555087606482606481101515610f0d57fe5b019080519060200190610f21929190611488565b508660c882606481101515610f3257fe5b01819055508561012c82606481101515610f4857fe5b019080519060200190610f5c929190611488565b508461019082606481101515610f6e57fe5b019080519060200190610f82929190611488565b50836101f482606481101515610f9457fe5b019080519060200190610fa8929190611488565b508261025882606481101515610fba57fe5b019080519060200190610fce929190611488565b5080610515","81905550610515549150509695505050505050565b60006060600060608061051454861115151561106c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f5472616e73616374696f6e20494420646f6573206e6f7420657869737400000081525060200191505060405180910390fd5b60008660648110151561107b57fe5b015460648760648110151561108c57fe5b0160c88860648110151561109c57fe5b015461012c896064811015156110ae57fe5b016101908a6064811015156110bf57fe5b01838054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156111555780601f1061112a57610100808354040283529160200191611155565b820191906000526020600020905b81548152906001019060200180831161113857829003601f168201915b50505050509350818054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156111f15780601f106111c6576101008083540402835291602001916111f1565b820191906000526020600020905b8154815290600101906020018083116111d457829003601f168201915b50505050509150808054600181600116156101000203166002900480601f01602080910402602001604051908101604052809291908181526020018280546001816001161561010002031660029004801561128d5780601f106112625761010080835404028352916020019161128d565b820191906000526020600020905b81548152906001019060200180831161127057829003601f168201915b505050505090509450945094509450945091939590929450565b606080610514548311151515611325576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f5472616e73616374696f6e20494420646f6573206e6f7420657869737400000081525060200191505060405180910390fd5b61044c8360648110151561133557fe5b016104b08460648110151561134657fe5b01818054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156113dc5780601f106113b1576101008083540402835291602001916113dc565b820191906000526020600020905b8154815290600101906020018083116113bf57829003601f168201915b50505050509150808054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156114785780601f1061144d57610100808354040283529160200191611478565b820191906000526020600020905b81548152906001019060200180831161145b57829003601f168201915b5050505050905091509150915091565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f106114c957805160ff19168380011785556114f7565b828001600101855582156114f7579182015b828111156114f65782518255916020019190600101906114db565b5b5090506115049190611508565b5090565b61152a91905b8082111561152657600081600090555060010161150e565b5090565b905600a165627a7a72305820f58c10335543243fd89f361b0f350e49539df4740923417d0d4a58e403929b7e0029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":true,\"inputs\":[{\"name\":\"id\",\"type\":\"uint256\"}],\"name\":\"getTransaction2\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"uint256\"},{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"companyName\",\"type\":\"string\"},{\"name\":\"date1\",\"type\":\"string\"},{\"name\":\"reductionExpected\",\"type\":\"uint256\"},{\"name\":\"description\",\"type\":\"string\"},{\"name\":\"file1\",\"type\":\"string\"},{\"name\":\"file2\",\"type\":\"string\"}],\"name\":\"_txrRecord2\",\"outputs\":[],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"_getSize\",\"outputs\":[{\"name\":\"size\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"displayTime\",\"type\":\"string\"},{\"name\":\"price\",\"type\":\"uint256\"},{\"name\":\"contactPerson\",\"type\":\"string\"},{\"name\":\"contactWay\",\"type\":\"string\"},{\"name\":\"name\",\"type\":\"string\"},{\"name\":\"status\",\"type\":\"string\"}],\"name\":\"_txrRecord1\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"id\",\"type\":\"uint256\"}],\"name\":\"getTransaction1\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"uint256\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"id\",\"type\":\"uint256\"}],\"name\":\"getTransaction3\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC_GETTRANSACTION2 = "getTransaction2";

    public static final String FUNC__TXRRECORD2 = "_txrRecord2";

    public static final String FUNC__GETSIZE = "_getSize";

    public static final String FUNC__TXRRECORD1 = "_txrRecord1";

    public static final String FUNC_GETTRANSACTION1 = "getTransaction1";

    public static final String FUNC_GETTRANSACTION3 = "getTransaction3";

    protected CCER_Transaction(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public Tuple6<String, String, String, String, BigInteger, String> getTransaction2(BigInteger id) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSACTION2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(id)),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple6<String, String, String, String, BigInteger, String>(
                (String) results.get(0).getValue(),
                (String) results.get(1).getValue(),
                (String) results.get(2).getValue(),
                (String) results.get(3).getValue(),
                (BigInteger) results.get(4).getValue(),
                (String) results.get(5).getValue());
    }

    public TransactionReceipt _txrRecord2(String companyName, String date1, BigInteger reductionExpected, String description, String file1, String file2) {
        final Function function = new Function(
                FUNC__TXRRECORD2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(companyName),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(date1),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(reductionExpected),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(description),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(file1),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(file2)),
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void _txrRecord2(String companyName, String date1, BigInteger reductionExpected, String description, String file1, String file2, TransactionCallback callback) {
        final Function function = new Function(
                FUNC__TXRRECORD2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(companyName),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(date1),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(reductionExpected),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(description),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(file1),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(file2)),
                Collections.<TypeReference<?>>emptyList());

    }

    public String getSignedTransactionFor_txrRecord2(String companyName, String date1, BigInteger reductionExpected, String description, String file1, String file2) {
        final Function function = new Function(
                FUNC__TXRRECORD2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(companyName),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(date1),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(reductionExpected),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(description),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(file1),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(file2)),
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple6<String, String, BigInteger, String, String, String> get_txrRecord2Input(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC__TXRRECORD2,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple6<String, String, BigInteger, String, String, String>(

                (String) results.get(0).getValue(),
                (String) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (String) results.get(3).getValue(),
                (String) results.get(4).getValue(),
                (String) results.get(5).getValue()
                );
    }

    public BigInteger _getSize() throws ContractException {
        final Function function = new Function(FUNC__GETSIZE,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public TransactionReceipt _txrRecord1(String displayTime, BigInteger price, String contactPerson, String contactWay, String name, String status) {
        final Function function = new Function(
                FUNC__TXRRECORD1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(displayTime),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactPerson),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactWay),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(name),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(status)),
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void  _txrRecord1(String displayTime, BigInteger price, String contactPerson, String contactWay, String name, String status, TransactionCallback callback) {
        final Function function = new Function(
                FUNC__TXRRECORD1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(displayTime),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactPerson),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactWay),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(name),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(status)),
                Collections.<TypeReference<?>>emptyList());

    }

    public String getSignedTransactionFor_txrRecord1(String displayTime, BigInteger price, String contactPerson, String contactWay, String name, String status) {
        final Function function = new Function(
                FUNC__TXRRECORD1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(displayTime),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactPerson),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactWay),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(name),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(status)),
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple6<String, BigInteger, String, String, String, String> get_txrRecord1Input(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC__TXRRECORD1,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple6<String, BigInteger, String, String, String, String>(

                (String) results.get(0).getValue(),
                (BigInteger) results.get(1).getValue(),
                (String) results.get(2).getValue(),
                (String) results.get(3).getValue(),
                (String) results.get(4).getValue(),
                (String) results.get(5).getValue()
                );
    }

    public Tuple1<BigInteger> get_txrRecord1Output(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getOutput();
        final Function function = new Function(FUNC__TXRRECORD1,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<BigInteger>(

                (BigInteger) results.get(0).getValue()
                );
    }

    public Tuple5<BigInteger, String, BigInteger, String, String> getTransaction1(BigInteger id) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSACTION1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(id)),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple5<BigInteger, String, BigInteger, String, String>(
                (BigInteger) results.get(0).getValue(),
                (String) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (String) results.get(3).getValue(),
                (String) results.get(4).getValue());
    }

    public Tuple2<String, String> getTransaction3(BigInteger id) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSACTION3,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(id)),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple2<String, String>(
                (String) results.get(0).getValue(),
                (String) results.get(1).getValue());
    }

    public static CCER_Transaction load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new CCER_Transaction(contractAddress, client, credential);
    }

    public static CCER_Transaction deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(CCER_Transaction.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }
}
