package org.example.TanLu_v3.raw;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple2;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple5;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple6;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class CEA_Transaction extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405260006102bc5534801561001657600080fd5b50610b2a806100266000396000f300608060405260043610610062576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff1680630dba29d8146100675780637876414d14610179578063818f00ae146101a4578063b72c7ef21461036c575b600080fd5b34801561007357600080fd5b5061009260048036038101908080359060200190929190505050610493565b604051808060200180602001838103835285818151815260200191508051906020019080838360005b838110156100d65780820151818401526020810190506100bb565b50505050905090810190601f1680156101035780820380516001836020036101000a031916815260200191505b50838103825284818151815260200191508051906020019080838360005b8381101561013c578082015181840152602081019050610121565b50505050905090810190601f1680156101695780820380516001836020036101000a031916815260200191505b5094505050505060405180910390f35b34801561018557600080fd5b5061018e610674565b6040518082815260200191505060405180910390f35b3480156101b057600080fd5b506102f1600480360381019080803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929080359060200190929190803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929080359060200190929190803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f016020809104026020016040519081016040528093929190818152602001838380828437820191505050505050919291929050505061067f565b6040518080602001828103825283818151815260200191508051906020019080838360005b83811015610331578082015181840152602081019050610316565b50505050905090810190601f16801561035e5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561037857600080fd5b5061039760048036038101908080359060200190929190505050610834565b604051808681526020018060200185815260200180602001848152602001838103835287818151815260200191508051906020019080838360005b838110156103ed5780820151818401526020810190506103d2565b50505050905090810190601f16801561041a5780820380516001836020036101000a031916815260200191505b50838103825285818151815260200191508051906020019080838360005b83811015610453578082015181840152602081019050610438565b50505050905090810190601f1680156104805780820380516001836020036101000a031916815260200191505b5097505050505050505060405180910390f35b6060806102bc548311151515610511576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f5472616e73616374696f6e20494420646f6573206e6f7420657869737400000081525060200191505060405180910390fd5b6101f48360648110151561052157fe5b016102588460648110151561053257fe5b01818054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156105c85780601f1061059d576101008083540402835291602001916105c8565b820191906000526020600020905b8154815290600101906020018083116105ab57829003601f168201915b50505050509150808054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156106645780601f1061063957610100808354040283529160200191610664565b820191906000526020600020905b81548152906001019060200180831161064757829003601f168201915b5050505050905091509150915091565b60006102bc54905090565b6060600060646102bc541015156106fe576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260198152602001807f5472616e73616374696f6e206c696d697420726561636865640000000000000081525060200191505060405180910390fd5b60016102bc540190508060008260648110151561071757fe5b01819055508760648260648110151561072c57fe5b019080519060200190610740929190610a59565b508660c88260648110151561075157fe5b01819055508561012c8260648110151561076757fe5b01908051906020019061077b929190610a59565b50846101908260648110151561078d57fe5b0181905550836101f4826064811015156107a357fe5b0190805190602001906107b7929190610a59565b5082610258826064811015156107c957fe5b0190805190602001906107dd929190610a59565b506102bc600081548092919060010191905055506040805190810160405280600781526020017f53756363657373000000000000000000000000000000000000000000000000008152509150509695505050505050565b600060606000606060006102bc5486111515156108b9576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601d8152602001807f5472616e73616374696f6e20494420646f6573206e6f7420657869737400000081525060200191505060405180910390fd5b6000866064811015156108c857fe5b01546064876064811015156108d957fe5b0160c8886064811015156108e957fe5b015461012c896064811015156108fb57fe5b016101908a60648110151561090c57fe5b0154838054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156109a35780601f10610978576101008083540402835291602001916109a3565b820191906000526020600020905b81548152906001019060200180831161098657829003601f168201915b50505050509350818054600181600116156101000203166002900480601f016020809104026020016040519081016040528092919081815260200182805460018160011615610100020316600290048015610a3f5780601f10610a1457610100808354040283529160200191610a3f565b820191906000526020600020905b815481529060010190602001808311610a2257829003601f168201915b505050505091509450945094509450945091939590929450565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10610a9a57805160ff1916838001178555610ac8565b82800160010185558215610ac8579182015b82811115610ac7578251825591602001919060010190610aac565b5b509050610ad59190610ad9565b5090565b610afb91905b80821115610af7576000816000905550600101610adf565b5090565b905600a165627a7a72305820891cf493e16c14c800aa188c6cfd211107bdaba727b17acae847dfc505d4ac530029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":true,\"inputs\":[{\"name\":\"id\",\"type\":\"uint256\"}],\"name\":\"getTransaction2\",\"outputs\":[{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"_getSize\",\"outputs\":[{\"name\":\"size\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"companyName\",\"type\":\"string\"},{\"name\":\"transAmount\",\"type\":\"uint256\"},{\"name\":\"time\",\"type\":\"string\"},{\"name\":\"price\",\"type\":\"uint256\"},{\"name\":\"contactPerson\",\"type\":\"string\"},{\"name\":\"contactWay\",\"type\":\"string\"}],\"name\":\"_txaRecord\",\"outputs\":[{\"name\":\"log\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"id\",\"type\":\"uint256\"}],\"name\":\"getTransaction1\",\"outputs\":[{\"name\":\"\",\"type\":\"uint256\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"uint256\"},{\"name\":\"\",\"type\":\"string\"},{\"name\":\"\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC_GETTRANSACTION2 = "getTransaction2";

    public static final String FUNC__GETSIZE = "_getSize";

    public static final String FUNC__TXARECORD = "_txaRecord";

    public static final String FUNC_GETTRANSACTION1 = "getTransaction1";

    protected CEA_Transaction(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public Tuple2<String, String> getTransaction2(BigInteger id) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSACTION2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(id)),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple2<String, String>(
                (String) results.get(0).getValue(),
                (String) results.get(1).getValue());
    }

    public BigInteger _getSize() throws ContractException {
        final Function function = new Function(FUNC__GETSIZE,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public TransactionReceipt _txaRecord(String companyName, BigInteger transAmount, String time, BigInteger price, String contactPerson, String contactWay) {
        final Function function = new Function(
                FUNC__TXARECORD,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(companyName),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(transAmount),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(time),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactPerson),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactWay)),
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void  _txaRecord(String companyName, BigInteger transAmount, String time, BigInteger price, String contactPerson, String contactWay, TransactionCallback callback) {
        final Function function = new Function(
                FUNC__TXARECORD,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(companyName),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(transAmount),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(time),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactPerson),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactWay)),
                Collections.<TypeReference<?>>emptyList());

    }

    public String getSignedTransactionFor_txaRecord(String companyName, BigInteger transAmount, String time, BigInteger price, String contactPerson, String contactWay) {
        final Function function = new Function(
                FUNC__TXARECORD,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(companyName),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(transAmount),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(time),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactPerson),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(contactWay)),
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple6<String, BigInteger, String, BigInteger, String, String> get_txaRecordInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC__TXARECORD,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple6<String, BigInteger, String, BigInteger, String, String>(

                (String) results.get(0).getValue(),
                (BigInteger) results.get(1).getValue(),
                (String) results.get(2).getValue(),
                (BigInteger) results.get(3).getValue(),
                (String) results.get(4).getValue(),
                (String) results.get(5).getValue()
                );
    }

    public Tuple1<String> get_txaRecordOutput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getOutput();
        final Function function = new Function(FUNC__TXARECORD,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public Tuple5<BigInteger, String, BigInteger, String, BigInteger> getTransaction1(BigInteger id) throws ContractException {
        final Function function = new Function(FUNC_GETTRANSACTION1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(id)),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple5<BigInteger, String, BigInteger, String, BigInteger>(
                (BigInteger) results.get(0).getValue(),
                (String) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (String) results.get(3).getValue(),
                (BigInteger) results.get(4).getValue());
    }

    public static CEA_Transaction load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new CEA_Transaction(contractAddress, client, credential);
    }

    public static CEA_Transaction deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(CEA_Transaction.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }
}
