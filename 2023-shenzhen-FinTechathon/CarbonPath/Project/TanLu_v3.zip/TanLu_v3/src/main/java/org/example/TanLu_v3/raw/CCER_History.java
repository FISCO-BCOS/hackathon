package org.example.TanLu_v3.raw;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple5;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class CCER_History extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405260006102585534801561001657600080fd5b50610936806100266000396000f300608060405260043610610057576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff1680637876414d1461005c578063da7e9a2d14610087578063dc5d9df014610213575b600080fd5b34801561006857600080fd5b50610071610395565b6040518082815260200191505060405180910390f35b34801561009357600080fd5b506100b2600480360381019080803590602001909291905050506103a0565b60405180806020018060200186815260200185815260200180602001848103845289818151815260200191508051906020019080838360005b838110156101065780820151818401526020810190506100eb565b50505050905090810190601f1680156101335780820380516001836020036101000a031916815260200191505b50848103835288818151815260200191508051906020019080838360005b8381101561016c578082015181840152602081019050610151565b50505050905090810190601f1680156101995780820380516001836020036101000a031916815260200191505b50848103825285818151815260200191508051906020019080838360005b838110156101d25780820151818401526020810190506101b7565b50505050905090810190601f1680156101ff5780820380516001836020036101000a031916815260200191505b509850505050505050505060405180910390f35b34801561021f57600080fd5b5061031a600480360381019080803590602001908201803590602001908080601f0160208091040260200160405190810160405280939291908181526020018383808284378201915050505050509192919290803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091929192908035906020019092919080359060200190929190803590602001908201803590602001908080601f01602080910402602001604051908101604052809392919081815260200183838082843782019150505050505091929192905050506106b6565b6040518080602001828103825283818151815260200191508051906020019080838360005b8381101561035a57808201518184015260208101905061033f565b50505050905090810190601f1680156103875780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b600061025854905090565b60608060008060606000600190505b610258548111151561061857866000826064811015156103cb57fe5b0154141561060b576064816064811015156103e257fe5b0160c8826064811015156103f257fe5b0161012c8360648110151561040357fe5b01546101908460648110151561041557fe5b01546101f48560648110151561042757fe5b01848054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156104bd5780601f10610492576101008083540402835291602001916104bd565b820191906000526020600020905b8154815290600101906020018083116104a057829003601f168201915b50505050509450838054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156105595780601f1061052e57610100808354040283529160200191610559565b820191906000526020600020905b81548152906001019060200180831161053c57829003601f168201915b50505050509350808054600181600116156101000203166002900480601f0160208091040260200160405190810160405280929190818152602001828054600181600116156101000203166002900480156105f55780601f106105ca576101008083540402835291602001916105f5565b820191906000526020600020905b8154815290600101906020018083116105d857829003601f168201915b50505050509050955095509550955095506106ac565b80806001019150506103af565b6040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602d8152602001807f486973746f726963616c205472616e73616374696f6e20496e666f726d61746981526020017f6f6e206e6f7420666f756e642e0000000000000000000000000000000000000081525060400191505060405180910390fd5b5091939590929450565b6060600060646102585410151561075b576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260318152602001807f486973746f726963616c205472616e73616374696f6e20496e666f726d61746981526020017f6f6e206c696d697420726561636865642e00000000000000000000000000000081525060400191505060405180910390fd5b6001610258540190508060008260648110151561077457fe5b01819055508660648260648110151561078957fe5b01908051906020019061079d929190610865565b508560c8826064811015156107ae57fe5b0190805190602001906107c2929190610865565b508461012c826064811015156107d457fe5b018190555083610190826064811015156107ea57fe5b0181905550826101f48260648110151561080057fe5b019080519060200190610814929190610865565b5060016102585401610258819055506040805190810160405280600781526020017f537563636573730000000000000000000000000000000000000000000000000081525091505095945050505050565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f106108a657805160ff19168380011785556108d4565b828001600101855582156108d4579182015b828111156108d35782518255916020019190600101906108b8565b5b5090506108e191906108e5565b5090565b61090791905b808211156109035760008160009055506001016108eb565b5090565b905600a165627a7a72305820b5ab5e569955224f5b4e9a9d5741bcc421f99c1030d08e0826d3354a09ce69ae0029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":true,\"inputs\":[],\"name\":\"_getSize\",\"outputs\":[{\"name\":\"size\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[{\"name\":\"_id\",\"type\":\"uint256\"}],\"name\":\"getHtxr\",\"outputs\":[{\"name\":\"seller\",\"type\":\"string\"},{\"name\":\"buyer\",\"type\":\"string\"},{\"name\":\"amount\",\"type\":\"uint256\"},{\"name\":\"price\",\"type\":\"uint256\"},{\"name\":\"time\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"_seller\",\"type\":\"string\"},{\"name\":\"_buyer\",\"type\":\"string\"},{\"name\":\"_amount\",\"type\":\"uint256\"},{\"name\":\"_price\",\"type\":\"uint256\"},{\"name\":\"_time\",\"type\":\"string\"}],\"name\":\"htxrRecord\",\"outputs\":[{\"name\":\"log\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC__GETSIZE = "_getSize";

    public static final String FUNC_GETHTXR = "getHtxr";

    public static final String FUNC_HTXRRECORD = "htxrRecord";

    protected CCER_History(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public BigInteger _getSize() throws ContractException {
        final Function function = new Function(FUNC__GETSIZE,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public Tuple5<String, String, BigInteger, BigInteger, String> getHtxr(BigInteger _id) throws ContractException {
        final Function function = new Function(FUNC_GETHTXR,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_id)),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = executeCallWithMultipleValueReturn(function);
        return new Tuple5<String, String, BigInteger, BigInteger, String>(
                (String) results.get(0).getValue(),
                (String) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (BigInteger) results.get(3).getValue(),
                (String) results.get(4).getValue());
    }

    public TransactionReceipt htxrRecord(String _seller, String _buyer, BigInteger _amount, BigInteger _price, String _time) {
        final Function function = new Function(
                FUNC_HTXRRECORD,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_seller),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_buyer),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_amount),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_time)),
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void htxrRecord(String _seller, String _buyer, BigInteger _amount, BigInteger _price, String _time, TransactionCallback callback) {
        final Function function = new Function(
                FUNC_HTXRRECORD,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_seller),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_buyer),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_amount),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_time)),
                Collections.<TypeReference<?>>emptyList());

    }

    public String getSignedTransactionForHtxrRecord(String _seller, String _buyer, BigInteger _amount, BigInteger _price, String _time) {
        final Function function = new Function(
                FUNC_HTXRRECORD,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_seller),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_buyer),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_amount),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(_price),
                new org.fisco.bcos.sdk.abi.datatypes.Utf8String(_time)),
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple5<String, String, BigInteger, BigInteger, String> getHtxrRecordInput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC_HTXRRECORD,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple5<String, String, BigInteger, BigInteger, String>(

                (String) results.get(0).getValue(),
                (String) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (BigInteger) results.get(3).getValue(),
                (String) results.get(4).getValue()
                );
    }

    public Tuple1<String> getHtxrRecordOutput(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getOutput();
        final Function function = new Function(FUNC_HTXRRECORD,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public static CCER_History load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new CCER_History(contractAddress, client, credential);
    }

    public static CCER_History deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(CCER_History.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }
}
