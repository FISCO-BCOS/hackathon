package org.example.TanLu_v3.model.bo;

import java.lang.Object;
import java.lang.String;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClearanceHtxaRecordInputBO {
  private String _seller;

  private String _buyer;

  private BigInteger _amount;

  private BigInteger _price;

  private String _time;

  public List<Object> toArgs() {
    List args = new ArrayList();
    args.add(_seller);
    args.add(_buyer);
    args.add(_amount);
    args.add(_price);
    args.add(_time);
    return args;
  }
}
