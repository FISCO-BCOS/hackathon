package org.example.TanLu_v3.model.bo;

import java.lang.Object;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmissionAccounting_AccountEmission1InputBO {
  private BigInteger amount1;

  private BigInteger amount2;

  private BigInteger amount3;

  private BigInteger amount4;

  private BigInteger amount5;

  public List<Object> toArgs() {
    List args = new ArrayList();
    args.add(amount1);
    args.add(amount2);
    args.add(amount3);
    args.add(amount4);
    args.add(amount5);
    return args;
  }
}
