package org.example.TanLu_v3.model.bo;

import java.lang.Object;
import java.lang.String;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CCER_Transaction_txrRecord1InputBO {
  private String displayTime;

  private BigInteger price;

  private String contactPerson;

  private String contactWay;

  private String name;

  private String status;

  public List<Object> toArgs() {
    List args = new ArrayList();
    args.add(displayTime);
    args.add(price);
    args.add(contactPerson);
    args.add(contactWay);
    args.add(name);
    args.add(status);
    return args;
  }
}
