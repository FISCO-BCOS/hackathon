package org.example.TanLu_v3.Controller;

import org.example.TanLu_v3.model.bo.CCER_HistoryGetHtxrInputBO;
import org.example.TanLu_v3.service.CCER_HistoryService;
import org.example.TanLu_v3.utils.ParserTools;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("CCER_History")
public class CCER_H_Controller {

    @Autowired
    private CCER_HistoryService service;

    @GetMapping("getSize_rh")
    public int getEntrySize_a() throws Exception {

        String response = service._getSize().getValues();
        int returnValue = ParserTools.ExtractInt(response);
        System.out.println("size of entries is: " + returnValue);
        return returnValue;
    }

    @GetMapping("DisplayAll")
    public String getAllEntry_c() throws Exception {
        String response = service._getSize().getValues();
        int size = ParserTools.ExtractInt(response);
        JSONArray ccer_histories = new JSONArray();
        for (int index = 1; index <= size; index++) {
            // for one entry
            BigInteger number = BigInteger.valueOf(index);
            CCER_HistoryGetHtxrInputBO input = new CCER_HistoryGetHtxrInputBO(number);
            //Parse returnObject
            List<Object> list1 = service.getHtxr(input).getReturnObject();

            JSONObject CCER_History = new JSONObject();
            CCER_History.put("CCER History Id", list1.get(0));
            CCER_History.put("seller companyName", list1.get(1));
            CCER_History.put("buyer companyName", list1.get(2));
            CCER_History.put("amount", list1.get(3));
            float temp = Integer.valueOf((Integer) list1.get(4)) / 100;
            CCER_History.put("price", temp);
            CCER_History.put("time", list1.get(5));
            System.out.println(CCER_History);

            ccer_histories.put(CCER_History);
        }
        System.out.println(ccer_histories);
        return ccer_histories.toString();
    }

}
// http://localhost:8080/CCER_History/DisplayAll   展示所有CCER历史交易信息
