package org.example.TanLu_v3.raw;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.fisco.bcos.sdk.abi.FunctionReturnDecoder;
import org.fisco.bcos.sdk.abi.TypeReference;
import org.fisco.bcos.sdk.abi.datatypes.Function;
import org.fisco.bcos.sdk.abi.datatypes.Type;
import org.fisco.bcos.sdk.abi.datatypes.Utf8String;
import org.fisco.bcos.sdk.abi.datatypes.generated.StaticArray12;
import org.fisco.bcos.sdk.abi.datatypes.generated.Uint256;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple1;
import org.fisco.bcos.sdk.abi.datatypes.generated.tuples.generated.Tuple5;
import org.fisco.bcos.sdk.client.Client;
import org.fisco.bcos.sdk.contract.Contract;
import org.fisco.bcos.sdk.crypto.CryptoSuite;
import org.fisco.bcos.sdk.crypto.keypair.CryptoKeyPair;
import org.fisco.bcos.sdk.model.CryptoType;
import org.fisco.bcos.sdk.model.TransactionReceipt;
import org.fisco.bcos.sdk.model.callback.TransactionCallback;
import org.fisco.bcos.sdk.transaction.model.exception.ContractException;

@SuppressWarnings("unchecked")
public class EmissionAccounting extends Contract {
    public static final String[] BINARY_ARRAY = {"608060405234801561001057600080fd5b50610e7b806100206000396000f300608060405260043610610061576000357c0100000000000000000000000000000000000000000000000000000000900463ffffffff168062b561881461006657806324f4fbd4146101345780634e56d0811461015f578063fe17a64f1461022d575b600080fd5b34801561007257600080fd5b506100b96004803603810190808035906020019092919080359060200190929190803590602001909291908035906020019092919080359060200190929190505050610280565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156100f95780820151818401526020810190506100de565b50505050905090810190601f1680156101265780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561014057600080fd5b506101496106f6565b6040518082815260200191505060405180910390f35b34801561016b57600080fd5b506101b26004803603810190808035906020019092919080359060200190929190803590602001909291908035906020019092919080359060200190929190505050610707565b6040518080602001828103825283818151815260200191508051906020019080838360005b838110156101f25780820151818401526020810190506101d7565b50505050905090810190601f16801561021f5780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b34801561023957600080fd5b50610242610b7e565b6040518082600c60200280838360005b8381101561026d578082015181840152602081019050610252565b5050505090500191505060405180910390f35b6060600080600080600080610c188c02955061013e8b02945060df8a02935061020a890292506101b8880291508183858789010101019050806001819055506102c886610cc9565b6102d186610cc9565b6102da86610cc9565b6102e386610cc9565b6102ec86610cc9565b6102f586610cc9565b60405160200180807f456d697373696f6e733a20000000000000000000000000000000000000000000815250600b01807f44696573656c3a2000000000000000000000000000000000000000000000000081525060080187805190602001908083835b60208310151561037d5780518252602082019150602081019050602083039250610358565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f4b32434f333a200000000000000000000000000000000000000000000000000081525060070186805190602001908083835b60208310151561042057805182526020820191506020810190506020830392506103fb565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f4261434f333a200000000000000000000000000000000000000000000000000081525060070185805190602001908083835b6020831015156104c3578051825260208201915060208101905060208303925061049e565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f4d67434f333a200000000000000000000000000000000000000000000000000081525060070184805190602001908083835b6020831015156105665780518252602082019150602081019050602083039250610541565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f4361434f333a200000000000000000000000000000000000000000000000000081525060070183805190602001908083835b60208310151561060957805182526020820191506020810190506020830392506105e4565b6001836020036101000a038019825116818451168082178552505050505050905001807f3b20000000000000000000000000000000000000000000000000000000000000815250600201807f546f74616c3a200000000000000000000000000000000000000000000000000081525060070182805190602001908083835b6020831015156106ac5780518252602082019150602081019050602083039250610687565b6001836020036101000a0380198251168184511680821785525050505050509050019650505050505050604051602081830303815290604052965050505050505095945050505050565b600060015460005401905080905090565b60606000806000806000806107bd8c0295506109658b029450610b2c8a02935061547689029250610b6d8802915081838587890101010190508060008190555061075086610cc9565b61075986610cc9565b61076286610cc9565b61076b86610cc9565b61077486610cc9565b61077d86610cc9565b60405160200180807f456d697373696f6e733a20000000000000000000000000000000000000000000815250600b01807f436f616c3a20000000000000000000000000000000000000000000000000000081525060060187805190602001908083835b60208310151561080557805182526020820191506020810190506020830392506107e0565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f526566696e656420436f616c3a20000000000000000000000000000000000000815250600e0186805190602001908083835b6020831015156108a85780518252602082019150602081019050602083039250610883565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f436f6b653a20000000000000000000000000000000000000000000000000000081525060060185805190602001908083835b60208310151561094b5780518252602082019150602081019050602083039250610926565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f4e61747572616c204761733a2000000000000000000000000000000000000000815250600d0184805190602001908083835b6020831015156109ee57805182526020820191506020810190506020830392506109c9565b6001836020036101000a038019825116818451168082178552505050505050905001807f2c20000000000000000000000000000000000000000000000000000000000000815250600201807f4761736f6c696e653a2000000000000000000000000000000000000000000000815250600a0183805190602001908083835b602083101515610a915780518252602082019150602081019050602083039250610a6c565b6001836020036101000a038019825116818451168082178552505050505050905001807f3b20000000000000000000000000000000000000000000000000000000000000815250600201807f546f74616c3a200000000000000000000000000000000000000000000000000081525060070182805190602001908083835b602083101515610b345780518252602082019150602081019050602083039250610b0f565b6001836020036101000a0380198251168184511680821785525050505050509050019650505050505050604051602081830303815290604052965050505050505095945050505050565b610b86610e2b565b6034816000600c81101515610b9757fe5b602002018181525050603c816001600c81101515610bb157fe5b6020020181815250506035816002600c81101515610bcb57fe5b602002018181525050601f816003600c81101515610be557fe5b602002018181525050601e816004600c81101515610bff57fe5b602002018181525050602a816005600c81101515610c1957fe5b6020020181815250506032816006600c81101515610c3357fe5b602002018181525050602c816007600c81101515610c4d57fe5b6020020181815250506020816008600c81101515610c6757fe5b602002018181525050601d816009600c81101515610c8157fe5b602002018181525050602881600a600c81101515610c9b57fe5b6020020181815250506001546000540181600b600c81101515610cba57fe5b60200201818152505080905090565b60606000806060600080600080881415610d1a576040805190810160405280600181526020017f30000000000000000000000000000000000000000000000000000000000000008152509650610e20565b8795505b600086141515610d44578480600101955050600a86811515610d3c57fe5b049550610d1e565b846040519080825280601f01601f191660200182016040528015610d775781602001602082028038833980820191505090505b5093508492505b600088141515610e1c57600183039250600a8089811515610d9b57fe5b040288036030019150817f0100000000000000000000000000000000000000000000000000000000000000029050808484815181101515610dd857fe5b9060200101907effffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff1916908160001a905350600a88811515610e1457fe5b049750610d7e565b8396505b505050505050919050565b61018060405190810160405280600c906020820280388339808201915050905050905600a165627a7a72305820c380baab765a5dcce88b14a799bff591698463986379af2b21693d9c8e9c5cdb0029"};

    public static final String BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", BINARY_ARRAY);

    public static final String[] SM_BINARY_ARRAY = {};

    public static final String SM_BINARY = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", SM_BINARY_ARRAY);

    public static final String[] ABI_ARRAY = {"[{\"constant\":false,\"inputs\":[{\"name\":\"amount6\",\"type\":\"uint256\"},{\"name\":\"amount7\",\"type\":\"uint256\"},{\"name\":\"amount8\",\"type\":\"uint256\"},{\"name\":\"amount9\",\"type\":\"uint256\"},{\"name\":\"amount10\",\"type\":\"uint256\"}],\"name\":\"_AccountEmission2\",\"outputs\":[{\"name\":\"log\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"_sumEmission\",\"outputs\":[{\"name\":\"totalEmissions\",\"type\":\"uint256\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"},{\"constant\":false,\"inputs\":[{\"name\":\"amount1\",\"type\":\"uint256\"},{\"name\":\"amount2\",\"type\":\"uint256\"},{\"name\":\"amount3\",\"type\":\"uint256\"},{\"name\":\"amount4\",\"type\":\"uint256\"},{\"name\":\"amount5\",\"type\":\"uint256\"}],\"name\":\"_AccountEmission1\",\"outputs\":[{\"name\":\"log\",\"type\":\"string\"}],\"payable\":false,\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"constant\":true,\"inputs\":[],\"name\":\"_queryEmission\",\"outputs\":[{\"name\":\"emissions\",\"type\":\"uint256[12]\"}],\"payable\":false,\"stateMutability\":\"view\",\"type\":\"function\"}]"};

    public static final String ABI = org.fisco.bcos.sdk.utils.StringUtils.joinAll("", ABI_ARRAY);

    public static final String FUNC__ACCOUNTEMISSION2 = "_AccountEmission2";

    public static final String FUNC__SUMEMISSION = "_sumEmission";

    public static final String FUNC__ACCOUNTEMISSION1 = "_AccountEmission1";

    public static final String FUNC__QUERYEMISSION = "_queryEmission";

    protected EmissionAccounting(String contractAddress, Client client, CryptoKeyPair credential) {
        super(getBinary(client.getCryptoSuite()), contractAddress, client, credential);
    }

    public static String getBinary(CryptoSuite cryptoSuite) {
        return (cryptoSuite.getCryptoTypeConfig() == CryptoType.ECDSA_TYPE ? BINARY : SM_BINARY);
    }

    public TransactionReceipt _AccountEmission2(BigInteger amount6, BigInteger amount7, BigInteger amount8, BigInteger amount9, BigInteger amount10) {
        final Function function = new Function(
                FUNC__ACCOUNTEMISSION2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount6),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount7),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount8),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount9),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount10)),
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void  _AccountEmission2(BigInteger amount6, BigInteger amount7, BigInteger amount8, BigInteger amount9, BigInteger amount10, TransactionCallback callback) {
        final Function function = new Function(
                FUNC__ACCOUNTEMISSION2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount6),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount7),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount8),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount9),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount10)),
                Collections.<TypeReference<?>>emptyList());

    }

    public String getSignedTransactionFor_AccountEmission2(BigInteger amount6, BigInteger amount7, BigInteger amount8, BigInteger amount9, BigInteger amount10) {
        final Function function = new Function(
                FUNC__ACCOUNTEMISSION2,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount6),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount7),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount8),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount9),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount10)),
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple5<BigInteger, BigInteger, BigInteger, BigInteger, BigInteger> get_AccountEmission2Input(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC__ACCOUNTEMISSION2,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple5<BigInteger, BigInteger, BigInteger, BigInteger, BigInteger>(

                (BigInteger) results.get(0).getValue(),
                (BigInteger) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (BigInteger) results.get(3).getValue(),
                (BigInteger) results.get(4).getValue()
                );
    }

    public Tuple1<String> get_AccountEmission2Output(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getOutput();
        final Function function = new Function(FUNC__ACCOUNTEMISSION2,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public BigInteger _sumEmission() throws ContractException {
        final Function function = new Function(FUNC__SUMEMISSION,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeCallWithSingleValueReturn(function, BigInteger.class);
    }

    public TransactionReceipt _AccountEmission1(BigInteger amount1, BigInteger amount2, BigInteger amount3, BigInteger amount4, BigInteger amount5) {
        final Function function = new Function(
                FUNC__ACCOUNTEMISSION1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount1),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount2),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount3),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount4),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount5)),
                Collections.<TypeReference<?>>emptyList());
        return executeTransaction(function);
    }

    public void  _AccountEmission1(BigInteger amount1, BigInteger amount2, BigInteger amount3, BigInteger amount4, BigInteger amount5, TransactionCallback callback) {
        final Function function = new Function(
                FUNC__ACCOUNTEMISSION1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount1),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount2),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount3),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount4),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount5)),
                Collections.<TypeReference<?>>emptyList());

    }

    public String getSignedTransactionFor_AccountEmission1(BigInteger amount1, BigInteger amount2, BigInteger amount3, BigInteger amount4, BigInteger amount5) {
        final Function function = new Function(
                FUNC__ACCOUNTEMISSION1,
                Arrays.<Type>asList(new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount1),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount2),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount3),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount4),
                new org.fisco.bcos.sdk.abi.datatypes.generated.Uint256(amount5)),
                Collections.<TypeReference<?>>emptyList());
        return createSignedTransaction(function);
    }

    public Tuple5<BigInteger, BigInteger, BigInteger, BigInteger, BigInteger> get_AccountEmission1Input(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getInput().substring(10);
        final Function function = new Function(FUNC__ACCOUNTEMISSION1,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple5<BigInteger, BigInteger, BigInteger, BigInteger, BigInteger>(

                (BigInteger) results.get(0).getValue(),
                (BigInteger) results.get(1).getValue(),
                (BigInteger) results.get(2).getValue(),
                (BigInteger) results.get(3).getValue(),
                (BigInteger) results.get(4).getValue()
                );
    }

    public Tuple1<String> get_AccountEmission1Output(TransactionReceipt transactionReceipt) {
        String data = transactionReceipt.getOutput();
        final Function function = new Function(FUNC__ACCOUNTEMISSION1,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        List<Type> results = FunctionReturnDecoder.decode(data, function.getOutputParameters());
        return new Tuple1<String>(

                (String) results.get(0).getValue()
                );
    }

    public List _queryEmission() throws ContractException {
        final Function function = new Function(FUNC__QUERYEMISSION,
                Arrays.<Type>asList(),
                Arrays.<TypeReference<?>>asList(new TypeReference<StaticArray12<Uint256>>() {}));
        List<Type> result = (List<Type>) executeCallWithSingleValueReturn(function, List.class);
        return convertToNative(result);
    }

    public static EmissionAccounting load(String contractAddress, Client client, CryptoKeyPair credential) {
        return new EmissionAccounting(contractAddress, client, credential);
    }

    public static EmissionAccounting deploy(Client client, CryptoKeyPair credential) throws ContractException {
        return deploy(EmissionAccounting.class, client, credential, getBinary(client.getCryptoSuite()), "");
    }
}
