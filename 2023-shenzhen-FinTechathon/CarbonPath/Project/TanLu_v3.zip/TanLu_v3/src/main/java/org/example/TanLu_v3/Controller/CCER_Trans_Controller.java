package org.example.TanLu_v3.Controller;

import org.example.TanLu_v3.model.bo.*;
import org.example.TanLu_v3.service.CCER_TransactionService;
import org.example.TanLu_v3.service.CEA_TransactionService;
import org.example.TanLu_v3.utils.ParserTools;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("CCER_Transaction")
public class CCER_Trans_Controller {
    @Autowired
    private CCER_TransactionService service;
    @GetMapping("getSize_r")
    public int getEntrySize_a() throws Exception {

        String response = service._getSize().getValues();
        int returnValue = ParserTools.ExtractInt(response);
        System.out.println("size of entries is: " + returnValue);
        return returnValue;
    }

    @GetMapping("DisplayAll")
    public String getAllEntry_c() throws Exception {
        String response = service._getSize().getValues();
        int size = ParserTools.ExtractInt(response);
        JSONArray ccer_transactions = new JSONArray();
        for (int index = 1; index <= size; index++) {
            // for one entry
            BigInteger number = BigInteger.valueOf(index);
            CCER_TransactionGetTransaction1InputBO input1 = new CCER_TransactionGetTransaction1InputBO(number);
            CCER_TransactionGetTransaction2InputBO input2 = new CCER_TransactionGetTransaction2InputBO(number);
            CCER_TransactionGetTransaction3InputBO input3 = new CCER_TransactionGetTransaction3InputBO(number);
            //Parse returnObject
            List<Object> list1 = service.getTransaction1(input1).getReturnObject();
            List<Object> list2 = service.getTransaction2(input2).getReturnObject();
            List<Object> list3 = service.getTransaction3(input3).getReturnObject();
            JSONObject ccer_transaction = new JSONObject();
            ccer_transaction.put("id", list1.get(0));
            ccer_transaction.put("display_time", list1.get(1));
            float temp = Integer.valueOf((Integer) list1.get(2)) / 100;
            ccer_transaction.put("price", temp);
            ccer_transaction.put("contactPerson", list1.get(3));
            ccer_transaction.put("contactWay", list1.get(4));

            ccer_transaction.put("name", list2.get(0));
            ccer_transaction.put("status", list2.get(1));
            ccer_transaction.put("type", list2.get(2));
            ccer_transaction.put("companyName", list2.get(3));
            ccer_transaction.put("date1", list2.get(4));
            ccer_transaction.put("reductionExpected", list2.get(5));
            ccer_transaction.put("description", list2.get(6));

            ccer_transaction.put("file1", list3.get(0));
            ccer_transaction.put("file2", list3.get(1));
            System.out.println(ccer_transaction);

            ccer_transactions.put(ccer_transaction);
        }
        System.out.println(ccer_transactions);
        return ccer_transactions.toString();
    }


}
// http://localhost:8080/CCER_Transaction/DisplayAll   展示所有CCER交易信息
