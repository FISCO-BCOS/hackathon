package org.example.TanLu_v3.config;

import java.lang.String;
import lombok.Data;

@Data
public class ContractConfig {
  private String cCER_TransactionAddress;

  private String clearanceAddress;

  private String cCER_HistoryAddress;

  private String emissionAccountingAddress;

  private String cEA_TransactionAddress;
}
