package org.example.TanLu_v3.service;

import lombok.NoArgsConstructor;
import org.example.TanLu_v3.entity.CompanyInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.sql.*;

@Service
@NoArgsConstructor
public class QueryService {

    private static final Logger log = LoggerFactory.getLogger(DBConnection.class);
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/cd3?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER_NAME = "root";
    private static final String PASSWORD = "123456";
    private static Connection conn = null;
    private int companyCount = 3;

    public void connectToDB(String url, String username, String password) {
        try {
            log.info("Connect DB...");
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void closeDBConnection() {
        try{
            if(conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String queryDB_username(){
        QueryService dbConnection = new QueryService();
        dbConnection.connectToDB(DB_URL, USER_NAME, PASSWORD);
        String query = "select * from company_registration";
        String username = null;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                username = rs.getString(2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(username);
        dbConnection.closeDBConnection();
        return username;
    }
    // TODO 改密码查询
    public String queryDB_password(){
        QueryService dbConnection = new QueryService();
        dbConnection.connectToDB(DB_URL, USER_NAME, PASSWORD);

        String query = "select * from company_registration";
        String password = null;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                password = rs.getString(3);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        dbConnection.closeDBConnection();
        return password;
    }

    public CompanyInfo queryDB_company(String username_query){
        QueryService dbConnection = new QueryService();
        dbConnection.connectToDB(DB_URL, USER_NAME, PASSWORD);

        String query = "select * from company_registration where username = '" + username_query + "'";
        int id_company = 0;
        String username = null;
        int type_c = 0; // type = 1/2/3--企业/第三方审计机构/政府监管机关
        String companyName = null;
        String industry = null;
        String address_c = null;
        String contact = null;
        String liscence = null;
        String LegalRepresentative_Certification = null;
        String AccountRepresentative_Authorization = null;
        int status = 0; // status = 0/1 等待审核/审核通过
        int id_TransactionAccount_fk = 0;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                id_company = Integer.parseInt(rs.getString(1));
                username = rs.getString(2);
                type_c = Integer.parseInt(rs.getString(4));
                companyName = rs.getString(5);
                industry = rs.getString(6);
                address_c = rs.getString(7);
                contact = rs.getString(8);
                liscence  = rs.getString(9);
                LegalRepresentative_Certification = rs.getString(10);
                AccountRepresentative_Authorization = rs.getString(11);
                status = Integer.parseInt(rs.getString(12));
                id_TransactionAccount_fk = Integer.parseInt(rs.getString(13));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        dbConnection.closeDBConnection();
        CompanyInfo cInfo = new CompanyInfo(id_company, username, type_c, companyName, industry, address_c, contact, liscence, LegalRepresentative_Certification, AccountRepresentative_Authorization, status, id_TransactionAccount_fk);
        return cInfo;
    }

    public boolean insertCompanyInfo(String username, String password, int role, String cName, String industry, String address, String contact, String liscence, String LC, String AA, int status) throws SQLException {
        companyCount ++;
        boolean result = false;
        QueryService dbConnection = new QueryService();
        dbConnection.connectToDB(DB_URL, USER_NAME, PASSWORD);
        String query = "INSERT INTO company_registration (id_company, username, password, role, companyName, industry, address, contact, liscence, LegalRepresentative_Certification, AccountRepresentative_Authorization, status, id_TransactionAccount_fk) VALUES ("+ companyCount + ", '" + username + "', '"+ password +"', "+ role + ", '"+ cName +"', '" + industry +"', '"+ address +"', '" + contact +"', '"+ liscence +"', '"+LC+"', '"+AA+"', "+status+", 1);";
        Statement stmt = conn.createStatement();
        int flag = stmt.executeUpdate(query);
        if(flag == 1)
        {
            result = true;
        }
        else
        {
            result = false;
        }
        return result;
    }

/*id_company: int
        username: varchar(255)
        password: varchar(255)
        type: int
        companyName: varchar(255)
        industry: varchar(255)
        address: varchar(255)
        contact: varchar(255)
        liscence: varchar(255)
        LegalRepresentative_Certification: varchar(255)
        AccountRepresentative_Authorization: varchar(255)d
        status: int
        id_TransactionAccount_fk: int  0- invalid*/

    public static void main(String args[]) throws SQLException {
         /*QueryService service = new QueryService();
         System.out.println(service.queryDB_company("admin2").toString());*/


    }

}
