package org.example.TanLu_v3.utils;
import java.util.Arrays;

public class ParserTools {
    private ParserTools(){}

    // Extract number from a string with all kinds of chars
    public static int ExtractInt(String str){
        // 提取字符串中的数字
        str = str.trim();
        String str2 = "";
        if(str != null && !"".equals(str)){
            for(int i = 0; i < str.length(); i++){
                if(str.charAt(i) >= 48 && str.charAt(i) <= 57){
                    str2 += str.charAt(i);
                }
            }
        }
        int returnValue = Integer.parseInt(str2);
        return returnValue;
    }
    // >= 0 有，-1 无
    public static int ExtractInfo(String text, String pattern) {
        int n = text.length(), m = pattern.length();
        int[] fail = new int[m];
        Arrays.fill(fail, -1);
        for (int i = 1, j = -1; i < m; i++) {
            while (j >= 0 && pattern.charAt(i) != pattern.charAt(j + 1)) {
                j = fail[j];
            }
            if (pattern.charAt(i) == pattern.charAt(j + 1)) {
                j++;
            }
            fail[i] = j;
        }
        for (int i = 0, j = -1; i < n; i++) {
            while (j >= 0 && text.charAt(i) != pattern.charAt(j + 1)) {
                j = fail[j];
            }
            if (text.charAt(i) == pattern.charAt(j + 1)) {
                j++;
            }
            if (j == m - 1) {
                return i - m + 1;
            }
        }
        return -1;
    }

/*    public static void main(String[] args){
        String Response = "Success";
        String pattern = "Success";
        System.out.println(ExtractInfo(Response, pattern));


    }*/



}

