package org.example.TanLu_v3.Controller;

import org.example.TanLu_v3.model.bo.CCER_HistoryGetHtxrInputBO;
import org.example.TanLu_v3.model.bo.ClearanceGetHtxaInputBO;
import org.example.TanLu_v3.model.bo.Clearance_getclBoughtInputBO;
import org.example.TanLu_v3.model.bo.Clearance_getclSoldInputBO;
import org.example.TanLu_v3.raw.Clearance;
import org.example.TanLu_v3.service.CEA_TransactionService;
import org.example.TanLu_v3.service.ClearanceService;
import org.example.TanLu_v3.utils.ParserTools;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.List;

@RestController
@RequestMapping("Clearance")
public class Clearance_Controller {
    @Autowired
    private ClearanceService service;
    @GetMapping("DisplayCEAHistory")
    public String getAllEntry_a() throws Exception {
        String response = service._getSize().getValues();
        int size = ParserTools.ExtractInt(response);
        JSONArray cea_histories = new JSONArray();
        for (int index = 1; index <= size; index++) {
            // for one entry
            BigInteger number = BigInteger.valueOf(index);
            ClearanceGetHtxaInputBO input = new ClearanceGetHtxaInputBO(number);
            //Parse returnObject
            List<Object> list1 = service.getHtxa(input).getReturnObject();

            JSONObject cea_History = new JSONObject();
            cea_History.put("CCER History Id", list1.get(0));
            cea_History.put("seller companyName", list1.get(1));
            cea_History.put("buyer companyName", list1.get(2));
            cea_History.put("amount", list1.get(3));
            float temp = Integer.valueOf((Integer) list1.get(4)) / 100;
            cea_History.put("price", temp);
            cea_History.put("time", list1.get(5));
            System.out.println(cea_History);

            cea_histories.put(cea_History);
        }
        System.out.println(cea_histories);
        return cea_histories.toString();
    }
    @GetMapping("MonthlyBuyings")
    public String getClBought(String companyName) throws Exception{
        int size = 12;
        JSONArray buyings = new JSONArray();
        Clearance_getclBoughtInputBO input = new Clearance_getclBoughtInputBO(companyName);
        List<Object> list1 = service._getclBought(input).getReturnObject();
        for (int index = 0; index < size; index++) {
            JSONObject monthlyBought = new JSONObject();
            monthlyBought.put("month"+(index + 1), ((Number) list1.get(index)).doubleValue() / 100);
            buyings.put(monthlyBought);
        }
        return buyings.toString();
    }

    @GetMapping("MonthlySellings")
    public String getClSold(String companyName) throws Exception{
        int size = 12;
        JSONArray buyings = new JSONArray();
        Clearance_getclSoldInputBO input = new Clearance_getclSoldInputBO(companyName);
        List<Object> list1 = service._getclSold(input).getReturnObject();
        for (int index = 0; index < size; index++) {
            JSONObject monthlySold = new JSONObject();
            monthlySold.put("month"+(index + 1), ((Number) list1.get(index)).doubleValue() / 100);
            buyings.put(monthlySold);
        }
        return buyings.toString();
    }


}
// http://localhost:8080/Clearance/DisplayCEAHistory   展示所有CEA历史交易信息
// http://localhost:8080/Clearance/MonthlySellings 展示该公司本年所有CEA分月卖出量
// http://localhost:8080/Clearance/MonthlyBuyings 展示该公司本年所有CEA分月买入量
