package org.example.TanLu_v3.Controller;


import org.example.TanLu_v3.model.bo.CEA_TransactionGetTransaction1InputBO;
import org.example.TanLu_v3.model.bo.CEA_TransactionGetTransaction2InputBO;
import org.example.TanLu_v3.service.CEA_TransactionService;
import org.example.TanLu_v3.utils.ParserTools;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigInteger;
import java.util.List;

/*
    // CCER Transcation information
    uint constant txr_limit = 100;
    uint[txr_limit] txr_id;
    string[txr_limit] txr_displayTime;
    uint[txr_limit] txr_price; //should be float; multiply 100 times
    string[txr_limit] txr_contactPerson;
    string[txr_limit] txr_contactWay; //email or ...
    string[txr_limit] txr_name;
    string[txr_limit] txr_status;
    string[txr_limit] txr_companyName;
    string[txr_limit] txr_date1;
    uint[txr_limit] txr_reductionExpected;
    string[txr_limit] txr_description;
    string[txr_limit] txr_file1;
    string[txr_limit] txr_file2;
 */


@RestController
@RequestMapping("CEA_Transaction")
public class CEA_Trans_Controller {
    @Autowired
    private CEA_TransactionService service;

    @GetMapping("getSize_a")
    public int getEntrySize_a() throws Exception {

        String response = service._getSize().getValues();
        int returnValue = ParserTools.ExtractInt(response);
        System.out.println("size of entries is: " + returnValue);
        return returnValue;
    }
    @GetMapping("DisplayAll")
    public String getAllEntry_c() throws Exception {
        String response = service._getSize().getValues();
        int size = ParserTools.ExtractInt(response);
        JSONArray cea_transactions = new JSONArray();
        for (int index = 1; index <= size; index++) {
            // for one entry
            BigInteger number = BigInteger.valueOf(index);
            CEA_TransactionGetTransaction1InputBO input1 = new CEA_TransactionGetTransaction1InputBO(number);
            CEA_TransactionGetTransaction2InputBO input2 = new CEA_TransactionGetTransaction2InputBO(number);
            //Parse returnObject
            List<Object> list1 = service.getTransaction1(input1).getReturnObject();
            List<Object> list2 = service.getTransaction2(input2).getReturnObject();
            JSONObject cea_transaction = new JSONObject();
            cea_transaction.put("companyName", list1.get(0));
            cea_transaction.put("companyName", list1.get(1));
            cea_transaction.put("transAmount", list1.get(2));
            cea_transaction.put("display_time", list1.get(3));
            float temp = Integer.valueOf((Integer) list1.get(4)) / 100;
            cea_transaction.put("price", temp);
            cea_transaction.put("contactPerson", list2.get(0));
            cea_transaction.put("contactWay", list2.get(1));
            System.out.println(cea_transaction);

            cea_transactions.put(cea_transaction);
        }
        System.out.println(cea_transactions);
        return cea_transactions.toString();
    }


}

// http://localhost:8080/CEA_Transaction/DisplayAll   展示所有CEA交易信息
