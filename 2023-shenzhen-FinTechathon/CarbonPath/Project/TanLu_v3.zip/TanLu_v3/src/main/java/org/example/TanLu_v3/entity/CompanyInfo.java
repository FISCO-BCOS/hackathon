package org.example.TanLu_v3.entity;

import lombok.Data;

@Data
public class CompanyInfo {
    public int id_company;
    public String username;
    public String password;
    public int type_c; // type = 1/2/3--企业/第三方审计机构/政府监管机关
    public String companyName;
    public String industry;
    public String address_c;
    public String contact;
    public String liscence;
    public String LegalRepresentative_Certification;
    public String AccountRepresentative_Authorization;
    public int status; // status = 0/1 等待审核/审核通过
    public int id_TransactionAccount_fk;

    public CompanyInfo(){

    }
    public CompanyInfo(int id_company, String username, int type_c, String companyName, String industry, String address_c, String contact, String liscence, String LegalRepresentative_Certification, String AccountRepresentative_Authorization, int status, int id_TransactionAccount_fk){
        this.id_company = id_company;
        this.username = username;
        this.password = password;
        this.type_c = type_c;
        this.companyName = companyName;
        this.industry = industry;
        this.address_c = address_c;
        this.contact = contact;
        this.liscence = liscence;
        this.LegalRepresentative_Certification = LegalRepresentative_Certification;
        this.AccountRepresentative_Authorization = AccountRepresentative_Authorization;
        this.status = status;
        this.id_TransactionAccount_fk = id_TransactionAccount_fk;
    }

}


/*
id_company: int
username: varchar(255)
password: varchar(255)
type: int
companyName: varchar(255)
industry: varchar(255)
address: varchar(255)
contact: varchar(255)
liscence: varchar(255)
LegalRepresentative_Certification: varchar(255)
AccountRepresentative_Authorization: varchar(255)
status: int
id_TransactionAccount_fk: int
 */
