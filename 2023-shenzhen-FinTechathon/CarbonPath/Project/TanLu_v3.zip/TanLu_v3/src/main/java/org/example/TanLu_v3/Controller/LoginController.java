package org.example.TanLu_v3.Controller;


import org.example.TanLu_v3.service.QueryService;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("test")
public class LoginController {
    @Autowired
    private QueryService service;

    @GetMapping("login")
    public boolean checkLogin(String username, String password) throws Exception {

        boolean flag = false;
        String DBusername = service.queryDB_username();
        String DBpassword = service.queryDB_password();
        if(username.equals(DBusername) && password.equals(DBpassword)){
            flag = true;
        }
        return flag;
    }
    @GetMapping("login2")
    public JSONObject checkLogin2(String username, String password) throws Exception {
        boolean flag = false;
        String DBusername = service.queryDB_username();
        String DBpassword = service.queryDB_password();

        JSONObject object = new JSONObject();

        if(username.equals(DBusername) && password.equals(DBpassword))
        {
            //login success
            object.put("code", 20000);
            object.put("data", "Success");
            //flag = true;
        }
        else
        {
            //login failure
            object.put("code", 404);
            object.put("data", "Failure");
            //flag = true;
        }
        return object;
    }
    @GetMapping("logout")
    public JSONObject logout() throws Exception {
        JSONObject object = new JSONObject();
            //login success
            object.put("code", 20000);
            object.put("data", "Success");
        return object;
    }
}
// http://localhost:8080/test/login?username=admin2&password=123456
// http://localhost:8080/test/login2?username=admin2&password=123456


// 登录：/test/login - 登录成功返回 bool true 错误信息：false
// 交易获取： /test/getValue  - 交易发送： /test/setValue?param=

