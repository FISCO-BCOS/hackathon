package org.example.TanLu_v3.model.bo;

import java.lang.Object;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Clearance_getclBoughtInputBO {
  private String companyName;

  public List<Object> toArgs() {
    List args = new ArrayList();
    args.add(companyName);
    return args;
  }
}
