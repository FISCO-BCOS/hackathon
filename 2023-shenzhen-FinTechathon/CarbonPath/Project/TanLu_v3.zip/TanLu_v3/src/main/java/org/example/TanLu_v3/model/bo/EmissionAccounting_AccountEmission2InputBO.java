package org.example.TanLu_v3.model.bo;

import java.lang.Object;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmissionAccounting_AccountEmission2InputBO {
  private BigInteger amount6;

  private BigInteger amount7;

  private BigInteger amount8;

  private BigInteger amount9;

  private BigInteger amount10;

  public List<Object> toArgs() {
    List args = new ArrayList();
    args.add(amount6);
    args.add(amount7);
    args.add(amount8);
    args.add(amount9);
    args.add(amount10);
    return args;
  }
}
