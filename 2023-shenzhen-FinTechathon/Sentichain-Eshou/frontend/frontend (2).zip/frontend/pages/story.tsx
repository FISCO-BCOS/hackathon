// pages/story.tsx

import React, { useState, useEffect } from "react";
import StoryCard from "../components/StoryCard";
import Link from "next/link";
import router from "next/router";
import { comment } from "postcss";

interface story {
  StoryID: number;
  StoryDetail: string;
  CID: number;
  Time: string;
  PublicAddress: string;
}

type StoryData = {
  CID: number;
  PublicAddress: string;
  StoryDetail: string;
  StoryID: number;
  Time: string;
};

interface Comment {
  UserAddress: string;
  Time: string;
  Info: string;
}

type ProductData = {
  [key: string]: StoryData[];
};

const Product_data: ProductData = {
  "科比逝世三周年!詹姆斯发文怀念科比和Gigi": [
    {
      CID: 18,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "我是一个湖人队的忠实球迷，而科比·布莱恩特则是我篮球追逐的神话。我第一次看到科比在球场上的表演，便深深被他的专业精神和无与伦比的天赋所吸引。每一场比赛，我都坚定地支持着他，无论球队胜败。科比的冷静、果断和全力以赴的比赛态度成为我生活的榜样。我记得那个81分的比赛，那一刻，我仿佛亲历了传奇的诞生。巨星陨落，传奇永存。",
      StoryID: 16,
      Time: "2023-12-16 07:26:31",
    },
    {
      CID: 19,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "在洛杉矶斯台普斯中心，我观看了科比的最后一场比赛。这场比赛里我穿着科比反转青蜂侠这双鞋，鞋码42，现在将它“传递”给有缘人。最后谈一些自己的感想。 | 2016年4月13日，洛杉矶湖人以101-96力克犹他爵士，科比-布莱恩特在这场生涯谢幕战50投22中攻下60分4篮板4助攻，创造联盟球员在生涯谢幕战的得分最高纪录。岁月枷锁的封印轰然碎裂，步履蹒跚的英雄重获神威，科比用一场旷古绝今的盛大表演告别这片明光烁亮的赛场。Mamba Out——一声辞别，后会无期。",
      StoryID: 17,
      Time: "2023-12-16 07:29:04",
    },
    {
      CID: 20,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "第一次知道科比，是2001年NBA总决赛，湖人对76人。那也是我第一次看NBA，那时候爱上的是艾弗森，全身纹身之下，是十几处大大小小的伤病，小小的身躯在场上风驰电掣、闪转腾挪，挑战着强大的紫金王朝。他骨子里那种叛逆、强悍和不屈，还有什么比这更能吸引青春期少年的崇拜?而那时的科比，给我留下印象最深的，还只是那一个爆炸头而已。早年的辉煌之后，兵败活塞，王朝崩塌，鲨鱼东游，鹰郡事件一，全世界都在指责科比、咒骂科比。在那个时候，你简直难以想象科比今天退役时所受到的尊崇。那个时候的科比，每个夜晚都从法庭直接踏上球场，把一腔怒火发泄到对手身上，迎着山呼海啸的嘘声拿下30、40、50、60分。那个时候的科比，在千夫所指中居然走上了个人能力的巅峰，他一次次摧毁无数球迷的主队，一次次将处于低谷的湖人拉回到季后赛的行列。“得分爆炸力”、“球场统治力R”这样的词汇流传开来以形容科比。本人有幸观看了科比09年的比赛，2009年科比·布莱恩特比赛的球面观感如同沉浸在一场精彩的艺术表演中。他的技术娴熟、决胜时刻的冷静、以及对比赛的投入，构成了一场无以伦比的篮球盛宴。在球场上，科比的运球如同音符一般流畅，每一个动作都充满力量和控制。他的投篮仿佛一场精密的演奏，每一个出手都带有决断与精准。那场比赛中，科比的81分创造了历史，每一分都凝聚着他对篮球的热爱和对胜利的渴望。在紧张的比赛中，他展现了作为领袖的风范，带领球队冲破困境。观看这场比赛，我仿佛看到了一位巨人在球场上征服一切，他的激情和毅力让人为之倾倒。更重要的是，这场比赛不仅仅是关于篮球的胜负，更是关于一个人对梦想的追逐，对困境的挑战。科比的表现不仅让我热血沸腾，也在心灵深处留下了对奋斗和坚持的深刻印记。那一刻，我成为了科比的坚定粉丝，他的传奇故事激励着我追逐自己的梦想。科比的篮球风格不是每一个人喜欢的，科比狂傲的性格不是每一个人待见的，但是，无论是黑是蜜，无论是主队被摧毁后的切齿痛恨、还是为逆天表现彻底臣服，都是我们记忆里宝贵的时刻。我们之所以拥有这样珍贵的回忆，我们之所以如此热爱篮球，就是因为这个叫科比·布莱恩特的男人，用他的叛逆、强悍和不屈，捍卫着自己的光荣，书写着自己的传奇，直到他生涯最后一刻。",
      StoryID: 18,
      Time: "2023-12-16 07:45:24",
    },
    {
      CID: 21,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "十年之间，弹指一挥间，科比终究还是走了。回顾过去的青春岁月，有你的陪伴，真好！每当我遇到困难的时候，我总会想，假如是科比，他怎么去解决？当一个人用他的一生去诠释某种坚定信念的时候，就注定他是永垂不朽的。哪怕他已经离开了这个世界，他依然活在了很多人的心中。奋勇拼搏的精神是值得赞扬的，面对困境的永不言弃，是值得铭刻的。对事业完美的执着，对技艺精益求精的精神，对困难的蔑视，对人生目标的孜孜不倦，不论他是否在某方面具有天赋还是没有天赋，只要他肯付出，就一定会有意想不到的收获。不是每一个人都能最终实现梦想，但我觉得要做一个对梦想永不言弃的人。不管最后的结果怎么样，都要历尽艰辛，努力去实现它。\n每一个人都每一个人的生活，并不是每一个人都能做到MAMBA那样的程度。但对于我们来说，MAMBA是精神的偶像，是前行的领路人，是对理想的一种寄托，也是对自己未来的希望。MAMBA走后，NBA就看得少了。除了一年一度的 总决赛，偶尔还会看上一两眼，由于工作的繁忙，时间对于我们来说，已经不是当初的那个我了。\n2020年，1月26日，科比和女儿吉安娜一同在直升机事故中不幸遇难。敲下这段字眼，总是有些难以言喻的心情在释放。人生没有什么是必然的，也没有什么是偶然的。我曾记得那一天早上醒来，一翻开手机，就是这条新闻。我恍然惊起，说了一声：“不可能！”。我宁愿这是一条假新闻，宁愿科比在那场事故中神奇地活下来。我们见证了太多关于他的奇迹。可这一次，真的，不是最后一场球赛，也不是球衣退役，而是他真的到天堂去做MVP去了。",
      StoryID: 19,
      Time: "2023-12-16 07:50:07",
    },
  ],
  名侦探柯南x潮玩星球: [
    {
      CID: 22,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "青山作为一名漫画家，画风最好水平是柯南中期，分镜最好水平是《YAⅠBA》（只要看过的都知道这部漫画战斗有多频繁，战斗分镜有多简洁明快，切换自如）。现在柯南连载速度放缓，但画风与中期差距不大，倒是隔壁《魔术快斗》，看一看第一、二卷和第三、四、五卷对比，简直不是一部漫画。不得不说魔快的冷门和柯南的爆火，画风差距在其中一定有很重大的影响。\n我入柯南坑的原因是10年的时侯去我叔叔家玩，晚上看了M13，我被这部片吸引了，回家百度出了柯南全集，看了以后才发现这是多么精彩。青山写的内容没有多深刻，但他的写作如仓木麻衣的歌声一样，具有融化心灵的力量，才会让柯南成长为一部国民番。\n青山在小学毕业作文中写他想成为一名画侦探漫画的漫画家，但他开始工作时并不是想做一名漫画家，而是一名动画画师，这也是他后来能为剧场版画原画的原因。由于他父母的劝他当美术老师，而他只能为了坚持自己梦想强行漫画家出道，算是证明了漫画能为自己混口饭吃，他父母才不再干涉。\n",
      StoryID: 20,
      Time: "2023-12-16 07:53:31",
    },
    {
      CID: 23,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "先声明一下观点:我是纯血新兰党，如果有支持柯哀的朋友可以直接滑到下一个故事。\n我为什么是新兰？第一是因为我在四五岁的年纪入的的名柯，那时候小嘛，觉得男主女主在一起是天经地义的事情，第二是长大后发现新兰真的很美好，还是怪73给这对情侣加的时候buff太多了:一见钟情+长久陪伴+一吻定情，恨不得将一切形容爱情美好状态的词都加进去，因为新兰我才第一次喜欢“青梅竹马”“两小无猜”这两个词，此后的十几年都觉得这样是很美好的爱情。\n而且新一和兰他们的三观相同，三观是决定一对情侣走得是否长远的重要基础，这一点也不用我说，纽约篇那里可以看得出来。\n再就是，新一辛辛苦苦当了兰的十几年男闺蜜，各种给兰的情书都半路截去，好不容易转正了，实在令人心疼。\n刚看到了一个博主故事提到“如果没有兰，小哀和柯南一定会一起长大，一定会相爱”这一点实在不能苟同，从我的观点来看，新一给我的那种感觉就是喜欢那种乐观，开朗的女孩子，而且他是“毛利兰”主义者，而哀太理智理性了，她和柯南我觉得只是战友关系，为了同一个目标而奋斗。希望哀有一个很好很好的结局吧。",
      StoryID: 21,
      Time: "2023-12-16 07:57:59",
    },
    {
      CID: 24,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "柯哀党都是什么心态呢，明知毫无结果，却还是如此热爱\n因为灰原能填补柯南/新一内心的孤独。\n新一是很孤独的，长辈对于他而言太优秀，是自己要超越的目标而不是贴心伙伴，同辈对他而言又太无聊，强大的推理能力让他轻易能猜度出别人所想，比如在危命篇中他接受众人欢呼时，只是看了大众一眼，并没有骄傲或其他的表现，他的心里自有一股不肯服输的傲劲，但偏偏他又选择了守护者这条道路，拥有过人的智慧与能力却不愿意轻易伤害别人，那就像一只大象时时刻刻都要注意自己是否踩碎了蚂蚁，其中的无聊和痛苦是显而易见的，但偏偏他周围的人并没有与他匹配的大象，所以没有人能理解他的痛苦与孤独。\n在漫画前期，小兰是能缓解这种孤独的，但为什么呢？是因为小兰不喜欢推理，这让精力无处发泄的新一有了一个目标，就是让小兰喜欢上推理，成为自己的华生，然后让她来缓解自己的孤独，这就是为什么新一总要在兰的面前讲福尔摩斯，因为这就是他对兰的征服欲，他一定要想方设法攻破兰这道堡垒。\n这种征服欲随着灰原的出现，理所应当的转移到了灰原身上，他在哀的面前几乎没怎么讲过福尔摩斯，反而倒是哀主动讲了好几次，为什么，双方都了解，有共识的东西了啊，平时偶尔聊几句就够了，还有其他大把的话题排队呢，不论是案子，人际关系，学术，推理小说，运动还是其他方面，双方不仅能有来有回，甚至哀在生化，物理，药理，网络技术等纯粹理论的领域方面（哀的应用倒是很差，饮水鸟和静电什么的表现太差）还能碾压他，柯对哀一开始那是什么感情？那是见猎心喜，征服欲搜一下就上来了，所以柯对哀聊的最多的是啥啊？足球，因为哀一开始对足球不感兴趣，好，那我非要你喜欢上足球，所以哀用了一天的时间就赶到了兰十几年才到达的进度，而最让新一，或者说小柯满足的是，哀真的因为他对足球有了一定的兴趣，你想想你们给朋友安利成功一款游戏，小说或爱好时，你们是什么心情？你们会不会主动向被安利的一方靠近？新一活了十几年，但只有哀在的这半年里他的心是充实的，圆满的，也就只有哀可以恃宠而骄，拿捏柯南，不仅仅是因为药，也不仅仅是因为组织，而是柯南十几年无法跟别人聊的话题，都只有哀能做出他想要的回应，所以柯南害怕失去哀——在遇到哀以前，他还可以憋着，曾经沧海难为水，失去了哀，他到底还有谁可以放心的去聊那些话题？赤井？降谷零？他们两个柯南真的放心嘛？真放心为什么从来不和他们暴露自己真身？还是说因为更重要的某个人不可以暴露真身？\n其实同样的道理放在哀身上也成立，除了柯南，她有谁可以信任？什么叫命运共同体？这两个人，你杀任何一个都等于双杀，他们俩都承担不起失去另一个人的后果。",
      StoryID: 22,
      Time: "2023-12-16 08:00:14",
    },
    {
      CID: 25,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "嗑快新嗑的就是就是那种若即若离，捉摸不定的感觉!\n说实话快斗是不应该认识工藤的，但是作为怪盗，就不一样了，他可以有他的小侦探。\n怪盗和侦探本应该是命中的宿敌，但是在有的时候他们却可以并肩作战，毫无顾忌的把自己的后背交给对方。\n在绀青之拳里，可以说基德和柯南的关系是有史以来最亲密的时刻（虽然说KID sama被削弱的很惨），可是他们的关系也有一定的界限。基德在天台包扎伤口时，柯南一步一步走向没有任何伪装的真实的快斗，却被基德突然换上的披风挡住了视线，再看，基德已经完成了全部的穿衣步骤。这样一个举动，使这部剧里他们越界的关系瞬间回到了原来的位置。所有的合作都止步于怪盗基德的身份，柯南再前进一步，就会被基德拒之于千里之外。但是即使如此他们的默契不会被切断。\n我想如果是工藤遇到基德，他一定会把基德绳之以法，他不会想知道基德的故事，更不可能和基德一起合作，可是柯南就不一样了，他见过这个世界的不美好，他知道这个事件并不是非黑即白的。他在与黑暗组织对抗的过程中也成长了许多，所以他愿意去与怪盗基德合作，去了解他的故事。\n或许这就是柯基cp的萌点（之一）吧，在交错的命运中并肩作战，将脆弱的后背交给对方，若即若离却诚挚可靠。",
      StoryID: 23,
      Time: "2023-12-16 08:02:36",
    },
  ],
  奥特曼之日: [
    {
      CID: 26,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "新冠的变异、杀伤力，给了人类空前的恐惧感。人们希望战胜新冠，或者说，人们想要奥特曼战胜新冠病毒这头怪兽，人们怀念荧屏前奥特曼打怪兽的日子，曾经，90年后的几代人都变成了光——在遭到社会毒打以后，有的已经不相信什么正义了——我们看到那些黑心垄断商人披上了慈善家的外衣到处演讲、抄袭者拥有自己的影视公司、最low的人占据最多的财富，好人活得像城墙下孤独的狗——请问谁还相信正义？人们放弃正义，也放弃梦想，甘心做犬儒，当年奥特之星的信念，就像迪迦变成石像一样沉入了深深大海。历经了职场的浮浮沉沉，无常的聚散，父母的变老，大师的离世，我们无处叫喊那份惶恐不安，日复一日的生活在相同的困扰里，但是，病毒危机让很多人重新省视生活的意义——\n我们可以平凡，却不能软弱!我们纵然圆滑处世，却不能没有原则!我们也许一辈子都无法实现梦想，但却不能丧失追寻梦想的勇气!我们可以被爱情和情欲放逐，却仍然敢搭讪美女，哪怕吃不到天鹅肉，但是癞蛤蟆也有追求美学的权力，我们可以被朋友背叛千百次，却不能丢失热忱之心!\n我们可以失败千百次，却永远会重新站起来!\n让我回到那个时代，那时候，光之国蔚然闪亮，万物都在萌芽状态，我们从银河之滨发现奇迹之光，注入3000万年前的金字塔下的古代巨人石像。\n奥特曼精神一直没有死去，每个人都是奥特之星。\n光，一直都在人心里。",
      StoryID: 24,
      Time: "2023-12-16 08:09:26",
    },
    {
      CID: 27,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "我犹记得那一天的情形，在一个窄小的，破旧的，路边摊似的小店里，我选中了这一盒《杰克奥特曼》光碟。回来的路上，撞见两位族兄都是羡慕不已。打开包装盒，光碟正面印着紫色的奥特曼与怪兽格斗的纹路，即使是现在想起来都觉得惊讶。毕竟在那个盗版盛行的年代，有时候你买的光碟内容甚至可以与标题毫不相干。那一盒光碟并不是全套，只是第一集开始到中间部分而已。但这一部《杰克奥特曼》却成为了我内心对奥特曼整个系列最原始的印象。\n如今岁月已逝，奥特曼的身影或许已不再频繁出现在我生活中，但那份怀念和对那段无忧无虑岁月的眷恋却永远存在。小时候奥特曼的陪伴，不仅是一段美好的记忆，更是一个激发勇气和正义之心的动力源泉。\n",
      StoryID: 25,
      Time: "2023-12-16 08:14:11",
    },
    {
      CID: 28,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "为什么好多人都喜欢奥特曼？\n因为我们既是光，又是人类吧。\n“当我第一次看到奥特曼的时候，我还以为我遇见了上帝，觉得他可以把人类导向正途，但事实好像不是，后来我才了解到，奥特曼既是光，也是人类！所以，大古队员，你没有义务去对付一个根本赢不了的敌人，你应该听懂了吧。”\n武侠小说是成年人的童话，奥特曼则是小孩的童话，其实都反映了人类渴望有无上的力量，足以呼风唤雨，成为救世主。",
      StoryID: 26,
      Time: "2023-12-16 08:17:35",
    },
    {
      CID: 29,
      PublicAddress:
        "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646",
      StoryDetail:
        "以前当身边的人谈论到奥特曼如何如何幼稚，特摄剧如何如何幼稚的时候，其实有想过去解释一下，也有点买弄的心理，但想想还是算了，人家根本不鸟你，从小到大生活中遇到的真心喜爱，可以相互讨论分享特摄的人，也就那几个，真的挺无趣。其实作为特摄迷，最开心的莫过于分享传播，让更多人知道。作为特摄迷，就算有人说特摄如何如何幼稚，甚至弱智，我都不觉得生气，因为真正令人难过的并不是有人不认同，而是没有多少人有兴趣去了解，他们的不认同，没有建立在充分的了解上。明明对一部作品没有多少了解，却敢妄加评论，这种人最令人惋惜，因为他停滞住了一部优秀作品的传播，而这就是大众对特摄剧的评价不公的根源。\n突然想到了迫水队长的一番话，大概，这就是我们特摄迷想表达的心情吧：\n“不能为人所理解的孤独就是指这个吧这并不是什么特别的事谁都会遇到，对自己来说理所当然的事对别人来说却不同寻常对自己来说十分重要的东西对别人来说却是十分无聊的东西不明白是很正常的，因此想要让别人明白就得拼命地把自己的想法传达给他人。”",
      StoryID: 27,
      Time: "2023-12-16 08:19:09",
    },
  ],
  "虚拟偶像再临，歌后邓丽君“重现”舞台": [],
  "2023年奥斯卡获奖名单!杨紫琼与影后创造历史,《瞬息》横扫七大奖项": [],
  "一个鱿鱼游戏带来1000亿,奈飞找到了爆款公式": [],
  "小野来了·限定快闪": [],
  "《原神》4.0卡池更新": [],
  易梦玲谷嘉诚夕阳红版多巴胺穿搭: [],
  "首个国风潮玩联名火箭，泡泡玛特助力航天科技": [],
};

const Story = () => {
  const [stories, setStories] = useState<story[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  //获取所有热搜
  const [hotSearchOptions, setHotSearchOptions] = useState<string[]>([]);
  //获取选中的热搜
  const [selectedHotSearch, setSelectedHotSearch] = useState<
    string | undefined
  >(undefined);
  // 使用数组来管理每个故事的 Dropdown 显示状态
  const [showDropdowns, setShowDropdowns] = useState<boolean[]>(
    Array(stories.length).fill(false)
  );

  //获取每个故事对应的评论
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState("");

  const pubAddress =
    "80f442c18a3ad4f9944b5274a90add19b35cccd1fdd47ba9b28e91f67a3b19214723f7c9813e71c2e18a18bfc28414ed078934ace6adecd733fbb45f8d322646";
  const handleSearch = async () => {
    try {
      const response = await fetch("http://81.71.5.116:9090/storiesitem", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = await response.json();
      if (data) {
        setIsLoading(false);
      }
      console.log(data.storieslist);
      setStories(data.storieslist);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    handleSearch();
    // 获取所有热点名称
    const hotSearchNames = Object.keys(Product_data);
    setHotSearchOptions(hotSearchNames);
  }, [pubAddress]);

  const handleSearch1 = () => {
    if (selectedHotSearch) {
      const selectedStories = Product_data[selectedHotSearch];
      console.log(selectedStories);
      setIsLoading(false);
      setStories(selectedStories || []);
      console.log(stories);
    }
  };

  const handleToggleDropdown = (index: number) => {
    // 切换对应故事的 Dropdown 显示状态
    const newShowDropdowns = [...showDropdowns];
    newShowDropdowns[index] = !newShowDropdowns[index];
    setShowDropdowns(newShowDropdowns);
  };

  const handleGoToDetails = (productId: number) => {
    // 使用 next/router 的 push 方法手动触发路由导航
    router.push(`/[productId]`, `/${productId}`);
  };

  // 点击评论按钮时触发的函数
  const handleIndexComments = async (storyId: number, index: number) => {
    try {
      // 向后端发送请求获取指定故事的评论信息
      const response = await fetch(
        `http://81.71.5.116:9090/searchcomment?storyid=${storyId}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const data = await response.json();
      if (data) {
        // 将评论信息更新到 comments 数组
        // 重置原来的评论，然后再赋值
        console.log(data)
        setComments([]);
        setComments(data.commentlist);
        console.log(comments)
      }
    } catch (error) {
      console.error(error);
    }
  };
  // 上传新评论时触发的函数
  const handleNewComment = async (storyId: number) => {
    try {
      // 向后端发送请求获取指定故事的评论信息
      console.log(newComment);
      const response = await fetch(
        `http://81.71.5.116:9090/releasecomment?storyid=${storyId}&useraddress=${pubAddress}&comment=${newComment}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const data = await response.json();
      if (data) {
        console.log(data);
        setNewComment('');
        alert("评论成功！");
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div
      className="hero min-h-screen"
      style={{
        backgroundImage:
          "url(https://cdn.midjourney.com/3a0d817a-d493-4e17-acd0-0620fff981ac/0_2.webp)",
        backgroundColor: "rgba(255, 255, 255, 0.1)",
      }}
    >
      {/* <div className="hero-overlay bg-opacity-0"></div> */}
      <div className="hero-content text-center text-neutral-content">
        <div className="w-full p-5">
          <h1 className="mb-5 text-6xl font-bold font-sans text-white">
            What happened elsewhere?
          </h1>
          <div className="join mb-5">
            <select
              className="select select-bordered join-item w-full max-w-xs"
              onChange={(e) => setSelectedHotSearch(e.target.value)}
              value={selectedHotSearch || ""}
              style={{ color: "black", minWidth: "300px" }}
            >
              <option disabled value="">
                选择热搜
              </option>
              {/* 动态渲染热搜选项 */}
              {hotSearchOptions.map((option, index) => (
                <option key={index} value={option}>
                  {option}
                </option>
              ))}
            </select>
            <button
              className="btn join-item rounded-r-full"
              onClick={handleSearch1}
              style={{ minWidth: "100px", height: "40px" }}
            >
              Search
            </button>
          </div>
          <div
            className="mx-auto rounded-lg border glass flex-col p-5"
            style={{ maxWidth: "100%" }}
          >
            {isLoading ? (
              <div className="product-display w-full mt-40 p-7 mx-auto rounded-lg border glass flex items-center justify-center">
                <span className="loading loading-bars loading-lg"></span>
                <span className="loading loading-bars loading-lg"></span>
                <span className="loading loading-bars loading-lg"></span>
              </div>
            ) : (
              stories.map((s, index) => (
                <div
                  key={index}
                  className="card bg-base-100 shadow-xl text-black m-5 glass"
                >
                  <div className="card-body">
                    <div
                      className="tooltip tooltip-open tooltip-right"
                      data-tip={`商品id:` + s.CID}
                    >
                      <h2 className="card-title text-left">用户地址：</h2>
                      <p className="text-left break-all">{s.PublicAddress}</p>
                    </div>
                    <p className="text-3xl m-5 text-left break-all">
                      {s.StoryDetail.length > 120
                        ? s.StoryDetail.substring(0, 120) + "..."
                        : s.StoryDetail}
                    </p>
                    <p className="text-left">商品发布时间：{s.Time}</p>
                    {/* 添加按钮，点击跳转到商品详情页 */}
                    <button
                      className="btn btn-sm mt-4"
                      onClick={() => handleGoToDetails(s.CID)}
                    >
                      商品详情
                    </button>
                    {/* 评论功能 */}
                    <button
                      className="btn btn-sm mt-4"
                      onClick={() => {
                        // 点击评论按钮时触发函数，传入故事ID和索引
                        handleIndexComments(s.StoryID, index);
                        // 切换对应故事的 Dropdown 显示状态
                        handleToggleDropdown(index);
                      }}
                    >
                      评论
                    </button>
                    {showDropdowns[index] && (
                      <div>
                        {/* 这块包含两个部分，分别是高赞评论的展现，以及上传用户的评论 */}
                        <p className="text-2xl text-left font-bold">高赞评论</p>
                        {/* 遍历展示高赞评论 */}
                        {comments && comments.length !== 0 ? (
                          comments.map((comment, commentIndex) => (
                            <div key={commentIndex} className="text-left mb-2">
                              <p className="break-all">用户地址</p>
                              <p className="break-all text-sm">{comment.UserAddress}</p>
                              <p className="text-sm m-2">评论时间：{comment.Time}</p>
                              <p className="text-2xl font-bold break-all">
                                "{comment.Info}""
                              </p>
                              <div className="divider"></div> 
                            </div>
                          ))
                        ) : (
                          <span className="mb-5 text-left">暂无更多评论</span>
                        )}
                        <div>
                          <div className="join mt-2">
                            <input
                              className="input input-bordered join-item"
                              placeholder="输入您的评论"
                              value={newComment}
                              onChange={(e) => {
                                // 在此处更新评论内容
                                setNewComment(e.target.value);
                              }}
                            />
                            <button
                              className="btn join-item rounded-r-full"
                              onClick={() => handleNewComment(s.StoryID)}
                            >
                              上传评论
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Story;
