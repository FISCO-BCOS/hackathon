/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./components/Header.tsx":
/*!*******************************!*\
  !*** ./components/Header.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Header: () => (/* binding */ Header)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ \"./node_modules/next/image.js\");\n/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _components_useOutsideClick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/useOutsideClick */ \"./components/useOutsideClick.ts\");\n\n\n\n\n\n\nconst NavLink = ({ href, children })=>{\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();\n    const isActive = router.pathname === href;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n        href: href,\n        passHref: true,\n        className: `${isActive ? \"bg-sky-500 shadow-md\" : \"\"} hover:bg-sky-500 hover:shadow-md focus:!bg-sky-500 active:!text-neutral py-1.5 px-3 text-sm rounded-full gap-2 grid grid-flow-col`,\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n        lineNumber: 12,\n        columnNumber: 5\n    }, undefined);\n};\n/**\r\n * Site header\r\n */ const Header = ()=>{\n    const [isDrawerOpen, setIsDrawerOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const burgerMenuRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);\n    (0,_components_useOutsideClick__WEBPACK_IMPORTED_MODULE_5__.useOutsideClick)(burgerMenuRef, (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>setIsDrawerOpen(false), []));\n    const navLinks = /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(NavLink, {\n                    href: \"/\",\n                    children: \"好物列表\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                    lineNumber: 38,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(NavLink, {\n                    href: \"/sellGoods\",\n                    children: \"我要发布\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                    lineNumber: 41,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                lineNumber: 40,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(NavLink, {\n                    href: \"/story\",\n                    children: \"情感寄托\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                    lineNumber: 46,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                lineNumber: 45,\n                columnNumber: 7\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"li\", {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(NavLink, {\n                    href: \"/personalInfo\",\n                    children: \"个人信息\"\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                    lineNumber: 51,\n                    columnNumber: 9\n                }, undefined)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                lineNumber: 50,\n                columnNumber: 7\n            }, undefined)\n        ]\n    }, void 0, true);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"sticky lg:static top-0 navbar bg-base-100 min-h-0 flex-shrink-0 justify-between z-20 shadow-md shadow-sky-500 px-0 sm:px-2\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            className: \"navbar-start w-auto lg:w-1/2\",\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {\n                    href: \"/\",\n                    passHref: true,\n                    className: \"hidden lg:flex items-center gap-2 ml-4 mr-6 shrink-0\",\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"flex relative w-10 h-10\",\n                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {\n                                alt: \"SE2 logo\",\n                                className: \"cursor-pointer\",\n                                fill: true,\n                                src: \"/sentichain_logo.png\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                                lineNumber: 85,\n                                columnNumber: 13\n                            }, undefined)\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                            lineNumber: 84,\n                            columnNumber: 9\n                        }, undefined),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            className: \"flex flex-col\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                    className: \"font-bold leading-tight\",\n                                    children: \"SentiChain\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                                    lineNumber: 88,\n                                    columnNumber: 13\n                                }, undefined),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                                    className: \"text-xs\",\n                                    children: \"让感动长留心间\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                                    lineNumber: 89,\n                                    columnNumber: 13\n                                }, undefined)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                            lineNumber: 87,\n                            columnNumber: 11\n                        }, undefined)\n                    ]\n                }, void 0, true, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                    lineNumber: 83,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"ul\", {\n                    className: \"hidden lg:flex lg:flex-nowrap menu menu-horizontal px-1 gap-2\",\n                    children: navLinks\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n                    lineNumber: 92,\n                    columnNumber: 9\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n            lineNumber: 60,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\components\\\\Header.tsx\",\n        lineNumber: 59,\n        columnNumber: 5\n    }, undefined);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0hlYWRlci50c3giLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUE2RDtBQUM5QjtBQUNGO0FBQ1c7QUFDd0I7QUFFaEUsTUFBTVEsVUFBVSxDQUFDLEVBQUVDLElBQUksRUFBRUMsUUFBUSxFQUErQztJQUM5RSxNQUFNQyxTQUFTTCxzREFBU0E7SUFDeEIsTUFBTU0sV0FBV0QsT0FBT0UsUUFBUSxLQUFLSjtJQUVyQyxxQkFDRSw4REFBQ0osa0RBQUlBO1FBQ0hJLE1BQU1BO1FBQ05LLFFBQVE7UUFDUkMsV0FBVyxDQUFDLEVBQ1ZILFdBQVcseUJBQXlCLEdBQ3JDLGtJQUFrSSxDQUFDO2tCQUVuSUY7Ozs7OztBQUdQO0FBRUE7O0NBRUMsR0FDTSxNQUFNTSxTQUFTO0lBQ3BCLE1BQU0sQ0FBQ0MsY0FBY0MsZ0JBQWdCLEdBQUdmLCtDQUFRQSxDQUFDO0lBQ2pELE1BQU1nQixnQkFBZ0JqQiw2Q0FBTUEsQ0FBaUI7SUFDN0NLLDRFQUFlQSxDQUNiWSxlQUNBbEIsa0RBQVdBLENBQUMsSUFBTWlCLGdCQUFnQixRQUFRLEVBQUU7SUFHOUMsTUFBTUUseUJBQ0o7OzBCQUNFLDhEQUFDQzswQkFDQyw0RUFBQ2I7b0JBQVFDLE1BQUs7OEJBQUk7Ozs7Ozs7Ozs7OzBCQUVwQiw4REFBQ1k7MEJBQ0MsNEVBQUNiO29CQUFRQyxNQUFLOzhCQUFhOzs7Ozs7Ozs7OzswQkFJN0IsOERBQUNZOzBCQUNDLDRFQUFDYjtvQkFBUUMsTUFBSzs4QkFBUzs7Ozs7Ozs7Ozs7MEJBSXpCLDhEQUFDWTswQkFDQyw0RUFBQ2I7b0JBQVFDLE1BQUs7OEJBQWdCOzs7Ozs7Ozs7Ozs7O0lBT3BDLHFCQUNFLDhEQUFDYTtRQUFJUCxXQUFVO2tCQUNiLDRFQUFDTztZQUFJUCxXQUFVOzs4QkF1QmIsOERBQUNWLGtEQUFJQTtvQkFBQ0ksTUFBSztvQkFBSUssUUFBUTtvQkFBQ0MsV0FBVTs7c0NBQ2xDLDhEQUFDTzs0QkFBSVAsV0FBVTtzQ0FDWCw0RUFBQ1gsbURBQUtBO2dDQUFDbUIsS0FBSTtnQ0FBV1IsV0FBVTtnQ0FBaUJTLElBQUk7Z0NBQUNDLEtBQUk7Ozs7Ozs7Ozs7O3NDQUU1RCw4REFBQ0g7NEJBQUlQLFdBQVU7OzhDQUNiLDhEQUFDVztvQ0FBS1gsV0FBVTs4Q0FBMEI7Ozs7Ozs4Q0FDMUMsOERBQUNXO29DQUFLWCxXQUFVOzhDQUFVOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OEJBRzlCLDhEQUFDWTtvQkFBR1osV0FBVTs4QkFBaUVLOzs7Ozs7Ozs7Ozs7Ozs7OztBQUl2RixFQUFFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbW9vZG1pbmQvLi9jb21wb25lbnRzL0hlYWRlci50c3g/MDM2OCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlQ2FsbGJhY2ssIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEltYWdlIGZyb20gXCJuZXh0L2ltYWdlXCI7XHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCB7IHVzZU91dHNpZGVDbGljayB9IGZyb20gXCIuLi9jb21wb25lbnRzL3VzZU91dHNpZGVDbGlja1wiO1xyXG5cclxuY29uc3QgTmF2TGluayA9ICh7IGhyZWYsIGNoaWxkcmVuIH06IHsgaHJlZjogc3RyaW5nOyBjaGlsZHJlbjogUmVhY3QuUmVhY3ROb2RlIH0pID0+IHtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBpc0FjdGl2ZSA9IHJvdXRlci5wYXRobmFtZSA9PT0gaHJlZjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxMaW5rXHJcbiAgICAgIGhyZWY9e2hyZWZ9XHJcbiAgICAgIHBhc3NIcmVmXHJcbiAgICAgIGNsYXNzTmFtZT17YCR7XHJcbiAgICAgICAgaXNBY3RpdmUgPyBcImJnLXNreS01MDAgc2hhZG93LW1kXCIgOiBcIlwiXHJcbiAgICAgIH0gaG92ZXI6Ymctc2t5LTUwMCBob3ZlcjpzaGFkb3ctbWQgZm9jdXM6IWJnLXNreS01MDAgYWN0aXZlOiF0ZXh0LW5ldXRyYWwgcHktMS41IHB4LTMgdGV4dC1zbSByb3VuZGVkLWZ1bGwgZ2FwLTIgZ3JpZCBncmlkLWZsb3ctY29sYH1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9MaW5rPlxyXG4gICk7XHJcbn07XHJcblxyXG4vKipcclxuICogU2l0ZSBoZWFkZXJcclxuICovXHJcbmV4cG9ydCBjb25zdCBIZWFkZXIgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2lzRHJhd2VyT3Blbiwgc2V0SXNEcmF3ZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBidXJnZXJNZW51UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcclxuICB1c2VPdXRzaWRlQ2xpY2soXHJcbiAgICBidXJnZXJNZW51UmVmLFxyXG4gICAgdXNlQ2FsbGJhY2soKCkgPT4gc2V0SXNEcmF3ZXJPcGVuKGZhbHNlKSwgW10pLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IG5hdkxpbmtzID0gKFxyXG4gICAgPD5cclxuICAgICAgPGxpPlxyXG4gICAgICAgIDxOYXZMaW5rIGhyZWY9XCIvXCI+5aW954mp5YiX6KGoPC9OYXZMaW5rPlxyXG4gICAgICA8L2xpPlxyXG4gICAgICA8bGk+XHJcbiAgICAgICAgPE5hdkxpbmsgaHJlZj1cIi9zZWxsR29vZHNcIj5cclxuICAgICAgICAgIOaIkeimgeWPkeW4g1xyXG4gICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgPC9saT5cclxuICAgICAgPGxpPlxyXG4gICAgICAgIDxOYXZMaW5rIGhyZWY9XCIvc3RvcnlcIj5cclxuICAgICAgICAgIOaDheaEn+WvhOaJmFxyXG4gICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgPC9saT5cclxuICAgICAgPGxpPlxyXG4gICAgICAgIDxOYXZMaW5rIGhyZWY9XCIvcGVyc29uYWxJbmZvXCI+XHJcbiAgICAgICAgICDkuKrkurrkv6Hmga9cclxuICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgIDwvbGk+XHJcbiAgICA8Lz5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzdGlja3kgbGc6c3RhdGljIHRvcC0wIG5hdmJhciBiZy1iYXNlLTEwMCBtaW4taC0wIGZsZXgtc2hyaW5rLTAganVzdGlmeS1iZXR3ZWVuIHotMjAgc2hhZG93LW1kIHNoYWRvdy1za3ktNTAwIHB4LTAgc206cHgtMlwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5hdmJhci1zdGFydCB3LWF1dG8gbGc6dy0xLzJcIj5cclxuICAgICAgICB7Lyog5Y+v5Lul5oqKbG9nb+aUvui/m+adpeS5i+WQjuWGjeWPlua2iOazqOmHiiAqL31cclxuICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJsZzpoaWRkZW4gZHJvcGRvd25cIiByZWY9e2J1cmdlck1lbnVSZWZ9PlxyXG4gICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgIHRhYkluZGV4PXswfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BtbC0xIGJ0biBidG4tZ2hvc3QgJHtpc0RyYXdlck9wZW4gPyBcImhvdmVyOmJnLXNreS01MDBcIiA6IFwiaG92ZXI6YmctdHJhbnNwYXJlbnRcIn1gfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0SXNEcmF3ZXJPcGVuKHByZXZJc09wZW5TdGF0ZSA9PiAhcHJldklzT3BlblN0YXRlKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICB7aXNEcmF3ZXJPcGVuICYmIChcclxuICAgICAgICAgICAgPHVsXHJcbiAgICAgICAgICAgICAgdGFiSW5kZXg9ezB9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWVudSBtZW51LWNvbXBhY3QgZHJvcGRvd24tY29udGVudCBtdC0zIHAtMiBzaGFkb3cgYmctYmFzZS0xMDAgcm91bmRlZC1ib3ggdy01MlwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0SXNEcmF3ZXJPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge25hdkxpbmtzfVxyXG4gICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgPExpbmsgaHJlZj1cIi9cIiBwYXNzSHJlZiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWwtNCBtci02IHNocmluay0wXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHJlbGF0aXZlIHctMTAgaC0xMFwiPlxyXG4gICAgICAgICAgICA8SW1hZ2UgYWx0PVwiU0UyIGxvZ29cIiBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiIGZpbGwgc3JjPVwiL3NlbnRpY2hhaW5fbG9nby5wbmdcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIGxlYWRpbmctdGlnaHRcIj5TZW50aUNoYWluPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+6K6p5oSf5Yqo6ZW/55WZ5b+D6Ze0PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJoaWRkZW4gbGc6ZmxleCBsZzpmbGV4LW5vd3JhcCBtZW51IG1lbnUtaG9yaXpvbnRhbCBweC0xIGdhcC0yXCI+e25hdkxpbmtzfTwvdWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlQ2FsbGJhY2siLCJ1c2VSZWYiLCJ1c2VTdGF0ZSIsIkltYWdlIiwiTGluayIsInVzZVJvdXRlciIsInVzZU91dHNpZGVDbGljayIsIk5hdkxpbmsiLCJocmVmIiwiY2hpbGRyZW4iLCJyb3V0ZXIiLCJpc0FjdGl2ZSIsInBhdGhuYW1lIiwicGFzc0hyZWYiLCJjbGFzc05hbWUiLCJIZWFkZXIiLCJpc0RyYXdlck9wZW4iLCJzZXRJc0RyYXdlck9wZW4iLCJidXJnZXJNZW51UmVmIiwibmF2TGlua3MiLCJsaSIsImRpdiIsImFsdCIsImZpbGwiLCJzcmMiLCJzcGFuIiwidWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/Header.tsx\n");

/***/ }),

/***/ "./components/useOutsideClick.ts":
/*!***************************************!*\
  !*** ./components/useOutsideClick.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   useOutsideClick: () => (/* binding */ useOutsideClick)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\n/**\r\n * Check if a click was made outside the passed ref\r\n */ const useOutsideClick = (ref, callback)=>{\n    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{\n        function handleOutsideClick(event) {\n            if (!(event.target instanceof Element)) {\n                return;\n            }\n            if (ref.current && !ref.current.contains(event.target)) {\n                callback();\n            }\n        }\n        document.addEventListener(\"click\", handleOutsideClick);\n        return ()=>document.removeEventListener(\"click\", handleOutsideClick);\n    }, [\n        ref,\n        callback\n    ]);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL3VzZU91dHNpZGVDbGljay50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBeUM7QUFFekM7O0NBRUMsR0FDTSxNQUFNRSxrQkFBa0IsQ0FBQ0MsS0FBc0NDO0lBQ3BFSCxnREFBU0EsQ0FBQztRQUNSLFNBQVNJLG1CQUFtQkMsS0FBaUI7WUFDM0MsSUFBSSxDQUFFQSxDQUFBQSxNQUFNQyxNQUFNLFlBQVlDLE9BQU0sR0FBSTtnQkFDdEM7WUFDRjtZQUVBLElBQUlMLElBQUlNLE9BQU8sSUFBSSxDQUFDTixJQUFJTSxPQUFPLENBQUNDLFFBQVEsQ0FBQ0osTUFBTUMsTUFBTSxHQUFHO2dCQUN0REg7WUFDRjtRQUNGO1FBRUFPLFNBQVNDLGdCQUFnQixDQUFDLFNBQVNQO1FBQ25DLE9BQU8sSUFBTU0sU0FBU0UsbUJBQW1CLENBQUMsU0FBU1I7SUFDckQsR0FBRztRQUFDRjtRQUFLQztLQUFTO0FBQ3BCLEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9tb29kbWluZC8uL2NvbXBvbmVudHMvdXNlT3V0c2lkZUNsaWNrLnRzPzI2OWUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuLyoqXHJcbiAqIENoZWNrIGlmIGEgY2xpY2sgd2FzIG1hZGUgb3V0c2lkZSB0aGUgcGFzc2VkIHJlZlxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IHVzZU91dHNpZGVDbGljayA9IChyZWY6IFJlYWN0LlJlZk9iamVjdDxIVE1MRGl2RWxlbWVudD4sIGNhbGxiYWNrOiB7ICgpOiB2b2lkIH0pID0+IHtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZnVuY3Rpb24gaGFuZGxlT3V0c2lkZUNsaWNrKGV2ZW50OiBNb3VzZUV2ZW50KSB7XHJcbiAgICAgIGlmICghKGV2ZW50LnRhcmdldCBpbnN0YW5jZW9mIEVsZW1lbnQpKSB7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAocmVmLmN1cnJlbnQgJiYgIXJlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCkpIHtcclxuICAgICAgICBjYWxsYmFjaygpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGhhbmRsZU91dHNpZGVDbGljayk7XHJcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGhhbmRsZU91dHNpZGVDbGljayk7XHJcbiAgfSwgW3JlZiwgY2FsbGJhY2tdKTtcclxufTtcclxuIl0sIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlT3V0c2lkZUNsaWNrIiwicmVmIiwiY2FsbGJhY2siLCJoYW5kbGVPdXRzaWRlQ2xpY2siLCJldmVudCIsInRhcmdldCIsIkVsZW1lbnQiLCJjdXJyZW50IiwiY29udGFpbnMiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/useOutsideClick.ts\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tailwindcss/tailwind.css */ \"./node_modules/tailwindcss/tailwind.css\");\n/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var daisyui_dist_full_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! daisyui/dist/full.css */ \"./node_modules/daisyui/dist/full.css\");\n/* harmony import */ var daisyui_dist_full_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(daisyui_dist_full_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/components/Header */ \"./components/Header.tsx\");\n\n\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"flex flex-col min-h-screen\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Header__WEBPACK_IMPORTED_MODULE_4__.Header, {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\pages\\\\_app.tsx\",\n                lineNumber: 11,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"main\", {\n                className: \"relative flex flex-col flex-1\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\pages\\\\_app.tsx\",\n                    lineNumber: 13,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\pages\\\\_app.tsx\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\GaoTao\\\\Desktop\\\\sth good\\\\hackthon\\\\2023微众\\\\moodmind\\\\pages\\\\_app.tsx\",\n        lineNumber: 10,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUE4QjtBQUNJO0FBQ0g7QUFHYztBQUU5QixTQUFTQyxJQUFJLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFZO0lBQzVELHFCQUNFLDhEQUFDQztRQUFJQyxXQUFVOzswQkFDYiw4REFBQ0wsc0RBQU1BOzs7OzswQkFDUCw4REFBQ007Z0JBQUtELFdBQVU7MEJBQ2QsNEVBQUNIO29CQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSWhDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbW9vZG1pbmQvLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIkAvc3R5bGVzL2dsb2JhbHMuY3NzXCI7XG5pbXBvcnQgXCJ0YWlsd2luZGNzcy90YWlsd2luZC5jc3NcIjtcbmltcG9ydCBcImRhaXN5dWkvZGlzdC9mdWxsLmNzc1wiO1xuXG5pbXBvcnQgdHlwZSB7IEFwcFByb3BzIH0gZnJvbSBcIm5leHQvYXBwXCI7XG5pbXBvcnQgeyBIZWFkZXIgfSBmcm9tIFwiQC9jb21wb25lbnRzL0hlYWRlclwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtaW4taC1zY3JlZW5cIj5cbiAgICAgIDxIZWFkZXIgLz5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC1jb2wgZmxleC0xXCI+XG4gICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgIDwvbWFpbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJIZWFkZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJkaXYiLCJjbGFzc05hbWUiLCJtYWluIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/tailwindcss","vendor-chunks/daisyui"], () => (__webpack_exec__("./pages/_app.tsx")));
module.exports = __webpack_exports__;

})();