./startFarmerCC.sh
./startDriverCC.sh
./startMaterialCC.sh
./startProductInfoCC.sh
./startProductProcessCC.sh
./startRetailerCC.sh
